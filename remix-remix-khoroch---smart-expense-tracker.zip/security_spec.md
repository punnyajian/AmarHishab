# Security Specification & Test Suite

## 1. Data Invariants
1. **User Identity Invariant**: All documents under `/users/{userId}/**` must strictly belong to the authenticated user where `request.auth.uid == userId`.
2. **Payload Identity Integrity**: Any `userId` field inside document payloads must strictly match `request.auth.uid`. No user may impersonate another user or assign data to an external UID.
3. **Immutability of Key Identifiers**: Document IDs, user IDs, and creation timestamps must remain immutable across all update operations.
4. **Boundary Limits**: Numeric values for transactions, budgets, goals, and debts must be finite positive numbers within sensible limits (`amount >= 0` and `amount <= 1000000000`). String lengths must be bounded to prevent Denial-of-Wallet attacks.
5. **Sanitization of Document IDs**: Path variables must adhere to `isValidId` (`size <= 128` and matching alphanumeric/hyphen/underscore).
6. **Isolated Isolation (PII & Financial Data)**: Financial records, accounts, cards, and bazaar items can never be queried or read by any other authenticated or unauthenticated user. Blanket reads (`allow read: if isSignedIn();`) are strictly banned.

## 2. The "Dirty Dozen" Payloads (Designed to Fail)
1. **Payload 1 (Impersonation Write)**: An authenticated user `userA` attempts to write a transaction into `/users/userB/transactions/tx123`.
2. **Payload 2 (Payload Identity Mismatch)**: User `userA` creates a transaction under `/users/userA/transactions/tx1` with payload `{ "userId": "victimUser" }`.
3. **Payload 3 (Unauthenticated Read)**: An unauthenticated client attempts to read `/users/userA/transactions/tx1`.
4. **Payload 4 (Blanket Listing Attempt)**: User `userA` executes a collection group query or reads `/users/userB/transactions`.
5. **Payload 5 (Shadow Field Injection)**: User `userA` sends transaction data containing unauthorized ghost fields `{ "isAdmin": true, "superUser": true }`.
6. **Payload 6 (Oversized Payload / Resource Exhaustion)**: User `userA` attempts to submit a note or title with a 10MB string payload to induce storage exhaustion.
7. **Payload 7 (Path Traversal / Malformed Document ID)**: Malicious user sends a document ID with SQL/Script injection or path characters `/users/userA/transactions/../../../etc/passwd`.
8. **Payload 8 (Negative Financial Value)**: User submits a transaction with negative amount `{ "amount": -50000 }` to reverse balances fraudulently.
9. **Payload 9 (Tampering with Immutable ID)**: User updates a transaction attempting to mutate its `userId` from `userA` to `userB`.
10. **Payload 10 (Card CVV Leak Prevention)**: User writes unmasked card credentials or unauthorized card format.
11. **Payload 11 (Public Unauthenticated Write to Test Probe)**: Unauthenticated user attempts to overwrite `/test/connection` document.
12. **Payload 12 (Foreign Debt Settlement Tampering)**: User `userA` attempts to mark debts under `/users/userB/debts/d1` as settled.

## 3. Test Runner Specification (`firestore.rules.test.ts`)
```typescript
import { assertFails, assertSucceeds, initializeTestEnvironment } from '@firebase/rules-unit-testing';
import { readFileSync } from 'fs';

let testEnv: any;

beforeAll(async () => {
  testEnv = await initializeTestEnvironment({
    projectId: 'elegant-wave-qsmzh',
    firestore: {
      rules: readFileSync('firestore.rules', 'utf8'),
    },
  });
});

afterAll(async () => {
  await testEnv.cleanup();
});

describe('Firestore Security Rules Enforcement', () => {
  test('Reject cross-user document creation (Payload 1)', async () => {
    const userA = testEnv.authenticatedContext('userA');
    await assertFails(
      userA.firestore().doc('users/userB/transactions/tx1').set({
        id: 'tx1',
        userId: 'userB',
        type: 'expense',
        amount: 100,
        categoryId: 'cat1',
        accountId: 'acc1',
        date: '2026-10-09'
      })
    );
  });

  test('Reject userId spoofing inside payload (Payload 2)', async () => {
    const userA = testEnv.authenticatedContext('userA');
    await assertFails(
      userA.firestore().doc('users/userA/transactions/tx1').set({
        id: 'tx1',
        userId: 'victimUser',
        type: 'expense',
        amount: 100,
        categoryId: 'cat1',
        accountId: 'acc1',
        date: '2026-10-09'
      })
    );
  });

  test('Reject unauthenticated reads (Payload 3)', async () => {
    const unauth = testEnv.unauthenticatedContext();
    await assertFails(unauth.firestore().doc('users/userA/transactions/tx1').get());
  });

  test('Allow authenticated user to read and write own document', async () => {
    const userA = testEnv.authenticatedContext('userA');
    await assertSucceeds(
      userA.firestore().doc('users/userA/transactions/tx1').set({
        id: 'tx1',
        userId: 'userA',
        type: 'expense',
        amount: 100,
        categoryId: 'cat1',
        accountId: 'acc1',
        date: '2026-10-09'
      })
    );
  });
});
```
