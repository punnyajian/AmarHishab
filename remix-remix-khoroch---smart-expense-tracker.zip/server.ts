import express, { Request, Response, NextFunction } from 'express';
import { createServer as createViteServer } from 'vite';
import path from 'path';
import fs from 'fs';
import crypto from 'crypto';

interface StoredSecurityQuestion {
  id: string;
  question: string;
  answerHash: string;
}

interface StoredUser {
  id: string;
  username: string; // original case display
  usernameLower: string; // for case-insensitive lookup
  passwordHash: string;
  salt: string;
  createdAt: string;
  lastLoginAt?: string;
  failedLoginAttempts: number;
  lockedUntil?: number; // epoch ms
  securityQuestions: StoredSecurityQuestion[];
  failedRecoveryAttempts: number;
  recoveryLockedUntil?: number; // epoch ms
}

interface StoredSession {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: number; // epoch ms
}

interface StoredResetToken {
  token: string;
  userId: string;
  createdAt: string;
  expiresAt: number; // epoch ms
}

interface UserFinancialData {
  userId: string;
  lastUpdated: string;
  transactions?: any[];
  categories?: any[];
  accounts?: any[];
  budgets?: any[];
  goals?: any[];
  debts?: any[];
  subscriptions?: any[];
  digitalCards?: any[];
  bazarItems?: any[];
  messData?: any;
  investments?: any[];
  goldRates?: any[];
  trips?: any[];
  savingsChallenges?: any[];
  noSpendRecords?: any[];
  billSplits?: any[];
  wishlistItems?: any[];
  currency?: any;
  language?: any;
  safetospendConfig?: any;
  customReminders?: any[];
  paymentEngineConfig?: any;
  selectedPaymentStrategy?: any;
  customObligations?: any[];
  notificationSettings?: any;
}

interface DatabaseSchema {
  users: Record<string, StoredUser>; // keyed by userId
  usernameToId: Record<string, string>; // lowercase username -> userId
  sessions: Record<string, StoredSession>; // token -> session
  resetTokens: Record<string, StoredResetToken>; // token -> resetToken info
  userData: Record<string, UserFinancialData>; // userId -> financial bundle
}

const DATA_DIR = path.resolve(process.cwd(), '.data');
const DB_FILE = path.resolve(DATA_DIR, 'khoroch_auth_vault.json');

// Ensure storage directory and database file exist
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function loadDatabase(): DatabaseSchema {
  try {
    if (fs.existsSync(DB_FILE)) {
      const raw = fs.readFileSync(DB_FILE, 'utf-8');
      return JSON.parse(raw);
    }
  } catch (err) {
    console.error('[Vault] Error reading database file:', err);
  }
  return {
    users: {},
    usernameToId: {},
    sessions: {},
    resetTokens: {},
    userData: {},
  };
}

let dbMemory: DatabaseSchema = loadDatabase();

function saveDatabase() {
  try {
    const tempFile = `${DB_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(dbMemory, null, 2), 'utf-8');
    fs.renameSync(tempFile, DB_FILE);
  } catch (err) {
    console.error('[Vault] Error writing database file:', err);
  }
}

// Cryptographic helpers
function generateSalt(): string {
  return crypto.randomBytes(16).toString('hex');
}

function hashPassword(password: string, salt: string): string {
  return crypto.scryptSync(password, salt, 64).toString('hex');
}

function hashAnswer(answer: string, salt: string): string {
  const normalized = answer.trim().toLowerCase();
  return crypto.scryptSync(normalized, salt, 32).toString('hex');
}

function verifyPassword(password: string, salt: string, storedHash: string): boolean {
  try {
    const computedHash = hashPassword(password, salt);
    const bufA = Buffer.from(computedHash, 'hex');
    const bufB = Buffer.from(storedHash, 'hex');
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

function verifyAnswer(answer: string, salt: string, storedHash: string): boolean {
  try {
    const computedHash = hashAnswer(answer, salt);
    const bufA = Buffer.from(computedHash, 'hex');
    const bufB = Buffer.from(storedHash, 'hex');
    if (bufA.length !== bufB.length) return false;
    return crypto.timingSafeEqual(bufA, bufB);
  } catch {
    return false;
  }
}

// In-memory IP rate limiter for brute-force defense
interface RateLimitRecord {
  attempts: number;
  lastAttempt: number;
}
const ipRateLimits = new Map<string, RateLimitRecord>();

function checkIpRateLimit(ip: string, maxAttempts = 15, windowMs = 60000): boolean {
  const now = Date.now();
  const rec = ipRateLimits.get(ip);
  if (!rec || now - rec.lastAttempt > windowMs) {
    ipRateLimits.set(ip, { attempts: 1, lastAttempt: now });
    return true;
  }
  rec.attempts += 1;
  rec.lastAttempt = now;
  return rec.attempts <= maxAttempts;
}

// Validation rules
const USERNAME_REGEX = /^[a-zA-Z0-9_.-]{3,30}$/;
const MAX_PASSWORD_LENGTH = 128;

// Authentication middleware
interface AuthenticatedRequest extends Request {
  authenticatedUser?: StoredUser;
  sessionToken?: string;
}

function authenticateToken(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers['authorization'];
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'Authentication required' });
  }

  const token = authHeader.split(' ')[1];
  const session = dbMemory.sessions[token];

  if (!session) {
    return res.status(401).json({ error: 'Session expired or invalid. Please log in again.' });
  }

  if (Date.now() > session.expiresAt) {
    delete dbMemory.sessions[token];
    saveDatabase();
    return res.status(401).json({ error: 'Session expired. Please log in again.' });
  }

  const user = dbMemory.users[session.userId];
  if (!user) {
    delete dbMemory.sessions[token];
    saveDatabase();
    return res.status(401).json({ error: 'User account not found.' });
  }

  req.authenticatedUser = user;
  req.sessionToken = token;
  next();
}

async function startServer() {
  const app = express();
  const PORT = parseInt(process.env.PORT || '3000', 10);

  app.use(express.json({ limit: '50mb' }));

  // Health check
  app.get('/api/health', (_req, res) => {
    res.json({ status: 'ok', service: 'Khoroch Authentication & Sync Engine', timestamp: new Date().toISOString() });
  });

  // 1. Check Username Availability
  app.get('/api/auth/check-username', (req, res) => {
    const rawUsername = (req.query.username as string || '').trim();
    if (!rawUsername) {
      return res.status(400).json({ error: 'Username is required', available: false });
    }

    if (!USERNAME_REGEX.test(rawUsername)) {
      return res.json({
        available: false,
        reason: 'Username must be 3-30 characters long (letters, numbers, underscores, dots, or dashes).'
      });
    }

    const lower = rawUsername.toLowerCase();
    const isTaken = !!dbMemory.usernameToId[lower];

    return res.json({
      available: !isTaken,
      reason: isTaken ? 'This username is already taken. Please choose another.' : undefined
    });
  });

  // 2. Register Account
  app.post('/api/auth/register', (req, res) => {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    if (!checkIpRateLimit(clientIp)) {
      return res.status(429).json({ error: 'Too many requests. Please try again in a minute.' });
    }

    const { username, password, confirmPassword, securityQuestions } = req.body;

    // Validate username
    if (!username || typeof username !== 'string') {
      return res.status(400).json({ error: 'Username is required.' });
    }
    const trimmedUsername = username.trim();
    if (!USERNAME_REGEX.test(trimmedUsername)) {
      return res.status(400).json({
        error: 'Username must be 3-30 characters long and can only contain letters, numbers, hyphens, dots, and underscores.'
      });
    }

    const usernameLower = trimmedUsername.toLowerCase();
    if (dbMemory.usernameToId[usernameLower]) {
      return res.status(409).json({ error: 'Username is already registered. Please choose another username or log in.' });
    }

    // Validate password - accept ANY non-empty text, reject only empty or exceeding max
    if (!password || typeof password !== 'string' || password.length === 0) {
      return res.status(400).json({ error: 'Password cannot be empty.' });
    }
    if (password.length > MAX_PASSWORD_LENGTH) {
      return res.status(400).json({ error: `Password cannot exceed ${MAX_PASSWORD_LENGTH} characters.` });
    }

    if (password !== confirmPassword) {
      return res.status(400).json({ error: 'Password confirmation does not match.' });
    }

    // Validate security questions (at least 2 required)
    if (!Array.isArray(securityQuestions) || securityQuestions.length < 2) {
      return res.status(400).json({ error: 'Please set up at least two (2) security recovery questions.' });
    }

    const salt = generateSalt();
    const storedQuestions: StoredSecurityQuestion[] = [];

    for (let i = 0; i < securityQuestions.length; i++) {
      const q = securityQuestions[i];
      if (!q || !q.question || !q.question.trim() || !q.answer || !q.answer.trim()) {
        return res.status(400).json({ error: `Question #${i + 1} and its answer cannot be empty.` });
      }
      storedQuestions.push({
        id: q.id || `sq_${i + 1}`,
        question: q.question.trim(),
        answerHash: hashAnswer(q.answer, salt),
      });
    }

    const userId = `usr_${crypto.randomBytes(12).toString('hex')}`;
    const passwordHash = hashPassword(password, salt);
    const nowIso = new Date().toISOString();

    const newUser: StoredUser = {
      id: userId,
      username: trimmedUsername,
      usernameLower,
      passwordHash,
      salt,
      createdAt: nowIso,
      lastLoginAt: nowIso,
      failedLoginAttempts: 0,
      securityQuestions: storedQuestions,
      failedRecoveryAttempts: 0,
    };

    // Generate Session Token (30 days validity)
    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;

    dbMemory.users[userId] = newUser;
    dbMemory.usernameToId[usernameLower] = userId;
    dbMemory.sessions[sessionToken] = {
      token: sessionToken,
      userId,
      createdAt: nowIso,
      expiresAt,
    };

    // Initialize user cloud data bundle
    dbMemory.userData[userId] = {
      userId,
      lastUpdated: nowIso,
      transactions: [],
      accounts: [],
      categories: [],
      budgets: [],
      goals: [],
      debts: [],
      subscriptions: [],
      digitalCards: [],
      bazarItems: [],
    };

    saveDatabase();

    return res.status(201).json({
      message: 'Account created successfully!',
      session: {
        token: sessionToken,
        user: {
          id: newUser.id,
          username: newUser.username,
          createdAt: newUser.createdAt,
          lastLoginAt: newUser.lastLoginAt,
          hasSecurityQuestions: true,
        },
        expiresAt: new Date(expiresAt).toISOString(),
      },
    });
  });

  // 3. Login
  app.post('/api/auth/login', (req, res) => {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    if (!checkIpRateLimit(clientIp)) {
      return res.status(429).json({ error: 'Too many login attempts. Please wait a moment.' });
    }

    const { username, password } = req.body;

    if (!username || typeof username !== 'string' || !password || typeof password !== 'string') {
      return res.status(400).json({ error: 'Username and password are required.' });
    }

    const usernameLower = username.trim().toLowerCase();
    const userId = dbMemory.usernameToId[usernameLower];

    if (!userId || !dbMemory.users[userId]) {
      // Constant-time dummy hash to resist timing attacks
      hashPassword(password, 'dummysalt0000000000000000000000');
      return res.status(401).json({ error: 'Invalid username or password.' });
    }

    const user = dbMemory.users[userId];

    // Check account lockout
    if (user.lockedUntil && Date.now() < user.lockedUntil) {
      const waitMinutes = Math.ceil((user.lockedUntil - Date.now()) / 60000);
      return res.status(423).json({
        error: `Account is temporarily locked due to multiple failed login attempts. Please try again in ${waitMinutes} minute(s).`
      });
    }

    const isValid = verifyPassword(password, user.salt, user.passwordHash);

    if (!isValid) {
      user.failedLoginAttempts = (user.failedLoginAttempts || 0) + 1;
      if (user.failedLoginAttempts >= 5) {
        user.lockedUntil = Date.now() + 10 * 60 * 1000; // 10 minutes lockout
        saveDatabase();
        return res.status(423).json({
          error: 'Too many failed login attempts. Your account has been locked for 10 minutes for your security.'
        });
      }
      saveDatabase();
      const remainingAttempts = 5 - user.failedLoginAttempts;
      return res.status(401).json({
        error: `Invalid username or password. (${remainingAttempts} attempt${remainingAttempts === 1 ? '' : 's'} remaining)`
      });
    }

    // Login successful - Reset failed counters
    user.failedLoginAttempts = 0;
    user.lockedUntil = undefined;
    user.lastLoginAt = new Date().toISOString();

    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;

    dbMemory.sessions[sessionToken] = {
      token: sessionToken,
      userId: user.id,
      createdAt: new Date().toISOString(),
      expiresAt,
    };

    saveDatabase();

    return res.json({
      message: 'Logged in successfully!',
      session: {
        token: sessionToken,
        user: {
          id: user.id,
          username: user.username,
          createdAt: user.createdAt,
          lastLoginAt: user.lastLoginAt,
          hasSecurityQuestions: user.securityQuestions && user.securityQuestions.length > 0,
        },
        expiresAt: new Date(expiresAt).toISOString(),
      },
    });
  });

  // 4. Logout
  app.post('/api/auth/logout', (req, res) => {
    const authHeader = req.headers['authorization'];
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.split(' ')[1];
      delete dbMemory.sessions[token];
      saveDatabase();
    }
    return res.json({ message: 'Logged out successfully.' });
  });

  // 5. Get Current User Info
  app.get('/api/auth/me', authenticateToken, (req: AuthenticatedRequest, res) => {
    const user = req.authenticatedUser!;
    return res.json({
      user: {
        id: user.id,
        username: user.username,
        createdAt: user.createdAt,
        lastLoginAt: user.lastLoginAt,
        hasSecurityQuestions: user.securityQuestions && user.securityQuestions.length > 0,
      },
    });
  });

  // 6. Change Password (for authenticated users)
  app.post('/api/auth/change-password', authenticateToken, (req: AuthenticatedRequest, res) => {
    const user = req.authenticatedUser!;
    const { currentPassword, newPassword, confirmNewPassword } = req.body;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ error: 'Current password and new password are required.' });
    }

    if (!verifyPassword(currentPassword, user.salt, user.passwordHash)) {
      return res.status(401).json({ error: 'Current password is incorrect.' });
    }

    if (newPassword.length === 0 || newPassword.length > MAX_PASSWORD_LENGTH) {
      return res.status(400).json({ error: `Password must be between 1 and ${MAX_PASSWORD_LENGTH} characters.` });
    }

    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ error: 'New password confirmation does not match.' });
    }

    // Generate fresh salt and update
    user.salt = generateSalt();
    user.passwordHash = hashPassword(newPassword, user.salt);

    // Re-hash existing security questions with new salt if needed
    saveDatabase();

    return res.json({ message: 'Password updated successfully!' });
  });

  // 7. Security Question Recovery: Step 1 - Get Prompts
  app.post('/api/auth/security-questions/get', (req, res) => {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    if (!checkIpRateLimit(clientIp)) {
      return res.status(429).json({ error: 'Too many requests. Please wait a moment.' });
    }

    const { username } = req.body;
    if (!username || typeof username !== 'string') {
      return res.status(400).json({ error: 'Username is required.' });
    }

    const usernameLower = username.trim().toLowerCase();
    const userId = dbMemory.usernameToId[usernameLower];

    if (!userId || !dbMemory.users[userId]) {
      // Return safe, plausible dummy prompts so attackers cannot easily enumerate registered usernames
      return res.json({
        exists: false,
        questions: [
          { id: 'sq_1', question: 'What is the name of your first school?' },
          { id: 'sq_2', question: 'What city or town were you born in?' },
        ],
      });
    }

    const user = dbMemory.users[userId];

    if (user.recoveryLockedUntil && Date.now() < user.recoveryLockedUntil) {
      const waitMinutes = Math.ceil((user.recoveryLockedUntil - Date.now()) / 60000);
      return res.status(423).json({
        error: `Account recovery is temporarily locked due to failed attempts. Please try again in ${waitMinutes} minute(s).`,
      });
    }

    if (!user.securityQuestions || user.securityQuestions.length === 0) {
      return res.status(400).json({
        error: 'No security recovery questions have been configured for this account. Please contact system support.',
      });
    }

    // Only return question IDs and text (never the answers or hashes)
    const prompts = user.securityQuestions.map((q) => ({
      id: q.id,
      question: q.question,
    }));

    return res.json({
      exists: true,
      questions: prompts,
    });
  });

  // 8. Security Question Recovery: Step 2 - Verify Answers & Issue Reset Token
  app.post('/api/auth/security-questions/verify', (req, res) => {
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';
    if (!checkIpRateLimit(clientIp)) {
      return res.status(429).json({ error: 'Too many requests. Please wait a moment.' });
    }

    const { username, answers } = req.body;

    if (!username || !Array.isArray(answers) || answers.length === 0) {
      return res.status(400).json({ error: 'Username and answers are required.' });
    }

    const usernameLower = username.trim().toLowerCase();
    const userId = dbMemory.usernameToId[usernameLower];

    if (!userId || !dbMemory.users[userId]) {
      // Simulate verification delay
      verifyAnswer('dummy', 'dummysalt', '00');
      return res.status(400).json({ error: 'One or more security question answers are incorrect.' });
    }

    const user = dbMemory.users[userId];

    if (user.recoveryLockedUntil && Date.now() < user.recoveryLockedUntil) {
      const waitMinutes = Math.ceil((user.recoveryLockedUntil - Date.now()) / 60000);
      return res.status(423).json({
        error: `Recovery is temporarily locked. Please try again in ${waitMinutes} minute(s).`
      });
    }

    // Verify answers
    let allCorrect = true;
    for (const q of user.securityQuestions) {
      const submitted = answers.find((a: any) => a.id === q.id || a.question === q.question);
      if (!submitted || !submitted.answer || !verifyAnswer(submitted.answer, user.salt, q.answerHash)) {
        allCorrect = false;
        break;
      }
    }

    if (!allCorrect) {
      user.failedRecoveryAttempts = (user.failedRecoveryAttempts || 0) + 1;
      if (user.failedRecoveryAttempts >= 3) {
        user.recoveryLockedUntil = Date.now() + 15 * 60 * 1000; // 15 mins lock
        saveDatabase();
        return res.status(423).json({
          error: 'Too many incorrect attempts. Recovery has been temporarily locked for 15 minutes.'
        });
      }
      saveDatabase();
      const remaining = 3 - user.failedRecoveryAttempts;
      return res.status(400).json({
        error: `One or more security answers are incorrect. (${remaining} attempt${remaining === 1 ? '' : 's'} remaining)`
      });
    }

    // Verification succeeded!
    user.failedRecoveryAttempts = 0;
    user.recoveryLockedUntil = undefined;

    // Create a single-use Password Reset Token valid for 15 minutes
    const resetToken = `rst_${crypto.randomBytes(32).toString('hex')}`;
    const expiresAt = Date.now() + 15 * 60 * 1000;

    dbMemory.resetTokens[resetToken] = {
      token: resetToken,
      userId: user.id,
      createdAt: new Date().toISOString(),
      expiresAt,
    };

    saveDatabase();

    return res.json({
      message: 'Security answers verified successfully!',
      resetToken,
      expiresAt: new Date(expiresAt).toISOString(),
    });
  });

  // 9. Security Question Recovery: Step 3 - Reset Password with Token
  app.post('/api/auth/reset-password', (req, res) => {
    const { resetToken, newPassword, confirmNewPassword } = req.body;

    if (!resetToken || typeof resetToken !== 'string') {
      return res.status(400).json({ error: 'Reset token is required.' });
    }

    const tokenRecord = dbMemory.resetTokens[resetToken];
    if (!tokenRecord || Date.now() > tokenRecord.expiresAt) {
      delete dbMemory.resetTokens[resetToken];
      saveDatabase();
      return res.status(400).json({ error: 'Password reset link or token has expired. Please initiate recovery again.' });
    }

    const user = dbMemory.users[tokenRecord.userId];
    if (!user) {
      delete dbMemory.resetTokens[resetToken];
      saveDatabase();
      return res.status(400).json({ error: 'User account not found.' });
    }

    if (!newPassword || typeof newPassword !== 'string' || newPassword.length === 0) {
      return res.status(400).json({ error: 'New password cannot be empty.' });
    }
    if (newPassword.length > MAX_PASSWORD_LENGTH) {
      return res.status(400).json({ error: `Password cannot exceed ${MAX_PASSWORD_LENGTH} characters.` });
    }
    if (newPassword !== confirmNewPassword) {
      return res.status(400).json({ error: 'Passwords do not match.' });
    }

    // Consume reset token
    delete dbMemory.resetTokens[resetToken];

    // Invalidate any other prior sessions for security
    Object.keys(dbMemory.sessions).forEach((sToken) => {
      if (dbMemory.sessions[sToken].userId === user.id) {
        delete dbMemory.sessions[sToken];
      }
    });

    // Update password
    user.salt = generateSalt();
    user.passwordHash = hashPassword(newPassword, user.salt);
    user.failedLoginAttempts = 0;
    user.lockedUntil = undefined;

    // Issue fresh session for immediate seamless login
    const sessionToken = crypto.randomBytes(32).toString('hex');
    const expiresAt = Date.now() + 30 * 24 * 60 * 60 * 1000;
    dbMemory.sessions[sessionToken] = {
      token: sessionToken,
      userId: user.id,
      createdAt: new Date().toISOString(),
      expiresAt,
    };

    saveDatabase();

    return res.json({
      message: 'Password has been reset successfully!',
      session: {
        token: sessionToken,
        user: {
          id: user.id,
          username: user.username,
          createdAt: user.createdAt,
          lastLoginAt: user.lastLoginAt,
          hasSecurityQuestions: true,
        },
        expiresAt: new Date(expiresAt).toISOString(),
      },
    });
  });

  // 10. Update Security Questions
  app.post('/api/auth/update-security-questions', authenticateToken, (req: AuthenticatedRequest, res) => {
    const user = req.authenticatedUser!;
    const { questions, currentPassword } = req.body;

    if (!currentPassword || !verifyPassword(currentPassword, user.salt, user.passwordHash)) {
      return res.status(401).json({ error: 'Current password is required to update security recovery questions.' });
    }

    if (!Array.isArray(questions) || questions.length < 2) {
      return res.status(400).json({ error: 'Please configure at least two (2) security questions.' });
    }

    const storedQuestions: StoredSecurityQuestion[] = [];
    for (let i = 0; i < questions.length; i++) {
      const q = questions[i];
      if (!q || !q.question || !q.question.trim() || !q.answer || !q.answer.trim()) {
        return res.status(400).json({ error: `Question #${i + 1} and its answer cannot be empty.` });
      }
      storedQuestions.push({
        id: q.id || `sq_${i + 1}`,
        question: q.question.trim(),
        answerHash: hashAnswer(q.answer, user.salt),
      });
    }

    user.securityQuestions = storedQuestions;
    saveDatabase();

    return res.json({ message: 'Security recovery questions updated successfully!' });
  });

  // ==================== CLOUD DATA SYNCHRONIZATION API ====================

  // 11. Pull User Cloud Data
  app.get('/api/sync/pull', authenticateToken, (req: AuthenticatedRequest, res) => {
    const user = req.authenticatedUser!;
    const bundle = dbMemory.userData[user.id] || {
      userId: user.id,
      lastUpdated: new Date().toISOString(),
      transactions: [],
      accounts: [],
      categories: [],
      budgets: [],
      goals: [],
      debts: [],
      subscriptions: [],
      digitalCards: [],
      bazarItems: [],
    };

    return res.json({
      status: 'success',
      data: bundle,
    });
  });

  // 12. Push User Cloud Data
  app.post('/api/sync/push', authenticateToken, (req: AuthenticatedRequest, res) => {
    const user = req.authenticatedUser!;
    const payload = req.body || {};

    const nowIso = new Date().toISOString();
    const updatedBundle: UserFinancialData = {
      ...payload,
      userId: user.id, // Strictly isolate by authenticated user ID
      lastUpdated: nowIso,
    };

    dbMemory.userData[user.id] = updatedBundle;
    saveDatabase();

    return res.json({
      status: 'success',
      message: 'Cloud data synchronized successfully.',
      lastUpdated: nowIso,
    });
  });

  // Mount Vite middleware in development or serve static in production
  const isProduction = process.env.NODE_ENV === 'production';
  if (isProduction) {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  } else {
    const vite = await createViteServer({
      server: { middlewareMode: true, hmr: false },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Khoroch Server] Running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('[Khoroch Server] Startup failed:', err);
  process.exit(1);
});
