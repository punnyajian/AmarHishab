import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  deleteDoc,
  onSnapshot,
  writeBatch,
  Unsubscribe,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from './firebase';
import {
  Transaction,
  Category,
  Account,
  Budget,
  SavingsGoal,
  Debt,
  SubscriptionBill,
  BazarItem,
  DigitalCard,
  SafeToSpendConfig,
  Currency,
  Language,
} from '../types';

export interface UserExtraPayload {
  messData?: any;
  investments?: any[];
  trips?: any[];
  savingsChallenges?: any[];
  noSpendRecords?: any[];
  billSplits?: any[];
  wishlistItems?: any[];
  aiMemory?: any;
  aiActivityLogs?: any[];
  goldRates?: any[];
}

export interface UserCloudState {
  transactions: Transaction[];
  categories: Category[];
  accounts: Account[];
  budgets: Budget[];
  goals: SavingsGoal[];
  debts: Debt[];
  subscriptions: SubscriptionBill[];
  bazarItems: BazarItem[];
  digitalCards: DigitalCard[];
  currency?: Currency;
  language?: Language;
  safeToSpendConfig?: SafeToSpendConfig;
  extra?: UserExtraPayload;
}

// Ensure user profile document exists
export async function ensureUserProfile(userId: string, email: string, displayName?: string, photoURL?: string) {
  const path = `users/${userId}`;
  try {
    const userDocRef = doc(db, 'users', userId);
    await setDoc(
      userDocRef,
      {
        userId,
        email: email || '',
        displayName: displayName || '',
        photoURL: photoURL || '',
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Fetch complete cloud state for a user on login
export async function fetchUserCloudData(userId: string): Promise<UserCloudState> {
  const basePath = `users/${userId}`;

  try {
    // 1. Transactions
    const txSnap = await getDocs(collection(db, basePath, 'transactions')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/transactions`)
    );
    const transactions = txSnap.docs.map((d) => d.data() as Transaction);

    // 2. Accounts
    const accSnap = await getDocs(collection(db, basePath, 'accounts')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/accounts`)
    );
    const accounts = accSnap.docs.map((d) => d.data() as Account);

    // 3. Categories
    const catSnap = await getDocs(collection(db, basePath, 'categories')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/categories`)
    );
    const categories = catSnap.docs.map((d) => d.data() as Category);

    // 4. Budgets
    const budgetSnap = await getDocs(collection(db, basePath, 'budgets')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/budgets`)
    );
    const budgets = budgetSnap.docs.map((d) => d.data() as Budget);

    // 5. Goals
    const goalSnap = await getDocs(collection(db, basePath, 'goals')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/goals`)
    );
    const goals = goalSnap.docs.map((d) => d.data() as SavingsGoal);

    // 6. Debts
    const debtSnap = await getDocs(collection(db, basePath, 'debts')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/debts`)
    );
    const debts = debtSnap.docs.map((d) => d.data() as Debt);

    // 7. Subscriptions
    const subSnap = await getDocs(collection(db, basePath, 'subscriptions')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/subscriptions`)
    );
    const subscriptions = subSnap.docs.map((d) => d.data() as SubscriptionBill);

    // 8. Bazar
    const bazarSnap = await getDocs(collection(db, basePath, 'bazarItems')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/bazarItems`)
    );
    const bazarItems = bazarSnap.docs.map((d) => d.data() as BazarItem);

    // 9. Cards
    const cardSnap = await getDocs(collection(db, basePath, 'cards')).catch((err) =>
      handleFirestoreError(err, OperationType.LIST, `${basePath}/cards`)
    );
    const digitalCards = cardSnap.docs.map((d) => d.data() as DigitalCard);

    // 10. Settings
    let currency: Currency | undefined;
    let language: Language | undefined;
    let safeToSpendConfig: SafeToSpendConfig | undefined;
    try {
      const settingsDoc = await getDoc(doc(db, basePath, 'settings', 'preferences'));
      if (settingsDoc.exists()) {
        const sData = settingsDoc.data();
        if (sData.language) language = sData.language as Language;
        if (sData.safeToSpendMode) {
          safeToSpendConfig = {
            mode: sData.safeToSpendMode,
            customMonthlyCap: sData.safeToSpendCap,
          };
        }
      }
    } catch {
      // Continue gracefully
    }

    // 11. Extra
    let extra: UserExtraPayload | undefined;
    try {
      const extraDoc = await getDoc(doc(db, basePath, 'extra', 'main'));
      if (extraDoc.exists()) {
        const eData = extraDoc.data();
        if (eData.extraJson) {
          extra = JSON.parse(eData.extraJson);
        }
      }
    } catch {
      // Continue gracefully
    }

    return {
      transactions,
      accounts,
      categories,
      budgets,
      goals,
      debts,
      subscriptions,
      bazarItems,
      digitalCards,
      currency,
      language,
      safeToSpendConfig,
      extra,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, basePath);
  }
}

// Single-item sync operations
export async function syncSaveTransaction(userId: string, tx: Transaction) {
  const path = `users/${userId}/transactions/${tx.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'transactions', tx.id), {
      ...tx,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteTransaction(userId: string, txId: string) {
  const path = `users/${userId}/transactions/${txId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'transactions', txId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveAccount(userId: string, acc: Account) {
  const path = `users/${userId}/accounts/${acc.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'accounts', acc.id), {
      ...acc,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteAccount(userId: string, accId: string) {
  const path = `users/${userId}/accounts/${accId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'accounts', accId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveCategory(userId: string, cat: Category) {
  const path = `users/${userId}/categories/${cat.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'categories', cat.id), {
      ...cat,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncSaveBudget(userId: string, b: Budget) {
  const path = `users/${userId}/budgets/${b.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'budgets', b.id), {
      ...b,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteBudget(userId: string, budgetId: string) {
  const path = `users/${userId}/budgets/${budgetId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'budgets', budgetId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveGoal(userId: string, g: SavingsGoal) {
  const path = `users/${userId}/goals/${g.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'goals', g.id), {
      ...g,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteGoal(userId: string, goalId: string) {
  const path = `users/${userId}/goals/${goalId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'goals', goalId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveDebt(userId: string, d: Debt) {
  const path = `users/${userId}/debts/${d.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'debts', d.id), {
      ...d,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteDebt(userId: string, debtId: string) {
  const path = `users/${userId}/debts/${debtId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'debts', debtId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveSubscription(userId: string, s: SubscriptionBill) {
  const path = `users/${userId}/subscriptions/${s.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'subscriptions', s.id), {
      ...s,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteSubscription(userId: string, subId: string) {
  const path = `users/${userId}/subscriptions/${subId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'subscriptions', subId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveBazarItem(userId: string, item: BazarItem) {
  const path = `users/${userId}/bazarItems/${item.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'bazarItems', item.id), {
      ...item,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteBazarItem(userId: string, itemId: string) {
  const path = `users/${userId}/bazarItems/${itemId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'bazarItems', itemId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveCard(userId: string, card: DigitalCard) {
  const path = `users/${userId}/cards/${card.id}`;
  try {
    await setDoc(doc(db, 'users', userId, 'cards', card.id), {
      ...card,
      userId,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncDeleteCard(userId: string, cardId: string) {
  const path = `users/${userId}/cards/${cardId}`;
  try {
    await deleteDoc(doc(db, 'users', userId, 'cards', cardId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export async function syncSaveSettings(userId: string, currencyCode: string, language: string, cap?: number, mode?: string) {
  const path = `users/${userId}/settings/preferences`;
  try {
    await setDoc(
      doc(db, 'users', userId, 'settings', 'preferences'),
      {
        userId,
        currencyCode,
        language,
        safeToSpendCap: cap ?? 0,
        safeToSpendMode: mode ?? 'budget',
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function syncSaveExtra(userId: string, payload: UserExtraPayload) {
  const path = `users/${userId}/extra/main`;
  try {
    const jsonStr = JSON.stringify(payload);
    await setDoc(
      doc(db, 'users', userId, 'extra', 'main'),
      {
        userId,
        extraJson: jsonStr,
        updatedAt: new Date().toISOString(),
      },
      { merge: true }
    );
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

// Bulk migration helper for first-time cloud synchronization
export async function uploadLocalDataToCloud(
  userId: string,
  state: {
    transactions: Transaction[];
    accounts: Account[];
    categories: Category[];
    budgets: Budget[];
    goals: SavingsGoal[];
    debts: Debt[];
    subscriptions: SubscriptionBill[];
    bazarItems: BazarItem[];
    digitalCards: DigitalCard[];
    extra: UserExtraPayload;
  }
) {
  const batch = writeBatch(db);

  // Accounts
  state.accounts.forEach((acc) => {
    batch.set(doc(db, 'users', userId, 'accounts', acc.id), {
      ...acc,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Categories
  state.categories.forEach((cat) => {
    batch.set(doc(db, 'users', userId, 'categories', cat.id), {
      ...cat,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Transactions (up to batch limits)
  state.transactions.slice(0, 450).forEach((tx) => {
    batch.set(doc(db, 'users', userId, 'transactions', tx.id), {
      ...tx,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Budgets
  state.budgets.forEach((b) => {
    batch.set(doc(db, 'users', userId, 'budgets', b.id), {
      ...b,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Goals
  state.goals.forEach((g) => {
    batch.set(doc(db, 'users', userId, 'goals', g.id), {
      ...g,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Debts
  state.debts.forEach((d) => {
    batch.set(doc(db, 'users', userId, 'debts', d.id), {
      ...d,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Subscriptions
  state.subscriptions.forEach((s) => {
    batch.set(doc(db, 'users', userId, 'subscriptions', s.id), {
      ...s,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Bazar
  state.bazarItems.forEach((b) => {
    batch.set(doc(db, 'users', userId, 'bazarItems', b.id), {
      ...b,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Cards
  state.digitalCards.forEach((c) => {
    batch.set(doc(db, 'users', userId, 'cards', c.id), {
      ...c,
      userId,
      updatedAt: new Date().toISOString(),
    });
  });

  // Extra
  batch.set(doc(db, 'users', userId, 'extra', 'main'), {
    userId,
    extraJson: JSON.stringify(state.extra),
    updatedAt: new Date().toISOString(),
  });

  await batch.commit();
}
