// Smart Payment Priority Engine — Core Deterministic Calculation Engine
// Compliant with Financial Safety Rules, Multi-Currency Conversion, and Transparent Scoring

import {
  PaymentObligation,
  RankedObligation,
  PriorityScoreBreakdown,
  PaymentEngineConfig,
  CashFlowAnalysis,
  PaymentStrategyType,
  WhatIfSimulationInput,
  WhatIfSimulationResult,
  CustomObligationInput,
  ConsequenceSeverity,
  PriorityLevel,
} from '../types/paymentPriority';
import {
  SubscriptionBill,
  Debt,
  DigitalCard,
  Account,
  Transaction,
  InvestmentItem,
  Currency,
} from '../types';
import { convertCurrency, formatCurrencyAmount } from '../utils/currencyUtils';

export const DEFAULT_PRIORITY_CONFIG: PaymentEngineConfig = {
  weights: {
    urgency: 25,
    overdue: 15,
    penalty: 20,
    interest: 15,
    consequence: 15,
    essential: 10,
  },
  thresholds: {
    critical: 85,
    high: 65,
    medium: 40,
  },
  essentialLivingReserve: 3000, // ৳3,000 baseline reserve for food/medicine
  advanceReminderDays: 3,
  creditCardMinRatePercent: 5, // 5% minimum payment
  creditCardMinMinimumBDT: 500, // ৳500 minimum floor
};

/**
 * Extracts and consolidates all unpaid obligations from bills, debts, credit cards, investments, and custom entries.
 * Converts all amounts to the active user currency deterministically.
 */
export function extractAllObligations(params: {
  subscriptions: SubscriptionBill[];
  debts: Debt[];
  digitalCards: DigitalCard[];
  investments: InvestmentItem[];
  customObligations: CustomObligationInput[];
  transactions: Transaction[];
  activeCurrency: Currency;
  config: PaymentEngineConfig;
}): PaymentObligation[] {
  const {
    subscriptions,
    debts,
    digitalCards,
    investments,
    customObligations,
    transactions,
    activeCurrency,
    config,
  } = params;

  const obligations: PaymentObligation[] = [];
  const today = new Date();
  const todayStr = today.toISOString().slice(0, 10);
  const todayTime = new Date(todayStr).getTime();
  const activeCode = activeCurrency.code;

  // Helper to calculate days remaining
  const getDaysDiff = (dateStr: string): { days: number; isOverdue: boolean; overdueDays: number } => {
    if (!dateStr) return { days: 999, isOverdue: false, overdueDays: 0 };
    const dueTime = new Date(dateStr).getTime();
    const diff = Math.round((dueTime - todayTime) / 86400000);
    return {
      days: diff,
      isOverdue: diff < 0,
      overdueDays: diff < 0 ? Math.abs(diff) : 0,
    };
  };

  // Helper: check if a bill was already paid in recent transactions or bill's lastPaidDate
  const isBillPaidThisCycle = (sub: SubscriptionBill): boolean => {
    if (sub.status === 'paused' || sub.status === 'cancelled') return true;
    if (sub.lastPaidDate) {
      // If paid within current month or cycle
      const currentMonth = todayStr.slice(0, 7);
      if (sub.lastPaidDate.startsWith(currentMonth)) return true;
    }
    // Check if recorded in transactions for this bill name within last 25 days
    const matchedTx = transactions.some(
      (tx) =>
        tx.type === 'expense' &&
        tx.date >= todayStr.slice(0, 7) + '-01' &&
        tx.note.toLowerCase().includes(sub.name.toLowerCase())
    );
    return matchedTx;
  };

  // 1. Subscriptions & Bills
  subscriptions.forEach((sub) => {
    if (isBillPaidThisCycle(sub)) return;

    const { days, isOverdue, overdueDays } = getDaysDiff(sub.dueDate);
    const amountInActive = convertCurrency(sub.amount, 'BDT', activeCode);

    // Determine essentiality & consequence based on category
    let isEssential = false;
    let consequence: ConsequenceSeverity = 'service_interruption';
    let consequenceDesc = 'Service temporarily suspended until payment.';
    let consequenceDescBn = 'পরিশোধ না করলে পরিষেবা সাময়িকভাবে স্থগিত হতে পারে।';
    let lateFeeAmount: number | null = null;
    let lateFeePct: number | null = null;
    const missingFlags: string[] = [];

    switch (sub.category) {
      case 'utility':
        isEssential = true;
        consequence = 'disconnection';
        consequenceDesc = 'Risk of electricity/gas/water line disconnection & reconnection fee.';
        consequenceDescBn = 'বিদ্যুৎ/গ্যাস/পানি সংযোগ বিচ্ছিন্ন হওয়ার মারাত্মক ঝুঁকি ও রি-কানেকশন জরিমানা।';
        lateFeePct = 5; // e.g., standard 5% utility surcharge
        lateFeeAmount = Math.round(amountInActive * 0.05);
        break;
      case 'rent':
        isEssential = true;
        consequence = 'legal_contractual';
        consequenceDesc = 'Breach of lease agreement, landlord conflict, or late penalty.';
        consequenceDescBn = 'বাসা ভাড়ার চুক্তি লঙ্ঘন, নোটিশ বা বাড়িওয়ালার সাথে বিরোধের ঝুঁকি।';
        break;
      case 'internet':
      case 'mobile':
        isEssential = true;
        consequence = 'service_interruption';
        consequenceDesc = 'Line blocked, broadband disconnected, or communication loss.';
        consequenceDescBn = 'ইন্টারনেট বা মোবাইল লাইন বন্ধ হয়ে গুরুত্বপূর্ণ যোগাযোগ ব্যাহত হবে।';
        lateFeeAmount = 50;
        break;
      case 'insurance':
        isEssential = true;
        consequence = 'legal_contractual';
        consequenceDesc = 'Lapse of insurance coverage leaving health/family unprotected.';
        consequenceDescBn = 'পলিসি বাতিল হয়ে গেলে জরুরি চিকিৎসায় কোনো সুরক্ষা পাওয়া যাবে না।';
        break;
      case 'education':
        isEssential = true;
        consequence = 'financial_penalty';
        consequenceDesc = 'Late exam registration fee or exam eligibility block.';
        consequenceDescBn = 'পরীক্ষায় অংশগ্রহণে বাধা বা জরিমানা ফি প্রযোজ্য হতে পারে।';
        break;
      case 'streaming':
      case 'software':
      case 'fitness':
      default:
        isEssential = false;
        consequence = 'mild';
        consequenceDesc = 'Subscription will pause automatically; no legal or life impact.';
        consequenceDescBn = 'সাবস্ক্রিপশন স্বয়ংক্রিয়ভাবে স্থগিত হবে, কোনো আইনি বা জীবনের ক্ষতি নেই।';
        break;
    }

    if (lateFeeAmount === null && lateFeePct === null) {
      missingFlags.push('unknown_late_fee');
    }

    obligations.push({
      id: `sub-${sub.id}`,
      sourceType: 'bill',
      sourceId: sub.id,
      name: sub.name,
      nameBn: sub.nameBn || sub.name,
      category: sub.category,
      categoryBn: sub.category === 'utility' ? 'বিদ্যুৎ ও পানি' : sub.category === 'rent' ? 'বাসা ভাড়া' : sub.category === 'internet' ? 'ইন্টারনেট' : sub.category,
      amount: sub.amount,
      currencyCode: 'BDT',
      amountConverted: amountInActive,
      dueDate: sub.dueDate,
      daysRemaining: days,
      isOverdue,
      overdueDays,
      isPartiallyPaid: false,
      paidAmount: 0,
      remainingAmount: amountInActive,
      minimumAmountDue: amountInActive,
      lateFeeAmount,
      lateFeePercentage: lateFeePct,
      hasLateFee: lateFeeAmount !== null || lateFeePct !== null,
      interestRateAPR: null,
      consequenceSeverity: consequence,
      consequenceDesc,
      consequenceDescBn,
      isEssential,
      isMandatoryMinimum: isEssential || sub.category === 'utility' || sub.category === 'rent',
      notes: sub.notes,
      linkedAccountId: sub.accountId,
      linkedCardId: sub.cardId,
      subscriberId: sub.subscriberIdOrMeterNo,
      providerName: sub.providerName,
      missingInfoFlags: missingFlags,
      status: 'unpaid',
      createdAt: sub.createdAt || todayStr,
    });
  });

  // 2. Debts / Borrowed Money / Loans
  debts.forEach((debt) => {
    if (debt.type !== 'borrowed' || debt.settled) return;
    const unpaid = debt.amount - (debt.paidAmount || 0);
    if (unpaid <= 0) return;

    const { days, isOverdue, overdueDays } = getDaysDiff(debt.dueDate);
    const unpaidInActive = convertCurrency(unpaid, 'BDT', activeCode);

    // Differentiate between formal bank loan / cooperative vs personal debt
    const isBankLoan =
      debt.note?.toLowerCase().includes('loan') ||
      debt.note?.toLowerCase().includes('bank') ||
      debt.note?.toLowerCase().includes('emi') ||
      debt.personName.toLowerCase().includes('bank');

    const consequence: ConsequenceSeverity = isBankLoan ? 'legal_contractual' : 'mild';
    const consequenceDesc = isBankLoan
      ? 'Default recorded on CIB report, penalty interest & legal notice.'
      : 'Personal trust and relationship impact with the lender.';
    const consequenceDescBn = isBankLoan
      ? 'ব্যাংক সিআইবি রিপোর্টে খেলাপি হওয়ার ঝুঁকি ও অতিরিক্ত সুদ/নোটিশ।'
      : 'ব্যক্তিগত বিশ্বাস ও সুসম্পর্ক ক্ষুণ্ণ হওয়ার ঝুঁকি।';

    const missingFlags: string[] = [];
    if (!debt.note?.includes('%')) {
      missingFlags.push('unknown_interest_rate');
    }

    obligations.push({
      id: `debt-${debt.id}`,
      sourceType: isBankLoan ? 'emi_loan' : 'debt_borrowed',
      sourceId: debt.id,
      name: `${isBankLoan ? 'ঋণের কিস্তি' : 'ধার পরিশোধ'}: ${debt.personName}`,
      nameBn: `${isBankLoan ? 'ঋণের কিস্তি' : 'ধার পরিশোধ'}: ${debt.personName}`,
      category: isBankLoan ? 'loan' : 'debt',
      categoryBn: isBankLoan ? 'ব্যাংক ঋণ ও ইএমআই' : 'ব্যক্তিগত ধারদেনা',
      amount: unpaid,
      currencyCode: 'BDT',
      amountConverted: unpaidInActive,
      dueDate: debt.dueDate,
      daysRemaining: days,
      isOverdue,
      overdueDays,
      isPartiallyPaid: (debt.paidAmount || 0) > 0,
      paidAmount: convertCurrency(debt.paidAmount || 0, 'BDT', activeCode),
      remainingAmount: unpaidInActive,
      minimumAmountDue: isBankLoan ? unpaidInActive : Math.min(unpaidInActive, 1000),
      lateFeeAmount: isBankLoan ? 300 : null,
      lateFeePercentage: isBankLoan ? 2 : null,
      hasLateFee: isBankLoan,
      interestRateAPR: isBankLoan ? 12 : null, // Default 12% for loans if specified
      consequenceSeverity: consequence,
      consequenceDesc,
      consequenceDescBn,
      isEssential: false,
      isMandatoryMinimum: isBankLoan,
      notes: debt.note,
      recipientPhone: debt.phone,
      missingInfoFlags: missingFlags,
      status: 'unpaid',
      createdAt: debt.createdAt || todayStr,
    });
  });

  // 3. Credit Cards — Separate Minimum Payment from Remaining Balance
  digitalCards.forEach((card) => {
    if (card.type !== 'credit') return;
    const spent = card.currentSpentThisMonth || 0;
    if (spent <= 0) return;

    const spentInActive = convertCurrency(spent, 'BDT', activeCode);

    // Calculate due date based on billing cycle day
    // Typical credit card grace period: 15-20 days after cycle day
    const cycleDay = card.billingCycleDay || 15;
    const dueDay = (cycleDay + 15) % 28 || 28;
    const currentYear = today.getFullYear();
    const currentMonth = today.getMonth();
    const dueDateObj = new Date(currentYear, currentMonth, dueDay);
    if (dueDateObj.getTime() < todayTime - 86400000 * 5) {
      // Due in next month
      dueDateObj.setMonth(dueDateObj.getMonth() + 1);
    }
    const dueDateStr = dueDateObj.toISOString().slice(0, 10);
    const { days, isOverdue, overdueDays } = getDaysDiff(dueDateStr);

    // Minimum Payment calculation: 5% of balance or ৳500 minimum floor
    const minCalculated = Math.max(
      spentInActive * (config.creditCardMinRatePercent / 100),
      config.creditCardMinMinimumBDT
    );
    const minDue = Math.min(minCalculated, spentInActive);
    const remainingAfterMin = spentInActive - minDue;

    // A. Minimum Payment Obligation (High Urgency / Mandatory)
    obligations.push({
      id: `card-min-${card.id}`,
      sourceType: 'credit_card_min',
      sourceId: card.id,
      name: `${card.issuerName} — Minimum Payment (বাধ্যতামূলক ন্যূনতম)`,
      nameBn: `${card.issuerName} — ন্যূনতম পরিশোধ (Min Due)`,
      category: 'credit_card',
      categoryBn: 'ক্রেডিট কার্ড ন্যূনতম',
      amount: minDue,
      currencyCode: activeCode,
      amountConverted: minDue,
      dueDate: dueDateStr,
      daysRemaining: days,
      isOverdue,
      overdueDays,
      isPartiallyPaid: false,
      paidAmount: 0,
      remainingAmount: minDue,
      minimumAmountDue: minDue,
      lateFeeAmount: 500, // Standard late fee for missing min payment
      lateFeePercentage: null,
      hasLateFee: true,
      interestRateAPR: 24, // 24% standard annual APR
      consequenceSeverity: 'credit_damage',
      consequenceDesc:
        'Missing minimum payment immediately incurs ৳500 late fee, cancels 45-day interest-free period, and damages credit score.',
      consequenceDescBn:
        'ন্যূনতম পরিশোধ মিস করলে সাথে সাথে বিলম্ব ফি (৳৫০০) যোগ হবে, সুদমুক্ত মেয়াদ বাতিল হবে এবং ক্রেডিট স্কোর ক্ষতিগ্রস্ত হবে।',
      isEssential: false,
      isMandatoryMinimum: true,
      notes: `Card: ${card.cardNumberMasked}. Limit: ${card.creditLimit || 'N/A'}`,
      linkedCardId: card.id,
      missingInfoFlags: [],
      status: 'unpaid',
      createdAt: todayStr,
    });

    // B. Full Outstanding Balance above Minimum (Optional / Lower Priority if cash is tight)
    if (remainingAfterMin > 0) {
      obligations.push({
        id: `card-full-${card.id}`,
        sourceType: 'credit_card_full',
        sourceId: card.id,
        name: `${card.issuerName} — Remaining Balance (বাকি ব্যালেন্স)`,
        nameBn: `${card.issuerName} — বাকি ব্যালেন্স (Remaining)`,
        category: 'credit_card',
        categoryBn: 'ক্রেডিট কার্ড বাকি ব্যালেন্স',
        amount: remainingAfterMin,
        currencyCode: activeCode,
        amountConverted: remainingAfterMin,
        dueDate: dueDateStr,
        daysRemaining: days,
        isOverdue,
        overdueDays,
        isPartiallyPaid: false,
        paidAmount: 0,
        remainingAmount: remainingAfterMin,
        minimumAmountDue: 0,
        lateFeeAmount: null,
        lateFeePercentage: null,
        hasLateFee: false,
        interestRateAPR: 24, // High APR accrual on unpaid balance
        consequenceSeverity: 'financial_penalty',
        consequenceDesc:
          'Paying only the minimum avoids late fees but incurs 2% monthly interest (24% APR) on this remaining balance.',
        consequenceDescBn:
          'ন্যূনতম দিলে জরিমানা এড়ানো যাবে, তবে বাকি টাকার উপর মাসিক ২% (বার্ষিক ২৪%) চক্রবৃদ্ধি সুদ প্রযোজ্য হবে।',
        isEssential: false,
        isMandatoryMinimum: false,
        notes: `Total bill: ${formatCurrencyAmount(spentInActive, activeCurrency.symbol)}. If cash is tight, paying minimum protects your credit score.`,
        linkedCardId: card.id,
        missingInfoFlags: [],
        status: 'unpaid',
        createdAt: todayStr,
      });
    }
  });

  // 4. DPS / Sanchayapatra Installments
  investments.forEach((inv) => {
    if (inv.type !== 'dps' || inv.status !== 'active') return;
    const monthlyInstallment = inv.monthlyInstallment || 0;
    if (monthlyInstallment <= 0) return;

    // Due date from nextInstallmentDueDate or default to 10th of current month
    const currentMonth = todayStr.slice(0, 7);
    const dueDateStr = inv.nextInstallmentDueDate || `${currentMonth}-10`;
    const { days, isOverdue, overdueDays } = getDaysDiff(dueDateStr);
    const installmentInActive = convertCurrency(monthlyInstallment, 'BDT', activeCode);

    obligations.push({
      id: `dps-${inv.id}`,
      sourceType: 'dps_installment',
      sourceId: inv.id,
      name: `DPS কিস্তি: ${inv.title}`,
      nameBn: `ডিপিএস কিস্তি: ${inv.title}`,
      category: 'dps',
      categoryBn: 'ডিপিএস সঞ্চয় কিস্তি',
      amount: monthlyInstallment,
      currencyCode: 'BDT',
      amountConverted: installmentInActive,
      dueDate: dueDateStr,
      daysRemaining: days,
      isOverdue,
      overdueDays,
      isPartiallyPaid: false,
      paidAmount: 0,
      remainingAmount: installmentInActive,
      minimumAmountDue: installmentInActive,
      lateFeeAmount: 50,
      lateFeePercentage: null,
      hasLateFee: true,
      interestRateAPR: null,
      consequenceSeverity: 'financial_penalty',
      consequenceDesc: 'Bank charges late fine per delayed month; continuous delay may cancel scheme.',
      consequenceDescBn: 'দেরিতে দিলে ব্যাংক বিলম্ব ফি কাটবে; টানা ৩ মাস মিস করলে ডিপিএস বন্ধ হতে পারে।',
      isEssential: false,
      isMandatoryMinimum: true,
      notes: `Maturity: ${inv.maturityAmount ? formatCurrencyAmount(inv.maturityAmount, activeCurrency.symbol) : 'N/A'}`,
      missingInfoFlags: [],
      status: 'unpaid',
      createdAt: inv.startDate || todayStr,
    });
  });

  // 5. Custom Obligations added by User
  customObligations.forEach((custom, idx) => {
    const { days, isOverdue, overdueDays } = getDaysDiff(custom.dueDate);
    const amountInActive = convertCurrency(custom.amount, custom.currencyCode || 'BDT', activeCode);
    const minDue = custom.minimumAmountDue
      ? convertCurrency(custom.minimumAmountDue, custom.currencyCode || 'BDT', activeCode)
      : amountInActive;

    obligations.push({
      id: `custom-${idx}-${custom.name.replace(/\s+/g, '-').toLowerCase()}`,
      sourceType: 'custom',
      sourceId: `custom-${idx}`,
      name: custom.name,
      nameBn: custom.nameBn || custom.name,
      category: custom.category,
      categoryBn: custom.category,
      amount: custom.amount,
      currencyCode: custom.currencyCode || 'BDT',
      amountConverted: amountInActive,
      dueDate: custom.dueDate,
      daysRemaining: days,
      isOverdue,
      overdueDays,
      isPartiallyPaid: false,
      paidAmount: 0,
      remainingAmount: amountInActive,
      minimumAmountDue: minDue,
      lateFeeAmount: custom.lateFeeAmount || null,
      lateFeePercentage: null,
      hasLateFee: !!custom.lateFeeAmount,
      interestRateAPR: custom.interestRateAPR || null,
      consequenceSeverity: custom.consequenceSeverity,
      consequenceDesc: custom.notes || 'User defined obligation.',
      consequenceDescBn: custom.notes || 'ব্যবহারকারী নির্ধারিত আর্থিক দায়।',
      isEssential: custom.isEssential,
      isMandatoryMinimum: custom.isEssential || minDue > 0,
      notes: custom.notes,
      recipientPhone: custom.recipientPhone,
      missingInfoFlags: [],
      status: 'unpaid',
      createdAt: todayStr,
    });
  });

  return obligations;
}

/**
 * Calculates priority score (0-100) using 8 dimensions + hard safety overrides.
 */
export function calculatePriorityScore(
  obligation: PaymentObligation,
  availableBalance: number,
  config: PaymentEngineConfig
): PriorityScoreBreakdown {
  const { weights, thresholds } = config;
  const assumptions: string[] = [];

  // A. Due-date urgency score (0 - 100)
  let urgencyScore = 0;
  if (obligation.isOverdue) {
    urgencyScore = 100;
  } else if (obligation.daysRemaining === 0) {
    urgencyScore = 95;
  } else if (obligation.daysRemaining === 1) {
    urgencyScore = 90;
  } else if (obligation.daysRemaining <= 3) {
    urgencyScore = 75;
  } else if (obligation.daysRemaining <= 7) {
    urgencyScore = 55;
  } else if (obligation.daysRemaining <= 14) {
    urgencyScore = 35;
  } else {
    urgencyScore = 15;
  }

  // B. Overdue duration score (0 - 100)
  let overdueScore = 0;
  if (obligation.isOverdue) {
    if (obligation.overdueDays >= 14) overdueScore = 100;
    else if (obligation.overdueDays >= 7) overdueScore = 85;
    else if (obligation.overdueDays >= 3) overdueScore = 70;
    else overdueScore = 55;
  }

  // C. Late fees and penalties score (0 - 100)
  let penaltyScore = 0;
  if (obligation.hasLateFee) {
    if (obligation.lateFeeAmount && obligation.lateFeeAmount >= 500) penaltyScore = 100;
    else if (obligation.lateFeeAmount && obligation.lateFeeAmount >= 200) penaltyScore = 80;
    else if (obligation.lateFeePercentage && obligation.lateFeePercentage >= 5) penaltyScore = 85;
    else penaltyScore = 60;
  } else if (obligation.missingInfoFlags.includes('unknown_late_fee')) {
    penaltyScore = 15;
    assumptions.push('Late fee unspecified; assumed minimal penalty.');
  }

  // D. Additional interest / financial cost (0 - 100)
  let interestScore = 0;
  if (obligation.interestRateAPR && obligation.interestRateAPR > 0) {
    if (obligation.interestRateAPR >= 20) interestScore = 95; // e.g. credit card 24%
    else if (obligation.interestRateAPR >= 12) interestScore = 75;
    else if (obligation.interestRateAPR >= 6) interestScore = 50;
    else interestScore = 30;
  } else if (obligation.missingInfoFlags.includes('unknown_interest_rate')) {
    interestScore = 10;
    assumptions.push('Interest rate unknown; assumed 0% additional cost.');
  }

  // E. Consequences severity score (0 - 100)
  let consequenceScore = 20;
  switch (obligation.consequenceSeverity) {
    case 'disconnection':
      consequenceScore = 100; // Electricity, water, gas cutoff
      break;
    case 'legal_contractual':
      consequenceScore = 90; // Lease, legal debt, bank loan
      break;
    case 'credit_damage':
      consequenceScore = 85; // Credit card default, CIB hit
      break;
    case 'service_interruption':
      consequenceScore = 65; // Internet, mobile
      break;
    case 'financial_penalty':
      consequenceScore = 50;
      break;
    case 'mild':
      consequenceScore = 20;
      break;
    case 'uncertain':
    default:
      consequenceScore = 25;
      break;
  }

  // F. Essential-service importance score (0 - 100)
  const essentialScore = obligation.isEssential ? 100 : 25;

  // G. Cash buffer score (0 - 100)
  let cashBufferScore = 30;
  if (obligation.amountConverted > availableBalance) {
    cashBufferScore = 80; // High competition for scarce cash
  }

  // Calculate weighted baseline score
  const totalWeight =
    weights.urgency +
    weights.overdue +
    weights.penalty +
    weights.interest +
    weights.consequence +
    weights.essential;

  const rawScore =
    (urgencyScore * weights.urgency +
      overdueScore * weights.overdue +
      penaltyScore * weights.penalty +
      interestScore * weights.interest +
      consequenceScore * weights.consequence +
      essentialScore * weights.essential) /
    (totalWeight || 100);

  let finalScore = Math.round(rawScore);
  let hardOverrideApplied = false;
  let overrideReason: string | null = null;
  let overrideReasonBn: string | null = null;

  // HARD SAFETY OVERRIDES:
  // 1. Overdue Essential Bills (Electricity, Water, Gas, Rent)
  if (obligation.isOverdue && obligation.isEssential) {
    finalScore = Math.max(finalScore, 96);
    hardOverrideApplied = true;
    overrideReason = 'Hard Override: Overdue essential service risking immediate disconnection or eviction.';
    overrideReasonBn = 'কঠোর নিয়ম প্রয়োগ: বকেয়া জরুরি পরিষেবা বিচ্ছিন্ন হওয়া বা বাসা ভাড়ার আইনি ঝুঁকি এড়াতে সর্বোচ্চ অগ্রাধিকার।';
  }

  // 2. Imminent Mandatory Minimum Payment (Due within 24 hours)
  if (obligation.isMandatoryMinimum && obligation.daysRemaining <= 1) {
    finalScore = Math.max(finalScore, 90);
    hardOverrideApplied = true;
    overrideReason = 'Hard Override: Mandatory minimum payment due within 24 hours to prevent account default.';
    overrideReasonBn = 'কঠোর নিয়ম প্রয়োগ: অ্যাকাউন্ট সচল রাখতে ও জরিমানা এড়াতে ২৪ ঘণ্টার মধ্যে ন্যূনতম পরিশোধ বাধ্যতামূলক।';
  }

  // 3. Optional Credit Card Balance Safeguard:
  // If this is the remaining non-minimum balance and cash is insufficient, cap its priority
  // so it does not cannibalize essential living groceries/utilities
  if (
    obligation.sourceType === 'credit_card_full' &&
    availableBalance < config.essentialLivingReserve + obligation.amountConverted
  ) {
    if (finalScore > 64) {
      finalScore = 64; // Keep in Medium priority
      hardOverrideApplied = true;
      overrideReason =
        'Hard Override: Deprioritized full card balance to preserve emergency cash buffer for basic living necessities.';
      overrideReasonBn =
        'কঠোর নিয়ম প্রয়োগ: খাবার ও জরুরি জীবনযাত্রার ক্যাশ রিজার্ভ রক্ষা করতে পুরো কার্ড পরিশোধের পরিবর্তে মাঝারি প্রায়োরিটিতে রাখা হয়েছে।';
    }
  }

  // Clamp 0 - 100
  finalScore = Math.max(0, Math.min(100, finalScore));

  // Determine Level
  let level: PriorityLevel = 'low';
  if (finalScore >= thresholds.critical) level = 'critical';
  else if (finalScore >= thresholds.high) level = 'high';
  else if (finalScore >= thresholds.medium) level = 'medium';

  // Generate clear bilingual explanation
  let explanationSummary = '';
  let explanationSummaryBn = '';
  let recommendedAction = '';
  let recommendedActionBn = '';

  if (level === 'critical') {
    explanationSummary = obligation.isOverdue
      ? `Overdue by ${obligation.overdueDays} day(s). Immediate action required to prevent disconnection or compounding penalties.`
      : `Due within ${obligation.daysRemaining === 0 ? 'today' : obligation.daysRemaining + ' day(s)'}. Critical obligation with severe consequences if delayed.`;
    explanationSummaryBn = obligation.isOverdue
      ? `${obligation.overdueDays} দিন পার হয়ে গেছে! সংযোগ বিচ্ছিন্ন বা জরিমানা এড়াতে এখনই পরিশোধ করুন।`
      : `${obligation.daysRemaining === 0 ? 'আজকেই' : obligation.daysRemaining + ' দিনের মধ্যে'} শেষ সময়। দেরি করলে মারাত্মক ক্ষতি হতে পারে।`;
    recommendedAction = 'Pay immediately from available bank/wallet balance.';
    recommendedActionBn = 'বিদ্যমান ব্যাংক বা ওয়ালেট অ্যাকাউন্ট থেকে অবিলম্বে পরিশোধ করুন।';
  } else if (level === 'high') {
    explanationSummary = `Upcoming deadline with substantial interest or penalty risk. Timely settlement preserves financial health.`;
    explanationSummaryBn = `আসন্ন সময়সীমা—অতিরিক্ত সুদ বা জরিমানা এড়াতে নির্দিষ্ট সময়ের মধ্যে পরিশোধ করা উচিত।`;
    recommendedAction = 'Schedule payment within next 48 hours.';
    recommendedActionBn = 'আগামী ৪৮ ঘণ্টার মধ্যে পরিশোধ সম্পন্ন করার পরিকল্পনা করুন।';
  } else if (level === 'medium') {
    explanationSummary = `Manageable obligation with moderate consequences. Can be scheduled after critical essentials are met.`;
    explanationSummaryBn = `মাঝারি অগ্রাধিকার—জরুরি ও বকেয়া বিল পরিশোধের পর সুবিধাজনক সময়ে দেওয়া যাবে।`;
    recommendedAction = 'Pay if funds remain after critical obligations are cleared.';
    recommendedActionBn = 'জরুরি বিল দেওয়ার পর ব্যালেন্স অবশিষ্ট থাকলে পরিশোধ করুন।';
  } else {
    explanationSummary = `Discretionary or low-cost obligation. Can be delayed or paused without financial harm.`;
    explanationSummaryBn = `ঐচ্ছিক বা নিম্ন ব্যয়—প্রয়োজনে সাময়িক বিরতি বা স্থগিত রাখা নিরাপদ।`;
    recommendedAction = 'Pay at leisure or consider pausing if funds are constrained.';
    recommendedActionBn = 'টাকা সংকট থাকলে সাবস্ক্রিপশনটি সাময়িক পজ করে রাখতে পারেন।';
  }

  return {
    score: finalScore,
    level,
    urgencyScore,
    overdueScore,
    penaltyScore,
    interestScore,
    consequenceScore,
    essentialScore,
    cashBufferScore,
    hardOverrideApplied,
    overrideReason,
    overrideReasonBn,
    explanationSummary,
    explanationSummaryBn,
    recommendedAction,
    recommendedActionBn,
    assumptions,
  };
}

/**
 * Ranks all obligations based on chosen strategy and computes cash allocation & shortfall.
 */
export function rankObligations(
  obligations: PaymentObligation[],
  strategy: PaymentStrategyType,
  availableBalance: number,
  config: PaymentEngineConfig
): { rankedItems: RankedObligation[]; cashFlow: CashFlowAnalysis } {
  // Compute individual scores first
  const scored = obligations.map((ob) => ({
    obligation: ob,
    scoreBreakdown: calculatePriorityScore(ob, availableBalance, config),
  }));

  // Sort based on strategy
  scored.sort((a, b) => {
    switch (strategy) {
      case 'deadline_first':
        // Overdue first, then ascending days remaining
        return a.obligation.daysRemaining - b.obligation.daysRemaining;

      case 'highest_interest':
        // Highest APR first, then score
        const aprA = a.obligation.interestRateAPR || 0;
        const aprB = b.obligation.interestRateAPR || 0;
        if (aprB !== aprA) return aprB - aprA;
        return b.scoreBreakdown.score - a.scoreBreakdown.score;

      case 'highest_penalty':
        // Highest penalty fee first, then score
        const penA = a.obligation.lateFeeAmount || 0;
        const penB = b.obligation.lateFeeAmount || 0;
        if (penB !== penA) return penB - penA;
        return b.scoreBreakdown.score - a.scoreBreakdown.score;

      case 'essential_first':
        // Essential first, then score
        if (a.obligation.isEssential !== b.obligation.isEssential) {
          return a.obligation.isEssential ? -1 : 1;
        }
        return b.scoreBreakdown.score - a.scoreBreakdown.score;

      case 'balanced_smart':
      default:
        // Score descending (includes hard overrides)
        return b.scoreBreakdown.score - a.scoreBreakdown.score;
    }
  });

  // Calculate cash flow allocations step by step
  let runningBalance = availableBalance;
  let dueIn24Hours = 0;
  let dueIn3Days = 0;
  let dueIn7Days = 0;
  let totalEssentialDue = 0;
  let totalAllUpcomingDue = 0;

  const rankedItems: RankedObligation[] = scored.map((item, index) => {
    const ob = item.obligation;
    const amount = ob.amountConverted;

    totalAllUpcomingDue += amount;
    if (ob.isEssential) totalEssentialDue += amount;
    if (ob.daysRemaining <= 1) dueIn24Hours += amount;
    if (ob.daysRemaining <= 3) dueIn3Days += amount;
    if (ob.daysRemaining <= 7) dueIn7Days += amount;

    let coverageStatus: 'fully_covered' | 'minimum_covered_only' | 'shortfall_uncovered' =
      'shortfall_uncovered';
    let allocatedAmount = 0;
    let shortfallForThisItem = 0;

    if (runningBalance >= amount) {
      coverageStatus = 'fully_covered';
      allocatedAmount = amount;
      runningBalance -= amount;
    } else if (ob.minimumAmountDue > 0 && runningBalance >= ob.minimumAmountDue) {
      coverageStatus = 'minimum_covered_only';
      allocatedAmount = ob.minimumAmountDue;
      runningBalance -= ob.minimumAmountDue;
      shortfallForThisItem = amount - ob.minimumAmountDue;
    } else {
      coverageStatus = 'shortfall_uncovered';
      allocatedAmount = Math.max(0, runningBalance);
      shortfallForThisItem = amount - allocatedAmount;
      runningBalance = 0;
    }

    return {
      obligation: ob,
      scoreBreakdown: item.scoreBreakdown,
      rank: index + 1,
      coverageStatus,
      allocatedAmount: Math.round(allocatedAmount * 100) / 100,
      remainingBalanceAfter: Math.round(runningBalance * 100) / 100,
      shortfallForThisItem: Math.round(shortfallForThisItem * 100) / 100,
    };
  });

  const shortfallAmount = Math.max(0, totalAllUpcomingDue - availableBalance);
  const hasShortfall = shortfallAmount > 0;
  let shortfallRiskLevel: 'safe' | 'tight' | 'critical_shortfall' = 'safe';

  if (availableBalance < dueIn24Hours || availableBalance < totalEssentialDue) {
    shortfallRiskLevel = 'critical_shortfall';
  } else if (hasShortfall || availableBalance < dueIn7Days) {
    shortfallRiskLevel = 'tight';
  }

  const cashFlow: CashFlowAnalysis = {
    availableBalance: Math.round(availableBalance * 100) / 100,
    dueIn24Hours: Math.round(dueIn24Hours * 100) / 100,
    dueIn3Days: Math.round(dueIn3Days * 100) / 100,
    dueIn7Days: Math.round(dueIn7Days * 100) / 100,
    totalEssentialDue: Math.round(totalEssentialDue * 100) / 100,
    totalAllUpcomingDue: Math.round(totalAllUpcomingDue * 100) / 100,
    projectedRemaining: Math.round(runningBalance * 100) / 100,
    shortfallAmount: Math.round(shortfallAmount * 100) / 100,
    hasShortfall,
    shortfallRiskLevel,
    activeCurrencyCode: 'BDT',
    activeCurrencySymbol: '৳',
  };

  return { rankedItems, cashFlow };
}

/**
 * Runs What-If Simulation without modifying any real financial records.
 */
export function runWhatIfSimulation(
  obligations: PaymentObligation[],
  baseAvailableBalance: number,
  input: WhatIfSimulationInput,
  config: PaymentEngineConfig
): WhatIfSimulationResult {
  // Create a deep copy of obligations
  let simObligations: PaymentObligation[] = obligations.map((ob) => ({ ...ob }));

  // Exclude obligations if user toggled off in simulator
  if (input.excludeObligationIds && input.excludeObligationIds.length > 0) {
    simObligations = simObligations.filter((ob) => !input.excludeObligationIds?.includes(ob.id));
  }

  // Adjusted available funds
  let effectiveFunds =
    input.availableFundsOverride !== null ? input.availableFundsOverride : baseAvailableBalance;

  // If non-essential subscriptions delayed, push their due dates back
  if (input.delayNonEssentialsDays > 0) {
    simObligations = simObligations.map((ob) => {
      if (!ob.isEssential && (ob.sourceType === 'bill' || ob.sourceType === 'custom')) {
        const newDays = ob.daysRemaining + input.delayNonEssentialsDays;
        return {
          ...ob,
          daysRemaining: newDays,
          isOverdue: newDays < 0,
          overdueDays: newDays < 0 ? Math.abs(newDays) : 0,
        };
      }
      return ob;
    });
  }

  // If paying only minimums across all debts
  if (input.payOnlyMinimums) {
    simObligations = simObligations.map((ob) => {
      if (ob.minimumAmountDue > 0 && ob.minimumAmountDue < ob.amountConverted) {
        return {
          ...ob,
          amountConverted: ob.minimumAmountDue,
          remainingAmount: ob.minimumAmountDue,
        };
      }
      return ob;
    });
  }

  // Determine strategy to use in simulator
  const simStrategy: PaymentStrategyType = input.payCreditCardFirst
    ? 'highest_interest'
    : 'balanced_smart';

  const { rankedItems, cashFlow } = rankObligations(simObligations, simStrategy, effectiveFunds, config);

  // Compute metrics
  let fullyPaid = 0;
  let partiallyPaid = 0;
  let unpaid = 0;
  let penaltiesAvoided = 0;
  let interestSaved = 0;
  let essentialCovered = 0;
  let essentialTotal = 0;

  rankedItems.forEach((item) => {
    if (item.coverageStatus === 'fully_covered') {
      fullyPaid++;
      if (item.obligation.hasLateFee && item.obligation.lateFeeAmount) {
        penaltiesAvoided += item.obligation.lateFeeAmount;
      }
      if (item.obligation.interestRateAPR && item.obligation.interestRateAPR >= 20) {
        // Estimated monthly interest saved
        interestSaved += (item.obligation.amountConverted * (item.obligation.interestRateAPR / 100)) / 12;
      }
    } else if (item.coverageStatus === 'minimum_covered_only') {
      partiallyPaid++;
    } else {
      unpaid++;
    }

    if (item.obligation.isEssential) {
      essentialTotal += item.obligation.amountConverted;
      essentialCovered += item.allocatedAmount;
    }
  });

  const essentialCoveragePercent =
    essentialTotal > 0 ? Math.round((essentialCovered / essentialTotal) * 100) : 100;

  // Impact summary
  let impactSummary = '';
  let impactSummaryBn = '';

  if (cashFlow.hasShortfall) {
    impactSummary = `Simulated shortfall of ${Math.round(cashFlow.shortfallAmount).toLocaleString()}. ${unpaid} obligation(s) remain uncovered. Essential coverage is at ${essentialCoveragePercent}%.`;
    impactSummaryBn = `সিমুলেশনে ঘাটতি ${Math.round(cashFlow.shortfallAmount).toLocaleString()} টাকা। ${unpaid}টি দায় অপরিশোধিত থাকছে। জরুরি ব্যয়ের কাভারেজ ${essentialCoveragePercent}%।`;
  } else {
    impactSummary = `All ${fullyPaid} obligations are fully covered with ${Math.round(cashFlow.projectedRemaining).toLocaleString()} remaining cash buffer. Avoided estimated ${Math.round(penaltiesAvoided).toLocaleString()} in penalties.`;
    impactSummaryBn = `সকল ${fullyPaid}টি দায় সম্পূর্ণ পরিশোধযোগ্য এবং ${Math.round(cashFlow.projectedRemaining).toLocaleString()} টাকা অবশিষ্ট থাকবে। আনুমানিক ${Math.round(penaltiesAvoided).toLocaleString()} টাকা জরিমানা সাশ্রয় হয়েছে।`;
  }

  return {
    simulatedAvailableBalance: effectiveFunds,
    simulatedDueIn7Days: cashFlow.dueIn7Days,
    simulatedRemainingBalance: cashFlow.projectedRemaining,
    simulatedShortfall: cashFlow.shortfallAmount,
    simulatedPenaltiesAvoided: Math.round(penaltiesAvoided),
    simulatedInterestSaved: Math.round(interestSaved),
    simulatedEssentialCoveragePercent: essentialCoveragePercent,
    fullyPaidCount: fullyPaid,
    partiallyPaidCount: partiallyPaid,
    unpaidCount: unpaid,
    impactSummary,
    impactSummaryBn,
    rankedItems,
  };
}
