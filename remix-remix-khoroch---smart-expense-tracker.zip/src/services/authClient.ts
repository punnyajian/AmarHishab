// Client-side Authentication and Cloud Sync Service for Khoroch
import { AuthUser, AuthSession, SecurityQuestionItem, SecurityQuestionPrompt } from '../types/auth';

const SESSION_STORAGE_KEY = 'khoroch_auth_session_v4';

export class AuthClient {
  private static cachedSession: AuthSession | null = null;

  static getSession(): AuthSession | null {
    if (this.cachedSession) return this.cachedSession;
    try {
      const stored = localStorage.getItem(SESSION_STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored) as AuthSession;
        if (parsed.expiresAt && new Date(parsed.expiresAt).getTime() > Date.now()) {
          this.cachedSession = parsed;
          return parsed;
        } else {
          this.clearSession();
        }
      }
    } catch (err) {
      console.warn('[AuthClient] Failed to read stored session:', err);
    }
    return null;
  }

  static setSession(session: AuthSession) {
    this.cachedSession = session;
    try {
      localStorage.setItem(SESSION_STORAGE_KEY, JSON.stringify(session));
    } catch (err) {
      console.error('[AuthClient] Failed to save session:', err);
    }
  }

  static clearSession() {
    this.cachedSession = null;
    try {
      localStorage.removeItem(SESSION_STORAGE_KEY);
    } catch (err) {
      console.error('[AuthClient] Failed to clear session:', err);
    }
  }

  static getToken(): string | null {
    const session = this.getSession();
    return session ? session.token : null;
  }

  static getCurrentUser(): AuthUser | null {
    const session = this.getSession();
    return session ? session.user : null;
  }

  static async checkUsername(username: string): Promise<{ available: boolean; reason?: string }> {
    try {
      const res = await fetch(`/api/auth/check-username?username=${encodeURIComponent(username)}`);
      const data = await res.json();
      return data;
    } catch (err: any) {
      return { available: false, reason: 'Failed to connect to authentication server.' };
    }
  }

  static async register(payload: {
    username: string;
    password: string;
    confirmPassword: string;
    securityQuestions: { id?: string; question: string; answer: string }[];
  }): Promise<{ user: AuthUser; token: string }> {
    const res = await fetch('/api/auth/register', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to create account.');
    }

    this.setSession(data.session);
    return { user: data.session.user, token: data.session.token };
  }

  static async login(payload: { username: string; password: string }): Promise<{ user: AuthUser; token: string }> {
    const res = await fetch('/api/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to log in.');
    }

    this.setSession(data.session);
    return { user: data.session.user, token: data.session.token };
  }

  static async logout(): Promise<void> {
    const token = this.getToken();
    try {
      if (token) {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
          },
        });
      }
    } catch (err) {
      console.warn('[AuthClient] Logout request error:', err);
    } finally {
      this.clearSession();
    }
  }

  static async getMe(): Promise<AuthUser | null> {
    const token = this.getToken();
    if (!token) return null;

    try {
      const res = await fetch('/api/auth/me', {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (!res.ok) {
        this.clearSession();
        return null;
      }
      const data = await res.json();
      return data.user;
    } catch (err) {
      console.warn('[AuthClient] getMe request failed:', err);
      return this.getCurrentUser();
    }
  }

  static async changePassword(payload: {
    currentPassword: string;
    newPassword: string;
    confirmNewPassword: string;
  }): Promise<void> {
    const token = this.getToken();
    if (!token) throw new Error('You must be logged in to change your password.');

    const res = await fetch('/api/auth/change-password', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to change password.');
    }
  }

  static async getSecurityQuestions(username: string): Promise<{ exists: boolean; questions: SecurityQuestionPrompt[] }> {
    const res = await fetch('/api/auth/security-questions/get', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username }),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Unable to retrieve recovery questions.');
    }
    return data;
  }

  static async verifySecurityAnswers(payload: {
    username: string;
    answers: { id: string; question: string; answer: string }[];
  }): Promise<{ resetToken: string }> {
    const res = await fetch('/api/auth/security-questions/verify', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Security answers verification failed.');
    }
    return { resetToken: data.resetToken };
  }

  static async resetPasswordWithToken(payload: {
    resetToken: string;
    newPassword: string;
    confirmNewPassword: string;
  }): Promise<{ user: AuthUser; token: string }> {
    const res = await fetch('/api/auth/reset-password', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Password reset failed.');
    }

    this.setSession(data.session);
    return { user: data.session.user, token: data.session.token };
  }

  static async updateSecurityQuestions(payload: {
    currentPassword: string;
    questions: { id: string; question: string; answer: string }[];
  }): Promise<void> {
    const token = this.getToken();
    if (!token) throw new Error('You must be logged in to update recovery questions.');

    const res = await fetch('/api/auth/update-security-questions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to update security questions.');
    }
  }

  // Cloud Data Synchronization
  static async pullCloudData(): Promise<any> {
    const token = this.getToken();
    if (!token) throw new Error('Authentication required to download cloud data.');

    const res = await fetch('/api/sync/pull', {
      headers: { Authorization: `Bearer ${token}` },
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to download cloud data.');
    }
    return data.data;
  }

  static async pushCloudData(bundle: any): Promise<void> {
    const token = this.getToken();
    if (!token) throw new Error('Authentication required to upload cloud data.');

    const res = await fetch('/api/sync/push', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${token}`,
      },
      body: JSON.stringify(bundle),
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to upload cloud data.');
    }
  }
}
