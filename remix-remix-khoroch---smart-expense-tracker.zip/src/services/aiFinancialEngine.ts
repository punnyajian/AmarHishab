import {
  Transaction,
  Category,
  Account,
  Budget,
  SavingsGoal,
  Debt,
  SubscriptionBill,
  DigitalCard,
  InvestmentItem,
  AIHealthScore,
  AIActionProposal,
  AIActivityEvent,
  AIMemoryPreferences,
  AIAnomalyRisk,
  AINetWorthBreakdown,
  AICashFlowForecast,
  AIReportSummary,
  Currency,
  Language,
} from '../types';

// ==========================================
// 1. FINANCIAL HEALTH SCORE CALCULATION
// ==========================================
export function calculateFinancialHealthScore(params: {
  transactions: Transaction[];
  budgets: Budget[];
  accounts: Account[];
  debts: Debt[];
  subscriptions: SubscriptionBill[];
  totalIncomeThisMonth: number;
  totalExpenseThisMonth: number;
  language: Language;
}): AIHealthScore {
  const {
    transactions,
    budgets,
    accounts,
    debts,
    subscriptions,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    language,
  } = params;

  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const totalBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);

  // Pillar 1: Savings Rate (Weight: 25%)
  let savingsScore = 50;
  if (totalIncomeThisMonth > 0) {
    const savingsRate = ((totalIncomeThisMonth - totalExpenseThisMonth) / totalIncomeThisMonth) * 100;
    if (savingsRate >= 25) savingsScore = 100;
    else if (savingsRate >= 15) savingsScore = 85;
    else if (savingsRate >= 5) savingsScore = 65;
    else if (savingsRate >= 0) savingsScore = 50;
    else savingsScore = Math.max(10, Math.round(50 + savingsRate));
  } else if (totalExpenseThisMonth === 0) {
    savingsScore = 60;
  } else {
    savingsScore = 30;
  }

  // Pillar 2: Budget Discipline (Weight: 25%)
  let budgetScore = 75;
  if (budgets.length > 0) {
    let budgetTotalPoints = 0;
    budgets.forEach(b => {
      const spent = transactions
        .filter(t => t.type === 'expense' && t.categoryId === b.categoryId && t.date.startsWith(currentMonthStr))
        .reduce((sum, t) => sum + t.amount, 0);
      const ratio = spent / (b.monthlyLimit || 1);
      if (ratio <= 0.7) budgetTotalPoints += 100;
      else if (ratio <= 0.9) budgetTotalPoints += 85;
      else if (ratio <= 1.0) budgetTotalPoints += 65;
      else if (ratio <= 1.2) budgetTotalPoints += 40;
      else budgetTotalPoints += 15;
    });
    budgetScore = Math.round(budgetTotalPoints / budgets.length);
  }

  // Pillar 3: Debt to Income / Liquidity (Weight: 20%)
  const borrowedDebt = debts
    .filter(d => d.type === 'borrowed' && !d.settled)
    .reduce((sum, d) => sum + (d.amount - (d.paidAmount || 0)), 0);
  
  let debtScore = 100;
  if (borrowedDebt > 0) {
    const monthlyIncomeBench = totalIncomeThisMonth > 0 ? totalIncomeThisMonth : 40000;
    const debtRatio = borrowedDebt / monthlyIncomeBench;
    if (debtRatio <= 0.2) debtScore = 90;
    else if (debtRatio <= 0.5) debtScore = 75;
    else if (debtRatio <= 1.0) debtScore = 55;
    else if (debtRatio <= 2.0) debtScore = 35;
    else debtScore = 20;
  }

  // Pillar 4: Liquidity & Cash Runway (Weight: 15%)
  const daysInMonth = 30;
  const currentDay = Math.max(1, new Date().getDate());
  const dailyBurn = totalExpenseThisMonth > 0 ? totalExpenseThisMonth / currentDay : 500;
  const runwayDays = dailyBurn > 0 ? Math.round(totalBalance / dailyBurn) : 90;
  let liquidityScore = 50;
  if (runwayDays >= 60) liquidityScore = 100;
  else if (runwayDays >= 30) liquidityScore = 85;
  else if (runwayDays >= 14) liquidityScore = 65;
  else if (runwayDays >= 7) liquidityScore = 45;
  else liquidityScore = 20;

  // Pillar 5: Bill & Obligation Punctuality (Weight: 15%)
  const overdueBills = subscriptions.filter(s => {
    if (s.status !== 'active') return false;
    const isPastDue = new Date(s.dueDate).getTime() < new Date().getTime();
    return isPastDue && (!s.lastPaidDate || s.lastPaidDate < s.dueDate);
  }).length;
  let punctualityScore = Math.max(20, 100 - (overdueBills * 30));

  // Weighted overall calculation
  const overallScore = Math.round(
    savingsScore * 0.25 +
    budgetScore * 0.25 +
    debtScore * 0.20 +
    liquidityScore * 0.15 +
    punctualityScore * 0.15
  );

  let status: 'excellent' | 'good' | 'moderate' | 'critical' = 'good';
  if (overallScore >= 85) status = 'excellent';
  else if (overallScore >= 70) status = 'good';
  else if (overallScore >= 50) status = 'moderate';
  else status = 'critical';

  const summaryBn = 
    status === 'excellent'
      ? `আপনার সার্বিক আর্থিক স্বাস্থ্য চমৎকার (${overallScore}/১০০)। সঞ্চয়ের হার ভালো এবং বাজেট নিয়ন্ত্রণে রয়েছে।`
      : status === 'good'
      ? `আপনার অর্থনৈতিক স্বাস্থ্য সন্তোষজনক (${overallScore}/১০০)। কিছু ক্ষেত্রে ছোটখাটো সমন্বয়ে আরও সঞ্চয় সম্ভব।`
      : status === 'moderate'
      ? `আর্থিক স্বাস্থ্য সতর্কবার্তা পর্যায়ে রয়েছে (${overallScore}/১০০)। বাজেট সীমা অতিক্রম এবং খরচের হার কমানো জরুরি।`
      : `জরুরি আর্থিক হস্তক্ষেপ প্রয়োজন (${overallScore}/১০০)। ঋণ পরিশোধ ও নগদ অর্থের ঘাটতি অবিলম্বে নিয়ন্ত্রণ করুন।`;

  const summaryEn = 
    status === 'excellent'
      ? `Financial health is excellent (${overallScore}/100) with strong savings discipline and budget adherence.`
      : status === 'good'
      ? `Financial health is good (${overallScore}/100) with healthy reserves, minor tuning recommended.`
      : status === 'moderate'
      ? `Financial health requires caution (${overallScore}/100) due to elevated spending and tight cash flow.`
      : `Immediate attention needed (${overallScore}/100) to plug deficits and manage liquidity risks.`;

  return {
    overallScore,
    status,
    savingsScore,
    budgetDisciplineScore: budgetScore,
    debtToIncomeScore: debtScore,
    liquidityScore,
    billPunctualityScore: punctualityScore,
    summaryBn,
    summaryEn,
  };
}

// ==========================================
// 2. CONTINUOUS ANOMALY & RISK DETECTION
// ==========================================
export function detectAnomaliesAndRisks(params: {
  transactions: Transaction[];
  categories: Category[];
  budgets: Budget[];
  accounts: Account[];
  subscriptions: SubscriptionBill[];
  digitalCards: DigitalCard[];
  debts: Debt[];
  totalBalance: number;
  totalIncomeThisMonth: number;
  totalExpenseThisMonth: number;
  currency: Currency;
  language: Language;
}): AIAnomalyRisk[] {
  const {
    transactions,
    categories,
    budgets,
    accounts,
    subscriptions,
    digitalCards,
    debts,
    totalBalance,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    currency,
    language,
  } = params;

  const risks: AIAnomalyRisk[] = [];
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const isBn = language === 'bn';

  // 1. Detect Duplicate or Suspicious Transactions within 48h
  const expenses = transactions.filter(t => t.type === 'expense');
  for (let i = 0; i < expenses.length; i++) {
    for (let j = i + 1; j < expenses.length; j++) {
      const a = expenses[i];
      const b = expenses[j];
      if (a.amount === b.amount && a.categoryId === b.categoryId && a.date === b.date && a.id !== b.id) {
        const cat = categories.find(c => c.id === a.categoryId);
        const catName = isBn ? cat?.nameBn || cat?.name : cat?.name;
        risks.push({
          id: `risk-dup-${a.id}-${b.id}`,
          type: 'duplicate_tx',
          title: isBn ? 'সম্ভাব্য ডুপ্লিকেট লেনদেন শনাক্ত' : 'Potential Duplicate Transaction Detected',
          titleBn: 'সম্ভাব্য ডুপ্লিকেট লেনদেন শনাক্ত',
          message: isBn
            ? `${catName} খাতে একই দিনে ${currency.symbol}${a.amount.toLocaleString()} টাকার দুটি অভিন্ন লেনদেন পাওয়া গেছে।`
            : `Detected 2 identical ${currency.symbol}${a.amount.toLocaleString()} transactions in ${catName} on ${a.date}.`,
          messageBn: `${catName} খাতে একই দিনে ${currency.symbol}${a.amount.toLocaleString()} টাকার দুটি অভিন্ন লেনদেন পাওয়া গেছে।`,
          severity: 'medium',
          suggestedAction: isBn ? 'লেনদেন দুটি যাচাই করুন ও অতিরিক্তটি মুছে ফেলুন' : 'Review and delete redundant transaction',
          suggestedActionBn: 'লেনদেন দুটি যাচাই করুন ও অতিরিক্তটি মুছে ফেলুন',
          detectedAt: new Date().toISOString(),
          relatedId: a.id,
        });
        break;
      }
    }
  }

  // 2. Detect Unusually Large Spikes (> 2.5x of category average)
  if (expenses.length >= 5) {
    const avgExpense = totalExpenseThisMonth / Math.max(1, expenses.length);
    const recentExpenses = expenses.slice(0, 10);
    const spikeTx = recentExpenses.find(t => t.amount >= avgExpense * 3 && t.amount > 2000);
    if (spikeTx) {
      const cat = categories.find(c => c.id === spikeTx.categoryId);
      const catName = isBn ? cat?.nameBn || cat?.name : cat?.name;
      risks.push({
        id: `risk-spike-${spikeTx.id}`,
        type: 'spending_spike',
        title: isBn ? 'অস্বাভাবিক বড় একক ব্যয়' : 'Unusual Spending Spike Detected',
        titleBn: 'অস্বাভাবিক বড় একক ব্যয়',
        message: isBn
          ? `${catName} খাতে ${currency.symbol}${spikeTx.amount.toLocaleString()} টাকার একক ব্যয় গড়ের চেয়ে ৩ গুণ বেশি।`
          : `Single expense of ${currency.symbol}${spikeTx.amount.toLocaleString()} in ${catName} is 3x higher than average.`,
        messageBn: `${catName} খাতে ${currency.symbol}${spikeTx.amount.toLocaleString()} টাকার একক ব্যয় গড়ের চেয়ে ৩ গুণ বেশি।`,
        severity: 'high',
        suggestedAction: isBn ? 'ব্যয়টি পরিকল্পিত ছিল কি না যাচাই করুন' : 'Confirm if this expense was budgeted',
        suggestedActionBn: 'ব্যয়টি পরিকল্পিত ছিল কি না যাচাই করুন',
        detectedAt: new Date().toISOString(),
        relatedId: spikeTx.id,
      });
    }
  }

  // 3. Imminent Budget Violations (>85% or >100%)
  budgets.forEach(b => {
    const spent = transactions
      .filter(t => t.type === 'expense' && t.categoryId === b.categoryId && t.date.startsWith(currentMonthStr))
      .reduce((sum, t) => sum + t.amount, 0);
    const ratio = spent / (b.monthlyLimit || 1);
    const cat = categories.find(c => c.id === b.categoryId);
    const catName = isBn ? cat?.nameBn || cat?.name : cat?.name;

    if (ratio >= 1.0) {
      risks.push({
        id: `risk-budget-exceeded-${b.id}`,
        type: 'approaching_limit',
        title: isBn ? `বাজেট সীমা অতিক্রম: ${catName}` : `Budget Exceeded: ${catName}`,
        titleBn: `বাজেট সীমা অতিক্রম: ${catName}`,
        message: isBn
          ? `${catName} খাতে মাসিক সীমা ${currency.symbol}${b.monthlyLimit.toLocaleString()} ছাড়িয়ে ${currency.symbol}${spent.toLocaleString()} খরচ হয়েছে (${Math.round(ratio * 100)}%)।`
          : `${catName} budget exhausted: spent ${currency.symbol}${spent.toLocaleString()} of ${currency.symbol}${b.monthlyLimit.toLocaleString()} (${Math.round(ratio * 100)}%).`,
        messageBn: `${catName} খাতে মাসিক সীমা ছাড়িয়ে গেছে।`,
        severity: 'critical',
        suggestedAction: isBn ? 'বাজেট সামঞ্জস্য করুন অথবা বাকি দিনগুলোতে খরচ বন্ধ রাখুন' : 'Pause non-essential spending in this category',
        suggestedActionBn: 'বাজেট সামঞ্জস্য করুন অথবা বাকি দিনগুলোতে খরচ বন্ধ রাখুন',
        detectedAt: new Date().toISOString(),
        relatedId: b.id,
        actionProposal: {
          id: `prop-budget-${b.id}`,
          type: 'update_budget',
          title: isBn ? `${catName} বাজেট পুনর্নির্ধারণ` : `Adjust ${catName} Budget`,
          titleBn: `${catName} বাজেট পুনর্নির্ধারণ`,
          description: isBn ? `${catName} বাজেট সীমা বৃদ্ধি করে নিয়ন্ত্রণে আনা` : `Increase limit to reflect realistic run-rate`,
          descriptionBn: `${catName} বাজেট সীমা বৃদ্ধি করে নিয়ন্ত্রণে আনা`,
          currentValue: `${currency.symbol}${b.monthlyLimit.toLocaleString()}`,
          newValue: `${currency.symbol}${Math.round(spent * 1.15).toLocaleString()}`,
          reason: isBn ? 'বর্তমান মাসের রান-রেট অনুযায়ী বাজেট পার হয়ে গেছে' : 'Spending exceeded planned threshold',
          reasonBn: 'বর্তমান মাসের রান-রেট অনুযায়ী বাজেট পার হয়ে গেছে',
          severity: 'warning',
          requiresConfirmation: true,
          payload: { categoryId: b.categoryId, newLimit: Math.round(spent * 1.15) },
          createdAt: new Date().toISOString(),
          status: 'pending',
        },
      });
    } else if (ratio >= 0.8) {
      risks.push({
        id: `risk-budget-warn-${b.id}`,
        type: 'approaching_limit',
        title: isBn ? `বাজেট সতর্কবার্তা: ${catName}` : `Budget Warning: ${catName}`,
        titleBn: `বাজেট সতর্কবার্তা: ${catName}`,
        message: isBn
          ? `${catName} বাজেটের ${Math.round(ratio * 100)}% খরচ হয়ে গেছে। বাকি আছে মাত্র ${currency.symbol}${(b.monthlyLimit - spent).toLocaleString()}।`
          : `${Math.round(ratio * 100)}% of ${catName} budget consumed. Remaining: ${currency.symbol}${(b.monthlyLimit - spent).toLocaleString()}.`,
        messageBn: `${catName} বাজেটের ৮০% এর বেশি খরচ হয়ে গেছে।`,
        severity: 'medium',
        suggestedAction: isBn ? 'মাসের বাকি দিনগুলোতে এই খাতে সতর্ক থাকুন' : 'Slow down spending in this category',
        suggestedActionBn: 'মাসের বাকি দিনগুলোতে এই খাতে সতর্ক থাকুন',
        detectedAt: new Date().toISOString(),
        relatedId: b.id,
      });
    }
  });

  // 4. Imminent Obligations & Cash-Flow Shortage Alert
  const nowMs = new Date().getTime();
  const next7DaysMs = nowMs + 7 * 24 * 60 * 60 * 1000;
  const imminentBills = subscriptions.filter(s => {
    if (s.status !== 'active') return false;
    const dueMs = new Date(s.dueDate).getTime();
    return dueMs >= nowMs && dueMs <= next7DaysMs;
  });
  const upcomingBillsTotal = imminentBills.reduce((sum, s) => sum + s.amount, 0);

  if (upcomingBillsTotal > 0 && totalBalance < upcomingBillsTotal) {
    risks.push({
      id: 'risk-cash-shortage',
      type: 'cash_shortage',
      title: isBn ? 'নগদ অর্থের সম্ভাব্য ঘাটতি (Cash-flow Shortage)' : 'Cash-flow Shortage Warning',
      titleBn: 'নগদ অর্থের সম্ভাব্য ঘাটতি (Cash-flow Shortage)',
      message: isBn
        ? `আগামী ৭ দিনে ${currency.symbol}${upcomingBillsTotal.toLocaleString()} টাকার বিল বাকি, কিন্তু মোট ব্যালেন্স মাত্র ${currency.symbol}${totalBalance.toLocaleString()}।`
        : `Upcoming obligations in 7 days (${currency.symbol}${upcomingBillsTotal.toLocaleString()}) exceed available liquidity (${currency.symbol}${totalBalance.toLocaleString()}).`,
      messageBn: 'আগামী সপ্তাহের বিল পরিশোধে তহবিলের ঘাটতি রয়েছে।',
      severity: 'critical',
      suggestedAction: isBn ? 'অন্যান্য অ্যাকাউন্ট থেকে ফান্ড ট্রান্সফার বা জমা করুন' : 'Transfer funds to cover due bills',
      suggestedActionBn: 'অন্যান্য অ্যাকাউন্ট থেকে ফান্ড ট্রান্সফার বা জমা করুন',
      detectedAt: new Date().toISOString(),
    });
  }

  // 5. Credit Card High Utilization Warning (> 70%)
  digitalCards.forEach(card => {
    if (card.type === 'credit' && card.creditLimit && card.creditLimit > 0) {
      const spent = card.currentSpentThisMonth || 0;
      const utilRatio = spent / card.creditLimit;
      if (utilRatio >= 0.7) {
        risks.push({
          id: `risk-card-util-${card.id}`,
          type: 'card_utilization',
          title: isBn ? `উচ্চ ক্রেডিট কার্ড ব্যবহার (${card.issuerName})` : `High Credit Card Utilization (${card.issuerName})`,
          titleBn: `উচ্চ ক্রেডিট কার্ড ব্যবহার (${card.issuerName})`,
          message: isBn
            ? `${card.issuerName} কার্ডের লিমিটের ${Math.round(utilRatio * 100)}% ব্যবহৃত হয়েছে (${currency.symbol}${spent.toLocaleString()}/${currency.symbol}${card.creditLimit.toLocaleString()})।`
            : `Card limit is ${Math.round(utilRatio * 100)}% utilized (${currency.symbol}${spent.toLocaleString()} of ${currency.symbol}${card.creditLimit.toLocaleString()}).`,
          messageBn: 'ক্রেডিট কার্ডের ৭০% এর বেশি লিমিট ব্যবহার হয়েছে।',
          severity: 'high',
          suggestedAction: isBn ? 'ক্রেডিট স্কোর সুরক্ষায় অবিলম্বে আংশিক পরিশোধ করুন' : 'Pay down card balance to safeguard credit profile',
          suggestedActionBn: 'ক্রেডিট স্কোর সুরক্ষায় অবিলম্বে আংশিক পরিশোধ করুন',
          detectedAt: new Date().toISOString(),
          relatedId: card.id,
        });
      }
    }
  });

  return risks;
}

// ==========================================
// 3. NET WORTH INTELLIGENCE
// ==========================================
export function calculateNetWorthIntelligence(params: {
  accounts: Account[];
  investments: InvestmentItem[];
  debts: Debt[];
  subscriptions: SubscriptionBill[];
  digitalCards: DigitalCard[];
  language: Language;
  currency: Currency;
}): AINetWorthBreakdown {
  const { accounts, investments, debts, subscriptions, digitalCards, language, currency } = params;

  // Assets
  const liquidCashAndBank = accounts.reduce((sum, a) => sum + Math.max(0, a.balance || 0), 0);
  const activeInvestments = investments.filter(i => i.status === 'active');
  const investmentsAndGold = activeInvestments.reduce((sum, i) => sum + (i.currentValue || 0), 0);
  const receivablesLent = debts
    .filter(d => d.type === 'lent' && !d.settled)
    .reduce((sum, d) => sum + (d.amount - (d.paidAmount || 0)), 0);

  const totalAssets = liquidCashAndBank + investmentsAndGold + receivablesLent;

  // Liabilities
  const debtsBorrowed = debts
    .filter(d => d.type === 'borrowed' && !d.settled)
    .reduce((sum, d) => sum + (d.amount - (d.paidAmount || 0)), 0);
  const creditCardDues = digitalCards
    .filter(c => c.type === 'credit')
    .reduce((sum, c) => sum + (c.currentSpentThisMonth || 0), 0);
  const pendingBills = subscriptions
    .filter(s => s.status === 'active' && (!s.lastPaidDate || s.lastPaidDate < s.dueDate))
    .reduce((sum, s) => sum + s.amount, 0);

  const totalLiabilities = debtsBorrowed + creditCardDues + pendingBills;
  const netWorth = totalAssets - totalLiabilities;

  // Benchmark change from last month (estimated 5% increase or flat)
  const changeFromLastMonth = Math.round(netWorth * 0.035);

  const isBn = language === 'bn';
  const insightBn = totalLiabilities === 0
    ? `আপনার কোনো দায়ভার বা ঋণ নেই! মোট সম্পদ ${currency.symbol}${totalAssets.toLocaleString()} পুরোটাই আপনার নিট সম্পদ।`
    : `মোট সম্পদ ${currency.symbol}${totalAssets.toLocaleString()} থেকে দায়ভার ${currency.symbol}${totalLiabilities.toLocaleString()} বাদ দিলে বর্তমান নিট সম্পদ ${currency.symbol}${netWorth.toLocaleString()}।`;

  const insightEn = totalLiabilities === 0
    ? `Zero outstanding liabilities! All ${currency.symbol}${totalAssets.toLocaleString()} represents true net worth.`
    : `Total assets of ${currency.symbol}${totalAssets.toLocaleString()} minus ${currency.symbol}${totalLiabilities.toLocaleString()} liabilities yields net worth of ${currency.symbol}${netWorth.toLocaleString()}.`;

  return {
    totalAssets,
    liquidCashAndBank,
    investmentsAndGold,
    receivablesLent,
    totalLiabilities,
    debtsBorrowed,
    creditCardDues,
    pendingBills,
    netWorth,
    changeFromLastMonth,
    insightBn,
    insightEn,
  };
}

// ==========================================
// 4. CASH FLOW & RUNWAY FORECAST
// ==========================================
export function calculateCashFlowForecast(params: {
  accounts: Account[];
  subscriptions: SubscriptionBill[];
  totalIncomeThisMonth: number;
  totalExpenseThisMonth: number;
  currency: Currency;
  language: Language;
}): AICashFlowForecast {
  const { accounts, subscriptions, totalIncomeThisMonth, totalExpenseThisMonth, currency, language } = params;

  const currentLiquidBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);
  const now = new Date();
  const currentDay = Math.max(1, now.getDate());
  const totalDaysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const remainingDays = Math.max(1, totalDaysInMonth - currentDay);

  // Daily burn
  const dailyBurn = totalExpenseThisMonth > 0 ? totalExpenseThisMonth / currentDay : 600;
  const projectedExpensesRemainder = Math.round(dailyBurn * remainingDays);

  // Remaining upcoming bills
  const upcomingObligations = subscriptions
    .filter(s => s.status === 'active' && (!s.lastPaidDate || s.lastPaidDate < s.dueDate))
    .reduce((sum, s) => sum + s.amount, 0);

  // Projected income remainder (if salaried and income usually arrives end of month or already arrived)
  const projectedIncomeRemainder = 0; // conservative forecast

  const estimatedEndOfMonthBalance = Math.round(
    currentLiquidBalance - projectedExpensesRemainder - upcomingObligations
  );

  const runwayDays = dailyBurn > 0 ? Math.round(currentLiquidBalance / dailyBurn) : 90;

  let riskLevel: 'safe' | 'caution' | 'danger' = 'safe';
  if (estimatedEndOfMonthBalance < 0 || runwayDays < 10) riskLevel = 'danger';
  else if (estimatedEndOfMonthBalance < currentLiquidBalance * 0.25 || runwayDays < 20) riskLevel = 'caution';
  else riskLevel = 'safe';

  const isBn = language === 'bn';
  const adviceBn = 
    riskLevel === 'safe'
      ? `মাস শেষে আনুমানিক ${currency.symbol}${Math.max(0, estimatedEndOfMonthBalance).toLocaleString()} ব্যালেন্স উদ্বৃত্ত থাকার পূর্বাভাস পাওয়া যাচ্ছে। বর্তমান ক্যাশ রানওয়ে প্রায় ${runwayDays} দিন।`
      : riskLevel === 'caution'
      ? `মাস শেষে ব্যালেন্স কিছুটা টানাপোড়েনে পড়তে পারে। অপ্রয়োজনীয় খরচ ১০-১৫% কমালে নিরাপদ থাকা যাবে।`
      : `সতর্কতা: বর্তমান খরচের হারে মাস শেষের আগেই অর্থের ঘাটতি দেখা দিতে পারে! অবিলম্বে ব্যয় সংক্ষেপ করুন।`;

  const adviceEn = 
    riskLevel === 'safe'
      ? `Projected end-of-month surplus of ${currency.symbol}${Math.max(0, estimatedEndOfMonthBalance).toLocaleString()} with ${runwayDays} days of liquid runway.`
      : riskLevel === 'caution'
      ? `Cash flow tightens towards month-end. Trimming discretionary expenses by 10-15% will maintain safety.`
      : `High risk: Outflows outpace liquid balances before month-end. Immediate expense reduction required.`;

  return {
    currentLiquidBalance,
    projectedIncomeRemainder,
    projectedExpensesRemainder,
    upcomingObligations,
    estimatedEndOfMonthBalance,
    runwayDays,
    riskLevel,
    adviceBn,
    adviceEn,
  };
}

// ==========================================
// 5. DYNAMIC BUDGET RECOMMENDATIONS
// ==========================================
export function generateBudgetRecommendations(params: {
  transactions: Transaction[];
  categories: Category[];
  budgets: Budget[];
  totalIncomeThisMonth: number;
  totalExpenseThisMonth: number;
  currency: Currency;
  language: Language;
}): AIActionProposal[] {
  const { transactions, categories, budgets, totalIncomeThisMonth, totalExpenseThisMonth, currency, language } = params;

  const proposals: AIActionProposal[] = [];
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const isBn = language === 'bn';

  // Group expenses by category
  const categorySpend: Record<string, number> = {};
  transactions
    .filter(t => t.type === 'expense')
    .forEach(t => {
      categorySpend[t.categoryId] = (categorySpend[t.categoryId] || 0) + t.amount;
    });

  // Check categories with high spending but no budget
  Object.entries(categorySpend).forEach(([catId, amount]) => {
    const existingBudget = budgets.find(b => b.categoryId === catId);
    const cat = categories.find(c => c.id === catId);
    if (!cat) return;
    const catName = isBn ? cat.nameBn || cat.name : cat.name;

    if (!existingBudget && amount >= 2000) {
      const suggestedLimit = Math.round(amount * 1.15 / 500) * 500;
      proposals.push({
        id: `prop-new-budget-${catId}`,
        type: 'update_budget',
        title: isBn ? `${catName} খাতে নতুন বাজেট সুপারিশ` : `Recommended Budget for ${catName}`,
        titleBn: `${catName} খাতে নতুন বাজেট সুপারিশ`,
        description: isBn
          ? `${catName} খাতে নিয়মিত খরচ হলেও কোনো বাজেট সেট করা নেই।`
          : `Regular spending detected in ${catName} without a target cap.`,
        descriptionBn: `${catName} খাতে নিয়মিত খরচ হলেও কোনো বাজেট সেট করা নেই।`,
        currentValue: isBn ? 'বাজেট নেই' : 'None',
        newValue: `${currency.symbol}${suggestedLimit.toLocaleString()}/মাস`,
        reason: isBn
          ? `বর্তমান খরচ ${currency.symbol}${amount.toLocaleString()} এর ওপর ভিত্তি করে বাস্তবসম্মত মাসিক সীমা`
          : `Calculated from your historical spend of ${currency.symbol}${amount.toLocaleString()}`,
        reasonBn: `বর্তমান খরচ ${currency.symbol}${amount.toLocaleString()} এর ওপর ভিত্তি করে বাস্তবসম্মত মাসিক সীমা`,
        severity: 'info',
        requiresConfirmation: true,
        payload: { categoryId: catId, monthlyLimit: suggestedLimit },
        createdAt: new Date().toISOString(),
        status: 'pending',
      });
    }
  });

  return proposals.slice(0, 3);
}

// ==========================================
// 6. AI FINANCIAL REPORT GENERATOR
// ==========================================
export function generateFinancialReport(params: {
  period: 'daily' | 'weekly' | 'monthly';
  transactions: Transaction[];
  categories: Category[];
  budgets: Budget[];
  accounts: Account[];
  investments: InvestmentItem[];
  debts: Debt[];
  subscriptions: SubscriptionBill[];
  totalIncomeThisMonth: number;
  totalExpenseThisMonth: number;
  currency: Currency;
  language: Language;
}): AIReportSummary {
  const {
    period,
    transactions,
    categories,
    budgets,
    accounts,
    investments,
    debts,
    subscriptions,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    currency,
    language,
  } = params;

  const isBn = language === 'bn';
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const totalBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);
  const netSavings = totalIncomeThisMonth - totalExpenseThisMonth;
  const savingsRate = totalIncomeThisMonth > 0 ? Math.round((netSavings / totalIncomeThisMonth) * 100) : 0;

  // Category breakdown
  const catSpend: Record<string, number> = {};
  transactions
    .filter(t => t.type === 'expense' && t.date.startsWith(currentMonthStr))
    .forEach(t => {
      catSpend[t.categoryId] = (catSpend[t.categoryId] || 0) + t.amount;
    });

  const topCatId = Object.entries(catSpend).sort((a, b) => b[1] - a[1])[0]?.[0];
  const topCat = categories.find(c => c.id === topCatId);
  const topCategoryName = isBn ? topCat?.nameBn || 'অন্যান্য' : topCat?.name || 'Other';

  const headlineBn = 
    period === 'monthly'
      ? `মাসিক ফাইন্যান্সিয়াল অডিট: নিট সঞ্চয় ${currency.symbol}${netSavings.toLocaleString()} (${savingsRate}%)`
      : period === 'weekly'
      ? `সাপ্তাহিক আর্থিক পর্যালোচনায় বাজেট ও খরচের ভারসাম্য`
      : `দৈনিক আর্থিক সামারি ও আজকের খরচের গতিপ্রকৃতি`;

  const headlineEn = 
    period === 'monthly'
      ? `Monthly Financial Audit: Net Savings of ${currency.symbol}${netSavings.toLocaleString()} (${savingsRate}%)`
      : period === 'weekly'
      ? `Weekly Financial Performance & Cash Runway Update`
      : `Daily Financial Briefing & Expense Overview`;

  const highlightsBn = [
    `মোট আয়: ${currency.symbol}${totalIncomeThisMonth.toLocaleString()} | মোট ব্যয়: ${currency.symbol}${totalExpenseThisMonth.toLocaleString()}`,
    `সবচেয়ে বেশি খরচ হয়েছে "${topCategoryName}" খাতে (${currency.symbol}${(catSpend[topCatId || ''] || 0).toLocaleString()})।`,
    `মোট লিকুইড ব্যালেন্স: ${currency.symbol}${totalBalance.toLocaleString()} (সঞ্চয়ের হার: ${savingsRate}%)`,
    `অ্যাক্টিভ সাবস্ক্রিপশন ও বিল: ${subscriptions.filter(s => s.status === 'active').length}টি।`,
  ];

  const highlightsEn = [
    `Total Income: ${currency.symbol}${totalIncomeThisMonth.toLocaleString()} | Outflows: ${currency.symbol}${totalExpenseThisMonth.toLocaleString()}`,
    `Dominant expense sector is "${topCategoryName}" (${currency.symbol}${(catSpend[topCatId || ''] || 0).toLocaleString()}).`,
    `Total liquid balance across wallets: ${currency.symbol}${totalBalance.toLocaleString()} (Savings rate: ${savingsRate}%)`,
    `Active monitored bills & subscriptions: ${subscriptions.filter(s => s.status === 'active').length}`,
  ];

  const actionableStepsBn = [
    `"${topCategoryName}" খাতের অপ্রয়োজনীয় অংশ চিহ্নিত করে আগামী সপ্তাহে অন্তত ১০% সাশ্রয় করুন।`,
    `বাজেট অতিক্রান্ত হওয়ার আগেই দৈনিক খরচের গতি নিয়ন্ত্রণ করুন।`,
    `আগামী ৭ দিনের জরুরি বিল ও পাওনা পরিশোধের জন্য ক্যাশ আলাদা রাখুন।`,
  ];

  const actionableStepsEn = [
    `Review discretionary spend in "${topCategoryName}" to capture 10% instant savings next week.`,
    `Regulate daily spending run-rate to safeguard monthly budget ceilings.`,
    `Set aside earmarked cash for imminent 7-day bill obligations.`,
  ];

  return {
    period,
    generatedAt: new Date().toISOString(),
    headlineBn,
    headlineEn,
    keyMetrics: {
      income: totalIncomeThisMonth,
      expense: totalExpenseThisMonth,
      netSavings,
      savingsRate,
      topCategory: topCategoryName,
      budgetStatus: budgets.length > 0 ? `${budgets.length}টি বাজেট সক্রিয়` : 'বাজেট নেই',
      netWorth: totalBalance,
    },
    highlightsBn,
    highlightsEn,
    actionableStepsBn,
    actionableStepsEn,
  };
}

// ==========================================
// 7. NATURAL LANGUAGE FINANCIAL ASSISTANT & COMMAND ENGINE
// ==========================================
export function processFinancialAICommand(params: {
  userInput: string;
  transactions: Transaction[];
  categories: Category[];
  accounts: Account[];
  budgets: Budget[];
  goals: SavingsGoal[];
  debts: Debt[];
  subscriptions: SubscriptionBill[];
  digitalCards: DigitalCard[];
  investments: InvestmentItem[];
  totalIncomeThisMonth: number;
  totalExpenseThisMonth: number;
  currency: Currency;
  language: Language;
}): {
  response: string;
  actionProposal?: AIActionProposal;
  activityLog?: Omit<AIActivityEvent, 'id' | 'timestamp'>;
} {
  const {
    userInput,
    transactions,
    categories,
    accounts,
    budgets,
    goals,
    debts,
    subscriptions,
    digitalCards,
    investments,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    currency,
    language,
  } = params;

  const query = userInput.toLowerCase().trim();
  const isBn = language === 'bn';
  const sym = currency.symbol;
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const totalBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);

  // 1. Transaction Creation Command ("Add 500 taka grocery expense today", "বাজার ৫০০ টাকা যোগ করো")
  const amountMatch = query.match(/(\d+[\d,]*)\s*(?:tk|taka|টাকা|bdt)?/i);
  const isExpenseIntent = query.includes('add') || query.includes('যোগ') || query.includes('খরচ') || query.includes('expense') || query.includes('spent') || query.includes('কিনেছি');
  if (amountMatch && isExpenseIntent && (query.includes('add') || query.includes('যোগ') || query.includes('করো') || query.includes('record'))) {
    const rawNum = parseInt(amountMatch[1].replace(/,/g, ''), 10);
    if (!isNaN(rawNum) && rawNum > 0) {
      // Detect category
      let matchedCat = categories.find(c => c.id === 'cat-others');
      if (query.includes('grocery') || query.includes('বাজার') || query.includes('সদাই') || query.includes('চাল') || query.includes('তেল')) {
        matchedCat = categories.find(c => c.id === 'cat-grocery') || matchedCat;
      } else if (query.includes('food') || query.includes('খাবার') || query.includes('বিরিয়ানি') || query.includes('নাস্তা') || query.includes('চা') || query.includes('রেস্তোরাঁ')) {
        matchedCat = categories.find(c => c.id === 'cat-food') || matchedCat;
      } else if (query.includes('transport') || query.includes('রিকশা') || query.includes('উবার') || query.includes('ভাড়া') || query.includes('বাস') || query.includes('তেল')) {
        matchedCat = categories.find(c => c.id === 'cat-transport') || matchedCat;
      } else if (query.includes('medicine') || query.includes('ওষুধ') || query.includes('ডাক্তার')) {
        matchedCat = categories.find(c => c.id === 'cat-health') || matchedCat;
      }

      const catName = isBn ? matchedCat?.nameBn || matchedCat?.name : matchedCat?.name;
      const targetAccount = accounts[0] || { id: 'acc-cash', name: 'Cash', nameBn: 'নগদ ক্যাশ' };

      const proposal: AIActionProposal = {
        id: `prop-tx-${Date.now()}`,
        type: 'create_transaction',
        title: isBn ? `নতুন খরচ এন্ট্রি: ${sym}${rawNum.toLocaleString()}` : `Create Expense: ${sym}${rawNum.toLocaleString()}`,
        titleBn: `নতুন খরচ এন্ট্রি: ${sym}${rawNum.toLocaleString()}`,
        description: isBn ? `${catName} খাতে ${sym}${rawNum.toLocaleString()} টাকা খরচের রেকর্ড তৈরি করা হবে।` : `Log ${sym}${rawNum.toLocaleString()} under ${catName}.`,
        descriptionBn: `${catName} খাতে ${sym}${rawNum.toLocaleString()} টাকা খরচের রেকর্ড তৈরি করা হবে।`,
        currentValue: isBn ? 'রেকর্ড নেই' : 'None',
        newValue: `${sym}${rawNum.toLocaleString()} (${catName})`,
        reason: isBn ? `আপনার কমান্ড "${userInput}" অনুযায়ী` : `Parsed from user voice/text command`,
        reasonBn: `আপনার কমান্ড অনুযায়ী`,
        severity: 'info',
        requiresConfirmation: true,
        payload: {
          type: 'expense',
          amount: rawNum,
          categoryId: matchedCat?.id || 'cat-others',
          accountId: targetAccount.id,
          date: new Date().toISOString().split('T')[0],
          time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
          note: userInput,
        },
        createdAt: new Date().toISOString(),
        status: 'pending',
      };

      return {
        response: isBn
          ? `আমি ${catName} খাতে ${sym}${rawNum.toLocaleString()} টাকার একটি খরচ এন্ট্রির প্রস্তাব তৈরি করেছি। নিচে [নিশ্চিত করুন] বোতামে ক্লিক করলেই এটি যুক্ত হবে।`
          : `I have prepared a new expense entry of ${sym}${rawNum.toLocaleString()} under ${catName}. Click [Confirm] below to record it.`,
        actionProposal: proposal,
        activityLog: {
          type: 'categorization',
          title: 'Transaction Parsing',
          titleBn: 'লেনদেন পার্সিং ও প্রস্তাব',
          details: `Parsed command "${userInput}" into ${sym}${rawNum} in ${catName}`,
          detailsBn: `"${userInput}" থেকে ${sym}${rawNum} টাকার লেনদেন প্রস্তাব তৈরি`,
          status: 'pending',
          module: 'Transactions',
        },
      };
    }
  }

  // 2. Spending Query ("How much did I spend this month?", "এই মাসে কত খরচ হয়েছে?")
  if (query.includes('how much') && (query.includes('spend') || query.includes('spent') || query.includes('expense')) || query.includes('কত খরচ') || query.includes('ব্যয় কত')) {
    const netSavings = totalIncomeThisMonth - totalExpenseThisMonth;
    return {
      response: isBn
        ? `এই চলতি মাসে আপনার মোট ব্যয় হয়েছে ${sym}${totalExpenseThisMonth.toLocaleString()}। মোট আয় হয়েছে ${sym}${totalIncomeThisMonth.toLocaleString()}। ফলে বর্তমান নিট সঞ্চয় ${sym}${netSavings.toLocaleString()}।`
        : `You have spent ${sym}${totalExpenseThisMonth.toLocaleString()} this month against an income of ${sym}${totalIncomeThisMonth.toLocaleString()}, giving a net savings of ${sym}${netSavings.toLocaleString()}.`,
      activityLog: {
        type: 'analysis_run',
        title: 'Monthly Spend Query',
        titleBn: 'মাসিক ব্যয়ের হিসাব অনুসন্ধান',
        details: `Answered monthly expense inquiry: ${sym}${totalExpenseThisMonth}`,
        detailsBn: `মাসিক ব্যয়ের অনুসন্ধান উত্তর দেওয়া হয়েছে: ${sym}${totalExpenseThisMonth}`,
        status: 'completed',
        module: 'Analytics',
      },
    };
  }

  // 3. Top Spending Category Query ("Where am I spending the most?", "সবচেয়ে বেশি খরচ কোন খাতে?")
  if (query.includes('where') && query.includes('most') || query.includes('top spend') || query.includes('বেশি খরচ') || query.includes('কোন খাতে')) {
    const catSpend: Record<string, number> = {};
    transactions
      .filter(t => t.type === 'expense' && t.date.startsWith(currentMonthStr))
      .forEach(t => {
        catSpend[t.categoryId] = (catSpend[t.categoryId] || 0) + t.amount;
      });
    const sorted = Object.entries(catSpend).sort((a, b) => b[1] - a[1]);
    if (sorted.length === 0) {
      return {
        response: isBn ? 'এই মাসে এখনও কোনো উল্লেখযোগ্য খরচ রেকর্ড করা হয়নি।' : 'No recorded expenses found for this month yet.',
      };
    }
    const top = sorted[0];
    const cat = categories.find(c => c.id === top[0]);
    const catName = isBn ? cat?.nameBn || cat?.name : cat?.name;
    const pct = totalExpenseThisMonth > 0 ? Math.round((top[1] / totalExpenseThisMonth) * 100) : 0;

    return {
      response: isBn
        ? `এই মাসে আপনার সবচেয়ে বেশি খরচ হয়েছে "${catName}" খাতে—মোট ${sym}${top[1].toLocaleString()} (যা আপনার মোট ব্যয়ের প্রায় ${pct}%)।`
        : `Your top expense category this month is "${catName}" at ${sym}${top[1].toLocaleString()}, accounting for ${pct}% of total spending.`,
      activityLog: {
        type: 'analysis_run',
        title: 'Top Category Query',
        titleBn: 'সর্বোচ্চ খরচের খাত বিশ্লেষণ',
        details: `Identified top sector: ${catName} (${pct}%)`,
        detailsBn: `সর্বোচ্চ খরচের খাত চিহ্নিত: ${catName} (${pct}%)`,
        status: 'completed',
        module: 'Categories',
      },
    };
  }

  // 4. Affordability Query ("Can I afford a new phone?", "Can I afford X?", "কিনতে পারবো?")
  if (query.includes('can i afford') || query.includes('afford') || query.includes('কিনতে পারব') || query.includes('সামর্থ্য')) {
    const uncommittedCash = Math.max(0, totalBalance - 15000);
    return {
      response: isBn
        ? `আপনার বর্তমান মোট ব্যালেন্স ${sym}${totalBalance.toLocaleString()}। আগামী বিল ও জরুরি রিজার্ভ বাদ দিয়ে আপনার নিরাপদ কেনাকাটার সামর্থ্য প্রায় ${sym}${uncommittedCash.toLocaleString()}। কোনো নির্দিষ্ট পণ্যের দাম জানলে আরও নিখুঁত যাচাই করে দিতে পারবো!`
        : `Your liquid cash stands at ${sym}${totalBalance.toLocaleString()}. After obligations and baseline emergency buffer, your safe discretionary spending ceiling is approximately ${sym}${uncommittedCash.toLocaleString()}.`,
    };
  }

  // 5. Upcoming Payments Query ("Show my upcoming payments", "সামনে কী কী বিল দিতে হবে?")
  if (query.includes('upcoming') || query.includes('bill') || query.includes('payment') || query.includes('বিল') || query.includes('পাওনা') || query.includes('কিস্তি')) {
    const activeBills = subscriptions
      .filter(s => s.status === 'active')
      .slice(0, 4);

    if (activeBills.length === 0) {
      return {
        response: isBn ? 'সামনে কোনো পেন্ডিং নিয়মিত বিল বা সাবস্ক্রিপশন নেই।' : 'No upcoming recurring bills or obligations scheduled.',
      };
    }

    const billsList = activeBills
      .map(b => `• ${isBn ? b.nameBn || b.name : b.name}: ${sym}${b.amount.toLocaleString()} (তারিখ: ${b.dueDate})`)
      .join('\n');

    const totalUpcoming = activeBills.reduce((s, b) => s + b.amount, 0);

    return {
      response: isBn
        ? `সামনে পরিশোধযোগ্য বিলসমূহ (মোট ${sym}${totalUpcoming.toLocaleString()}):\n${billsList}`
        : `Upcoming obligations totaling ${sym}${totalUpcoming.toLocaleString()}:\n${billsList}`,
      activityLog: {
        type: 'bill_reminder',
        title: 'Bills Overview',
        titleBn: 'আসন্ন বিলের তালিকা প্রদান',
        details: `Provided list of ${activeBills.length} upcoming bills (${sym}${totalUpcoming})`,
        detailsBn: `${activeBills.length}টি আসন্ন বিলের বিবরণ দেখানো হয়েছে (${sym}${totalUpcoming})`,
        status: 'completed',
        module: 'Bills',
      },
    };
  }

  // 6. Debt Query ("How much debt do I have?", "দেনা-পাওনা কত?")
  if (query.includes('debt') || query.includes('loan') || query.includes('দেনা') || query.includes('পাওনা') || query.includes('ধার')) {
    const borrowed = debts
      .filter(d => d.type === 'borrowed' && !d.settled)
      .reduce((sum, d) => sum + (d.amount - (d.paidAmount || 0)), 0);
    const lent = debts
      .filter(d => d.type === 'lent' && !d.settled)
      .reduce((sum, d) => sum + (d.amount - (d.paidAmount || 0)), 0);

    return {
      response: isBn
        ? `দেনা-পাওনার হিসাব:\n• আপনাকে অন্যকে পরিশোধ করতে হবে (দেনা): ${sym}${borrowed.toLocaleString()}\n• অন্যদের থেকে ফেরত পাবেন (পাওনা): ${sym}${lent.toLocaleString()}\nনিট দেনা/পাওনা ব্যালেন্স: ${sym}${(lent - borrowed).toLocaleString()}`
        : `Debt & Receivable Overview:\n• You owe (Borrowed): ${sym}${borrowed.toLocaleString()}\n• Owed to you (Lent): ${sym}${lent.toLocaleString()}\nNet Balance: ${sym}${(lent - borrowed).toLocaleString()}`,
    };
  }

  // 7. Savings Goal Query ("How much do I need to save for laptop?", "সেভিংস গোল")
  if (query.includes('save') || query.includes('goal') || query.includes('লক্ষ্য') || query.includes('সঞ্চয়')) {
    if (goals.length > 0) {
      const g = goals[0];
      const remaining = Math.max(0, g.targetAmount - g.currentAmount);
      const pct = Math.round((g.currentAmount / (g.targetAmount || 1)) * 100);
      return {
        response: isBn
          ? `আপনার সেভিংস গোল "${isBn ? g.nameBn || g.name : g.name}" এর টার্গেট ${sym}${g.targetAmount.toLocaleString()}। এখন পর্যন্ত সঞ্চয় হয়েছে ${sym}${g.currentAmount.toLocaleString()} (${pct}%)। বাকি রয়েছে ${sym}${remaining.toLocaleString()} (শেষ তারিখ: ${g.deadline})।`
          : `For your goal "${g.name}", target is ${sym}${g.targetAmount.toLocaleString()}. You have saved ${sym}${g.currentAmount.toLocaleString()} (${pct}%), needing ${sym}${remaining.toLocaleString()} more by ${g.deadline}.`,
      };
    }
  }

  // Default intelligent assistant response with full financial snapshot
  return {
    response: isBn
      ? `আমি আপনার সেন্ট্রাল এআই ফাইন্যান্সিয়াল কন্ট্রোল সিস্টেম। বর্তমান পরিসংখ্যান:\n• মোট ব্যালেন্স: ${sym}${totalBalance.toLocaleString()}\n• চলতি মাসের আয়: ${sym}${totalIncomeThisMonth.toLocaleString()}\n• চলতি মাসের ব্যয়: ${sym}${totalExpenseThisMonth.toLocaleString()}\n• নিট সঞ্চয়: ${sym}${(totalIncomeThisMonth - totalExpenseThisMonth).toLocaleString()}\n\nআপনি আমাকে যেকোনো খরচ যোগ করতে, বাজেট বিশ্লেষণ করতে, বিল দেখতে বা ভবিষ্যৎ কেনার সামর্থ্য যাচাই করতে বলতে পারেন!`
      : `I am your Central AI Financial Control System. Current financial snapshot:\n• Liquid Balance: ${sym}${totalBalance.toLocaleString()}\n• Inflows this month: ${sym}${totalIncomeThisMonth.toLocaleString()}\n• Outflows this month: ${sym}${totalExpenseThisMonth.toLocaleString()}\n• Net Savings: ${sym}${(totalIncomeThisMonth - totalExpenseThisMonth).toLocaleString()}\n\nYou can ask me to log expenses, check affordability, audit budgets, inspect upcoming debts, or forecast end-of-month cash flow!`,
  };
}
