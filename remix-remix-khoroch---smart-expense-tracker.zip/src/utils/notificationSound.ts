// Audio chime & Browser Push notification utility for Khoroc

export function playNotificationChime() {
  try {
    const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    const now = ctx.currentTime;

    // Harmonic dual chime (D5 -> A5)
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const gainNode = ctx.createGain();

    osc1.type = 'sine';
    osc1.frequency.setValueAtTime(587.33, now); // D5
    osc1.frequency.exponentialRampToValueAtTime(880, now + 0.12); // A5

    osc2.type = 'triangle';
    osc2.frequency.setValueAtTime(880, now);
    osc2.frequency.exponentialRampToValueAtTime(1174.66, now + 0.15); // D6

    gainNode.gain.setValueAtTime(0.001, now);
    gainNode.gain.exponentialRampToValueAtTime(0.18, now + 0.04);
    gainNode.gain.exponentialRampToValueAtTime(0.0001, now + 0.45);

    osc1.connect(gainNode);
    osc2.connect(gainNode);
    gainNode.connect(ctx.destination);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.48);
    osc2.stop(now + 0.48);

    setTimeout(() => {
      try {
        ctx.close();
      } catch {
        // ignore
      }
    }, 600);
  } catch (e) {
    // Web Audio may be restricted before user gesture
    console.debug('Notification audio chime not played:', e);
  }
}

export async function requestBrowserPushPermission(): Promise<NotificationPermission> {
  if (!('Notification' in window)) {
    return 'denied';
  }
  if (Notification.permission === 'granted') {
    return 'granted';
  }
  return await Notification.requestPermission();
}

export function sendBrowserPushNotification(title: string, body: string, icon = '/vite.svg') {
  if (!('Notification' in window)) return;
  if (Notification.permission !== 'granted') return;

  try {
    new Notification(title, {
      body,
      icon,
      badge: icon,
    });
  } catch (e) {
    console.debug('Push notification failed:', e);
  }
}

export function generateCourteousDebtReminderMessage(
  personName: string,
  amount: number,
  currencySymbol: string,
  dueDate: string,
  type: 'lent' | 'borrowed',
  language: 'bn' | 'en'
): string {
  if (type === 'lent') {
    // I am owed money (পাওনা টাকা তাগাদা)
    if (language === 'bn') {
      return `আসসালামু আলাইকুম ${personName} ভাই/আপু, আশা করি ভালো আছেন। একটি ছোট তাগাদা ছিল—আপনার কাছে ${currencySymbol}${amount.toLocaleString()} পাওনা ছিল (${dueDate} তারিখের মধ্যে দেওয়ার কথা ছিল)। সুবিধা হলে অনুগ্রহ করে টাকাটা ক্লিয়ার করে দিলে খুব উপকার হতো। ধন্যবাদ!`;
    }
    return `Hello ${personName}, hope you are doing well! Just a gentle reminder regarding the ${currencySymbol}${amount.toLocaleString()} due on ${dueDate}. Whenever convenient, please settle it. Thank you!`;
  } else {
    // I owe money (আমি টাকা দেব)
    if (language === 'bn') {
      return `আসসালামু আলাইকুম ${personName} ভাই/আপু, আপনার থেকে নেওয়া ${currencySymbol}${amount.toLocaleString()}-এর হিসাবটি মনে আছে। ইনশাআল্লাহ নির্দিষ্ট সময়ে পরিশোধ করে দিচ্ছি। ধন্যবাদ!`;
    }
    return `Hello ${personName}, I have noted the ${currencySymbol}${amount.toLocaleString()} repayment due on ${dueDate}. I will settle it on time. Thank you!`;
  }
}
