// Multi-currency exchange rate and conversion system for Khoroc

export interface ExchangeRates {
  [currencyCode: string]: number; // Value relative to 1 BDT base
}

// Standard baseline exchange rates (1 unit of currency = X BDT)
export const DEFAULT_BDT_RATES: Record<string, number> = {
  BDT: 1,
  USD: 122.0,
  EUR: 132.5,
  GBP: 155.0,
  INR: 1.45,
  SAR: 32.5,
  AED: 33.2,
};

const STORAGE_KEY_EXCHANGE_RATES = 'khoroc_exchange_rates';

/**
 * Get active exchange rates, merging defaults with user custom overrides
 */
export function getExchangeRates(): Record<string, number> {
  try {
    const saved = localStorage.getItem(STORAGE_KEY_EXCHANGE_RATES);
    if (saved) {
      const parsed = JSON.parse(saved);
      return { ...DEFAULT_BDT_RATES, ...parsed };
    }
  } catch (err) {
    console.error('Failed to load exchange rates from localStorage', err);
  }
  return { ...DEFAULT_BDT_RATES };
}

/**
 * Save custom exchange rates
 */
export function saveExchangeRates(rates: Record<string, number>): void {
  try {
    localStorage.setItem(STORAGE_KEY_EXCHANGE_RATES, JSON.stringify(rates));
  } catch (err) {
    console.error('Failed to save exchange rates', err);
  }
}

/**
 * Converts an amount from one currency to another using BDT as reference pivot.
 * e.g., convertCurrency(10, 'USD', 'BDT') -> 1220 BDT
 * convertCurrency(1220, 'BDT', 'USD') -> 10 USD
 */
export function convertCurrency(
  amount: number,
  fromCode: string,
  toCode: string,
  customRates?: Record<string, number>
): number {
  if (!amount || isNaN(amount)) return 0;
  const from = (fromCode || 'BDT').toUpperCase();
  const to = (toCode || 'BDT').toUpperCase();

  if (from === to) return amount;

  const rates = customRates || getExchangeRates();
  const fromRateInBDT = rates[from] || DEFAULT_BDT_RATES[from] || 1;
  const toRateInBDT = rates[to] || DEFAULT_BDT_RATES[to] || 1;

  // Amount converted to BDT base
  const amountInBDT = amount * fromRateInBDT;
  // Convert BDT base to target currency
  const converted = amountInBDT / toRateInBDT;

  return Math.round(converted * 100) / 100;
}

/**
 * Formats an amount with currency symbol
 */
export function formatCurrencyAmount(
  amount: number,
  currencySymbol: string,
  decimals: number = 0
): string {
  if (isNaN(amount)) return `${currencySymbol}0`;
  const rounded = decimals > 0 ? amount.toFixed(decimals) : Math.round(amount).toLocaleString();
  return `${currencySymbol}${rounded}`;
}
