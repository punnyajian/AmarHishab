import { useEffect, useRef } from 'react';
import { useLockBodyScroll } from './useLockBodyScroll';

interface UseModalBehaviorOptions {
  isOpen: boolean;
  onClose: () => void;
  dismissible?: boolean;
}

/**
 * Reusable hook that handles:
 * 1. Body scroll locking with ref counting
 * 2. Escape key dismissal with stopPropagation
 * 3. Focus restoration to the previously active element upon close
 */
export const useModalBehavior = ({
  isOpen,
  onClose,
  dismissible = true,
}: UseModalBehaviorOptions) => {
  useLockBodyScroll(isOpen);
  const previousActiveElement = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!isOpen) return;

    previousActiveElement.current = document.activeElement as HTMLElement;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && dismissible) {
        e.stopPropagation();
        onClose();
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      if (
        previousActiveElement.current &&
        typeof previousActiveElement.current.focus === 'function'
      ) {
        // Delay slightly or check if connected to avoid focusing detached elements
        if (document.body.contains(previousActiveElement.current)) {
          previousActiveElement.current.focus();
        }
      }
    };
  }, [isOpen, dismissible, onClose]);
};
