/**
 * Bengali Solar Calendar (বঙ্গাব্দ / বাংলা বর্ষপঞ্জিকা) Utility
 * Based on the revised Bangla Academy standard (Bangladesh)
 * - Boishakh to Ashwin (1st 6 months): 31 days each
 * - Kartik to Magh (next 4 months): 30 days each
 * - Falgun: 29 days (30 days in leap year)
 * - Chaitra: 30 days
 */

export interface BengaliDateResult {
  day: number;
  dayBn: string;
  month: string;
  monthIndex: number; // 0 to 11
  monthBn: string;
  monthEn: string;
  year: number;
  yearBn: string;
  season: string;
  seasonBn: string;
  fullDateBn: string; // e.g. "১৫ আশ্বিন, ১৪৩৩ বঙ্গাব্দ"
  shortDateBn: string; // e.g. "১৫ আশ্বিন"
  combinedWithEnglish: string; // e.g. "30 Sep 2026 (১৫ আশ্বিন)"
}

const BENGALI_DIGITS = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];

export const toBengaliNumber = (num: number | string): string => {
  return num
    .toString()
    .split('')
    .map(ch => {
      const parsed = parseInt(ch, 10);
      return !isNaN(parsed) && BENGALI_DIGITS[parsed] !== undefined ? BENGALI_DIGITS[parsed] : ch;
    })
    .join('');
};

const BENGALI_MONTHS = [
  { bn: 'বৈশাখ', en: 'Boishakh', days: 31, seasonBn: 'গ্রীষ্ম', seasonEn: 'Summer' },
  { bn: 'জ্যৈষ্ঠ', en: 'Jaishtha', days: 31, seasonBn: 'গ্রীষ্ম', seasonEn: 'Summer' },
  { bn: 'আষাঢ়', en: 'Asharh', days: 31, seasonBn: 'বর্ষা', seasonEn: 'Monsoon' },
  { bn: 'শ্রাবণ', en: 'Shrabon', days: 31, seasonBn: 'বর্ষা', seasonEn: 'Monsoon' },
  { bn: 'ভাদ্র', en: 'Bhadro', days: 31, seasonBn: 'শরৎ', seasonEn: 'Autumn' },
  { bn: 'আশ্বিন', en: 'Ashwin', days: 31, seasonBn: 'শরৎ', seasonEn: 'Autumn' },
  { bn: 'কার্তিক', en: 'Kartik', days: 30, seasonBn: 'হেমন্ত', seasonEn: 'Late Autumn' },
  { bn: 'অগ্রহায়ণ', en: 'Agrahayan', days: 30, seasonBn: 'হেমন্ত', seasonEn: 'Late Autumn' },
  { bn: 'পৌষ', en: 'Poush', days: 30, seasonBn: 'শীত', seasonEn: 'Winter' },
  { bn: 'মাঘ', en: 'Magh', days: 30, seasonBn: 'শীত', seasonEn: 'Winter' },
  { bn: 'ফাল্গুন', en: 'Falgun', days: 29, seasonBn: 'বসন্ত', seasonEn: 'Spring' }, // 30 in leap year
  { bn: 'চৈত্র', en: 'Chaitra', days: 30, seasonBn: 'বসন্ত', seasonEn: 'Spring' },
];

const isLeapYear = (year: number): boolean => {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
};

/**
 * Converts any Gregorian Date or YYYY-MM-DD string into Bengali Calendar details
 */
export const getBengaliDate = (input: Date | string | number = new Date()): BengaliDateResult => {
  let gDate: Date;
  if (typeof input === 'string') {
    // Parse YYYY-MM-DD safely without timezone shifts
    const parts = input.split('-');
    if (parts.length >= 3) {
      gDate = new Date(parseInt(parts[0], 10), parseInt(parts[1], 10) - 1, parseInt(parts[2], 10));
    } else {
      gDate = new Date(input);
    }
  } else if (typeof input === 'number') {
    gDate = new Date(input);
  } else {
    gDate = input;
  }

  const gYear = gDate.getFullYear();
  const gMonth = gDate.getMonth(); // 0 to 11
  const gDay = gDate.getDate(); // 1 to 31

  // Start date of Boishakh is April 14
  // Bengali year starts on April 14
  // If date is on or after April 14, Bengali year = gYear - 593
  // If date is before April 14, Bengali year = gYear - 594
  const isAfterPohelaBoishakh = gMonth > 3 || (gMonth === 3 && gDay >= 14);
  const bYear = isAfterPohelaBoishakh ? gYear - 593 : gYear - 594;

  // Month durations for the current Bengali cycle
  // Falgun occurs in Gregorian February of gYear (if gMonth < 4) or next year
  const falgunYear = isAfterPohelaBoishakh ? gYear + 1 : gYear;
  const falgunDays = isLeapYear(falgunYear) ? 30 : 29;

  let bMonthIndex = 0;
  let bDay = 1;

  // Exact matching against Gregorian thresholds (Revised Bangladesh Standard)
  if (gMonth === 3) {
    // April: 1-13 Chaitra, 14-30 Boishakh
    if (gDay < 14) {
      bMonthIndex = 11; // Chaitra
      bDay = gDay + 17; // Chaitra starts March 15
    } else {
      bMonthIndex = 0; // Boishakh
      bDay = gDay - 13;
    }
  } else if (gMonth === 4) {
    // May: 1-14 Boishakh (31 days), 15-31 Jaishtha
    if (gDay < 15) {
      bMonthIndex = 0; // Boishakh
      bDay = gDay + 17; // 1 May is 18 Boishakh
    } else {
      bMonthIndex = 1; // Jaishtha
      bDay = gDay - 14;
    }
  } else if (gMonth === 5) {
    // June: 1-14 Jaishtha (31 days), 15-30 Asharh
    if (gDay < 15) {
      bMonthIndex = 1; // Jaishtha
      bDay = gDay + 17;
    } else {
      bMonthIndex = 2; // Asharh
      bDay = gDay - 14;
    }
  } else if (gMonth === 6) {
    // July: 1-15 Asharh (31 days), 16-31 Shrabon
    if (gDay < 16) {
      bMonthIndex = 2; // Asharh
      bDay = gDay + 16;
    } else {
      bMonthIndex = 3; // Shrabon
      bDay = gDay - 15;
    }
  } else if (gMonth === 7) {
    // August: 1-15 Shrabon (31 days), 16-31 Bhadro
    if (gDay < 16) {
      bMonthIndex = 3; // Shrabon
      bDay = gDay + 16;
    } else {
      bMonthIndex = 4; // Bhadro
      bDay = gDay - 15;
    }
  } else if (gMonth === 8) {
    // September: 1-15 Bhadro (31 days), 16-30 Ashwin
    if (gDay < 16) {
      bMonthIndex = 4; // Bhadro
      bDay = gDay + 16;
    } else {
      bMonthIndex = 5; // Ashwin
      bDay = gDay - 15;
    }
  } else if (gMonth === 9) {
    // October: 1-16 Ashwin (31 days), 17-31 Kartik
    if (gDay < 17) {
      bMonthIndex = 5; // Ashwin
      bDay = gDay + 15; // 1 Oct = 16 Ashwin
    } else {
      bMonthIndex = 6; // Kartik
      bDay = gDay - 16;
    }
  } else if (gMonth === 10) {
    // November: 1-15 Kartik (30 days), 16-30 Agrahayan
    if (gDay < 16) {
      bMonthIndex = 6; // Kartik
      bDay = gDay + 15;
    } else {
      bMonthIndex = 7; // Agrahayan
      bDay = gDay - 15;
    }
  } else if (gMonth === 11) {
    // December: 1-15 Agrahayan (30 days), 16-31 Poush
    if (gDay < 16) {
      bMonthIndex = 7; // Agrahayan
      bDay = gDay + 15;
    } else {
      bMonthIndex = 8; // Poush
      bDay = gDay - 15;
    }
  } else if (gMonth === 0) {
    // January: 1-14 Poush (30 days), 15-31 Magh
    if (gDay < 15) {
      bMonthIndex = 8; // Poush
      bDay = gDay + 16;
    } else {
      bMonthIndex = 9; // Magh
      bDay = gDay - 14;
    }
  } else if (gMonth === 1) {
    // February: 1-13 Magh (30 days), 14-28/29 Falgun
    if (gDay < 14) {
      bMonthIndex = 9; // Magh
      bDay = gDay + 17;
    } else {
      bMonthIndex = 10; // Falgun
      bDay = gDay - 13;
    }
  } else if (gMonth === 2) {
    // March: 1-14 Falgun (29/30 days), 15-31 Chaitra
    const falgunTransition = falgunDays === 30 ? 15 : 14;
    if (gDay <= falgunTransition) {
      bMonthIndex = 10; // Falgun
      bDay = gDay + (28 - 13 + (isLeapYear(gYear) ? 1 : 0));
      // clamp to falgun days
      if (bDay > falgunDays) {
        bMonthIndex = 11;
        bDay = 1;
      }
    } else {
      bMonthIndex = 11; // Chaitra
      bDay = gDay - falgunTransition;
    }
  }

  const monthObj = BENGALI_MONTHS[bMonthIndex];
  const dayBn = toBengaliNumber(bDay);
  const yearBn = toBengaliNumber(bYear);

  const fullDateBn = `${dayBn} ${monthObj.bn}, ${yearBn} বঙ্গাব্দ`;
  const shortDateBn = `${dayBn} ${monthObj.bn}`;

  // Formatted English date representation
  const engFormatted = gDate.toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
  });

  const combinedWithEnglish = `${engFormatted} (${shortDateBn})`;

  return {
    day: bDay,
    dayBn,
    month: monthObj.bn,
    monthIndex: bMonthIndex,
    monthBn: monthObj.bn,
    monthEn: monthObj.en,
    year: bYear,
    yearBn,
    season: monthObj.seasonEn,
    seasonBn: monthObj.seasonBn,
    fullDateBn,
    shortDateBn,
    combinedWithEnglish,
  };
};

/**
 * Helper to display both English and Bengali date inline
 * e.g. "30 Sep 2026 · ১৫ আশ্বিন"
 */
export const formatBilingualDate = (
  dateStr: string,
  options: { showBengaliYear?: boolean; separator?: string } = {}
): string => {
  const { showBengaliYear = false, separator = '·' } = options;
  if (!dateStr) return '';

  try {
    const bDate = getBengaliDate(dateStr);
    const bengaliPart = showBengaliYear ? bDate.fullDateBn : bDate.shortDateBn;
    return `${dateStr} ${separator} ${bengaliPart}`;
  } catch {
    return dateStr;
  }
};
