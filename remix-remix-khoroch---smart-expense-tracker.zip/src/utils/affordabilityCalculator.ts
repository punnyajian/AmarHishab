import { Account, Budget, Debt, SubscriptionBill } from '../types';

export type AffordabilityVerdict = 'affordable' | 'stretch' | 'risky';

export interface AffordabilityInput {
  itemName: string;
  price: number;
  categoryId: string;
  priority: 'need' | 'want';
  paymentMode: 'lump_sum' | 'emi';
  emiMonths?: number;
}

export interface AffordabilityResult {
  score: number; // 0 - 100
  verdict: AffordabilityVerdict;
  verdictTitleBn: string;
  verdictTitleEn: string;
  verdictSubtitleBn: string;
  verdictSubtitleEn: string;
  color: string;
  badgeBg: string;
  
  // Financial metrics
  totalLiquidBalance: number;
  balanceAfterPurchase: number;
  balanceRemainingPercent: number;
  workDaysCost: number;
  workHoursCost: number;
  dailyIncomeEstimate: number;
  
  // Checks
  isLiquidSufficient: boolean;
  isEmergencyBufferSafe: boolean; // At least 25% of balance remains or min 5,000
  isUpcomingBillsSafe: boolean;
  upcomingBillsTotal: number;
  isCategoryBudgetSafe: boolean;
  categoryBudgetRemaining: number;
  
  // Action advice
  aiAdviceBn: string;
  aiAdviceEn: string;
  opportunityCostBn: string;
}

export function calculateAffordability(
  input: AffordabilityInput,
  accounts: Account[],
  totalIncomeThisMonth: number,
  totalExpenseThisMonth: number,
  budgets: Budget[],
  subscriptions: SubscriptionBill[],
  debts: Debt[]
): AffordabilityResult {
  const price = Math.max(0, input.price);
  const effectiveCost = input.paymentMode === 'emi' && input.emiMonths
    ? Math.round(price / input.emiMonths)
    : price;

  // 1. Total liquid balance
  const totalLiquidBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);
  const balanceAfterPurchase = totalLiquidBalance - effectiveCost;
  const balanceRemainingPercent = totalLiquidBalance > 0
    ? Math.max(0, Math.round((balanceAfterPurchase / totalLiquidBalance) * 100))
    : 0;

  // 2. Upcoming bills & debts to pay
  const upcomingBillsTotal = subscriptions
    .filter(s => s.status === 'active')
    .reduce((sum, s) => sum + s.amount, 0);

  const debtsToPayTotal = debts
    .filter(d => d.type === 'borrowed' && !d.settled)
    .reduce((sum, d) => sum + (d.amount - (d.paidAmount || 0)), 0);

  const totalCommittedObligations = upcomingBillsTotal + debtsToPayTotal;
  const isUpcomingBillsSafe = balanceAfterPurchase >= totalCommittedObligations;

  // 3. Work Days / Hours Cost (Time Exchange)
  // Assume monthly income if available, or benchmark average 30,000 BDT
  const monthlyIncomeBenchmark = totalIncomeThisMonth > 0 ? totalIncomeThisMonth : Math.max(25000, totalExpenseThisMonth * 1.25);
  const dailyIncomeEstimate = Math.max(500, Math.round(monthlyIncomeBenchmark / 30));
  const hourlyIncomeEstimate = Math.max(60, Math.round(dailyIncomeEstimate / 8));
  
  const workDaysCost = Math.max(1, Math.round(price / dailyIncomeEstimate));
  const workHoursCost = Math.max(1, Math.round(price / hourlyIncomeEstimate));

  // 4. Emergency Buffer & Liquidity Checks
  const isLiquidSufficient = totalLiquidBalance >= effectiveCost;
  const isEmergencyBufferSafe = balanceAfterPurchase >= 5000 && balanceRemainingPercent >= 30;

  // 5. Category Budget Check
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const matchedBudget = budgets.find(b => b.categoryId === input.categoryId && b.month === currentMonthStr);
  const categoryBudgetLimit = matchedBudget?.monthlyLimit || 0;
  const categoryBudgetRemaining = Math.max(0, categoryBudgetLimit);
  const isCategoryBudgetSafe = categoryBudgetLimit === 0 || effectiveCost <= categoryBudgetRemaining;

  // Score calculation (0 to 100)
  let score = 50;

  // Liquidity factor (+30 or -40)
  if (!isLiquidSufficient) {
    score -= 40;
  } else if (balanceRemainingPercent >= 70) {
    score += 25;
  } else if (balanceRemainingPercent >= 45) {
    score += 15;
  } else if (balanceRemainingPercent < 20) {
    score -= 20;
  }

  // Emergency buffer factor
  if (isEmergencyBufferSafe) score += 10;
  else score -= 15;

  // Bills factor
  if (isUpcomingBillsSafe) score += 10;
  else score -= 25;

  // Need vs Want
  if (input.priority === 'need') score += 10;
  else score -= 5;

  // EMI risk
  if (input.paymentMode === 'emi') score -= 5;

  // Clamp score
  score = Math.min(100, Math.max(5, score));

  // Verdict determination
  let verdict: AffordabilityVerdict = 'risky';
  let verdictTitleBn = 'লাল সংকেত · এখন না কেনাই নিরাপদ!';
  let verdictTitleEn = 'Risky · Not Recommended Right Now';
  let verdictSubtitleBn = 'এটি কেনা আপনার নগদ রিজার্ভ ও জরুরি ব্যালেন্সের ওপর বড় চাপ ফেলতে পারে।';
  let verdictSubtitleEn = 'This purchase would severely drain your cash reserves and emergency buffer.';
  let color = '#ef4444';
  let badgeBg = 'bg-rose-50 text-rose-800 border-rose-200';

  if (score >= 75) {
    verdict = 'affordable';
    verdictTitleBn = 'সবুজ সংকেত · অনায়াসে কিনতে পারেন!';
    verdictTitleEn = 'Affordable · Safe to Purchase!';
    verdictSubtitleBn = 'আপনার আর্থিক রিজার্ভ ও চলতি মাসের বাজেট সম্পূর্ণ সুরক্ষিত রয়েছে।';
    verdictSubtitleEn = 'Your liquid cash and monthly commitments remain fully secure.';
    color = '#10b981';
    badgeBg = 'bg-emerald-50 text-emerald-800 border-emerald-200';
  } else if (score >= 50) {
    verdict = 'stretch';
    verdictTitleBn = 'হলুদ সংকেত · কেনা সম্ভব, তবে কিছুটা টাইট হবে';
    verdictTitleEn = 'Moderate Stretch · Possible with Caution';
    verdictSubtitleBn = 'কেনা যাবে, তবে চলতি মাসের অন্যান্য শখের খরচ নিয়ন্ত্রণ করতে হবে।';
    verdictSubtitleEn = 'You can afford this, but it will significantly reduce your disposable cushion.';
    color = '#f59e0b';
    badgeBg = 'bg-amber-50 text-amber-800 border-amber-200';
  }

  // AI Advice
  let aiAdviceBn = '';
  let aiAdviceEn = '';

  if (verdict === 'affordable') {
    aiAdviceBn = `আপনার মোট ব্যালেন্সের মাত্র ${100 - balanceRemainingPercent}% ব্যয় হবে। জরুরি তহবিলে পর্যাপ্ত ব্যালেন্স থাকায় আপনি নির্দ্বিধায় এটি কিনতে পারেন।`;
    aiAdviceEn = `This will only consume ${100 - balanceRemainingPercent}% of your liquid funds. Your cash buffer remains healthy.`;
  } else if (verdict === 'stretch') {
    aiAdviceBn = `এটি কেনার পর আপনার হাতে জরুরি রিজার্ভ কিছুটা কমে যাবে। ৩০ দিনের উইশলিস্ট রুল প্রয়োগ করে ২ সপ্তাহ অপেক্ষা করা বা কিস্তিতে নেওয়া বিবেচনা করতে পারেন।`;
    aiAdviceEn = `Your cash cushion will dip noticebly. Consider a 14-day cooling wait or creating a mini savings goal.`;
  } else {
    aiAdviceBn = `বর্তমানে আপনার ব্যালেন্স অপর্যাপ্ত অথবা আসন্ন বিল ও দায়ের তুলনায় ঝুঁকি বেশি। এটি কিনতে আপনার প্রায় ${workDaysCost} দিনের সম্পূর্ণ আয় প্রয়োজন। এখনই না কিনে সঞ্চয় লক্ষ্য তৈরি করুন।`;
    aiAdviceEn = `This poses high liquidity risk against your commitments. It equals ${workDaysCost} work-days of income. Create a savings goal instead.`;
  }

  const opportunityCostBn = `এই ৳${price.toLocaleString('bn-BD')} টাকা আপনার প্রায় ${workDaysCost} দিন (${workHoursCost} কর্মঘণ্টা) পরিশ্রমের সমপরিমাণ।`;

  return {
    score,
    verdict,
    verdictTitleBn,
    verdictTitleEn,
    verdictSubtitleBn,
    verdictSubtitleEn,
    color,
    badgeBg,
    totalLiquidBalance,
    balanceAfterPurchase,
    balanceRemainingPercent,
    workDaysCost,
    workHoursCost,
    dailyIncomeEstimate,
    isLiquidSufficient,
    isEmergencyBufferSafe,
    isUpcomingBillsSafe,
    upcomingBillsTotal,
    isCategoryBudgetSafe,
    categoryBudgetRemaining,
    aiAdviceBn,
    aiAdviceEn,
    opportunityCostBn,
  };
}
