import { Transaction, Category, MoneyLeakItem, MoneyLeakAnalysis, MoneyLeakSeverity } from '../types';

interface LeakPattern {
  id: string;
  title: string;
  titleBn: string;
  categoryName: string;
  categoryNameBn: string;
  icon: string;
  color: string;
  maxAmount: number;
  keywords: string[];
  recommendation: string;
  recommendationBn: string;
}

const PREDEFINED_LEAK_PATTERNS: LeakPattern[] = [
  {
    id: 'leak-tea-snacks',
    title: 'Daily Tea, Coffee & Street Snacks',
    titleBn: 'দৈনিক চা, কফি ও টংয়ের নাস্তা',
    categoryName: 'Food & Dining',
    categoryNameBn: 'খাবার ও রেস্তোরাঁ',
    icon: 'Coffee',
    color: '#f59e0b',
    maxAmount: 350,
    keywords: [
      'চা', 'টং', 'কফি', 'নাস্তা', 'ঝালমুড়ি', 'ফুচকা', 'বিস্কুট', 'পান', 'সিগারেট', 'আইসক্রিম', 'ড্রিংকস', 'কোল্ড ড্রিংকস', 'সমুচা', 'সিঙ্গারা', 'মিষ্টি', 'চা-নাস্তা',
      'tea', 'coffee', 'snack', 'snacks', 'biscuit', 'smoke', 'cigarette', 'coke', 'pepsi', 'juice', 'bakery'
    ],
    recommendation: 'Cap daily tea & street snacks to ৳50 or brew at home/office to save.',
    recommendationBn: 'অফিস বা বাসায় চা বানিয়ে পান করুন এবং দৈনিক নাস্তার সর্বোচ্চ সীমা ৫০ টাকায় বেঁধে দিন।',
  },
  {
    id: 'leak-short-rides',
    title: 'Short Distance Rickshaw & Auto Rides',
    titleBn: 'স্বল্প দূরত্বের রিকশা ও যাতায়াত ভাড়া',
    categoryName: 'Transport',
    categoryNameBn: 'যাতায়াত ও জ্বালানি',
    icon: 'Car',
    color: '#06b6d4',
    maxAmount: 300,
    keywords: [
      'রিকশা', 'রিকশা ভাড়া', 'লেগুনা', 'ভাড়া', 'সিএনজি', 'উবার', 'পাঠাও', 'অটো', 'ট্যাক্সি',
      'rickshaw', 'auto', 'uber', 'pathao', 'fare', 'cng', 'transport', 'commute'
    ],
    recommendation: 'Walking 10-15 min short distances keeps you fit and saves transport leaks.',
    recommendationBn: '১০-১৫ মিনিটের ছোট দূরত্বে পায়ে হাঁটার অভ্যাস করলে শরীরও সুস্থ থাকে এবং ভাড়া বাঁচে।',
  },
  {
    id: 'leak-delivery-fees',
    title: 'Food Delivery & Packaging Fees',
    titleBn: 'অনলাইন খাবার ডেলিভারি ও প্যাকেজিং চার্জ',
    categoryName: 'Food & Dining',
    categoryNameBn: 'খাবার ও রেস্তোরাঁ',
    icon: 'ShoppingBag',
    color: '#ec4899',
    maxAmount: 350,
    keywords: [
      'ডেলিভারি', 'ডেলিভারি চার্জ', 'ফুডপ্যান্ডা', 'সার্ভিস ফি', 'টিপস',
      'delivery', 'foodpanda', 'pathao food', 'fee', 'charge', 'tips', 'parcel'
    ],
    recommendation: 'Group orders with roommates/colleagues or order for pickup to eliminate fee leaks.',
    recommendationBn: 'বন্ধুদের সাথে অর্ডার শেয়ার করুন অথবা সরাসরি পিক-আপ করে ডেলিভারি চার্জ বাঁচান।',
  },
  {
    id: 'leak-impulse-drinks',
    title: 'Bottled Water & Soft Drinks',
    titleBn: 'বোতলজাত পানি ও কোমল পানীয়',
    categoryName: 'Food & Dining',
    categoryNameBn: 'খাবার ও রেস্তোরাঁ',
    icon: 'Wine',
    color: '#3b82f6',
    maxAmount: 200,
    keywords: [
      'পানি', 'মাম', 'কোমল পানীয়', 'স্প্রাইট', 'কোক', 'মিনারেল ওয়াটার', 'জুস',
      'water', 'mineral water', 'soft drink', 'sprite', 'coke', 'juice', 'shake'
    ],
    recommendation: 'Carrying a reusable personal water bottle eliminates unnecessary bottled water spend.',
    recommendationBn: 'বাইরে যাওয়ার সময় সাথে একটি নিজস্ব পানির বোতল রাখলে বোতলজাত পানির বাড়তি ব্যয় বন্ধ হয়।',
  },
  {
    id: 'leak-mobile-recharge',
    title: 'Micro Mobile Recharges & Internet Packs',
    titleBn: 'খুচরা মোবাইল রিচার্জ ও ছোট এমবি প্যাক',
    categoryName: 'Bills & Utilities',
    categoryNameBn: 'বিদ্যুৎ ও ইন্টারনেট বিল',
    icon: 'Smartphone',
    color: '#8b5cf6',
    maxAmount: 250,
    keywords: [
      'রিচার্জ', 'ফ্লেক্সিলোড', 'এমবি', 'ইন্টারনেট', 'ডাটা প্যাক', 'মিনিট',
      'recharge', 'flexiload', 'data pack', 'mb', 'minute pack', 'emergency balance'
    ],
    recommendation: 'Buy 30-day combo monthly packages instead of expensive 1-3 day micro packs.',
    recommendationBn: '১-৩ দিনের ছোট প্যাকের বদলে সাশ্রয়ী মাসিক ৩০ দিনের কম্বো প্যাক নিলে প্রায় ৩০% সাশ্রয় হয়।',
  },
  {
    id: 'leak-small-accessories',
    title: 'Impulse Accessories & Cheap Knick-Knacks',
    titleBn: 'হঠাৎ কেনা ছোটখাটো গ্যাজেট ও অ্যাক্সেসরিজ',
    categoryName: 'Shopping',
    categoryNameBn: 'কেনাকাটা ও পোশাক',
    icon: 'Tag',
    color: '#10b981',
    maxAmount: 500,
    keywords: [
      'কভার', 'কেস', 'গ্লাস', 'হেডফোন', 'কেবল', 'দারাজ ছোট', 'স্টিকার',
      'case', 'cover', 'glass', 'cable', 'headphone', 'daraz', 'accessory'
    ],
    recommendation: 'Apply a 48-hour cooling delay before buying non-essential small accessories.',
    recommendationBn: 'অপ্রয়োজনীয় ছোটখাটো গ্যাজেট কেনার আগে ৪৮ ঘণ্টার উইশলিস্ট কুলিং রুল প্রয়োগ করুন।',
  },
];

/**
 * Analyzes transaction records to uncover hidden micro-expenses and money leaks.
 */
export function analyzeMoneyLeaks(
  transactions: Transaction[],
  categories: Category[],
  totalExpenseThisMonth: number,
  language: 'bn' | 'en' = 'bn'
): MoneyLeakAnalysis {
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  
  // Filter all expense transactions
  const expenses = transactions.filter(t => t.type === 'expense');
  
  // We prioritize transactions from the current month if available, else look at recent 60 days
  const currentMonthExpenses = expenses.filter(t => t.date.startsWith(currentMonthStr));
  const activeExpensePool = currentMonthExpenses.length >= 3 ? currentMonthExpenses : expenses.slice(0, 50);

  const matchedTxIdSet = new Set<string>();
  const detectedLeaks: MoneyLeakItem[] = [];

  // 1. Scan against predefined high-probability micro-leak patterns
  for (const pattern of PREDEFINED_LEAK_PATTERNS) {
    const matchedTxs = activeExpensePool.filter(tx => {
      if (tx.amount > pattern.maxAmount) return false;
      const noteLower = (tx.note || '').toLowerCase();
      
      const cat = categories.find(c => c.id === tx.categoryId);
      const catNameLower = (cat?.name || '').toLowerCase();
      const catNameBnLower = (cat?.nameBn || '').toLowerCase();

      // Check if note matches any pattern keyword
      const noteMatches = pattern.keywords.some(kw => noteLower.includes(kw.toLowerCase()));
      // Or category name specifically matches and note is short
      const catMatches = (pattern.categoryName.toLowerCase().includes(catNameLower) || pattern.categoryNameBn.includes(catNameBnLower)) && tx.amount <= pattern.maxAmount * 0.7;

      return noteMatches || catMatches;
    });

    if (matchedTxs.length >= 2) {
      matchedTxs.forEach(t => matchedTxIdSet.add(t.id));
      const totalAmount = matchedTxs.reduce((sum, t) => sum + t.amount, 0);
      const count = matchedTxs.length;
      const averageAmount = Math.round(totalAmount / count);
      const yearlyProjected = totalAmount * 12;
      const savingPotential = Math.round(totalAmount * 0.5); // 50% can be saved

      let severity: MoneyLeakSeverity = 'low';
      if (totalAmount > 1500 || count >= 8) severity = 'high';
      else if (totalAmount > 600 || count >= 4) severity = 'medium';

      detectedLeaks.push({
        id: pattern.id,
        title: pattern.title,
        titleBn: pattern.titleBn,
        categoryName: pattern.categoryName,
        categoryNameBn: pattern.categoryNameBn,
        icon: pattern.icon,
        color: pattern.color,
        monthlyAmount: totalAmount,
        yearlyProjected,
        count,
        averageAmount,
        severity,
        recommendation: pattern.recommendation,
        recommendationBn: pattern.recommendationBn,
        savingPotential,
        matchedTransactionIds: matchedTxs.map(t => t.id),
      });
    }
  }

  // 2. Scan for un-patterned repetitive micro-spending (AI Clustering by repeated note phrases <= 400 BDT)
  const remainingMicroTxs = activeExpensePool.filter(tx => !matchedTxIdSet.has(tx.id) && tx.amount <= 400 && tx.note && tx.note.trim().length > 1);
  const noteClusters: { [cleanNote: string]: Transaction[] } = {};

  remainingMicroTxs.forEach(tx => {
    const clean = tx.note!.trim().toLowerCase();
    if (!noteClusters[clean]) noteClusters[clean] = [];
    noteClusters[clean].push(tx);
  });

  Object.entries(noteClusters).forEach(([noteName, clusterTxs]) => {
    if (clusterTxs.length >= 2) {
      clusterTxs.forEach(t => matchedTxIdSet.add(t.id));
      const totalAmount = clusterTxs.reduce((sum, t) => sum + t.amount, 0);
      const count = clusterTxs.length;
      const averageAmount = Math.round(totalAmount / count);
      const yearlyProjected = totalAmount * 12;
      const savingPotential = Math.round(totalAmount * 0.6);

      const firstTx = clusterTxs[0];
      const cat = categories.find(c => c.id === firstTx.categoryId);

      let severity: MoneyLeakSeverity = 'low';
      if (totalAmount > 1200 || count >= 6) severity = 'high';
      else if (totalAmount > 500 || count >= 3) severity = 'medium';

      const capitalized = noteName.charAt(0).toUpperCase() + noteName.slice(1);

      detectedLeaks.push({
        id: `leak-cluster-${encodeURIComponent(noteName)}`,
        title: `Repeated Micro-Expense: "${capitalized}"`,
        titleBn: `ঘনঘন পুনরাবৃত্ত খুচরা খরচ: "${firstTx.note}"`,
        categoryName: cat?.name || 'General Expense',
        categoryNameBn: cat?.nameBn || 'সাধারণ খরচ',
        icon: 'Receipt',
        color: '#f97316',
        monthlyAmount: totalAmount,
        yearlyProjected,
        count,
        averageAmount,
        severity,
        recommendation: `Track recurring "${capitalized}" entries and consider a weekly cap.`,
        recommendationBn: `"${firstTx.note}" বাবদ ঘনঘন ছোট খরচ বন্ধ করতে একটি সাপ্তাহিক বাজেট ঠিক করুন।`,
        savingPotential,
        matchedTransactionIds: clusterTxs.map(t => t.id),
      });
    }
  });

  // Sort leaks by monthly amount descending (highest leak first)
  detectedLeaks.sort((a, b) => b.monthlyAmount - a.monthlyAmount);

  const totalMonthlyLeak = detectedLeaks.reduce((sum, l) => sum + l.monthlyAmount, 0);
  const totalYearlyLeak = totalMonthlyLeak * 12;
  const leakPercentageOfExpense = totalExpenseThisMonth > 0 ? Math.round((totalMonthlyLeak / totalExpenseThisMonth) * 100) : 0;
  const topLeak = detectedLeaks[0] || null;

  // Insight Summary
  let insightSummaryBn = '';
  let insightSummaryEn = '';

  if (detectedLeaks.length === 0) {
    insightSummaryBn = 'আপনার খরচে কোনো উল্লেখযোগ্য অর্থের অপচয় বা ছোটখাটো লিকেজ পাওয়া যায়নি! খরচের ওপর আপনার নিয়ন্ত্রণ অসাধারণ।';
    insightSummaryEn = 'No recurring micro-spending leaks detected! Your expense discipline is outstanding.';
  } else {
    insightSummaryBn = `চিহ্নিত ${detectedLeaks.length}টি খাতে মাসে মোট ৳${totalMonthlyLeak.toLocaleString('bn-BD')} টাকা অলক্ষ্যে বেরিয়ে যাচ্ছে (বছরে ৳${totalYearlyLeak.toLocaleString('bn-BD')} টাকা)। সবচেয়ে বড় লিকেজ: "${topLeak?.titleBn}"।`;
    insightSummaryEn = `Identified ${detectedLeaks.length} micro-leaks silently draining ৳${totalMonthlyLeak.toLocaleString()}/month (৳${totalYearlyLeak.toLocaleString()} yearly). Top leak: "${topLeak?.title}".`;
  }

  return {
    totalMonthlyLeak,
    totalYearlyLeak,
    leakPercentageOfExpense,
    detectedLeaksCount: detectedLeaks.length,
    leaks: detectedLeaks,
    topLeak,
    insightSummaryBn,
    insightSummaryEn,
  };
}
