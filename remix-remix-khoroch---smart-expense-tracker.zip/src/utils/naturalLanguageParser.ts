import { TransactionType, Account, Category } from '../types';

export interface ParsedTransactionResult {
  success: boolean;
  type: TransactionType;
  amount: number;
  categoryId: string;
  categoryName: string;
  categoryNameBn: string;
  categoryColor: string;
  categoryIcon: string;
  accountId: string;
  accountName: string;
  accountNameBn: string;
  accountColor: string;
  date: string; // YYYY-MM-DD
  time: string; // e.g. "01:30 PM"
  note: string;
  rawInput: string;
  meta: {
    detectedDateLabel?: string;
    detectedTimeLabel?: string;
    detectedCategoryLabel?: string;
    detectedAccountLabel?: string;
  };
  message?: string;
}

/**
 * Intelligent Natural Language Parser for Bengali and English transaction statements.
 * Example inputs supported:
 * - "আজ দুপুরে বন্ধুর সাথে ৪৫০ টাকা খরচ"
 * - "গতকাল রাতে রিকশা ভাড়া ১২০ টাকা ক্যাশ"
 * - "সকালে চা ও নাস্তা ৬৫ বিকাশ"
 * - "বাজার ১২০০ টাকা নগদ"
 * - "বেতন ৫০০০০ ব্যাংক"
 */
export function parseNaturalLanguageTransaction(
  input: string,
  accounts: Account[],
  categories: Category[],
  language: 'bn' | 'en' = 'bn'
): ParsedTransactionResult {
  const trimmed = input.trim();
  if (!trimmed) {
    return {
      success: false,
      type: 'expense',
      amount: 0,
      categoryId: categories[0]?.id || 'cat-others',
      categoryName: categories[0]?.name || 'Other',
      categoryNameBn: categories[0]?.nameBn || 'অন্যান্য',
      categoryColor: '#10b981',
      categoryIcon: 'MoreHorizontal',
      accountId: accounts[0]?.id || 'acc-cash',
      accountName: accounts[0]?.name || 'Cash',
      accountNameBn: accounts[0]?.nameBn || 'নগদ ক্যাশ',
      accountColor: '#10b981',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: '',
      rawInput: input,
      meta: {},
      message: language === 'bn' ? 'অনুগ্রহ করে কিছু লিখুন' : 'Please enter text',
    };
  }

  // 1. Normalize Bengali Digits to Standard Digits
  const bengaliDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
  let normalizedText = trimmed;
  bengaliDigits.forEach((bn, idx) => {
    normalizedText = normalizedText.replaceAll(bn, idx.toString());
  });

  const lower = normalizedText.toLowerCase();

  // 2. Extract Amount
  // Handles formats like "৪৫০ টাকা", "450tk", "৳৪৫০", "450", "৫ হাজার", "5k"
  let amount = 0;
  let detectedAmountMatch = '';

  // Check for "X হাজার" or "Xk"
  const thousandMatch = normalizedText.match(/(\d+(?:\.\d+)?)\s*(?:হাজার|k\b)/i);
  if (thousandMatch) {
    amount = parseFloat(thousandMatch[1]) * 1000;
    detectedAmountMatch = thousandMatch[0];
  } else {
    // Normal numeric match
    const amountMatch = normalizedText.match(/(?:৳|tk|bdt)?\s*(\d+(?:,\d+)*(?:\.\d+)?)\s*(?:টাকা|tk|bdt)?/i);
    if (amountMatch) {
      const cleanNum = amountMatch[1].replace(/,/g, '');
      amount = parseFloat(cleanNum);
      detectedAmountMatch = amountMatch[0];
    }
  }

  if (!amount || isNaN(amount) || amount <= 0) {
    return {
      success: false,
      type: 'expense',
      amount: 0,
      categoryId: categories[0]?.id || 'cat-others',
      categoryName: categories[0]?.name || 'Other',
      categoryNameBn: categories[0]?.nameBn || 'অন্যান্য',
      categoryColor: '#10b981',
      categoryIcon: 'MoreHorizontal',
      accountId: accounts[0]?.id || 'acc-cash',
      accountName: accounts[0]?.name || 'Cash',
      accountNameBn: accounts[0]?.nameBn || 'নগদ ক্যাশ',
      accountColor: '#10b981',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: trimmed,
      rawInput: input,
      meta: {},
      message: language === 'bn' ? 'কোনো টাকার পরিমাণ সনাক্ত করা যায়নি (যেমন: ৪৫০ টাকা)' : 'No valid amount found (e.g. 450)',
    };
  }

  // 3. Determine Date
  const today = new Date();
  let targetDate = new Date(today);
  let detectedDateLabel = language === 'bn' ? 'আজ' : 'Today';

  if (lower.includes('গতকাল') || lower.includes('গত কাল') || lower.includes('yesterday')) {
    targetDate.setDate(today.getDate() - 1);
    detectedDateLabel = language === 'bn' ? 'গতকাল' : 'Yesterday';
  } else if (lower.includes('গত পরশু') || lower.includes('পরশু') || lower.includes('day before yesterday')) {
    targetDate.setDate(today.getDate() - 2);
    detectedDateLabel = language === 'bn' ? 'গত পরশু' : 'Day before yesterday';
  } else if (lower.includes('আগামীকাল') || lower.includes('কালকে') || lower.includes('tomorrow')) {
    targetDate.setDate(today.getDate() + 1);
    detectedDateLabel = language === 'bn' ? 'আগামীকাল' : 'Tomorrow';
  } else if (lower.includes('আজ') || lower.includes('আজকে') || lower.includes('today')) {
    detectedDateLabel = language === 'bn' ? 'আজ' : 'Today';
  }

  const dateStr = `${targetDate.getFullYear()}-${String(targetDate.getMonth() + 1).padStart(2, '0')}-${String(targetDate.getDate()).padStart(2, '0')}`;

  // 4. Determine Time
  let timeStr = today.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  let detectedTimeLabel = '';

  if (lower.includes('দুপুর') || lower.includes('দুপুরে') || lower.includes('lunch') || lower.includes('noon')) {
    timeStr = '01:30 PM';
    detectedTimeLabel = language === 'bn' ? 'দুপুর (০১:৩০ PM)' : 'Lunch (01:30 PM)';
  } else if (lower.includes('সকাল') || lower.includes('সকালে') || lower.includes('morning') || lower.includes('breakfast')) {
    timeStr = '09:00 AM';
    detectedTimeLabel = language === 'bn' ? 'সকাল (০৯:০০ AM)' : 'Morning (09:00 AM)';
  } else if (lower.includes('বিকাল') || lower.includes('বিকালে') || lower.includes('afternoon') || lower.includes('আসর')) {
    timeStr = '05:00 PM';
    detectedTimeLabel = language === 'bn' ? 'বিকাল (০৫:০০ PM)' : 'Afternoon (05:00 PM)';
  } else if (lower.includes('সন্ধ্যা') || lower.includes('সন্ধ্যায়') || lower.includes('evening') || lower.includes('মাগরিব')) {
    timeStr = '07:00 PM';
    detectedTimeLabel = language === 'bn' ? 'সন্ধ্যা (০৭:০০ PM)' : 'Evening (07:00 PM)';
  } else if (lower.includes('রাত') || lower.includes('রাতে') || lower.includes('dinner') || lower.includes('night')) {
    timeStr = '09:30 PM';
    detectedTimeLabel = language === 'bn' ? 'রাত (০৯:৩০ PM)' : 'Night (09:30 PM)';
  }

  // 5. Determine Transaction Type (Income vs Expense)
  let type: TransactionType = 'expense';
  const isIncome = (
    lower.includes('salary') ||
    lower.includes('বেতন') ||
    lower.includes('income') ||
    lower.includes('আয়') ||
    lower.includes('বোনাস') ||
    lower.includes('profit') ||
    lower.includes('লাভ') ||
    lower.includes('মুনাফা') ||
    lower.includes('পেলাম') ||
    lower.includes('পেলোম') ||
    lower.includes('টিউশনি') ||
    lower.includes('ফ্রিল্যান্সিং') ||
    lower.includes('received') ||
    lower.includes('deposited')
  ) && !lower.includes('খরচ') && !lower.includes('দিলাম');

  if (isIncome) {
    type = 'income';
  }

  // 6. Determine Category
  let matchedCategory = categories.find(c => c.type === type) || categories[0];
  let detectedCategoryLabel = '';

  if (type === 'income') {
    const incCat = categories.find(c => c.type === 'income');
    if (incCat) matchedCategory = incCat;
    detectedCategoryLabel = language === 'bn' ? matchedCategory.nameBn || matchedCategory.name : matchedCategory.name;
  } else {
    // Expense Categorization logic
    // Food & Dining
    if (
      lower.includes('খাবার') ||
      lower.includes('খাইলাম') ||
      lower.includes('খেয়েছি') ||
      lower.includes('বন্ধু') ||
      lower.includes('বন্ধুর সাথে') ||
      lower.includes('দুপুর') ||
      lower.includes('লাঞ্চ') ||
      lower.includes('ডিনার') ||
      lower.includes('নাস্তা') ||
      lower.includes('চা') ||
      lower.includes('কফি') ||
      lower.includes('বিরিয়ানি') ||
      lower.includes('কাচ্চি') ||
      lower.includes('রেস্টুরেন্ট') ||
      lower.includes('রেস্তোরাঁ') ||
      lower.includes('হোটেল') ||
      lower.includes('ফুচকা') ||
      lower.includes('বার্গার') ||
      lower.includes('পিৎজা') ||
      lower.includes('মিষ্টি') ||
      lower.includes('food') ||
      lower.includes('lunch') ||
      lower.includes('dinner') ||
      lower.includes('cafe') ||
      lower.includes('snack')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-food') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'খাবার ও রেস্তোরাঁ' : 'Food & Dining';
    }
    // Grocery / Bazar
    else if (
      lower.includes('বাজার') ||
      lower.includes('মুদি') ||
      lower.includes('মুদিখানা') ||
      lower.includes('সবজি') ||
      lower.includes('মাছ') ||
      lower.includes('মাংস') ||
      lower.includes('মুরগি') ||
      lower.includes('চাল') ||
      lower.includes('ডাল') ||
      lower.includes('তেল') ||
      lower.includes('ডিম') ||
      lower.includes('কাঁচাবাজার') ||
      lower.includes('grocery') ||
      lower.includes('bazar') ||
      lower.includes('supermarket')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-grocery') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'বাজার ও মুদিখানা' : 'Groceries';
    }
    // Transport
    else if (
      lower.includes('রিকশা') ||
      lower.includes('বাস') ||
      lower.includes('উবার') ||
      lower.includes('পাঠাও') ||
      lower.includes('সিএনজি') ||
      lower.includes('মেট্রোরেল') ||
      lower.includes('মেট্রো') ||
      lower.includes('ট্রেন') ||
      lower.includes('তেল') ||
      lower.includes('অকটেন') ||
      lower.includes('পেট্রোল') ||
      lower.includes('ভাড়া') ||
      lower.includes('uber') ||
      lower.includes('pathao') ||
      lower.includes('transport') ||
      lower.includes('cng') ||
      lower.includes('fuel')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-transport') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'যাতায়াত ও জ্বালানি' : 'Transport';
    }
    // Housing / Rent
    else if (
      lower.includes('বাসা ভাড়া') ||
      lower.includes('বাড়ি ভাড়া') ||
      lower.includes('রেন্ট') ||
      lower.includes('মেরামত') ||
      lower.includes('rent') ||
      lower.includes('housing')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-rent') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'বাসা ভাড়া' : 'Rent';
    }
    // Bills & Utilities
    else if (
      lower.includes('বিল') ||
      lower.includes('বিদ্যুৎ') ||
      lower.includes('কারেন্ট') ||
      lower.includes('ইন্টারনেট') ||
      lower.includes('ওয়াইফাই') ||
      lower.includes('wifi') ||
      lower.includes('গ্যাস') ||
      lower.includes('পানি') ||
      lower.includes('wasa') ||
      lower.includes('desco') ||
      lower.includes('bill')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-bills') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'বিদ্যুৎ ও ইন্টারনেট বিল' : 'Bills & Utilities';
    }
    // Health & Medicine
    else if (
      lower.includes('ওষুধ') ||
      lower.includes('ঔষধ') ||
      lower.includes('ডাক্তার') ||
      lower.includes('হাসপাতাল') ||
      lower.includes('ফার্মেসি') ||
      lower.includes('টেস্ট') ||
      lower.includes('medicine') ||
      lower.includes('doctor') ||
      lower.includes('health')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-health') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'স্বাস্থ্য ও ওষুধ' : 'Health & Medicine';
    }
    // Shopping
    else if (
      lower.includes('শপিং') ||
      lower.includes('কেনাকাটা') ||
      lower.includes('জামা') ||
      lower.includes('কাপড়') ||
      lower.includes('জুতো') ||
      lower.includes('শার্ট') ||
      lower.includes('প্যান্ট') ||
      lower.includes('shopping') ||
      lower.includes('dress') ||
      lower.includes('cloth')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-shopping') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'কেনাকাটা ও পোশাক' : 'Shopping';
    }
    // Entertainment
    else if (
      lower.includes('সিনেমা') ||
      lower.includes('মুভি') ||
      lower.includes('আড্ডা') ||
      lower.includes('ঘোরাঘুরি') ||
      lower.includes('পার্ক') ||
      lower.includes('entertainment') ||
      lower.includes('movie')
    ) {
      matchedCategory = categories.find(c => c.id === 'cat-entertainment') || categories[0];
      detectedCategoryLabel = language === 'bn' ? 'বিনোদন ও আড্ডা' : 'Entertainment';
    } else {
      matchedCategory = categories.find(c => c.id === 'cat-others') || categories[0];
      detectedCategoryLabel = language === 'bn' ? matchedCategory.nameBn || matchedCategory.name : matchedCategory.name;
    }
  }

  // 7. Determine Account
  let matchedAccount = accounts.find(a => a.type === 'cash') || accounts[0];
  let detectedAccountLabel = language === 'bn' ? 'নগদ ক্যাশ' : 'Cash';

  if (lower.includes('বিকাশ') || lower.includes('bkash')) {
    const bkash = accounts.find(a => a.name.toLowerCase().includes('bkash') || a.id.includes('bkash'));
    if (bkash) {
      matchedAccount = bkash;
      detectedAccountLabel = 'bKash';
    }
  } else if (lower.includes('নগদ') || lower.includes('nagad')) {
    // If the word "নগদ" is explicitly mentioning the MFS brand
    const nagad = accounts.find(a => a.name.toLowerCase().includes('nagad') || a.id.includes('nagad'));
    if (nagad) {
      matchedAccount = nagad;
      detectedAccountLabel = 'Nagad';
    }
  } else if (lower.includes('রকেট') || lower.includes('rocket')) {
    const rocket = accounts.find(a => a.name.toLowerCase().includes('rocket'));
    if (rocket) {
      matchedAccount = rocket;
      detectedAccountLabel = 'Rocket';
    }
  } else if (lower.includes('ব্যাংক') || lower.includes('কার্ড') || lower.includes('bank') || lower.includes('card')) {
    const bank = accounts.find(a => a.type === 'bank' || a.type === 'credit_card');
    if (bank) {
      matchedAccount = bank;
      detectedAccountLabel = bank.name;
    }
  } else if (lower.includes('ক্যাশ') || lower.includes('হাত থেকে') || lower.includes('নগদে') || lower.includes('cash')) {
    const cash = accounts.find(a => a.type === 'cash');
    if (cash) {
      matchedAccount = cash;
      detectedAccountLabel = language === 'bn' ? 'নগদ ক্যাশ' : 'Cash';
    }
  }

  // 8. Generate Clean Note
  // Remove matched amount, filler words, and clean up
  let cleanNote = trimmed;
  if (detectedAmountMatch) {
    cleanNote = cleanNote.replace(detectedAmountMatch, '');
  }

  // Remove common filler words while preserving semantic meaning
  cleanNote = cleanNote
    .replace(/\b(?:টাকা|টাকার|খরচ|হয়েছে|দিলাম|নিলাম|দিয়েছি|পেলোম|পেলাম|tk|bdt)\b/gi, '')
    .replace(/\s+/g, ' ')
    .trim();

  // If cleanNote became empty or just a symbol, fall back to meaningful context or category
  if (!cleanNote || cleanNote.length < 2) {
    cleanNote = language === 'bn'
      ? `${matchedCategory.nameBn || matchedCategory.name} বাবদ খরচ`
      : `${matchedCategory.name} expense`;
  }

  return {
    success: true,
    type,
    amount,
    categoryId: matchedCategory.id,
    categoryName: matchedCategory.name,
    categoryNameBn: matchedCategory.nameBn || matchedCategory.name,
    categoryColor: matchedCategory.color || '#10b981',
    categoryIcon: matchedCategory.icon || 'CircleDot',
    accountId: matchedAccount.id,
    accountName: matchedAccount.name,
    accountNameBn: matchedAccount.nameBn || matchedAccount.name,
    accountColor: matchedAccount.color || '#10b981',
    date: dateStr,
    time: timeStr,
    note: cleanNote,
    rawInput: input,
    meta: {
      detectedDateLabel,
      detectedTimeLabel,
      detectedCategoryLabel,
      detectedAccountLabel,
    },
    message: language === 'bn'
      ? `${dateStr} তারিখে ${amount.toLocaleString()} ৳ (${matchedCategory.nameBn || matchedCategory.name}) যুক্ত হবে`
      : `Will record ${amount.toLocaleString()} on ${dateStr} (${matchedCategory.name})`,
  };
}
