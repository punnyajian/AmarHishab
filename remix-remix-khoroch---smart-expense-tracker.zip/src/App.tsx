import React, { useState, useEffect } from 'react';
import { ExpenseProvider, useExpense } from './context/ExpenseContext';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { MobileBottomNav } from './components/MobileBottomNav';
import { TransactionModal } from './components/TransactionModal';
import { TransferModal } from './components/TransferModal';
import { AIInsightsModal } from './components/AIInsightsModal';
import { ResetConfirmModal } from './components/ResetConfirmModal';

// Views
import { DashboardView } from './components/views/DashboardView';
import { TransactionsView } from './components/views/TransactionsView';
import { BudgetsView } from './components/views/BudgetsView';
import { AnalyticsView } from './components/views/AnalyticsView';
import { WalletsView } from './components/views/WalletsView';
import { GoalsView } from './components/views/GoalsView';
import { DebtsView } from './components/views/DebtsView';
import { SplitBillView } from './components/views/SplitBillView';
import { WishlistView } from './components/views/WishlistView';
import { SubscriptionsView } from './components/views/SubscriptionsView';
import { InvestmentsView } from './components/views/InvestmentsView';
import { TripsView } from './components/views/TripsView';
import { TaxZakatView } from './components/views/TaxZakatView';
import { ChallengesView } from './components/views/ChallengesView';
import { MessView } from './components/views/MessView';
import { BazarView } from './components/views/BazarView';
import { AIControlCenterView } from './components/views/AIControlCenterView';
import { SettingsView } from './components/views/SettingsView';
import { ProfileView } from './components/views/ProfileView';
import { CashflowCalendarView } from './components/views/CashflowCalendarView';
import { AIActionConfirmationModal } from './components/AIActionConfirmationModal';
import { UserAuthModal } from './components/UserAuthModal';
import { NotificationCenterModal } from './components/notifications/NotificationCenterModal';
import { AddReminderModal } from './components/notifications/AddReminderModal';
import { NotificationSettingsModal } from './components/notifications/NotificationSettingsModal';
import { PaymentPriorityView } from './components/views/PaymentPriorityView';
import { OfflineIndicator } from './components/OfflineIndicator';

import { Transaction, TransactionType } from './types';

function AppContent() {
  const {
    activeTab,
    setActiveTab,
    activeActionConfirmationModal,
    setActiveActionConfirmationModal,
    executeAIAction,
    isAuthModalOpen,
    setIsAuthModalOpen,
    toggleSidebar,
    isNotificationCenterOpen,
    setIsNotificationCenterOpen,
    isAddReminderModalOpen,
    setIsAddReminderModalOpen,
    isNotificationSettingsModalOpen,
    setIsNotificationSettingsModalOpen,
  } = useExpense();

  // Modals state
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [initialTxType, setInitialTxType] = useState<TransactionType>('expense');
  const [editingTransaction, setEditingTransaction] = useState<Transaction | null>(null);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);

  // Determine whether any modal or overlay is active
  const isAnyModalOpen =
    isAddModalOpen ||
    isTransferModalOpen ||
    isAIModalOpen ||
    !!activeActionConfirmationModal ||
    isAuthModalOpen ||
    isNotificationCenterOpen ||
    isAddReminderModalOpen ||
    isNotificationSettingsModalOpen;

  // Global modal scroll lock effect ensuring no background scroll leakage
  useEffect(() => {
    if (isAnyModalOpen) {
      document.body.style.overflow = 'hidden';
      document.documentElement.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    }

    return () => {
      document.body.style.overflow = '';
      document.documentElement.style.overflow = '';
    };
  }, [isAnyModalOpen]);

  // Escape key handler to close active modal cleanly
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        if (isAddModalOpen) {
          setIsAddModalOpen(false);
          setEditingTransaction(null);
        } else if (isTransferModalOpen) {
          setIsTransferModalOpen(false);
        } else if (isAIModalOpen) {
          setIsAIModalOpen(false);
        } else if (isAuthModalOpen) {
          setIsAuthModalOpen(false);
        } else if (activeActionConfirmationModal) {
          setActiveActionConfirmationModal(null);
        }
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    isAddModalOpen,
    isTransferModalOpen,
    isAIModalOpen,
    isAuthModalOpen,
    activeActionConfirmationModal,
    setActiveActionConfirmationModal,
    setIsAuthModalOpen,
  ]);

  const handleOpenAdd = (type: TransactionType = 'expense') => {
    setEditingTransaction(null);
    setInitialTxType(type);
    setIsAddModalOpen(true);
  };

  const handleEditTx = (tx: Transaction) => {
    setEditingTransaction(tx);
    setIsAddModalOpen(true);
  };

  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView
            onOpenAddModal={handleOpenAdd}
            onOpenTransferModal={() => setIsTransferModalOpen(true)}
            onEditTx={handleEditTx}
          />
        );
      case 'calendar':
        return <CashflowCalendarView onOpenAddModal={() => handleOpenAdd('expense')} />;
      case 'ai_control':
        return <AIControlCenterView />;
      case 'transactions':
        return (
          <TransactionsView
            onOpenAddModal={() => handleOpenAdd('expense')}
            onEditTx={handleEditTx}
          />
        );
      case 'subscriptions':
        return <SubscriptionsView />;
      case 'investments':
        return <InvestmentsView />;
      case 'trips':
        return <TripsView />;
      case 'tax_zakat':
        return <TaxZakatView />;
      case 'challenges':
        return <ChallengesView />;
      case 'mess':
        return <MessView />;
      case 'bazar':
        return <BazarView />;
      case 'budgets':
        return <BudgetsView />;
      case 'analytics':
        return <AnalyticsView />;
      case 'wallets':
        return <WalletsView onOpenTransferModal={() => setIsTransferModalOpen(true)} />;
      case 'goals':
        return <GoalsView />;
      case 'debts':
        return <DebtsView />;
      case 'payment_priority':
        return <PaymentPriorityView />;
      case 'split':
        return <SplitBillView />;
      case 'wishlist':
        return <WishlistView />;
      case 'settings':
        return <SettingsView />;
      case 'profile':
        return <ProfileView onBack={() => setActiveTab('dashboard')} />;
      default:
        return (
          <DashboardView
            onOpenAddModal={handleOpenAdd}
            onOpenTransferModal={() => setIsTransferModalOpen(true)}
            onEditTx={handleEditTx}
          />
        );
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAF9] flex font-sans text-slate-800 relative">
      
      {/* Left Full-Height Sidebar */}
      <Sidebar />

      {/* Main Right Content Section (Navbar + Main View) */}
      <div className="flex-1 flex flex-col min-w-0">
        <Navbar onToggleMobileMenu={toggleSidebar} />

        <main className="flex-1 px-4 sm:px-6 lg:px-8 py-5 w-full max-w-[1520px] mx-auto overflow-x-hidden pb-28 md:pb-8">
          {renderActiveView()}
        </main>
      </div>

      {/* Mobile Bottom Navigation Bar */}
      <MobileBottomNav
        onOpenAddModal={() => handleOpenAdd('expense')}
        onOpenTransferModal={() => setIsTransferModalOpen(true)}
        onOpenAIModal={() => setIsAIModalOpen(true)}
      />

      {/* Modals */}
      <TransactionModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingTransaction(null);
        }}
        editTx={editingTransaction}
        initialType={initialTxType}
      />

      <TransferModal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
      />

      <AIInsightsModal
        isOpen={isAIModalOpen}
        onClose={() => setIsAIModalOpen(false)}
      />

      <AIActionConfirmationModal
        isOpen={!!activeActionConfirmationModal}
        proposal={activeActionConfirmationModal}
        onClose={() => setActiveActionConfirmationModal(null)}
        onConfirm={(proposal) => {
          executeAIAction(proposal.id);
          setActiveActionConfirmationModal(null);
        }}
      />

      <ResetConfirmModal />

      <UserAuthModal
        isOpen={isAuthModalOpen}
        onClose={() => setIsAuthModalOpen(false)}
      />

      {/* Advanced Reminder & Notification System Modals */}
      <NotificationCenterModal
        isOpen={isNotificationCenterOpen}
        onClose={() => setIsNotificationCenterOpen(false)}
        onOpenAddExpenseModal={() => handleOpenAdd('expense')}
      />

      <AddReminderModal
        isOpen={isAddReminderModalOpen}
        onClose={() => setIsAddReminderModalOpen(false)}
      />

      <NotificationSettingsModal
        isOpen={isNotificationSettingsModalOpen}
        onClose={() => setIsNotificationSettingsModalOpen(false)}
      />

      {/* Reliable Offline Workbox Status Indicator */}
      <OfflineIndicator />

    </div>
  );
}

export default function App() {
  return (
    <ExpenseProvider>
      <AppContent />
    </ExpenseProvider>
  );
}
