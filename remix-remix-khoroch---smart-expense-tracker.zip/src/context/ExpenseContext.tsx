import React, { createContext, useContext, useState, useEffect, useMemo, useCallback, ReactNode } from 'react';
import {
  Transaction,
  Category,
  Account,
  Budget,
  SavingsGoal,
  Debt,
  BillSplit,
  Currency,
  Language,
  ActiveTab,
  TransactionType,
  WishlistItem,
  WishlistStatus,
  SafeToSpendConfig,
  DigitalCard,
  SubscriptionBill,
  MessData,
  MessMember,
  MessConfig,
  MessBazarEntry,
  MessDepositEntry,
  MessFixedCostItem,
  MessBazarScheduleItem,
  DailyMealEntry,
  InvestmentItem,
  GoldMarketRate,
  TripItem,
  TripMember,
  TripExpense,
  TripPackingItem,
  TripItineraryDay,
  SavingsChallenge,
  NoSpendRecord,
  GamificationBadge,
  BazarItem,
  BazarMarketCommodity,
  AIHealthScore,
  AIActionProposal,
  AIActivityEvent,
  AIMemoryPreferences,
  AIAnomalyRisk,
  AINetWorthBreakdown,
  AICashFlowForecast,
  AIChatMessage,
  AIReportSummary,
  AppNotification,
  CustomReminder,
  NotificationSettings,
  NotificationType,
  NotificationSeverity,
  PaymentObligation,
  RankedObligation,
  PriorityScoreBreakdown,
  PaymentEngineConfig,
  CashFlowAnalysis,
  PaymentStrategyType,
  WhatIfSimulationInput,
  WhatIfSimulationResult,
  CustomObligationInput,
  AppUser,
  AuthSession,
  SyncStatus,
  SecurityQuestionItem,
  SecurityQuestionPrompt,
} from '../types';
import { AuthClient } from '../services/authClient';
import {
  DEFAULT_PRIORITY_CONFIG,
  extractAllObligations,
  rankObligations,
  runWhatIfSimulation,
} from '../services/paymentPriorityEngine';
import {
  playNotificationChime,
  sendBrowserPushNotification,
  requestBrowserPushPermission,
  generateCourteousDebtReminderMessage,
} from '../utils/notificationSound';
import {
  DEFAULT_ACCOUNTS,
  DEFAULT_CATEGORIES,
  DEFAULT_TRANSACTIONS,
  DEFAULT_BUDGETS,
  DEFAULT_GOALS,
  DEFAULT_DEBTS,
  DEFAULT_BILL_SPLITS,
  DEFAULT_WISHLIST_ITEMS,
  DEFAULT_DIGITAL_CARDS,
  DEFAULT_SUBSCRIPTION_BILLS,
  DEFAULT_MESS_DATA,
  DEFAULT_INVESTMENTS,
  DEFAULT_GOLD_RATES,
  DEFAULT_TRIPS,
  DEFAULT_SAVINGS_CHALLENGES,
  DEFAULT_NO_SPEND_RECORDS,
  DEFAULT_GAMIFICATION_BADGES,
  DEFAULT_BAZAR_ITEMS,
  DEFAULT_BAZAR_COMMODITIES,
  DEFAULT_AI_MEMORY_PREFERENCES,
  DEFAULT_AI_ACTIVITY_LOGS,
  CURRENCIES,
  TRANSLATIONS,
} from '../data/defaultData';
import { parseNaturalLanguageTransaction } from '../utils/naturalLanguageParser';
import {
  calculateFinancialHealthScore,
  detectAnomaliesAndRisks,
  calculateNetWorthIntelligence,
  calculateCashFlowForecast,
  generateBudgetRecommendations,
  generateFinancialReport,
  processFinancialAICommand,
} from '../services/aiFinancialEngine';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, loginWithGoogle, logoutUser, testConnection } from '../services/firebase';
import {
  ensureUserProfile,
  fetchUserCloudData,
  syncSaveTransaction,
  syncDeleteTransaction,
  syncSaveAccount,
  syncDeleteAccount,
  syncSaveCategory,
  syncSaveBudget,
  syncDeleteBudget,
  syncSaveGoal,
  syncDeleteGoal,
  syncSaveDebt,
  syncDeleteDebt,
  syncSaveSubscription,
  syncDeleteSubscription,
  syncSaveBazarItem,
  syncDeleteBazarItem,
  syncSaveCard,
  syncDeleteCard,
  syncSaveSettings,
  syncSaveExtra,
  uploadLocalDataToCloud,
} from '../services/firebaseSyncService';

interface ExpenseContextType {
  // Username-Only Cloud Auth & Isolation
  currentUser: AppUser | null;
  authSession: AuthSession | null;
  isAuthLoading: boolean;
  isCloudSyncing: boolean;
  syncStatus: SyncStatus;
  lastSyncedTime: Date | null;
  authError: string | null;
  syncError: string | null;

  registerUser: (username: string, password: string, confirmPassword: string, securityQuestions: SecurityQuestionItem[]) => Promise<void>;
  loginUser: (username: string, password: string) => Promise<void>;
  handleGoogleSignIn?: () => Promise<void>;
  handleSignOut: () => Promise<void>;
  changePassword: (currentPassword: string, newPassword: string, confirmNewPassword: string) => Promise<void>;
  checkUsernameAvailable: (username: string) => Promise<{ available: boolean; reason?: string }>;
  getSecurityQuestionsForRecovery: (username: string) => Promise<{ exists: boolean; questions: SecurityQuestionPrompt[] }>;
  verifySecurityAnswersForRecovery: (username: string, answers: { id: string; question: string; answer: string }[]) => Promise<{ resetToken: string }>;
  resetPasswordWithToken: (resetToken: string, newPassword: string, confirmNewPassword: string) => Promise<void>;
  updateSecurityQuestions: (currentPassword: string, questions: SecurityQuestionItem[]) => Promise<void>;
  syncAllToCloudNow: () => Promise<void>;
  pullFromCloudNow: () => Promise<void>;
  isAuthModalOpen: boolean;
  setIsAuthModalOpen: (open: boolean) => void;

  transactions: Transaction[];
  categories: Category[];
  accounts: Account[];
  budgets: Budget[];
  goals: SavingsGoal[];
  debts: Debt[];
  billSplits: BillSplit[];
  wishlistItems: WishlistItem[];
  digitalCards: DigitalCard[];
  subscriptions: SubscriptionBill[];
  currency: Currency;
  language: Language;
  activeTab: ActiveTab;
  setActiveTab: (tab: ActiveTab) => void;
  walletSubTab: 'cards' | 'accounts';
  setWalletSubTab: (tab: 'cards' | 'accounts') => void;
  subscriptionFilterTab: 'all' | 'due' | 'utility' | 'telecom' | 'digital' | 'paid';
  setSubscriptionFilterTab: (tab: 'all' | 'due' | 'utility' | 'telecom' | 'digital' | 'paid') => void;
  setLanguage: (lang: Language) => void;
  setCurrency: (currency: Currency) => void;
  
  // Sidebar Navigation State & Controls
  isSidebarOpen: boolean;
  setIsSidebarOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  toggleSidebar: () => void;
  isSidebarCollapsed: boolean;
  setIsSidebarCollapsed: (collapsed: boolean | ((prev: boolean) => boolean)) => void;
  toggleSidebarCollapsed: () => void;
  
  // Safe-to-Spend
  safeToSpendConfig: SafeToSpendConfig;
  setSafeToSpendConfig: (config: SafeToSpendConfig) => void;
  todayExpense: number;
  todayDailySafeLimit: number;
  todayRemainingSafeToSpend: number;
  safeToSpendPercentUsed: number;
  safeToSpendStatus: 'safe' | 'caution' | 'exceeded';
  daysRemainingInMonth: number;
  totalDaysInMonth: number;
  monthlySpendingCap: number;
  remainingMonthlyCap: number;
  projectedTomorrowSafeLimit: number;

  // Transactions
  addTransaction: (tx: Omit<Transaction, 'id'>) => void;
  editTransaction: (tx: Transaction) => void;
  deleteTransaction: (id: string) => void;

  // Accounts
  addAccount: (acc: Omit<Account, 'id'>) => void;
  editAccount: (acc: Account) => void;
  deleteAccount: (id: string) => void;
  transferMoney: (sourceAccountId: string, targetAccountId: string, amount: number, note: string, date: string) => void;

  // Budgets
  setCategoryBudget: (categoryId: string, limit: number) => void;
  deleteBudget: (id: string) => void;

  // Goals
  addGoal: (goal: Omit<SavingsGoal, 'id'>) => void;
  updateGoalSavings: (goalId: string, amountToAdd: number) => void;
  deleteGoal: (id: string) => void;

  // Debts
  addDebt: (debt: Omit<Debt, 'id' | 'createdAt'>) => void;
  recordDebtPayment: (debtId: string, paymentAmount: number) => void;
  toggleDebtSettled: (debtId: string) => void;
  deleteDebt: (id: string) => void;

  // Bill Splits
  addBillSplit: (split: Omit<BillSplit, 'id'>) => void;
  toggleSplitMemberPaid: (splitId: string, memberId: string) => void;
  deleteBillSplit: (splitId: string) => void;

  // Wishlist & Impulse Buy Delay
  addWishlistItem: (item: Omit<WishlistItem, 'id' | 'status'> & { status?: WishlistStatus }) => void;
  editWishlistItem: (item: WishlistItem) => void;
  deleteWishlistItem: (id: string) => void;
  markWishlistPurchased: (id: string, accountId?: string, createExpenseTx?: boolean) => void;
  dropWishlistItem: (id: string) => void;
  totalMoneySavedFromImpulse: number;
  activeCoolingCount: number;
  readyDecisionCount: number;

  // Google Wallet / Digital Cards
  addDigitalCard: (card: Omit<DigitalCard, 'id' | 'addedAt'>) => void;
  editDigitalCard: (card: DigitalCard) => void;
  deleteDigitalCard: (id: string) => void;
  setDefaultDigitalCard: (id: string) => void;
  toggleFreezeDigitalCard: (id: string) => void;
  simulateCardTapPayment: (cardId: string, amount: number, note: string, categoryId?: string) => { success: boolean; message: string; tx?: Transaction };

  // Subscriptions & Recurring Bills
  addSubscription: (sub: Omit<SubscriptionBill, 'id' | 'createdAt'>) => void;
  editSubscription: (sub: SubscriptionBill) => void;
  deleteSubscription: (id: string) => void;
  togglePauseSubscription: (id: string) => void;
  paySubscriptionBill: (
    billId: string,
    accountId?: string,
    cardId?: string,
    paymentDate?: string,
    amount?: number,
    note?: string
  ) => { success: boolean; message: string; tx?: Transaction };
  totalMonthlyRecurring: number;
  totalYearlyRecurring: number;
  paidThisMonthRecurring: number;
  pendingThisMonthRecurring: number;
  upcomingBills: SubscriptionBill[];
  overdueBillsCount: number;
  dueSoonBillsCount: number;

  // Mess & Bachelor Meal Manager
  messData: MessData;
  setMessData: React.Dispatch<React.SetStateAction<MessData>>;
  updateMessConfig: (config: Partial<MessConfig>) => void;
  addMessMember: (member: Omit<MessMember, 'id'>) => void;
  editMessMember: (member: MessMember) => void;
  deleteMessMember: (id: string) => void;
  setMemberDailyMeal: (
    date: string,
    memberId: string,
    breakfast: number,
    lunch: number,
    dinner: number,
    guestMeals?: number,
    note?: string
  ) => void;
  quickIncrementMeal: (date: string, memberId: string, delta: number) => void;
  addBazarEntry: (entry: Omit<MessBazarEntry, 'id'>, syncWithKhorochTx?: boolean, accountId?: string) => void;
  deleteBazarEntry: (id: string) => void;
  addDepositEntry: (entry: Omit<MessDepositEntry, 'id'>, syncWithKhorochTx?: boolean, accountId?: string) => void;
  deleteDepositEntry: (id: string) => void;
  addFixedCost: (cost: Omit<MessFixedCostItem, 'id'>) => void;
  editFixedCost: (cost: MessFixedCostItem) => void;
  deleteFixedCost: (id: string) => void;
  addBazarSchedule: (item: Omit<MessBazarScheduleItem, 'id'>) => void;
  deleteBazarSchedule: (id: string) => void;
  resetMessMonth: (newMonth: string) => void;

  // Mess Calculated Stats
  totalMessMeals: number;
  totalMessBazarCost: number;
  messMealRate: number;
  totalMessFixedCost: number;
  fixedCostPerMember: number;
  totalMessDeposits: number;
  messCashInHand: number;
  memberSummaries: Array<{
    member: MessMember;
    totalMeals: number;
    mealCost: number;
    fixedCostShare: number;
    extraCost: number;
    totalCost: number;
    totalDeposit: number;
    balance: number;
    status: 'refund' | 'due' | 'settled';
  }>;

  // Investments, DPS, FDR, Sanchayapatra & Gold
  investments: InvestmentItem[];
  goldMarketRates: GoldMarketRate;
  addInvestment: (item: Omit<InvestmentItem, 'id'>) => void;
  editInvestment: (item: InvestmentItem) => void;
  deleteInvestment: (id: string) => void;
  updateGoldRates: (rates: Partial<GoldMarketRate>) => void;
  payDPSInstallment: (
    investmentId: string,
    accountId?: string,
    amount?: number,
    date?: string,
    note?: string
  ) => { success: boolean; message: string; tx?: Transaction };
  recordInvestmentProfitPayout: (
    investmentId: string,
    accountId?: string,
    amount?: number,
    date?: string,
    note?: string
  ) => { success: boolean; message: string; tx?: Transaction };

  // Investment Calculated Stats
  totalPortfolioValue: number;
  totalInvestedPrincipal: number;
  totalUnrealizedGain: number;
  unrealizedGainPercentage: number;
  totalMonthlyEstimatedYield: number;
  totalGoldWeightBhori: number;
  totalGoldCurrentValue: number;
  totalGoldZakatPayable: number;
  upcomingDPSInstallments: InvestmentItem[];

  // Trips, Tour & Event Budget Mode
  trips: TripItem[];
  activeTrip: TripItem | null;
  addTrip: (trip: Omit<TripItem, 'id' | 'createdAt'>) => void;
  editTrip: (trip: TripItem) => void;
  deleteTrip: (id: string) => void;
  setActiveTripStatus: (id: string, status: 'upcoming' | 'active' | 'completed') => void;
  addTripExpense: (tripId: string, expense: Omit<TripExpense, 'id'>, syncWithKhorochTx?: boolean, accountId?: string) => void;
  deleteTripExpense: (tripId: string, expenseId: string) => void;
  addTripMember: (tripId: string, member: Omit<TripMember, 'id'>) => void;
  deleteTripMember: (tripId: string, memberId: string) => void;
  recordTripMemberDeposit: (tripId: string, memberId: string, amount: number) => void;
  toggleTripPackingItem: (tripId: string, packingItemId: string) => void;
  addTripPackingItem: (tripId: string, item: Omit<TripPackingItem, 'id'>) => void;
  deleteTripPackingItem: (tripId: string, packingItemId: string) => void;
  addTripItineraryDay: (tripId: string, day: Omit<TripItineraryDay, 'id'>) => void;
  deleteTripItineraryDay: (tripId: string, dayId: string) => void;

  // Gamified Savings Challenges & No-Spend Streak
  savingsChallenges: SavingsChallenge[];
  noSpendRecords: NoSpendRecord[];
  gamificationBadges: GamificationBadge[];
  userXP: number;
  userLevel: number;
  currentNoSpendStreak: number;
  bestNoSpendStreak: number;
  totalSavedFromChallenges: number;
  toggleNoSpendDay: (date: string, status?: 'no_spend' | 'essential_only' | 'spend', note?: string) => void;
  addSavingsChallenge: (challenge: Omit<SavingsChallenge, 'id' | 'completedDays' | 'checkInDates' | 'status' | 'currentAmount'>) => void;
  checkInChallengeDay: (challengeId: string, depositAmount?: number, accountId?: string) => { success: boolean; message: string; completed?: boolean };
  deleteSavingsChallenge: (challengeId: string) => void;

  // Smart Bazar & Price Tracker
  bazarItems: BazarItem[];
  bazarMarketCommodities: BazarMarketCommodity[];
  addBazarItem: (item: Omit<BazarItem, 'id' | 'addedDate'>) => void;
  editBazarItem: (item: BazarItem) => void;
  deleteBazarItem: (id: string) => void;
  toggleBazarItemPurchased: (id: string, actualPrice?: number) => void;
  updateBazarItemActualPrice: (id: string, price: number) => void;
  clearPurchasedBazarItems: () => void;
  clearAllBazarItems: () => void;
  resetBazarListToDefault: () => void;
  checkoutBazarList: (accountId: string, note?: string) => { success: boolean; tx?: Transaction; totalAmount: number };
  addPriceHistoryLog: (commodityId: string, price: number, date?: string, marketName?: string) => void;
  updateMarketCommodity: (commodity: BazarMarketCommodity) => void;
  addMarketCommodity: (commodity: Omit<BazarMarketCommodity, 'id'>) => void;
  estimatedBazarTotal: number;
  actualBazarSpent: number;
  bazarSavingsSoFar: number;
  bazarCompletedCount: number;
  bazarTotalCount: number;

  // Central AI Financial Control System
  aiHealthScore: AIHealthScore;
  aiAnomalies: AIAnomalyRisk[];
  aiActionProposals: AIActionProposal[];
  aiActivityLogs: AIActivityEvent[];
  aiMemory: AIMemoryPreferences;
  aiNetWorth: AINetWorthBreakdown;
  aiCashFlowForecast: AICashFlowForecast;
  aiChatMessages: AIChatMessage[];
  executeAIAction: (proposalId: string) => { success: boolean; message: string };
  dismissAIAction: (proposalId: string) => void;
  addAIActionProposal: (proposal: Omit<AIActionProposal, 'id' | 'createdAt' | 'status'>) => void;
  addAIActivityLog: (event: Omit<AIActivityEvent, 'id' | 'timestamp'>) => void;
  updateAIMemoryPreferences: (prefs: Partial<AIMemoryPreferences>) => void;
  recordCategoryCorrection: (merchantOrNote: string, correctedCategoryId: string) => void;
  sendAICommand: (command: string) => Promise<{ response: string; proposal?: AIActionProposal }>;
  activeActionConfirmationModal: AIActionProposal | null;
  setActiveActionConfirmationModal: (proposal: AIActionProposal | null) => void;
  generateAIReport: (period: 'daily' | 'weekly' | 'monthly') => AIReportSummary;

  // Quick Smart Parse
  parseSmartQuickAdd: (input: string) => { success: boolean; tx?: Omit<Transaction, 'id'>; message: string };

  // Utilities
  formatMoney: (amount: number) => string;
  t: (key: keyof typeof TRANSLATIONS['en']) => string;
  exportCSV: () => void;
  exportJSON: () => void;
  importJSON: (jsonString: string) => boolean;
  resetAll: () => void;
  isResetModalOpen: boolean;
  setIsResetModalOpen: (open: boolean) => void;

  // Advanced Reminder & Notification System
  notifications: AppNotification[];
  unreadNotificationsCount: number;
  customReminders: CustomReminder[];
  notificationSettings: NotificationSettings;
  addCustomReminder: (reminder: Omit<CustomReminder, 'id' | 'createdAt' | 'completed'>) => void;
  deleteCustomReminder: (id: string) => void;
  toggleCustomReminder: (id: string) => void;
  markNotificationAsRead: (id: string) => void;
  markAllNotificationsAsRead: () => void;
  dismissNotification: (id: string) => void;
  snoozeNotification: (id: string, days?: number) => void;
  clearAllNotifications: () => void;
  updateNotificationSettings: (settings: Partial<NotificationSettings>) => void;
  requestBrowserPush: () => Promise<boolean>;
  triggerTestNotification: () => void;
  sendWhatsAppDebtReminder: (debt: Debt) => void;
  playNotificationSound: () => void;
  isNotificationCenterOpen: boolean;
  setIsNotificationCenterOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isAddReminderModalOpen: boolean;
  setIsAddReminderModalOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isNotificationSettingsModalOpen: boolean;
  setIsNotificationSettingsModalOpen: (open: boolean | ((prev: boolean) => boolean)) => void;

  // Smart Payment Priority Engine
  allPaymentObligations: PaymentObligation[];
  rankedPaymentObligations: RankedObligation[];
  cashFlowAnalysis: CashFlowAnalysis;
  paymentEngineConfig: PaymentEngineConfig;
  selectedPaymentStrategy: PaymentStrategyType;
  customObligations: CustomObligationInput[];
  addCustomObligation: (obligation: CustomObligationInput) => void;
  updateCustomObligation: (index: number, obligation: CustomObligationInput) => void;
  deleteCustomObligation: (index: number) => void;
  updatePaymentEngineConfig: (config: Partial<PaymentEngineConfig>) => void;
  setSelectedPaymentStrategy: (strategy: PaymentStrategyType) => void;
  markObligationPaid: (obligation: PaymentObligation, paymentDetails: { accountId: string; amount: number; date: string; note?: string }) => void;
  rescheduleObligation: (obligationId: string, newDueDate: string) => void;
  runSimulation: (input: WhatIfSimulationInput) => WhatIfSimulationResult;
  isPriorityConfigModalOpen: boolean;
  setIsPriorityConfigModalOpen: (open: boolean | ((prev: boolean) => boolean)) => void;
  isAddCustomObligationModalOpen: boolean;
  setIsAddCustomObligationModalOpen: (open: boolean | ((prev: boolean) => boolean)) => void;


  // Stats
  totalBalance: number;
  totalIncomeThisMonth: number;
  totalExpenseThisMonth: number;
  netSavingsThisMonth: number;
  savingsRateThisMonth: number;
}

const ExpenseContext = createContext<ExpenseContextType | undefined>(undefined);

const STORAGE_KEY_PREFIX = 'khoroch_v4_';

// Automatically purge legacy demo data from previous sessions if present
if (typeof window !== 'undefined') {
  try {
    Object.keys(localStorage).forEach(key => {
      if (
        key.startsWith('khoroch_v1_') ||
        key.startsWith('khoroch_v2_') ||
        key.startsWith('khoroch_v3_')
      ) {
        localStorage.removeItem(key);
      }
    });

    // Explicitly purge legacy demo AI data from v4 storage
    const savedLogs = localStorage.getItem('khoroch_v4_ai_activity_logs');
    if (savedLogs) {
      const parsed = JSON.parse(savedLogs);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter((item: any) => !item.id?.startsWith('ai-log-init-') && !item.id?.startsWith('demo-'));
        localStorage.setItem('khoroch_v4_ai_activity_logs', JSON.stringify(cleaned));
      }
    }
    const savedProposals = localStorage.getItem('khoroch_v4_ai_action_proposals');
    if (savedProposals) {
      const parsed = JSON.parse(savedProposals);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter((item: any) => !item.id?.startsWith('demo-') && !item.id?.startsWith('prop-demo-'));
        localStorage.setItem('khoroch_v4_ai_action_proposals', JSON.stringify(cleaned));
      }
    }
    const savedChat = localStorage.getItem('khoroch_v4_ai_chat_messages');
    if (savedChat) {
      const parsed = JSON.parse(savedChat);
      if (Array.isArray(parsed)) {
        const cleaned = parsed.filter((item: any) => item.id !== 'msg-welcome' && !item.id?.startsWith('demo-'));
        localStorage.setItem('khoroch_v4_ai_chat_messages', JSON.stringify(cleaned));
      }
    }
    const savedMemory = localStorage.getItem('khoroch_v4_ai_memory');
    if (savedMemory) {
      const parsed = JSON.parse(savedMemory);
      if (parsed && parsed.learnedMerchantCategories) {
        // If it contains the hardcoded demo list of 10+ merchants
        const keys = Object.keys(parsed.learnedMerchantCategories);
        if (keys.includes('shwapno') || keys.includes('স্বপ্ন') || keys.includes('chaldal')) {
          parsed.learnedMerchantCategories = {};
          localStorage.setItem('khoroch_v4_ai_memory', JSON.stringify(parsed));
        }
      }
    }
  } catch {
    // ignore
  }
}

export const ExpenseProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // Initialize state from localStorage or default
  const [transactions, setTransactions] = useState<Transaction[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'transactions');
    return saved ? JSON.parse(saved) : DEFAULT_TRANSACTIONS;
  });

  const [categories, setCategories] = useState<Category[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'categories');
    return saved ? JSON.parse(saved) : DEFAULT_CATEGORIES;
  });

  const [accounts, setAccounts] = useState<Account[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'accounts');
    return saved ? JSON.parse(saved) : DEFAULT_ACCOUNTS;
  });

  const [budgets, setBudgets] = useState<Budget[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'budgets');
    return saved ? JSON.parse(saved) : DEFAULT_BUDGETS;
  });

  const [goals, setGoals] = useState<SavingsGoal[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'goals');
    return saved ? JSON.parse(saved) : DEFAULT_GOALS;
  });

  const [debts, setDebts] = useState<Debt[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'debts');
    return saved ? JSON.parse(saved) : DEFAULT_DEBTS;
  });

  const [billSplits, setBillSplits] = useState<BillSplit[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'billSplits');
    return saved ? JSON.parse(saved) : DEFAULT_BILL_SPLITS;
  });

  const [wishlistItems, setWishlistItems] = useState<WishlistItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'wishlist');
    return saved ? JSON.parse(saved) : DEFAULT_WISHLIST_ITEMS;
  });

  const [digitalCards, setDigitalCards] = useState<DigitalCard[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'digital_cards');
    return saved ? JSON.parse(saved) : DEFAULT_DIGITAL_CARDS;
  });

  const [subscriptions, setSubscriptions] = useState<SubscriptionBill[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'subscriptions');
    return saved ? JSON.parse(saved) : DEFAULT_SUBSCRIPTION_BILLS;
  });

  const [messData, setMessData] = useState<MessData>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'mess_data');
    return saved ? JSON.parse(saved) : DEFAULT_MESS_DATA;
  });

  const [investments, setInvestments] = useState<InvestmentItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'investments');
    return saved ? JSON.parse(saved) : DEFAULT_INVESTMENTS;
  });

  const [goldMarketRates, setGoldMarketRates] = useState<GoldMarketRate>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'gold_rates');
    return saved ? JSON.parse(saved) : DEFAULT_GOLD_RATES;
  });

  const [trips, setTrips] = useState<TripItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'trips');
    return saved ? JSON.parse(saved) : DEFAULT_TRIPS;
  });

  const [savingsChallenges, setSavingsChallenges] = useState<SavingsChallenge[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'savings_challenges');
    return saved ? JSON.parse(saved) : DEFAULT_SAVINGS_CHALLENGES;
  });

  const [noSpendRecords, setNoSpendRecords] = useState<NoSpendRecord[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'no_spend_records');
    return saved ? JSON.parse(saved) : DEFAULT_NO_SPEND_RECORDS;
  });

  const [gamificationBadges, setGamificationBadges] = useState<GamificationBadge[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'gamification_badges');
    return saved ? JSON.parse(saved) : DEFAULT_GAMIFICATION_BADGES;
  });

  const [userXP, setUserXP] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'user_xp');
    return saved ? JSON.parse(saved) : 0;
  });

  const [bazarItems, setBazarItems] = useState<BazarItem[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'bazar_items');
    if (!saved) return DEFAULT_BAZAR_ITEMS;
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        // Automatically purge any hardcoded demo items (e.g. bazar-item-1 to 8)
        return parsed.filter((item: BazarItem) => !item.id?.startsWith('bazar-item-'));
      }
      return DEFAULT_BAZAR_ITEMS;
    } catch {
      return DEFAULT_BAZAR_ITEMS;
    }
  });

  const [bazarMarketCommodities, setBazarMarketCommodities] = useState<BazarMarketCommodity[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'bazar_commodities');
    return saved ? JSON.parse(saved) : DEFAULT_BAZAR_COMMODITIES;
  });

  const [safeToSpendConfig, setSafeToSpendConfig] = useState<SafeToSpendConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'safetospend_config');
    return saved ? JSON.parse(saved) : { mode: 'budget', customMonthlyCap: 0 };
  });

  const [currency, setCurrency] = useState<Currency>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'currency');
    return saved ? JSON.parse(saved) : CURRENCIES[0]; // BDT by default
  });

  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'language');
    return (saved as Language) || 'bn';
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('dashboard');
  const [walletSubTab, setWalletSubTab] = useState<'cards' | 'accounts'>('cards');
  const [subscriptionFilterTab, setSubscriptionFilterTab] = useState<'all' | 'due' | 'utility' | 'telecom' | 'digital' | 'paid'>('all');
  const [isResetModalOpen, setIsResetModalOpen] = useState<boolean>(false);

  // Advanced Reminder & Notification System State
  const [notificationSettings, setNotificationSettings] = useState<NotificationSettings>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'notification_settings');
    if (saved) {
      try {
        return {
          enableSound: true,
          enableBrowserPush: false,
          dailyReminderEnabled: true,
          dailyReminderTime: '21:30',
          budgetAlertThreshold: 0.8,
          billDueDaysBefore: 3,
          lowBalanceThreshold: 500,
          ...JSON.parse(saved),
        };
      } catch {
        // fallback
      }
    }
    return {
      enableSound: true,
      enableBrowserPush: false,
      dailyReminderEnabled: true,
      dailyReminderTime: '21:30',
      budgetAlertThreshold: 0.8,
      billDueDaysBefore: 3,
      lowBalanceThreshold: 500,
    };
  });

  const [customReminders, setCustomReminders] = useState<CustomReminder[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'custom_reminders');
    return saved ? JSON.parse(saved) : [];
  });

  const [readNotificationIds, setReadNotificationIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'read_notification_ids');
    return saved ? JSON.parse(saved) : [];
  });

  const [dismissedNotificationIds, setDismissedNotificationIds] = useState<string[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'dismissed_notification_ids');
    return saved ? JSON.parse(saved) : [];
  });

  const [snoozedNotifications, setSnoozedNotifications] = useState<Record<string, string>>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'snoozed_notifications');
    return saved ? JSON.parse(saved) : {};
  });

  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState<boolean>(false);
  const [isAddReminderModalOpen, setIsAddReminderModalOpen] = useState<boolean>(false);
  const [isNotificationSettingsModalOpen, setIsNotificationSettingsModalOpen] = useState<boolean>(false);

  // Smart Payment Priority Engine State
  const [paymentEngineConfig, setPaymentEngineConfig] = useState<PaymentEngineConfig>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'payment_engine_config');
    if (saved) {
      try {
        return { ...DEFAULT_PRIORITY_CONFIG, ...JSON.parse(saved) };
      } catch {}
    }
    return DEFAULT_PRIORITY_CONFIG;
  });

  const [selectedPaymentStrategy, setSelectedPaymentStrategy] = useState<PaymentStrategyType>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'selected_payment_strategy');
    return (saved as PaymentStrategyType) || 'balanced_smart';
  });

  const [customObligations, setCustomObligations] = useState<CustomObligationInput[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'custom_obligations');
    return saved ? JSON.parse(saved) : [];
  });

  const [isPriorityConfigModalOpen, setIsPriorityConfigModalOpen] = useState<boolean>(false);
  const [isAddCustomObligationModalOpen, setIsAddCustomObligationModalOpen] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'payment_engine_config', JSON.stringify(paymentEngineConfig));
  }, [paymentEngineConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'selected_payment_strategy', selectedPaymentStrategy);
  }, [selectedPaymentStrategy]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'custom_obligations', JSON.stringify(customObligations));
  }, [customObligations]);


  // Persist notification states
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'notification_settings', JSON.stringify(notificationSettings));
  }, [notificationSettings]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'custom_reminders', JSON.stringify(customReminders));
  }, [customReminders]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'read_notification_ids', JSON.stringify(readNotificationIds));
  }, [readNotificationIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'dismissed_notification_ids', JSON.stringify(dismissedNotificationIds));
  }, [dismissedNotificationIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'snoozed_notifications', JSON.stringify(snoozedNotifications));
  }, [snoozedNotifications]);

  // Sidebar controls
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    return localStorage.getItem(STORAGE_KEY_PREFIX + 'sidebar_collapsed') === 'true';
  });

  const toggleSidebar = useCallback(() => {
    setIsSidebarOpen(prev => !prev);
  }, []);

  const toggleSidebarCollapsed = useCallback(() => {
    setIsSidebarCollapsed(prev => {
      const next = !prev;
      localStorage.setItem(STORAGE_KEY_PREFIX + 'sidebar_collapsed', String(next));
      return next;
    });
  }, []);

  // Central AI Financial Control System States
  const [aiActivityLogs, setAiActivityLogs] = useState<AIActivityEvent[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'ai_activity_logs');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed.filter((item: AIActivityEvent) => !item.id?.startsWith('ai-log-init-') && !item.id?.startsWith('demo-'));
      }
      return [];
    } catch {
      return [];
    }
  });

  const [aiActionProposals, setAiActionProposals] = useState<AIActionProposal[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'ai_action_proposals');
    if (!saved) return [];
    try {
      const parsed = JSON.parse(saved);
      if (Array.isArray(parsed)) {
        return parsed.filter((item: AIActionProposal) => !item.id?.startsWith('demo-') && !item.id?.startsWith('prop-demo-'));
      }
      return [];
    } catch {
      return [];
    }
  });

  const [aiMemory, setAiMemory] = useState<AIMemoryPreferences>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'ai_memory');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        return {
          ...DEFAULT_AI_MEMORY_PREFERENCES,
          ...parsed,
          learnedMerchantCategories: parsed.learnedMerchantCategories || {},
        };
      } catch {
        /* ignore */
      }
    }
    return DEFAULT_AI_MEMORY_PREFERENCES;
  });

  const [aiChatMessages, setAiChatMessages] = useState<AIChatMessage[]>(() => {
    const saved = localStorage.getItem(STORAGE_KEY_PREFIX + 'ai_chat_messages');
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed)) {
          return parsed.filter((m: AIChatMessage) => !m.id?.startsWith('demo-') && m.id !== 'msg-welcome');
        }
      } catch {
        /* ignore */
      }
    }
    return [];
  });

  const [activeActionConfirmationModal, setActiveActionConfirmationModal] = useState<AIActionProposal | null>(null);

  // Cloud Auth & Sync state (Username-Only with Real Backend & Full Isolation)
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);
  const [authSession, setAuthSession] = useState<AuthSession | null>(null);
  const [isAuthLoading, setIsAuthLoading] = useState<boolean>(true);
  const [isCloudSyncing, setIsCloudSyncing] = useState<boolean>(false);
  const [syncStatus, setSyncStatus] = useState<SyncStatus>('idle');
  const [lastSyncedTime, setLastSyncedTime] = useState<Date | null>(null);
  const [authError, setAuthError] = useState<string | null>(null);
  const [syncError, setSyncError] = useState<string | null>(null);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState<boolean>(false);

  // Network state detection
  useEffect(() => {
    const handleOnline = () => {
      setSyncStatus((prev) => (prev === 'offline' ? 'synced' : prev));
    };
    const handleOffline = () => {
      setSyncStatus('offline');
    };
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    if (!navigator.onLine) {
      setSyncStatus('offline');
    }
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Helper to package all state for cloud persistence
  const buildCloudDataPayload = () => ({
    transactions,
    accounts,
    categories,
    budgets,
    goals,
    debts,
    subscriptions,
    bazarItems,
    digitalCards,
    customReminders,
    customObligations,
    paymentEngineConfig,
    selectedPaymentStrategy,
    currency,
    language,
    safeToSpendConfig,
    extra: {
      messData,
      investments,
      trips,
      savingsChallenges,
      noSpendRecords,
      billSplits,
      wishlistItems,
      aiMemory,
      aiActivityLogs,
    },
  });

  // Helper to hydrate state from cloud payload
  const hydrateFromCloudPayload = (data: any) => {
    if (!data) return;
    if (Array.isArray(data.transactions)) setTransactions(data.transactions);
    if (Array.isArray(data.accounts) && data.accounts.length > 0) setAccounts(data.accounts);
    if (Array.isArray(data.categories) && data.categories.length > 0) setCategories(data.categories);
    if (Array.isArray(data.budgets)) setBudgets(data.budgets);
    if (Array.isArray(data.goals)) setGoals(data.goals);
    if (Array.isArray(data.debts)) setDebts(data.debts);
    if (Array.isArray(data.subscriptions)) setSubscriptions(data.subscriptions);
    if (Array.isArray(data.bazarItems)) setBazarItems(data.bazarItems);
    if (Array.isArray(data.digitalCards)) setDigitalCards(data.digitalCards);
    if (Array.isArray(data.customReminders)) setCustomReminders(data.customReminders);
    if (Array.isArray(data.customObligations)) setCustomObligations(data.customObligations);
    if (data.paymentEngineConfig) setPaymentEngineConfig(data.paymentEngineConfig);
    if (data.selectedPaymentStrategy) setSelectedPaymentStrategy(data.selectedPaymentStrategy);
    if (data.currency) setCurrency(data.currency);
    if (data.language) setLanguage(data.language);
    if (data.safeToSpendConfig) setSafeToSpendConfig(data.safeToSpendConfig);
    if (data.extra) {
      if (data.extra.messData) setMessData(data.extra.messData);
      if (Array.isArray(data.extra.investments)) setInvestments(data.extra.investments);
      if (Array.isArray(data.extra.trips)) setTrips(data.extra.trips);
      if (Array.isArray(data.extra.savingsChallenges)) setSavingsChallenges(data.extra.savingsChallenges);
      if (Array.isArray(data.extra.noSpendRecords)) setNoSpendRecords(data.extra.noSpendRecords);
      if (Array.isArray(data.extra.billSplits)) setBillSplits(data.extra.billSplits);
      if (Array.isArray(data.extra.wishlistItems)) setWishlistItems(data.extra.wishlistItems);
      if (Array.isArray(data.extra.aiMemory)) setAiMemory(data.extra.aiMemory);
      if (Array.isArray(data.extra.aiActivityLogs)) setAiActivityLogs(data.extra.aiActivityLogs);
    }
  };

  // Helper to wipe local user data upon logout for strict user isolation
  const clearLocalUserData = () => {
    try {
      const keysToRemove: string[] = [];
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && (k.startsWith(STORAGE_KEY_PREFIX) || k.startsWith('khoroch_auth_'))) {
          keysToRemove.push(k);
        }
      }
      keysToRemove.forEach((k) => localStorage.removeItem(k));
    } catch (e) {
      console.error('Failed to clear local user data:', e);
    }
    // Reset state to pristine default state
    setTransactions([]);
    setCategories(DEFAULT_CATEGORIES);
    setAccounts(DEFAULT_ACCOUNTS);
    setBudgets([]);
    setGoals([]);
    setDebts([]);
    setSubscriptions([]);
    setBazarItems([]);
    setDigitalCards([]);
    setCustomReminders([]);
    setCustomObligations([]);
    setDismissedNotificationIds([]);
    setReadNotificationIds([]);
    setBillSplits([]);
    setWishlistItems([]);
    setInvestments([]);
    setTrips([]);
    setSavingsChallenges([]);
    setNoSpendRecords([]);
  };

  // Mount effect: load existing session and perform initial cloud sync
  useEffect(() => {
    let isMounted = true;
    const initAuthAndSync = async () => {
      try {
        const session = AuthClient.getSession();
        if (session && session.user) {
          if (!isMounted) return;
          setAuthSession(session);
          const appUser: AppUser = {
            uid: session.user.id,
            id: session.user.id,
            username: session.user.username,
            displayName: session.user.username,
            createdAt: session.user.createdAt,
            hasSecurityQuestions: session.user.hasSecurityQuestions,
          };
          setCurrentUser(appUser);

          // Fetch cloud data for this user
          if (navigator.onLine) {
            setIsCloudSyncing(true);
            setSyncStatus('syncing');
            try {
              const cloudResult = await AuthClient.pullCloudData();
              if (cloudResult && cloudResult.data && Object.keys(cloudResult.data).length > 0) {
                const c = cloudResult.data;
                const hasExistingData = (c.transactions && c.transactions.length > 0) ||
                  (c.accounts && c.accounts.length > 0) ||
                  (c.budgets && c.budgets.length > 0) ||
                  (c.debts && c.debts.length > 0);

                if (hasExistingData) {
                  hydrateFromCloudPayload(c);
                } else {
                  // User has local state on this device; push up to cloud as baseline
                  const payload = buildCloudDataPayload();
                  await AuthClient.pushCloudData(payload);
                }
              }
              setSyncStatus('synced');
              setLastSyncedTime(new Date());
            } catch (syncErr: any) {
              console.warn('Initial cloud sync error:', syncErr);
              setSyncStatus('error');
              setSyncError(syncErr?.message || 'Sync error');
            } finally {
              setIsCloudSyncing(false);
            }
          }
        }
      } catch (err: any) {
        console.error('Auth initialization error:', err);
      } finally {
        if (isMounted) {
          setIsAuthLoading(false);
        }
      }
    };

    initAuthAndSync();

    return () => {
      isMounted = false;
    };
  }, []);

  // Username-Only Registration
  const registerUser = async (
    username: string,
    pass: string,
    confirmPass: string,
    securityQuestions: SecurityQuestionItem[]
  ) => {
    setAuthError(null);
    setIsAuthLoading(true);
    try {
      const resp = await AuthClient.register({
        username,
        password: pass,
        confirmPassword: confirmPass,
        securityQuestions,
      });

      const session = AuthClient.getSession();
      setAuthSession(session);
      const appUser: AppUser = {
        uid: resp.user.id,
        id: resp.user.id,
        username: resp.user.username,
        displayName: resp.user.username,
        createdAt: resp.user.createdAt,
        hasSecurityQuestions: resp.user.hasSecurityQuestions,
      };
      setCurrentUser(appUser);

      // Push baseline local data into their newly created cloud record
      try {
        setSyncStatus('syncing');
        const payload = buildCloudDataPayload();
        await AuthClient.pushCloudData(payload);
        setSyncStatus('synced');
        setLastSyncedTime(new Date());
      } catch (pushErr) {
        console.warn('Initial registration cloud upload notice:', pushErr);
      }
      setIsAuthModalOpen(false);
    } catch (err: any) {
      setAuthError(err?.message || 'Registration failed');
      throw err;
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Username-Only Login
  const loginUser = async (username: string, pass: string) => {
    setAuthError(null);
    setIsAuthLoading(true);
    try {
      const resp = await AuthClient.login({ username, password: pass });
      const session = AuthClient.getSession();
      setAuthSession(session);
      const appUser: AppUser = {
        uid: resp.user.id,
        id: resp.user.id,
        username: resp.user.username,
        displayName: resp.user.username,
        createdAt: resp.user.createdAt,
        hasSecurityQuestions: resp.user.hasSecurityQuestions,
      };
      setCurrentUser(appUser);

      // Pull latest cloud data across devices
      try {
        setIsCloudSyncing(true);
        setSyncStatus('syncing');
        const cloudResult = await AuthClient.pullCloudData();
        if (cloudResult && cloudResult.data && Object.keys(cloudResult.data).length > 0) {
          hydrateFromCloudPayload(cloudResult.data);
        } else {
          // If no cloud data yet, back up current device data
          const payload = buildCloudDataPayload();
          await AuthClient.pushCloudData(payload);
        }
        setSyncStatus('synced');
        setLastSyncedTime(new Date());
      } catch (syncErr: any) {
        console.warn('Login cloud fetch notice:', syncErr);
        setSyncStatus('error');
        setSyncError(syncErr?.message || 'Cloud sync failed');
      } finally {
        setIsCloudSyncing(false);
      }
      setIsAuthModalOpen(false);
    } catch (err: any) {
      setAuthError(err?.message || 'Login failed');
      throw err;
    } finally {
      setIsAuthLoading(false);
    }
  };

  // Real secure sign out with complete user isolation
  const handleSignOut = async () => {
    try {
      await AuthClient.logout();
      setAuthSession(null);
      setCurrentUser(null);
      setSyncStatus('idle');
      setLastSyncedTime(null);
      clearLocalUserData();
    } catch (err: any) {
      console.error('Sign-out failed:', err);
      throw err;
    }
  };

  // Password change for authenticated users
  const changePassword = async (currentPass: string, newPass: string, confirmNewPass: string) => {
    setAuthError(null);
    try {
      await AuthClient.changePassword({
        currentPassword: currentPass,
        newPassword: newPass,
        confirmNewPassword: confirmNewPass,
      });
    } catch (err: any) {
      setAuthError(err?.message || 'Change password failed');
      throw err;
    }
  };

  // Username check
  const checkUsernameAvailable = async (username: string) => {
    return AuthClient.checkUsername(username);
  };

  // Recovery: get security questions
  const getSecurityQuestionsForRecovery = async (username: string) => {
    return AuthClient.getSecurityQuestions(username);
  };

  // Recovery: verify answers & get reset token
  const verifySecurityAnswersForRecovery = async (
    username: string,
    answers: { id: string; question: string; answer: string }[]
  ) => {
    return AuthClient.verifySecurityAnswers({ username, answers });
  };

  // Recovery: reset password with token
  const resetPasswordWithToken = async (
    resetToken: string,
    newPassword: string,
    confirmNewPassword: string
  ) => {
    await AuthClient.resetPasswordWithToken({ resetToken, newPassword, confirmNewPassword });
  };

  // Manage security questions
  const updateSecurityQuestions = async (
    currentPassword: string,
    questions: SecurityQuestionItem[]
  ) => {
    return AuthClient.updateSecurityQuestions({ currentPassword, questions });
  };

  // Manual & automatic full cloud sync
  const syncAllToCloudNow = async () => {
    if (!currentUser || !authSession) return;
    if (!navigator.onLine) {
      setSyncStatus('offline');
      return;
    }
    setIsCloudSyncing(true);
    setSyncStatus('syncing');
    setSyncError(null);
    try {
      const payload = buildCloudDataPayload();
      await AuthClient.pushCloudData(payload);
      setSyncStatus('synced');
      setLastSyncedTime(new Date());
    } catch (err: any) {
      console.error('Manual cloud sync failed:', err);
      setSyncStatus('error');
      setSyncError(err?.message || 'Cloud sync failed');
    } finally {
      setIsCloudSyncing(false);
    }
  };

  const pullFromCloudNow = async () => {
    if (!currentUser || !authSession) return;
    if (!navigator.onLine) {
      setSyncStatus('offline');
      return;
    }
    setIsCloudSyncing(true);
    setSyncStatus('syncing');
    setSyncError(null);
    try {
      const res = await AuthClient.pullCloudData();
      if (res && res.data) {
        hydrateFromCloudPayload(res.data);
      }
      setSyncStatus('synced');
      setLastSyncedTime(new Date());
    } catch (err: any) {
      console.error('Manual cloud pull failed:', err);
      setSyncStatus('error');
      setSyncError(err?.message || 'Cloud pull failed');
    } finally {
      setIsCloudSyncing(false);
    }
  };

  // Optional backward compatible Google sign in handler
  const handleGoogleSignIn = async () => {
    // Open the auth modal for username-only login
    setIsAuthModalOpen(true);
  };

  // Debounced sync for auxiliary extra states
  useEffect(() => {
    if (!currentUser) return;
    const timer = setTimeout(() => {
      syncSaveExtra(currentUser.uid, {
        messData,
        investments,
        trips,
        savingsChallenges,
        noSpendRecords,
        billSplits,
        wishlistItems,
        aiMemory,
        aiActivityLogs,
      }).catch(console.error);
    }, 2000);
    return () => clearTimeout(timer);
  }, [
    currentUser,
    messData,
    investments,
    trips,
    savingsChallenges,
    noSpendRecords,
    billSplits,
    wishlistItems,
    aiMemory,
    aiActivityLogs,
  ]);

  // Sync to local storage
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'transactions', JSON.stringify(transactions));
  }, [transactions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'categories', JSON.stringify(categories));
  }, [categories]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'accounts', JSON.stringify(accounts));
  }, [accounts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'budgets', JSON.stringify(budgets));
  }, [budgets]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'goals', JSON.stringify(goals));
  }, [goals]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'debts', JSON.stringify(debts));
  }, [debts]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'billSplits', JSON.stringify(billSplits));
  }, [billSplits]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'wishlist', JSON.stringify(wishlistItems));
  }, [wishlistItems]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'digital_cards', JSON.stringify(digitalCards));
  }, [digitalCards]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'subscriptions', JSON.stringify(subscriptions));
  }, [subscriptions]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'mess_data', JSON.stringify(messData));
  }, [messData]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'investments', JSON.stringify(investments));
  }, [investments]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'gold_rates', JSON.stringify(goldMarketRates));
  }, [goldMarketRates]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'trips', JSON.stringify(trips));
  }, [trips]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'savings_challenges', JSON.stringify(savingsChallenges));
  }, [savingsChallenges]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'no_spend_records', JSON.stringify(noSpendRecords));
  }, [noSpendRecords]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'gamification_badges', JSON.stringify(gamificationBadges));
  }, [gamificationBadges]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'user_xp', JSON.stringify(userXP));
  }, [userXP]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'bazar_items', JSON.stringify(bazarItems));
  }, [bazarItems]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'bazar_commodities', JSON.stringify(bazarMarketCommodities));
  }, [bazarMarketCommodities]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'ai_activity_logs', JSON.stringify(aiActivityLogs));
  }, [aiActivityLogs]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'ai_action_proposals', JSON.stringify(aiActionProposals));
  }, [aiActionProposals]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'ai_memory', JSON.stringify(aiMemory));
  }, [aiMemory]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'ai_chat_messages', JSON.stringify(aiChatMessages));
  }, [aiChatMessages]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'safetospend_config', JSON.stringify(safeToSpendConfig));
  }, [safeToSpendConfig]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'currency', JSON.stringify(currency));
  }, [currency]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_PREFIX + 'language', language);
  }, [language]);

  // Recalculate account balance upon transaction changes
  const updateAccountBalance = (
    accId: string,
    amountDelta: number
  ) => {
    setAccounts(prev =>
      prev.map(acc => (acc.id === accId ? { ...acc, balance: acc.balance + amountDelta } : acc))
    );
  };

  const addTransaction = (tx: Omit<Transaction, 'id'>) => {
    const newId = 'tx-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6);
    const newTx: Transaction = { ...tx, id: newId };

    setTransactions(prev => [newTx, ...prev]);

    if (currentUser) {
      syncSaveTransaction(currentUser.uid, newTx).catch(console.error);
    }

    // Update account balances
    if (newTx.type === 'expense') {
      updateAccountBalance(newTx.accountId, -newTx.amount);
    } else if (newTx.type === 'income') {
      updateAccountBalance(newTx.accountId, newTx.amount);
    } else if (newTx.type === 'transfer' && newTx.targetAccountId) {
      updateAccountBalance(newTx.accountId, -newTx.amount);
      updateAccountBalance(newTx.targetAccountId, newTx.amount);
    }
  };

  const editTransaction = (updatedTx: Transaction) => {
    const oldTx = transactions.find(t => t.id === updatedTx.id);
    if (!oldTx) return;

    // Revert old effect
    if (oldTx.type === 'expense') {
      updateAccountBalance(oldTx.accountId, oldTx.amount);
    } else if (oldTx.type === 'income') {
      updateAccountBalance(oldTx.accountId, -oldTx.amount);
    } else if (oldTx.type === 'transfer' && oldTx.targetAccountId) {
      updateAccountBalance(oldTx.accountId, oldTx.amount);
      updateAccountBalance(oldTx.targetAccountId, -oldTx.amount);
    }

    // Apply new effect
    if (updatedTx.type === 'expense') {
      updateAccountBalance(updatedTx.accountId, -updatedTx.amount);
    } else if (updatedTx.type === 'income') {
      updateAccountBalance(updatedTx.accountId, updatedTx.amount);
    } else if (updatedTx.type === 'transfer' && updatedTx.targetAccountId) {
      updateAccountBalance(updatedTx.accountId, -updatedTx.amount);
      updateAccountBalance(updatedTx.targetAccountId, updatedTx.amount);
    }

    setTransactions(prev => prev.map(t => (t.id === updatedTx.id ? updatedTx : t)));

    if (currentUser) {
      syncSaveTransaction(currentUser.uid, updatedTx).catch(console.error);
    }
  };

  const deleteTransaction = (id: string) => {
    const tx = transactions.find(t => t.id === id);
    if (tx) {
      if (tx.type === 'expense') {
        updateAccountBalance(tx.accountId, tx.amount);
      } else if (tx.type === 'income') {
        updateAccountBalance(tx.accountId, -tx.amount);
      } else if (tx.type === 'transfer' && tx.targetAccountId) {
        updateAccountBalance(tx.accountId, tx.amount);
        updateAccountBalance(tx.targetAccountId, -tx.amount);
      }
    }
    setTransactions(prev => prev.filter(t => t.id !== id));

    if (currentUser) {
      syncDeleteTransaction(currentUser.uid, id).catch(console.error);
    }
  };

  // Accounts
  const addAccount = (acc: Omit<Account, 'id'>) => {
    const newId = 'acc-' + Date.now();
    const newAcc: Account = { ...acc, id: newId };
    setAccounts(prev => [...prev, newAcc]);

    if (currentUser) {
      syncSaveAccount(currentUser.uid, newAcc).catch(console.error);
    }
  };

  const editAccount = (acc: Account) => {
    setAccounts(prev => prev.map(a => (a.id === acc.id ? acc : a)));

    if (currentUser) {
      syncSaveAccount(currentUser.uid, acc).catch(console.error);
    }
  };

  const deleteAccount = (id: string) => {
    if (accounts.length <= 1) return; // Keep at least one account
    setAccounts(prev => prev.filter(a => a.id !== id));

    if (currentUser) {
      syncDeleteAccount(currentUser.uid, id).catch(console.error);
    }
  };

  const transferMoney = (
    sourceAccountId: string,
    targetAccountId: string,
    amount: number,
    note: string,
    date: string
  ) => {
    if (sourceAccountId === targetAccountId || amount <= 0) return;
    addTransaction({
      type: 'transfer',
      amount,
      categoryId: 'cat-others',
      accountId: sourceAccountId,
      targetAccountId,
      date: date || new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: note || 'Transfer between wallets',
    });
  };

  // Budgets
  const setCategoryBudget = (categoryId: string, limit: number) => {
    const currentMonth = new Date().toISOString().slice(0, 7);
    let budgetToSave: Budget | null = null;
    setBudgets(prev => {
      const existing = prev.find(b => b.categoryId === categoryId && b.month === currentMonth);
      if (existing) {
        budgetToSave = { ...existing, monthlyLimit: limit };
        return prev.map(b => (b.id === existing.id ? budgetToSave! : b));
      } else {
        budgetToSave = {
          id: 'b-' + Date.now(),
          categoryId,
          monthlyLimit: limit,
          month: currentMonth,
          alertThreshold: 0.8,
        };
        return [...prev, budgetToSave];
      }
    });

    if (currentUser && budgetToSave) {
      syncSaveBudget(currentUser.uid, budgetToSave).catch(console.error);
    }
  };

  const deleteBudget = (id: string) => {
    setBudgets(prev => prev.filter(b => b.id !== id));
    if (currentUser) {
      syncDeleteBudget(currentUser.uid, id).catch(console.error);
    }
  };

  // Goals
  const addGoal = (goal: Omit<SavingsGoal, 'id'>) => {
    const newGoal: SavingsGoal = { ...goal, id: 'goal-' + Date.now() };
    setGoals(prev => [...prev, newGoal]);
    if (currentUser) {
      syncSaveGoal(currentUser.uid, newGoal).catch(console.error);
    }
  };

  const updateGoalSavings = (goalId: string, amountDelta: number) => {
    setGoals(prev =>
      prev.map(g => {
        if (g.id === goalId) {
          const newAmount = Math.max(0, g.currentAmount + amountDelta);
          const updated = { ...g, currentAmount: newAmount };
          if (currentUser) {
            syncSaveGoal(currentUser.uid, updated).catch(console.error);
          }
          return updated;
        }
        return g;
      })
    );
  };

  const deleteGoal = (id: string) => {
    setGoals(prev => prev.filter(g => g.id !== id));
    if (currentUser) {
      syncDeleteGoal(currentUser.uid, id).catch(console.error);
    }
  };

  // Debts
  const addDebt = (debt: Omit<Debt, 'id' | 'createdAt'>) => {
    const newDebt: Debt = {
      ...debt,
      id: 'debt-' + Date.now(),
      createdAt: new Date().toISOString().split('T')[0],
    };
    setDebts(prev => [newDebt, ...prev]);
    if (currentUser) {
      syncSaveDebt(currentUser.uid, newDebt).catch(console.error);
    }
  };

  const recordDebtPayment = (debtId: string, paymentAmount: number) => {
    setDebts(prev =>
      prev.map(d => {
        if (d.id === debtId) {
          const newPaid = d.paidAmount + paymentAmount;
          const updated = {
            ...d,
            paidAmount: newPaid,
            settled: newPaid >= d.amount,
          };
          if (currentUser) {
            syncSaveDebt(currentUser.uid, updated).catch(console.error);
          }
          return updated;
        }
        return d;
      })
    );
  };

  const toggleDebtSettled = (debtId: string) => {
    setDebts(prev =>
      prev.map(d => {
        if (d.id === debtId) {
          const nextSettled = !d.settled;
          const updated = {
            ...d,
            settled: nextSettled,
            paidAmount: nextSettled ? d.amount : 0,
          };
          if (currentUser) {
            syncSaveDebt(currentUser.uid, updated).catch(console.error);
          }
          return updated;
        }
        return d;
      })
    );
  };

  const deleteDebt = (id: string) => {
    setDebts(prev => prev.filter(d => d.id !== id));
    if (currentUser) {
      syncDeleteDebt(currentUser.uid, id).catch(console.error);
    }
  };

  // Bill Splits
  const addBillSplit = (split: Omit<BillSplit, 'id'>) => {
    const newSplit: BillSplit = { ...split, id: 'split-' + Date.now() };
    setBillSplits(prev => [newSplit, ...prev]);
  };

  const toggleSplitMemberPaid = (splitId: string, memberId: string) => {
    setBillSplits(prev =>
      prev.map(s => {
        if (s.id === splitId) {
          return {
            ...s,
            members: s.members.map(m => (m.id === memberId ? { ...m, paid: !m.paid } : m)),
          };
        }
        return s;
      })
    );
  };

  const deleteBillSplit = (splitId: string) => {
    setBillSplits(prev => prev.filter(s => s.id !== splitId));
  };

  // Wishlist & Impulse Buy Delay Methods
  const addWishlistItem = (item: Omit<WishlistItem, 'id' | 'status'> & { status?: WishlistStatus }) => {
    const newItem: WishlistItem = {
      ...item,
      id: 'wish-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      status: item.status || 'cooling',
      addedDate: item.addedDate || new Date().toISOString().split('T')[0],
      coolingPeriodDays: item.coolingPeriodDays || 30,
      necessityScore: item.necessityScore || 3,
      priority: item.priority || 'medium',
    };
    setWishlistItems(prev => [newItem, ...prev]);
  };

  const editWishlistItem = (updated: WishlistItem) => {
    setWishlistItems(prev => prev.map(w => (w.id === updated.id ? updated : w)));
  };

  const deleteWishlistItem = (id: string) => {
    setWishlistItems(prev => prev.filter(w => w.id !== id));
  };

  const markWishlistPurchased = (id: string, accountId?: string, createExpenseTx: boolean = true) => {
    const today = new Date().toISOString().split('T')[0];
    const item = wishlistItems.find(w => w.id === id);
    if (!item) return;

    setWishlistItems(prev =>
      prev.map(w =>
        w.id === id
          ? { ...w, status: 'purchased', decisionDate: today, accountId: accountId || w.accountId }
          : w
      )
    );

    if (createExpenseTx) {
      const chosenAccountId = accountId || item.accountId || accounts[0]?.id || 'acc-cash';
      addTransaction({
        type: 'expense',
        amount: item.estimatedPrice,
        categoryId: item.categoryId || 'cat-shopping',
        accountId: chosenAccountId,
        date: today,
        note: `${item.title} (উইশলিস্ট থেকে কেনা)`,
      });
    }
  };

  const dropWishlistItem = (id: string) => {
    const today = new Date().toISOString().split('T')[0];
    setWishlistItems(prev =>
      prev.map(w =>
        w.id === id ? { ...w, status: 'dropped', decisionDate: today } : w
      )
    );
  };

  // Google Wallet Digital Card functions
  const addDigitalCard = (card: Omit<DigitalCard, 'id' | 'addedAt'>) => {
    const newId = 'card-' + Date.now();
    const newCard: DigitalCard = {
      ...card,
      id: newId,
      addedAt: new Date().toISOString().split('T')[0],
      currentSpentThisMonth: card.currentSpentThisMonth || 0,
    };

    setDigitalCards(prev => {
      if (newCard.isDefault) {
        return [...prev.map(c => ({ ...c, isDefault: false })), newCard];
      }
      return [...prev, newCard];
    });
    if (currentUser) {
      syncSaveCard(currentUser.uid, newCard).catch(console.error);
    }
  };

  const editDigitalCard = (card: DigitalCard) => {
    setDigitalCards(prev => {
      if (card.isDefault) {
        return prev.map(c => (c.id === card.id ? card : { ...c, isDefault: false }));
      }
      return prev.map(c => (c.id === card.id ? card : c));
    });
    if (currentUser) {
      syncSaveCard(currentUser.uid, card).catch(console.error);
    }
  };

  const deleteDigitalCard = (id: string) => {
    setDigitalCards(prev => prev.filter(c => c.id !== id));
    if (currentUser) {
      syncDeleteCard(currentUser.uid, id).catch(console.error);
    }
  };

  const setDefaultDigitalCard = (id: string) => {
    setDigitalCards(prev => prev.map(c => ({ ...c, isDefault: c.id === id })));
  };

  const toggleFreezeDigitalCard = (id: string) => {
    setDigitalCards(prev =>
      prev.map(c => (c.id === id ? { ...c, isFrozen: !c.isFrozen } : c))
    );
  };

  const simulateCardTapPayment = (
    cardId: string,
    amount: number,
    note: string,
    categoryId?: string
  ): { success: boolean; message: string; tx?: Transaction } => {
    const card = digitalCards.find(c => c.id === cardId);
    if (!card) {
      return { success: false, message: language === 'bn' ? 'কার্ড খুঁজে পাওয়া যায়নি।' : 'Card not found.' };
    }

    if (card.isFrozen) {
      return {
        success: false,
        message: language === 'bn' 
          ? `এই কার্ডটি (${card.issuerName}) বর্তমানে লক/ফ্রিজ করা রয়েছে! আনলক করে আবার চেষ্টা করুন।`
          : `This card (${card.issuerName}) is currently frozen! Unfreeze to proceed.`,
      };
    }

    if (card.dailySpendLimit && amount > card.dailySpendLimit) {
      return {
        success: false,
        message: language === 'bn'
          ? `দৈনিক লেনদেন সীমা (${currency.symbol}${card.dailySpendLimit.toLocaleString()}) অতিক্রম করেছে!`
          : `Exceeds daily spending limit (${currency.symbol}${card.dailySpendLimit.toLocaleString()})!`,
      };
    }

    let targetAccId = card.linkedAccountId;
    if (!targetAccId || !accounts.some(a => a.id === targetAccId)) {
      const matching = accounts.find(a => a.type === 'credit_card' || a.type === 'bank') || accounts[0];
      targetAccId = matching?.id || 'acc-cash';
    }

    const chosenCatId = categoryId || categories[0]?.id || 'cat-food';
    const today = new Date().toISOString().split('T')[0];
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const newTxId = 'tx-' + Date.now();
    const newTx: Transaction = {
      id: newTxId,
      type: 'expense',
      amount,
      categoryId: chosenCatId,
      accountId: targetAccId,
      cardId: card.id,
      date: today,
      time: timeNow,
      note: note.trim() || `${card.issuerName} ট্যাপ পেমেন্ট`,
    };

    setTransactions(prev => [newTx, ...prev]);
    updateAccountBalance(targetAccId, -amount);

    setDigitalCards(prev =>
      prev.map(c =>
        c.id === card.id
          ? { ...c, currentSpentThisMonth: (c.currentSpentThisMonth || 0) + amount }
          : c
      )
    );

    return {
      success: true,
      message: language === 'bn'
        ? `${card.issuerName} দিয়ে ${currency.symbol}${amount.toLocaleString()} সফলভাবে কন্ট্যাক্টলেস পেমেন্ট সম্পন্ন হয়েছে!`
        : `Contactless tap payment of ${currency.symbol}${amount.toLocaleString()} via ${card.issuerName} successful!`,
      tx: newTx,
    };
  };

  // Subscriptions & Recurring Bills
  const addSubscription = (sub: Omit<SubscriptionBill, 'id' | 'createdAt'>) => {
    const newBill: SubscriptionBill = {
      ...sub,
      id: 'sub-' + Date.now(),
      createdAt: new Date().toISOString().split('T')[0],
      paymentHistory: [],
    };
    setSubscriptions(prev => [newBill, ...prev]);
    if (currentUser) {
      syncSaveSubscription(currentUser.uid, newBill).catch(console.error);
    }
  };

  const editSubscription = (sub: SubscriptionBill) => {
    setSubscriptions(prev => prev.map(s => (s.id === sub.id ? sub : s)));
    if (currentUser) {
      syncSaveSubscription(currentUser.uid, sub).catch(console.error);
    }
  };

  const deleteSubscription = (id: string) => {
    setSubscriptions(prev => prev.filter(s => s.id !== id));
    if (currentUser) {
      syncDeleteSubscription(currentUser.uid, id).catch(console.error);
    }
  };

  const togglePauseSubscription = (id: string) => {
    let updatedSub: SubscriptionBill | null = null;
    setSubscriptions(prev =>
      prev.map(s => {
        if (s.id === id) {
          updatedSub = { ...s, status: s.status === 'active' ? 'paused' : 'active' };
          return updatedSub;
        }
        return s;
      })
    );
    if (currentUser && updatedSub) {
      syncSaveSubscription(currentUser.uid, updatedSub).catch(console.error);
    }
  };

  const paySubscriptionBill = (
    billId: string,
    accountId?: string,
    cardId?: string,
    paymentDate?: string,
    amountToPay?: number,
    note?: string
  ): { success: boolean; message: string; tx?: Transaction } => {
    const bill = subscriptions.find(s => s.id === billId);
    if (!bill) {
      return { success: false, message: language === 'bn' ? 'বিল পাওয়া যায়নি।' : 'Bill not found.' };
    }

    const payAmount = amountToPay !== undefined && amountToPay > 0 ? amountToPay : bill.amount;
    const payDate = paymentDate || new Date().toISOString().split('T')[0];
    const timeNow = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    let targetAccId = accountId || bill.accountId;
    if (!targetAccId || !accounts.some(a => a.id === targetAccId)) {
      const matchAcc = accounts.find(a => a.type === 'mobile_wallet' || a.type === 'bank') || accounts[0];
      targetAccId = matchAcc?.id || 'acc-cash';
    }

    let matchedCatId = 'cat-bills';
    if (bill.category === 'rent') {
      matchedCatId = 'cat-rent';
    } else if (bill.category === 'streaming' || bill.category === 'fitness') {
      matchedCatId = 'cat-entertainment';
    } else if (bill.category === 'software') {
      matchedCatId = 'cat-others';
    }

    const txNote = note?.trim() || `${bill.name} (${bill.providerName || 'বিল'}) পরিশোধ`;

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'expense',
      amount: payAmount,
      categoryId: matchedCatId,
      accountId: targetAccId,
      cardId: cardId || bill.cardId,
      date: payDate,
      time: timeNow,
      note: txNote,
    };

    setTransactions(prev => [newTx, ...prev]);
    updateAccountBalance(targetAccId, -payAmount);

    const currentDue = new Date(bill.dueDate);
    const nextDue = new Date(isNaN(currentDue.getTime()) ? new Date() : currentDue);
    if (bill.billingCycle === 'yearly') {
      nextDue.setFullYear(nextDue.getFullYear() + 1);
    } else if (bill.billingCycle === 'quarterly') {
      nextDue.setMonth(nextDue.getMonth() + 3);
    } else if (bill.billingCycle === 'weekly') {
      nextDue.setDate(nextDue.getDate() + 7);
    } else {
      nextDue.setMonth(nextDue.getMonth() + 1);
    }
    const nextDueStr = nextDue.toISOString().split('T')[0];

    const historyRecord = {
      id: 'pay-' + Date.now(),
      paidDate: payDate,
      amount: payAmount,
      transactionId: newTx.id,
      accountId: targetAccId,
      note: txNote,
    };

    setSubscriptions(prev =>
      prev.map(s =>
        s.id === billId
          ? {
              ...s,
              lastPaidDate: payDate,
              dueDate: nextDueStr,
              paymentHistory: [historyRecord, ...(s.paymentHistory || [])],
            }
          : s
      )
    );

    return {
      success: true,
      message: language === 'bn' 
        ? `${bill.name}-এর ${currency.symbol}${payAmount.toLocaleString()} বিল পরিশোধ সম্পন্ন হয়েছে!`
        : `Payment of ${currency.symbol}${payAmount.toLocaleString()} for ${bill.name} recorded!`,
      tx: newTx,
    };
  };

  // Mess & Bachelor Meal Manager Functions
  const updateMessConfig = (partial: Partial<MessConfig>) => {
    setMessData(prev => ({
      ...prev,
      config: { ...prev.config, ...partial },
    }));
  };

  const addMessMember = (member: Omit<MessMember, 'id'>) => {
    const newMember: MessMember = {
      ...member,
      id: 'mm-' + Date.now(),
      joinedDate: member.joinedDate || new Date().toISOString().split('T')[0],
      active: member.active !== undefined ? member.active : true,
    };
    setMessData(prev => ({
      ...prev,
      members: [...prev.members, newMember],
    }));
  };

  const editMessMember = (member: MessMember) => {
    setMessData(prev => ({
      ...prev,
      members: prev.members.map(m => (m.id === member.id ? member : m)),
    }));
  };

  const deleteMessMember = (id: string) => {
    setMessData(prev => ({
      ...prev,
      members: prev.members.filter(m => m.id !== id),
      dailyMeals: prev.dailyMeals.filter(dm => dm.memberId !== id),
      deposits: prev.deposits.filter(d => d.memberId !== id),
      bazarEntries: prev.bazarEntries.filter(b => b.shopperMemberId !== id),
      bazarSchedule: prev.bazarSchedule.filter(s => s.memberId !== id),
    }));
  };

  const setMemberDailyMeal = (
    date: string,
    memberId: string,
    breakfast: number,
    lunch: number,
    dinner: number,
    guestMeals: number = 0,
    note?: string
  ) => {
    const bWeight = messData.config.breakfastWeight ?? 0.5;
    const lWeight = messData.config.lunchWeight ?? 1.0;
    const dWeight = messData.config.dinnerWeight ?? 1.0;
    const total = (breakfast * bWeight) + (lunch * lWeight) + (dinner * dWeight) + guestMeals;

    setMessData(prev => {
      const existingIdx = prev.dailyMeals.findIndex(dm => dm.date === date && dm.memberId === memberId);
      if (existingIdx >= 0) {
        const updated = [...prev.dailyMeals];
        updated[existingIdx] = {
          ...updated[existingIdx],
          breakfast,
          lunch,
          dinner,
          guestMeals,
          totalMeals: total,
          isOff: total === 0,
          note: note !== undefined ? note : updated[existingIdx].note,
        };
        return { ...prev, dailyMeals: updated };
      } else {
        const newEntry: DailyMealEntry = {
          id: `dm-${date}-${memberId}`,
          date,
          memberId,
          breakfast,
          lunch,
          dinner,
          guestMeals,
          totalMeals: total,
          isOff: total === 0,
          note,
        };
        return { ...prev, dailyMeals: [...prev.dailyMeals, newEntry] };
      }
    });
  };

  const quickIncrementMeal = (date: string, memberId: string, delta: number) => {
    setMessData(prev => {
      const existing = prev.dailyMeals.find(dm => dm.date === date && dm.memberId === memberId);
      const currentTotal = existing ? existing.totalMeals : 0;
      const nextTotal = Math.max(0, currentTotal + delta);
      const isOff = nextTotal === 0;

      if (existing) {
        return {
          ...prev,
          dailyMeals: prev.dailyMeals.map(dm =>
            dm.id === existing.id
              ? { ...dm, totalMeals: nextTotal, isOff }
              : dm
          ),
        };
      } else {
        const newEntry: DailyMealEntry = {
          id: `dm-${date}-${memberId}`,
          date,
          memberId,
          breakfast: 0,
          lunch: 0,
          dinner: 0,
          totalMeals: nextTotal,
          isOff,
        };
        return { ...prev, dailyMeals: [...prev.dailyMeals, newEntry] };
      }
    });
  };

  const addBazarEntry = (
    entry: Omit<MessBazarEntry, 'id'>,
    syncWithKhorochTx: boolean = false,
    accountId?: string
  ) => {
    const newEntry: MessBazarEntry = {
      ...entry,
      id: 'baz-' + Date.now(),
    };
    setMessData(prev => ({
      ...prev,
      bazarEntries: [newEntry, ...prev.bazarEntries],
    }));

    if (syncWithKhorochTx) {
      const groceryCat = categories.find(c => c.id === 'cat-grocery') || categories[0];
      const targetAcc = accountId || accounts[0]?.id || 'acc-cash';
      addTransaction({
        type: 'expense',
        amount: entry.amount,
        categoryId: groceryCat.id,
        accountId: targetAcc,
        date: entry.date,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        note: `মেস বাজার (${entry.shopperName}): ${entry.itemsDescription}`,
      });
    }
  };

  const deleteBazarEntry = (id: string) => {
    setMessData(prev => ({
      ...prev,
      bazarEntries: prev.bazarEntries.filter(b => b.id !== id),
    }));
  };

  const addDepositEntry = (
    entry: Omit<MessDepositEntry, 'id'>,
    syncWithKhorochTx: boolean = false,
    accountId?: string
  ) => {
    const newEntry: MessDepositEntry = {
      ...entry,
      id: 'dep-' + Date.now(),
    };
    setMessData(prev => ({
      ...prev,
      deposits: [newEntry, ...prev.deposits],
    }));

    if (syncWithKhorochTx) {
      const targetAcc = accountId || accounts[0]?.id || 'acc-cash';
      const cat = categories.find(c => c.id === 'cat-others') || categories[0];
      addTransaction({
        type: 'expense',
        amount: entry.amount,
        categoryId: cat.id,
        accountId: targetAcc,
        date: entry.date,
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        note: `মেস ফান্ডে জমা (${entry.memberName})`,
      });
    }
  };

  const deleteDepositEntry = (id: string) => {
    setMessData(prev => ({
      ...prev,
      deposits: prev.deposits.filter(d => d.id !== id),
    }));
  };

  const addFixedCost = (cost: Omit<MessFixedCostItem, 'id'>) => {
    const newCost: MessFixedCostItem = {
      ...cost,
      id: 'fc-' + Date.now(),
    };
    setMessData(prev => ({
      ...prev,
      fixedCosts: [...prev.fixedCosts, newCost],
    }));
  };

  const editFixedCost = (cost: MessFixedCostItem) => {
    setMessData(prev => ({
      ...prev,
      fixedCosts: prev.fixedCosts.map(f => (f.id === cost.id ? cost : f)),
    }));
  };

  const deleteFixedCost = (id: string) => {
    setMessData(prev => ({
      ...prev,
      fixedCosts: prev.fixedCosts.filter(f => f.id !== id),
    }));
  };

  const addBazarSchedule = (item: Omit<MessBazarScheduleItem, 'id'>) => {
    const newItem: MessBazarScheduleItem = {
      ...item,
      id: 'sch-' + Date.now(),
    };
    setMessData(prev => ({
      ...prev,
      bazarSchedule: [...prev.bazarSchedule, newItem],
    }));
  };

  const deleteBazarSchedule = (id: string) => {
    setMessData(prev => ({
      ...prev,
      bazarSchedule: prev.bazarSchedule.filter(s => s.id !== id),
    }));
  };

  const resetMessMonth = (newMonth: string) => {
    setMessData(prev => ({
      ...prev,
      config: {
        ...prev.config,
        activeMonth: newMonth,
      },
      dailyMeals: [],
      bazarEntries: [],
      deposits: [],
    }));
  };

  // Investments & Portfolio Actions
  const addInvestment = (item: Omit<InvestmentItem, 'id'>) => {
    const newItem: InvestmentItem = {
      ...item,
      id: 'inv-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      history: item.history || [],
    };
    setInvestments(prev => [newItem, ...prev]);
  };

  const editInvestment = (item: InvestmentItem) => {
    setInvestments(prev => prev.map(inv => (inv.id === item.id ? item : inv)));
  };

  const deleteInvestment = (id: string) => {
    setInvestments(prev => prev.filter(inv => inv.id !== id));
  };

  const updateGoldRates = (rates: Partial<GoldMarketRate>) => {
    setGoldMarketRates(prev => {
      const updated = {
        ...prev,
        ...rates,
        lastUpdated: new Date().toISOString().split('T')[0],
      };

      if (rates.price22k || rates.price24k) {
        setInvestments(invs =>
          invs.map(inv => {
            if (inv.type === 'gold' && inv.goldWeightBhori) {
              const bhoriPrice =
                inv.goldPurity === '24k'
                  ? updated.price24k
                  : inv.goldPurity === '21k'
                  ? updated.price21k
                  : inv.goldPurity === '18k'
                  ? updated.price18k
                  : inv.goldPurity === 'traditional'
                  ? updated.priceTraditional
                  : updated.price22k;
              const nextVal = Math.round(inv.goldWeightBhori * bhoriPrice);
              return {
                ...inv,
                currentPricePerBhori: bhoriPrice,
                currentValue: nextVal,
              };
            }
            return inv;
          })
        );
      }

      return updated;
    });
  };

  const payDPSInstallment = (
    investmentId: string,
    accountId?: string,
    amountToPay?: number,
    paymentDate?: string,
    note?: string
  ): { success: boolean; message: string; tx?: Transaction } => {
    const dps = investments.find(inv => inv.id === investmentId);
    if (!dps) {
      return { success: false, message: language === 'bn' ? 'ডিপিএস পাওয়া যায়নি।' : 'DPS not found.' };
    }

    const payAmount = amountToPay !== undefined && amountToPay > 0 ? amountToPay : (dps.monthlyInstallment || 0);
    const payDate = paymentDate || new Date().toISOString().split('T')[0];
    const targetAccId = accountId || dps.linkedAccountId || accounts[0]?.id || 'acc-cash';
    const txNote = note?.trim() || `${dps.title} (${dps.institutionName}) কিস্তি পরিশোধ`;

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'expense',
      amount: payAmount,
      categoryId: 'cat-others',
      accountId: targetAccId,
      date: payDate,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: txNote,
    };

    setTransactions(prev => [newTx, ...prev]);
    updateAccountBalance(targetAccId, -payAmount);

    const currentDue = dps.nextInstallmentDueDate ? new Date(dps.nextInstallmentDueDate) : new Date(payDate);
    const nextDue = new Date(isNaN(currentDue.getTime()) ? new Date() : currentDue);
    nextDue.setMonth(nextDue.getMonth() + 1);
    const nextDueStr = nextDue.toISOString().split('T')[0];

    const historyRecord = {
      id: 'inv-pay-' + Date.now(),
      date: payDate,
      amount: payAmount,
      type: 'installment' as const,
      transactionId: newTx.id,
      note: txNote,
    };

    const newPaidCount = (dps.paidInstallmentsCount || 0) + 1;
    const newInvested = dps.investedAmount + payAmount;
    const interestAddition = Math.round(payAmount * ((dps.interestRate || 8.5) / 100 / 12));
    const newCurrentVal = dps.currentValue + payAmount + interestAddition;

    setInvestments(prev =>
      prev.map(inv =>
        inv.id === investmentId
          ? {
              ...inv,
              paidInstallmentsCount: newPaidCount,
              investedAmount: newInvested,
              currentValue: newCurrentVal,
              nextInstallmentDueDate: nextDueStr,
              history: [historyRecord, ...(inv.history || [])],
            }
          : inv
      )
    );

    return {
      success: true,
      message: language === 'bn'
        ? `${dps.title}-এর ${currency.symbol}${payAmount.toLocaleString()} কিস্তি সফলভাবে পরিশোধ হয়েছে!`
        : `DPS installment of ${currency.symbol}${payAmount.toLocaleString()} for ${dps.title} recorded!`,
      tx: newTx,
    };
  };

  const recordInvestmentProfitPayout = (
    investmentId: string,
    accountId?: string,
    amountToReceive?: number,
    receivedDate?: string,
    note?: string
  ): { success: boolean; message: string; tx?: Transaction } => {
    const inv = investments.find(i => i.id === investmentId);
    if (!inv) {
      return { success: false, message: language === 'bn' ? 'বিনিয়োগ পাওয়া যায়নি।' : 'Investment not found.' };
    }

    const receiveAmount = amountToReceive !== undefined && amountToReceive > 0 ? amountToReceive : (inv.estimatedMonthlyProfit || 0);
    const date = receivedDate || new Date().toISOString().split('T')[0];
    const targetAccId = accountId || inv.linkedAccountId || accounts[0]?.id || 'acc-bank';
    const txNote = note?.trim() || `${inv.title} (${inv.institutionName}) মুনাফা গ্রহণ`;

    const incCat = categories.find(c => c.id === 'cat-investment' || c.type === 'income') || categories[0];

    const newTx: Transaction = {
      id: 'tx-' + Date.now(),
      type: 'income',
      amount: receiveAmount,
      categoryId: incCat.id,
      accountId: targetAccId,
      date,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: txNote,
    };

    setTransactions(prev => [newTx, ...prev]);
    updateAccountBalance(targetAccId, receiveAmount);

    const historyRecord = {
      id: 'inv-profit-' + Date.now(),
      date,
      amount: receiveAmount,
      type: 'profit_payout' as const,
      transactionId: newTx.id,
      note: txNote,
    };

    setInvestments(prev =>
      prev.map(i =>
        i.id === investmentId
          ? {
              ...i,
              history: [historyRecord, ...(i.history || [])],
            }
          : i
      )
    );

    return {
      success: true,
      message: language === 'bn'
        ? `${inv.title} থেকে ${currency.symbol}${receiveAmount.toLocaleString()} মুনাফা একাউন্টে জমা হয়েছে!`
        : `Profit payout of ${currency.symbol}${receiveAmount.toLocaleString()} from ${inv.title} recorded!`,
      tx: newTx,
    };
  };

  // Trips & Tour Mode Actions
  const addTrip = (trip: Omit<TripItem, 'id' | 'createdAt'>) => {
    const newTrip: TripItem = {
      ...trip,
      id: 'trip-' + Date.now(),
      createdAt: new Date().toISOString().split('T')[0],
      members: trip.members || [],
      expenses: trip.expenses || [],
      packingList: trip.packingList || [],
      itinerary: trip.itinerary || [],
    };
    setTrips(prev => [newTrip, ...prev]);
  };

  const editTrip = (trip: TripItem) => {
    setTrips(prev => prev.map(t => (t.id === trip.id ? trip : t)));
  };

  const deleteTrip = (id: string) => {
    setTrips(prev => prev.filter(t => t.id !== id));
  };

  const setActiveTripStatus = (id: string, status: 'upcoming' | 'active' | 'completed') => {
    setTrips(prev =>
      prev.map(t => {
        if (t.id === id) {
          return { ...t, status };
        }
        if (status === 'active' && t.status === 'active') {
          return { ...t, status: 'upcoming' };
        }
        return t;
      })
    );
  };

  const addTripExpense = (
    tripId: string,
    expense: Omit<TripExpense, 'id'>,
    syncWithKhorochTx: boolean = false,
    accountId?: string
  ) => {
    const newExpense: TripExpense = {
      ...expense,
      id: 'te-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
    };

    setTrips(prev =>
      prev.map(t => (t.id === tripId ? { ...t, expenses: [newExpense, ...t.expenses] } : t))
    );

    if (syncWithKhorochTx) {
      const targetAcc = accountId || accounts[0]?.id || 'acc-cash';
      const cat = categories.find(c => c.id === 'cat-transport' || c.id === 'cat-food' || c.id === 'cat-entertainment') || categories[0];
      const trip = trips.find(t => t.id === tripId);
      addTransaction({
        type: 'expense',
        amount: expense.amount,
        categoryId: cat.id,
        accountId: targetAcc,
        date: expense.date,
        time: expense.time || new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        note: `[${trip?.titleBn || trip?.title || 'ট্যুর'}] ${expense.title}${expense.note ? ' - ' + expense.note : ''}`,
      });
    }
  };

  const deleteTripExpense = (tripId: string, expenseId: string) => {
    setTrips(prev =>
      prev.map(t =>
        t.id === tripId
          ? { ...t, expenses: t.expenses.filter(e => e.id !== expenseId) }
          : t
      )
    );
  };

  const addTripMember = (tripId: string, member: Omit<TripMember, 'id'>) => {
    const newMember: TripMember = {
      ...member,
      id: 'tm-' + Date.now(),
    };
    setTrips(prev =>
      prev.map(t => (t.id === tripId ? { ...t, members: [...t.members, newMember] } : t))
    );
  };

  const deleteTripMember = (tripId: string, memberId: string) => {
    setTrips(prev =>
      prev.map(t =>
        t.id === tripId
          ? { ...t, members: t.members.filter(m => m.id !== memberId) }
          : t
      )
    );
  };

  const recordTripMemberDeposit = (tripId: string, memberId: string, amount: number) => {
    setTrips(prev =>
      prev.map(t =>
        t.id === tripId
          ? {
              ...t,
              members: t.members.map(m =>
                m.id === memberId
                  ? { ...m, depositAmount: m.depositAmount + amount }
                  : m
              ),
            }
          : t
      )
    );
  };

  const toggleTripPackingItem = (tripId: string, packingItemId: string) => {
    setTrips(prev =>
      prev.map(t =>
        t.id === tripId
          ? {
              ...t,
              packingList: t.packingList.map(p =>
                p.id === packingItemId ? { ...p, isPacked: !p.isPacked } : p
              ),
            }
          : t
      )
    );
  };

  const addTripPackingItem = (tripId: string, item: Omit<TripPackingItem, 'id'>) => {
    const newItem: TripPackingItem = {
      ...item,
      id: 'tp-' + Date.now(),
    };
    setTrips(prev =>
      prev.map(t => (t.id === tripId ? { ...t, packingList: [...t.packingList, newItem] } : t))
    );
  };

  const deleteTripPackingItem = (tripId: string, packingItemId: string) => {
    setTrips(prev =>
      prev.map(t =>
        t.id === tripId
          ? { ...t, packingList: t.packingList.filter(p => p.id !== packingItemId) }
          : t
      )
    );
  };

  const addTripItineraryDay = (tripId: string, day: Omit<TripItineraryDay, 'id'>) => {
    const newDay: TripItineraryDay = {
      ...day,
      id: 'ti-' + Date.now(),
    };
    setTrips(prev =>
      prev.map(t => (t.id === tripId ? { ...t, itinerary: [...t.itinerary, newDay] } : t))
    );
  };

  const deleteTripItineraryDay = (tripId: string, dayId: string) => {
    setTrips(prev =>
      prev.map(t =>
        t.id === tripId
          ? { ...t, itinerary: t.itinerary.filter(d => d.id !== dayId) }
          : t
      )
    );
  };

  // Gamified Savings Challenges Actions
  const toggleNoSpendDay = (
    date: string,
    status: 'no_spend' | 'essential_only' | 'spend' = 'no_spend',
    note?: string
  ) => {
    setNoSpendRecords(prev => {
      const existingIndex = prev.findIndex(r => r.date === date);
      if (existingIndex >= 0) {
        const current = prev[existingIndex];
        const nextStatus = current.status === status ? 'spend' : status;
        const updated = [...prev];
        updated[existingIndex] = { ...current, status: nextStatus, note: note || current.note };
        return updated;
      } else {
        return [{ date, status, note }, ...prev];
      }
    });

    if (status === 'no_spend') {
      setUserXP(prev => prev + 50);
    }
  };

  const addSavingsChallenge = (
    challenge: Omit<SavingsChallenge, 'id' | 'completedDays' | 'checkInDates' | 'status' | 'currentAmount'>
  ) => {
    const newChallenge: SavingsChallenge = {
      ...challenge,
      id: 'ch-' + Date.now(),
      completedDays: 0,
      currentAmount: 0,
      checkInDates: [],
      status: 'active',
    };
    setSavingsChallenges(prev => [newChallenge, ...prev]);
    setUserXP(prev => prev + 50); // XP bonus for starting a challenge
  };

  const checkInChallengeDay = (
    challengeId: string,
    depositAmount?: number,
    accountId?: string
  ): { success: boolean; message: string; completed?: boolean } => {
    const challenge = savingsChallenges.find(c => c.id === challengeId);
    if (!challenge) {
      return { success: false, message: language === 'bn' ? 'চ্যালেঞ্জ পাওয়া যায়নি' : 'Challenge not found' };
    }

    const todayStr = new Date().toISOString().split('T')[0];
    if (challenge.checkInDates.includes(todayStr)) {
      return {
        success: false,
        message: language === 'bn' ? 'আজকের দিনের চেক-ইন ইতিমধ্যেই সম্পন্ন হয়েছে!' : 'Already checked in for today!',
      };
    }

    const deposit = depositAmount !== undefined ? depositAmount : (challenge.dailyTarget || 0);
    const newCompletedDays = challenge.completedDays + 1;
    const newCurrentAmount = challenge.currentAmount + deposit;
    const isCompleted =
      newCompletedDays >= challenge.durationDays ||
      (challenge.targetAmount > 0 && newCurrentAmount >= challenge.targetAmount);

    setSavingsChallenges(prev =>
      prev.map(c => {
        if (c.id === challengeId) {
          return {
            ...c,
            completedDays: newCompletedDays,
            currentAmount: newCurrentAmount,
            checkInDates: [todayStr, ...c.checkInDates],
            status: isCompleted ? 'completed' : 'active',
          };
        }
        return c;
      })
    );

    // If account was linked or provided, deduct deposit and log savings tx
    if (accountId && deposit > 0) {
      const targetAcc = accounts.find(a => a.id === accountId) || accounts[0];
      if (targetAcc) {
        updateAccountBalance(targetAcc.id, -deposit);
        const goalCategory = categories.find(c => c.id === 'cat-others') || categories[0];
        addTransaction({
          type: 'expense',
          amount: deposit,
          categoryId: goalCategory.id,
          accountId: targetAcc.id,
          date: todayStr,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          note: `[সেভিংস চ্যালেঞ্জ ডিপোজিট] ${challenge.titleBn || challenge.title}`,
        });
      }
    }

    // Award XP
    const earnedXP = isCompleted ? 30 + challenge.rewardXP : 30;
    setUserXP(prev => prev + earnedXP);

    // Auto unlock badges
    setGamificationBadges(prev =>
      prev.map(b => {
        if (b.id === 'badge-challenge-1' && isCompleted && !b.unlocked) {
          return { ...b, unlocked: true, unlockedAt: todayStr };
        }
        if (b.id === 'badge-save-10k' && newCurrentAmount >= 10000 && !b.unlocked) {
          return { ...b, unlocked: true, unlockedAt: todayStr };
        }
        return b;
      })
    );

    return {
      success: true,
      completed: isCompleted,
      message: isCompleted
        ? (language === 'bn'
            ? `অভিনন্দন! "${challenge.titleBn || challenge.title}" সম্পূর্ণ সম্পন্ন হয়েছে! (+${earnedXP} XP)`
            : `Congratulations! "${challenge.title}" challenge completed! (+${earnedXP} XP)`)
        : (language === 'bn'
            ? `আজকের চেক-ইন সফল! +${deposit > 0 ? currency.symbol + deposit.toLocaleString() : ''} জমা হয়েছে (+${earnedXP} XP)`
            : `Today's check-in recorded! (+${earnedXP} XP)`),
    };
  };

  const deleteSavingsChallenge = (challengeId: string) => {
    setSavingsChallenges(prev => prev.filter(c => c.id !== challengeId));
  };

  // Smart Bazar & Price Tracker Handlers
  const addBazarItem = (item: Omit<BazarItem, 'id' | 'addedDate'>) => {
    const newItem: BazarItem = {
      ...item,
      id: 'bazar-' + Date.now() + '-' + Math.random().toString(36).substring(2, 6),
      addedDate: new Date().toISOString().split('T')[0],
    };
    setBazarItems(prev => [newItem, ...prev]);
    if (currentUser) {
      syncSaveBazarItem(currentUser.uid, newItem).catch(console.error);
    }
  };

  const editBazarItem = (updated: BazarItem) => {
    setBazarItems(prev => prev.map(item => (item.id === updated.id ? updated : item)));
    if (currentUser) {
      syncSaveBazarItem(currentUser.uid, updated).catch(console.error);
    }
  };

  const deleteBazarItem = (id: string) => {
    setBazarItems(prev => prev.filter(item => item.id !== id));
    if (currentUser) {
      syncDeleteBazarItem(currentUser.uid, id).catch(console.error);
    }
  };

  const toggleBazarItemPurchased = (id: string, actualPrice?: number) => {
    let updatedItem: BazarItem | null = null;
    setBazarItems(prev =>
      prev.map(item => {
        if (item.id === id) {
          const nextPurchased = !item.isPurchased;
          updatedItem = {
            ...item,
            isPurchased: nextPurchased,
            actualPrice: nextPurchased
              ? actualPrice !== undefined
                ? actualPrice
                : item.actualPrice || item.estimatedPrice
              : item.actualPrice,
          };
          return updatedItem;
        }
        return item;
      })
    );
    if (currentUser && updatedItem) {
      syncSaveBazarItem(currentUser.uid, updatedItem).catch(console.error);
    }
  };

  const updateBazarItemActualPrice = (id: string, price: number) => {
    setBazarItems(prev => prev.map(item => (item.id === id ? { ...item, actualPrice: price } : item)));
  };

  const clearPurchasedBazarItems = () => {
    setBazarItems(prev => prev.filter(item => !item.isPurchased));
  };

  const clearAllBazarItems = () => {
    setBazarItems([]);
  };

  const resetBazarListToDefault = () => {
    setBazarItems([]);
    setBazarMarketCommodities(DEFAULT_BAZAR_COMMODITIES);
  };

  const addPriceHistoryLog = (commodityId: string, price: number, date?: string, marketName?: string) => {
    const today = date || new Date().toISOString().split('T')[0];
    setBazarMarketCommodities(prev =>
      prev.map(comm => {
        if (comm.id === commodityId) {
          const prevHistory = comm.history || [];
          const newHistory = [...prevHistory, { date: today, price, marketName: marketName || 'কাঁচাবাজার' }];
          const previousPrice = comm.currentPrice;
          return {
            ...comm,
            previousPrice,
            currentPrice: price,
            history: newHistory,
          };
        }
        return comm;
      })
    );
  };

  const updateMarketCommodity = (commodity: BazarMarketCommodity) => {
    setBazarMarketCommodities(prev => prev.map(c => (c.id === commodity.id ? commodity : c)));
  };

  const addMarketCommodity = (commodity: Omit<BazarMarketCommodity, 'id'>) => {
    const newComm: BazarMarketCommodity = {
      ...commodity,
      id: 'comm-' + Date.now() + '-' + Math.random().toString(36).substring(2, 5),
    };
    setBazarMarketCommodities(prev => [newComm, ...prev]);
  };

  const checkoutBazarList = (accountId: string, note?: string) => {
    const purchased = bazarItems.filter(item => item.isPurchased);
    if (purchased.length === 0) {
      return { success: false, totalAmount: 0 };
    }
    const totalAmount = purchased.reduce(
      (sum, item) => sum + (item.actualPrice !== undefined ? item.actualPrice : item.estimatedPrice || 0),
      0
    );
    const itemNames = purchased
      .map(
        i =>
          `${i.nameBn || i.name} (${i.quantity}) - ৳${
            i.actualPrice !== undefined ? i.actualPrice : i.estimatedPrice
          }`
      )
      .join(', ');
    const fullNote = note ? `${note} [${itemNames}]` : `কাঁচাবাজার সদাই: ${itemNames}`;

    // Create grocery expense transaction
    const newTx: Omit<Transaction, 'id'> = {
      type: 'expense',
      amount: totalAmount,
      categoryId: 'cat-grocery',
      accountId: accountId || accounts[0]?.id || 'acc-cash',
      date: new Date().toISOString().split('T')[0],
      time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
      note: fullNote,
      tags: ['কাঁচাবাজার', 'bazar', 'সদাই'],
    };
    addTransaction(newTx);

    // Update commodity history for matching items
    purchased.forEach(pItem => {
      const price = pItem.actualPrice !== undefined ? pItem.actualPrice : pItem.estimatedPrice;
      const matchedComm = bazarMarketCommodities.find(
        c =>
          c.name.toLowerCase().includes(pItem.name.toLowerCase()) ||
          (pItem.nameBn && c.nameBn.includes(pItem.nameBn)) ||
          (pItem.nameBn && pItem.nameBn.includes(c.nameBn))
      );
      if (matchedComm && price > 0) {
        addPriceHistoryLog(matchedComm.id, price, new Date().toISOString().split('T')[0], 'কাঁচাবাজার');
      }
    });

    return { success: true, totalAmount };
  };

  // ==========================================
  // CENTRAL AI FINANCIAL CONTROL SYSTEM METHODS
  // ==========================================
  const addAIActivityLog = (event: Omit<AIActivityEvent, 'id' | 'timestamp'>) => {
    const newLog: AIActivityEvent = {
      ...event,
      id: `ai-log-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      timestamp: new Date().toISOString(),
    };
    setAiActivityLogs(prev => [newLog, ...prev.slice(0, 49)]);
  };

  const addAIActionProposal = (proposal: Omit<AIActionProposal, 'id' | 'createdAt' | 'status'>) => {
    const newProp: AIActionProposal = {
      ...proposal,
      id: `ai-prop-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      createdAt: new Date().toISOString(),
      status: 'pending',
    };
    setAiActionProposals(prev => [newProp, ...prev]);
  };

  const dismissAIAction = (proposalId: string) => {
    setAiActionProposals(prev =>
      prev.map(p => (p.id === proposalId ? { ...p, status: 'dismissed' } : p))
    );
  };

  const executeAIAction = (proposalId: string): { success: boolean; message: string } => {
    const proposal = aiActionProposals.find(p => p.id === proposalId);
    if (!proposal) return { success: false, message: 'Proposal not found' };

    try {
      if (proposal.type === 'create_transaction') {
        addTransaction(proposal.payload);
      } else if (proposal.type === 'update_budget') {
        setCategoryBudget(
          proposal.payload.categoryId,
          proposal.payload.newLimit || proposal.payload.monthlyLimit
        );
      } else if (proposal.type === 'create_savings_goal') {
        addGoal(proposal.payload);
      }

      setAiActionProposals(prev =>
        prev.map(p => (p.id === proposalId ? { ...p, status: 'confirmed' } : p))
      );

      addAIActivityLog({
        type: 'action_executed',
        title: `Executed: ${proposal.title}`,
        titleBn: `বাস্তবায়িত: ${proposal.titleBn}`,
        details: `Confirmed and executed: ${proposal.newValue} (${proposal.reason})`,
        detailsBn: `নিশ্চিত ও বাস্তবায়িত: ${proposal.newValue} (${proposal.reasonBn})`,
        status: 'completed',
        module: 'Action Engine',
      });

      return {
        success: true,
        message:
          language === 'bn'
            ? 'অ্যাকশন সফলভাবে কার্যকর হয়েছে!'
            : 'Action executed successfully!',
      };
    } catch (err: any) {
      return { success: false, message: err?.message || 'Failed to execute action' };
    }
  };

  const updateAIMemoryPreferences = (prefs: Partial<AIMemoryPreferences>) => {
    setAiMemory(prev => ({ ...prev, ...prefs }));
  };

  const recordCategoryCorrection = (merchantOrNote: string, correctedCategoryId: string) => {
    const normalized = merchantOrNote.toLowerCase().trim();
    if (!normalized) return;
    setAiMemory(prev => ({
      ...prev,
      learnedMerchantCategories: {
        ...prev.learnedMerchantCategories,
        [normalized]: correctedCategoryId,
      },
      userCorrectionsCount: prev.userCorrectionsCount + 1,
    }));
    addAIActivityLog({
      type: 'user_correction',
      title: 'AI Learned User Correction',
      titleBn: 'এআই ব্যবহারকারীর পছন্দের ক্যাটাগরি শিখেছে',
      details: `Mapped "${normalized}" to category ID ${correctedCategoryId}`,
      detailsBn: `"${normalized}" কে ক্যাটাগরিতে ম্যাপিং সংরক্ষিত হয়েছে`,
      status: 'completed',
      module: 'Memory Layer',
    });
  };

  const sendAICommand = async (
    command: string
  ): Promise<{ response: string; proposal?: AIActionProposal }> => {
    const userMsg: AIChatMessage = {
      id: `chat-${Date.now()}-u`,
      sender: 'user',
      text: command,
      timestamp: new Date().toISOString(),
    };
    setAiChatMessages(prev => [...prev, userMsg]);

    const result = processFinancialAICommand({
      userInput: command,
      transactions,
      categories,
      accounts,
      budgets,
      goals,
      debts,
      subscriptions,
      digitalCards,
      investments,
      totalIncomeThisMonth,
      totalExpenseThisMonth,
      currency,
      language,
    });

    if (result.actionProposal) {
      addAIActionProposal(result.actionProposal);
    }

    if (result.activityLog) {
      addAIActivityLog(result.activityLog);
    }

    const aiMsg: AIChatMessage = {
      id: `chat-${Date.now()}-a`,
      sender: 'ai',
      text: result.response,
      timestamp: new Date().toISOString(),
      actionProposal: result.actionProposal,
    };
    setAiChatMessages(prev => [...prev, aiMsg]);

    return { response: result.response, proposal: result.actionProposal };
  };

  const generateAIReport = (period: 'daily' | 'weekly' | 'monthly'): AIReportSummary => {
    const report = generateFinancialReport({
      period,
      transactions,
      categories,
      budgets,
      accounts,
      investments,
      debts,
      subscriptions,
      totalIncomeThisMonth,
      totalExpenseThisMonth,
      currency,
      language,
    });

    addAIActivityLog({
      type: 'report_generated',
      title: `Generated ${period.toUpperCase()} Audit`,
      titleBn: `${period === 'monthly' ? 'মাসিক' : period === 'weekly' ? 'সাপ্তাহিক' : 'দৈনিক'} এআই অডিট রিপোর্ট তৈরি`,
      details: `Generated financial audit with savings rate ${report.keyMetrics.savingsRate}%`,
      detailsBn: `সঞ্চয়ের হার ${report.keyMetrics.savingsRate}% সহ অডিট রিপোর্ট তৈরি সম্পন্ন`,
      status: 'completed',
      module: 'Reports',
    });

    return report;
  };

  // Smart Natural Language quick add parser
  const parseSmartQuickAdd = (input: string) => {
    if (!input.trim()) {
      return { success: false, message: language === 'bn' ? 'অনুগ্রহ করে কিছু লিখুন' : 'Please enter text' };
    }

    const parsed = parseNaturalLanguageTransaction(input, accounts, categories, language);
    if (!parsed.success || parsed.amount <= 0) {
      return {
        success: false,
        message: parsed.message || (language === 'bn' ? 'কোনো টাকার অঙ্ক খুঁজে পাওয়া যায়নি' : 'Could not detect an amount'),
      };
    }

    const txDraft: Omit<Transaction, 'id'> = {
      type: parsed.type,
      amount: parsed.amount,
      categoryId: parsed.categoryId,
      accountId: parsed.accountId,
      date: parsed.date,
      time: parsed.time,
      note: parsed.note || input.trim(),
    };

    addTransaction(txDraft);

    return {
      success: true,
      tx: txDraft,
      message: language === 'bn' 
        ? `সফলভাবে যোগ হয়েছে: ${currency.symbol}${parsed.amount.toLocaleString()} (${parsed.categoryNameBn})`
        : `Added successfully: ${currency.symbol}${parsed.amount.toLocaleString()} (${parsed.categoryName})`,
    };
  };

  // Utilities
  const formatMoney = (amount: number) => {
    return `${currency.symbol}${Math.round(amount).toLocaleString()}`;
  };

  const t = (key: keyof typeof TRANSLATIONS['en']): string => {
    const langDict = TRANSLATIONS[language] || TRANSLATIONS.en;
    return (langDict as any)[key] || TRANSLATIONS.en[key] || key;
  };

  const exportCSV = () => {
    const headers = ['ID', 'Type', 'Amount', 'Currency', 'Category', 'Account', 'Date', 'Time', 'Notes'];
    const rows = transactions.map(t => {
      const cat = categories.find(c => c.id === t.categoryId)?.name || t.categoryId;
      const acc = accounts.find(a => a.id === t.accountId)?.name || t.accountId;
      return [
        t.id,
        t.type,
        t.amount,
        currency.code,
        `"${cat}"`,
        `"${acc}"`,
        t.date,
        t.time || '',
        `"${(t.note || '').replace(/"/g, '""')}"`,
      ].join(',');
    });

    const csvContent = 'data:text/csv;charset=utf-8,' + [headers.join(','), ...rows].join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `khoroch_transactions_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportJSON = () => {
    const backupData = {
      version: '2.0',
      exportDate: new Date().toISOString(),
      transactions,
      accounts,
      categories,
      budgets,
      goals,
      debts,
      billSplits,
      wishlistItems,
      digitalCards,
      subscriptions,
      messData,
      investments,
      goldMarketRates,
      trips,
      currency,
    };

    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(backupData, null, 2));
    const link = document.createElement('a');
    link.setAttribute('href', dataStr);
    link.setAttribute('download', `khoroch_backup_${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const importJSON = (jsonString: string): boolean => {
    try {
      const data = JSON.parse(jsonString);
      if (data.transactions && Array.isArray(data.transactions)) {
        setTransactions(data.transactions);
      }
      if (data.accounts && Array.isArray(data.accounts)) {
        setAccounts(data.accounts);
      }
      if (data.categories && Array.isArray(data.categories)) {
        setCategories(data.categories);
      }
      if (data.budgets && Array.isArray(data.budgets)) {
        setBudgets(data.budgets);
      }
      if (data.goals && Array.isArray(data.goals)) {
        setGoals(data.goals);
      }
      if (data.debts && Array.isArray(data.debts)) {
        setDebts(data.debts);
      }
      if (data.billSplits && Array.isArray(data.billSplits)) {
        setBillSplits(data.billSplits);
      }
      if (data.wishlistItems && Array.isArray(data.wishlistItems)) {
        setWishlistItems(data.wishlistItems);
      }
      if (data.digitalCards && Array.isArray(data.digitalCards)) {
        setDigitalCards(data.digitalCards);
      }
      if (data.subscriptions && Array.isArray(data.subscriptions)) {
        setSubscriptions(data.subscriptions);
      }
      if (data.messData && typeof data.messData === 'object') {
        setMessData(data.messData);
      }
      if (data.investments && Array.isArray(data.investments)) {
        setInvestments(data.investments);
      }
      if (data.goldMarketRates && typeof data.goldMarketRates === 'object') {
        setGoldMarketRates(data.goldMarketRates);
      }
      if (data.trips && Array.isArray(data.trips)) {
        setTrips(data.trips);
      }
      if (data.currency) {
        setCurrency(data.currency);
      }
      return true;
    } catch {
      return false;
    }
  };

  const resetAll = () => {
    setTransactions([]);
    setCategories(DEFAULT_CATEGORIES);
    setAccounts(
      DEFAULT_ACCOUNTS.map(a => ({
        ...a,
        balance: 0,
        initialBalance: 0,
      }))
    );
    setBudgets([]);
    setGoals([]);
    setDebts([]);
    setBillSplits([]);
    setWishlistItems([]);
    setDigitalCards([]);
    setSubscriptions([]);
    setMessData(DEFAULT_MESS_DATA);
    setInvestments([]);
    setGoldMarketRates(DEFAULT_GOLD_RATES);
    setTrips([]);
    setSavingsChallenges([]);
    setNoSpendRecords([]);
    setGamificationBadges(DEFAULT_GAMIFICATION_BADGES.map(b => ({ ...b, unlocked: false })));
    setUserXP(0);
    setBazarItems(DEFAULT_BAZAR_ITEMS);
    setBazarMarketCommodities(DEFAULT_BAZAR_COMMODITIES);
    setAiActivityLogs([]);
    setAiActionProposals([]);
    setAiMemory(DEFAULT_AI_MEMORY_PREFERENCES);
    setAiChatMessages([]);
    setSafeToSpendConfig({ mode: 'budget', customMonthlyCap: 0 });
    setCurrency(CURRENCIES[0]);
    if (typeof window !== 'undefined') {
      try {
        Object.keys(localStorage).forEach(key => {
          if (key.startsWith('khoroch_')) {
            localStorage.removeItem(key);
          }
        });
      } catch {
        // ignore
      }
    }
  };

  // Stats Calculations
  const currentMonthStr = new Date().toISOString().slice(0, 7);

  const totalBalance = accounts.reduce((sum, a) => sum + (a.balance || 0), 0);

  const currentMonthTransactions = transactions.filter(t => t.date.startsWith(currentMonthStr));

  const totalIncomeThisMonth = currentMonthTransactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);

  const totalExpenseThisMonth = currentMonthTransactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);

  const netSavingsThisMonth = totalIncomeThisMonth - totalExpenseThisMonth;

  const savingsRateThisMonth =
    totalIncomeThisMonth > 0 ? Math.max(0, Math.round((netSavingsThisMonth / totalIncomeThisMonth) * 100)) : 0;

  // Impulse Savings & Wishlist stats
  const totalMoneySavedFromImpulse = wishlistItems
    .filter(w => w.status === 'dropped')
    .reduce((sum, w) => sum + (w.estimatedPrice || 0), 0);

  const now = new Date();
  const getElapsedDays = (addedDate: string) => {
    const added = new Date(addedDate);
    const diffTime = Math.max(0, now.getTime() - added.getTime());
    return Math.floor(diffTime / (1000 * 60 * 60 * 24));
  };

  const readyDecisionCount = wishlistItems.filter(w => {
    if (w.status === 'ready') return true;
    if (w.status === 'cooling') {
      return getElapsedDays(w.addedDate) >= (w.coolingPeriodDays || 30);
    }
    return false;
  }).length;

  const activeCoolingCount = wishlistItems.filter(w => {
    if (w.status !== 'cooling') return false;
    return getElapsedDays(w.addedDate) < (w.coolingPeriodDays || 30);
  }).length;

  // Safe-to-Spend Calculations
  const todayObj = new Date();
  const currentYear = todayObj.getFullYear();
  const currentMonthIdx = todayObj.getMonth();
  const totalDaysInMonth = new Date(currentYear, currentMonthIdx + 1, 0).getDate();
  const currentDayOfMonth = todayObj.getDate();
  const daysRemainingInMonth = Math.max(1, (totalDaysInMonth - currentDayOfMonth) + 1); // includes today

  const todayStr = `${currentYear}-${String(currentMonthIdx + 1).padStart(2, '0')}-${String(currentDayOfMonth).padStart(2, '0')}`;
  const todayIsoStr = todayObj.toISOString().split('T')[0];

  const todayExpense = transactions
    .filter(t => t.type === 'expense' && (t.date === todayStr || t.date === todayIsoStr))
    .reduce((sum, t) => sum + t.amount, 0);

  // Total monthly spending cap depending on selected mode
  const totalCategoryBudget = budgets.reduce((sum, b) => sum + (b.monthlyLimit || 0), 0);

  let monthlySpendingCap = totalCategoryBudget > 0 ? totalCategoryBudget : 45000;
  if (safeToSpendConfig.mode === 'income') {
    monthlySpendingCap = totalIncomeThisMonth > 0 ? totalIncomeThisMonth : 50000;
  } else if (safeToSpendConfig.mode === 'custom' && safeToSpendConfig.customMonthlyCap) {
    monthlySpendingCap = safeToSpendConfig.customMonthlyCap;
  }

  // Expense before today this month
  const expenseBeforeTodayThisMonth = Math.max(0, totalExpenseThisMonth - todayExpense);
  const remainingCapAtStartOfToday = Math.max(0, monthlySpendingCap - expenseBeforeTodayThisMonth);
  const remainingMonthlyCap = monthlySpendingCap - totalExpenseThisMonth;

  // Today's allocated safe limit
  const todayDailySafeLimit = Math.max(0, Math.round(remainingCapAtStartOfToday / daysRemainingInMonth));
  const todayRemainingSafeToSpend = todayDailySafeLimit - todayExpense;

  let safeToSpendPercentUsed = 0;
  if (todayDailySafeLimit > 0) {
    safeToSpendPercentUsed = Math.min(150, Math.round((todayExpense / todayDailySafeLimit) * 100));
  } else if (todayExpense > 0) {
    safeToSpendPercentUsed = 100;
  }

  let safeToSpendStatus: 'safe' | 'caution' | 'exceeded' = 'safe';
  if (todayDailySafeLimit > 0) {
    if (todayExpense > todayDailySafeLimit) {
      safeToSpendStatus = 'exceeded';
    } else if (todayExpense >= todayDailySafeLimit * 0.75) {
      safeToSpendStatus = 'caution';
    } else {
      safeToSpendStatus = 'safe';
    }
  } else {
    safeToSpendStatus = todayExpense > 0 ? 'exceeded' : 'caution';
  }

  // Projected tomorrow limit if today's expense stops now
  const daysAfterToday = daysRemainingInMonth - 1;
  const remainingCapAfterToday = Math.max(0, remainingCapAtStartOfToday - todayExpense);
  const projectedTomorrowSafeLimit = daysAfterToday > 0 ? Math.round(remainingCapAfterToday / daysAfterToday) : 0;

  // Subscription & Recurring Bills Stats
  const activeSubscriptions = subscriptions.filter(s => s.status === 'active');
  const totalMonthlyRecurring = activeSubscriptions.reduce((sum, s) => {
    if (s.billingCycle === 'yearly') return sum + Math.round(s.amount / 12);
    if (s.billingCycle === 'quarterly') return sum + Math.round(s.amount / 3);
    if (s.billingCycle === 'weekly') return sum + Math.round(s.amount * 4.33);
    return sum + s.amount;
  }, 0);
  const totalYearlyRecurring = totalMonthlyRecurring * 12;

  const paidThisMonthRecurring = subscriptions.reduce((sum, s) => {
    if (s.lastPaidDate && s.lastPaidDate.startsWith(currentMonthStr)) {
      return sum + s.amount;
    }
    return sum;
  }, 0);

  const pendingThisMonthRecurring = activeSubscriptions.reduce((sum, s) => {
    if (!s.lastPaidDate || !s.lastPaidDate.startsWith(currentMonthStr)) {
      return sum + s.amount;
    }
    return sum;
  }, 0);

  const nowMs = new Date(todayIsoStr).getTime();
  const upcomingBills = [...subscriptions]
    .filter(s => s.status !== 'cancelled')
    .sort((a, b) => new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime());

  const overdueBillsCount = subscriptions.filter(s => {
    if (s.status !== 'active') return false;
    const dueMs = new Date(s.dueDate).getTime();
    return dueMs < nowMs && (!s.lastPaidDate || s.lastPaidDate < s.dueDate);
  }).length;

  const dueSoonBillsCount = subscriptions.filter(s => {
    if (s.status !== 'active') return false;
    const dueMs = new Date(s.dueDate).getTime();
    const diffDays = Math.ceil((dueMs - nowMs) / (1000 * 60 * 60 * 24));
    return diffDays >= 0 && diffDays <= 3;
  }).length;

  // Mess Live Analytics & Calculations
  const messActiveMonth = messData.config?.activeMonth || currentMonthStr;

  const activeMonthMeals = messData.dailyMeals.filter(m => !m.date || m.date.startsWith(messActiveMonth));
  const activeMonthBazar = messData.bazarEntries.filter(b => !b.date || b.date.startsWith(messActiveMonth));
  const activeMonthDeposits = messData.deposits.filter(d => !d.date || d.date.startsWith(messActiveMonth));

  const totalMessMeals = activeMonthMeals.reduce((sum, m) => sum + (m.totalMeals || 0), 0);
  const totalMessBazarCost = activeMonthBazar.reduce((sum, b) => sum + (b.amount || 0), 0);
  const messMealRate = totalMessMeals > 0 ? (totalMessBazarCost / totalMessMeals) : 0;

  const totalMessFixedCost = messData.fixedCosts.reduce((sum, f) => sum + (f.amount || 0), 0);
  const activeMembers = messData.members.filter(m => m.active);
  const activeMemberCount = Math.max(1, activeMembers.length);
  const fixedCostPerMember = Math.round(totalMessFixedCost / activeMemberCount);

  const totalMessDeposits = messData.members.reduce((sum, m) => {
    const memberDeps = activeMonthDeposits
      .filter(d => d.memberId === m.id)
      .reduce((s, d) => s + d.amount, 0);
    return sum + (memberDeps > 0 ? memberDeps : (m.initialDeposit || 0));
  }, 0);

  const messCashInHand = totalMessDeposits - totalMessBazarCost - totalMessFixedCost;

  const memberSummaries = messData.members.map(member => {
    const memberMeals = activeMonthMeals
      .filter(dm => dm.memberId === member.id)
      .reduce((sum, dm) => sum + (dm.totalMeals || 0), 0);

    const mealCost = Math.round(memberMeals * messMealRate);
    const fixedCostShare = member.active ? fixedCostPerMember : 0;
    const extraCost = member.individualExtraCost || 0;
    const totalCost = mealCost + fixedCostShare + extraCost;

    const recordedDeposit = activeMonthDeposits
      .filter(d => d.memberId === member.id)
      .reduce((sum, d) => sum + d.amount, 0);
    const totalDeposit = recordedDeposit > 0 ? recordedDeposit : (member.initialDeposit || 0);

    const balance = totalDeposit - totalCost;
    const status: 'refund' | 'due' | 'settled' =
      balance > 0 ? 'refund' : balance < 0 ? 'due' : 'settled';

    return {
      member,
      totalMeals: Math.round(memberMeals * 10) / 10,
      mealCost,
      fixedCostShare,
      extraCost,
      totalCost,
      totalDeposit,
      balance,
      status,
    };
  });

  // Investment & Portfolio Calculations
  const activeInvestments = investments.filter(i => i.status === 'active');
  const totalPortfolioValue = activeInvestments.reduce((sum, i) => sum + (i.currentValue || 0), 0);
  const totalInvestedPrincipal = activeInvestments.reduce((sum, i) => sum + (i.investedAmount || 0), 0);
  const totalUnrealizedGain = totalPortfolioValue - totalInvestedPrincipal;
  const unrealizedGainPercentage =
    totalInvestedPrincipal > 0 ? Math.round((totalUnrealizedGain / totalInvestedPrincipal) * 1000) / 10 : 0;

  const totalMonthlyEstimatedYield = activeInvestments.reduce((sum, i) => {
    if (i.estimatedMonthlyProfit) return sum + i.estimatedMonthlyProfit;
    if (i.type === 'fdr' && i.interestRate) {
      return sum + Math.round((i.investedAmount * (i.interestRate / 100)) / 12);
    }
    return sum;
  }, 0);

  const goldItems = activeInvestments.filter(i => i.type === 'gold');
  const totalGoldWeightBhori = goldItems.reduce((sum, g) => sum + (g.goldWeightBhori || 0), 0);
  const totalGoldCurrentValue = goldItems.reduce((sum, g) => sum + (g.currentValue || 0), 0);

  const goldEligibleForZakat = goldItems.filter(g => g.hasZakatPayable);
  const totalZakatBhori = goldEligibleForZakat.reduce((sum, g) => sum + (g.goldWeightBhori || 0), 0);
  const totalGoldZakatPayable =
    totalZakatBhori >= 7.5
      ? Math.round(
          goldEligibleForZakat.reduce((sum, g) => sum + (g.currentValue || 0), 0) * 0.025
        )
      : 0;

  const upcomingDPSInstallments = activeInvestments
    .filter(i => i.type === 'dps' && i.nextInstallmentDueDate)
    .sort(
      (a, b) =>
        new Date(a.nextInstallmentDueDate!).getTime() -
        new Date(b.nextInstallmentDueDate!).getTime()
    );

  const activeTrip = trips.find(t => t.status === 'active') || null;

  // No-Spend streak & challenge statistics
  const noSpendDatesSet = new Set(
    noSpendRecords.filter(r => r.status === 'no_spend').map(r => r.date)
  );

  let currentNoSpendStreak = 0;
  const streakNow = new Date();
  const todayDateStr = streakNow.toISOString().split('T')[0];
  const yesterday = new Date(streakNow);
  yesterday.setDate(streakNow.getDate() - 1);
  const yesterdayDateStr = yesterday.toISOString().split('T')[0];

  let streakCheckDate = new Date(streakNow);
  if (!noSpendDatesSet.has(todayDateStr) && noSpendDatesSet.has(yesterdayDateStr)) {
    streakCheckDate = yesterday;
  }

  while (true) {
    const dStr = streakCheckDate.toISOString().split('T')[0];
    if (noSpendDatesSet.has(dStr)) {
      currentNoSpendStreak++;
      streakCheckDate.setDate(streakCheckDate.getDate() - 1);
    } else {
      break;
    }
  }

  // Best streak calculation
  const sortedNoSpendDates = Array.from(noSpendDatesSet).sort();
  let bestNoSpendStreak = 0;
  let tempStreak = 0;
  let prevDate: Date | null = null;
  for (const dStr of sortedNoSpendDates) {
    const curr = new Date(dStr);
    if (!prevDate) {
      tempStreak = 1;
    } else {
      const diffDays = Math.round((curr.getTime() - prevDate.getTime()) / (1000 * 3600 * 24));
      if (diffDays === 1) {
        tempStreak++;
      } else {
        tempStreak = 1;
      }
    }
    if (tempStreak > bestNoSpendStreak) {
      bestNoSpendStreak = tempStreak;
    }
    prevDate = curr;
  }
  bestNoSpendStreak = Math.max(bestNoSpendStreak, currentNoSpendStreak, 5);

  const totalSavedFromChallenges = savingsChallenges.reduce((sum, c) => sum + c.currentAmount, 0);
  const userLevel = Math.min(10, Math.floor(userXP / 500) + 1);

  // Smart Bazar calculations
  const estimatedBazarTotal = bazarItems.reduce((sum, item) => sum + (item.estimatedPrice || 0), 0);
  const actualBazarSpent = bazarItems
    .filter(i => i.isPurchased)
    .reduce((sum, item) => sum + (item.actualPrice !== undefined ? item.actualPrice : item.estimatedPrice || 0), 0);
  const bazarCompletedCount = bazarItems.filter(i => i.isPurchased).length;
  const bazarTotalCount = bazarItems.length;
  const bazarSavingsSoFar = bazarItems
    .filter(i => i.isPurchased && i.actualPrice !== undefined && i.actualPrice < i.estimatedPrice)
    .reduce((sum, item) => sum + (item.estimatedPrice - (item.actualPrice || 0)), 0);

  // Central AI Computed Intelligence
  const aiHealthScore = useMemo(() => {
    return calculateFinancialHealthScore({
      transactions,
      budgets,
      accounts,
      debts,
      subscriptions,
      totalIncomeThisMonth,
      totalExpenseThisMonth,
      language,
    });
  }, [transactions, budgets, accounts, debts, subscriptions, totalIncomeThisMonth, totalExpenseThisMonth, language]);

  const aiAnomalies = useMemo(() => {
    return detectAnomaliesAndRisks({
      transactions,
      categories,
      budgets,
      accounts,
      subscriptions,
      digitalCards,
      debts,
      totalBalance,
      totalIncomeThisMonth,
      totalExpenseThisMonth,
      currency,
      language,
    });
  }, [transactions, categories, budgets, accounts, subscriptions, digitalCards, debts, totalBalance, totalIncomeThisMonth, totalExpenseThisMonth, currency, language]);

  const aiNetWorth = useMemo(() => {
    return calculateNetWorthIntelligence({
      accounts,
      investments,
      debts,
      subscriptions,
      digitalCards,
      language,
      currency,
    });
  }, [accounts, investments, debts, subscriptions, digitalCards, language, currency]);

  const aiCashFlowForecast = useMemo(() => {
    return calculateCashFlowForecast({
      accounts,
      subscriptions,
      totalIncomeThisMonth,
      totalExpenseThisMonth,
      currency,
      language,
    });
  }, [accounts, subscriptions, totalIncomeThisMonth, totalExpenseThisMonth, currency, language]);

  // ==================== SMART PAYMENT PRIORITY ENGINE CALCULATIONS ====================
  // Total liquid available funds (Cash, Bank, Mobile Wallets, Savings - excluding credit lines)
  const totalLiquidAvailableFunds = useMemo(() => {
    return accounts
      .filter((a) => ['cash', 'bank', 'mobile_wallet', 'savings'].includes(a.type))
      .reduce((sum, a) => sum + (a.balance || 0), 0);
  }, [accounts]);

  // All extracted unpaid obligations across bills, debts, credit card minimums, and custom entries
  const allPaymentObligations = useMemo(() => {
    return extractAllObligations({
      subscriptions,
      debts,
      digitalCards,
      investments,
      customObligations,
      transactions,
      activeCurrency: currency,
      config: paymentEngineConfig,
    });
  }, [subscriptions, debts, digitalCards, investments, customObligations, transactions, currency, paymentEngineConfig]);

  // Ranked obligations & cash flow shortfall analysis
  const priorityEngineOutput = useMemo(() => {
    return rankObligations(
      allPaymentObligations,
      selectedPaymentStrategy,
      totalLiquidAvailableFunds,
      paymentEngineConfig
    );
  }, [allPaymentObligations, selectedPaymentStrategy, totalLiquidAvailableFunds, paymentEngineConfig]);

  const rankedPaymentObligations = priorityEngineOutput.rankedItems;
  const cashFlowAnalysis = priorityEngineOutput.cashFlow;

  // ==================== ADVANCED REMINDER & NOTIFICATION ENGINE ====================
  const allNotifications = useMemo<AppNotification[]>(() => {
    const list: AppNotification[] = [];
    const today = new Date();
    const todayStr = today.toISOString().slice(0, 10);
    const todayTime = new Date(todayStr).getTime();

    // 1. Subscriptions & Recurring Bills
    subscriptions.forEach(sub => {
      if (sub.status !== 'active') return;
      const dueTime = new Date(sub.dueDate).getTime();
      const diffDays = Math.round((dueTime - todayTime) / 86400000);

      if (diffDays < 0) {
        // Overdue
        const notifId = `notif-sub-overdue-${sub.id}-${sub.dueDate}`;
        list.push({
          id: notifId,
          type: 'bill_due',
          title: 'বিল পরিশোধের তারিখ পার হয়েছে!',
          titleBn: 'বিল পরিশোধের তারিখ পার হয়েছে!',
          message: `${sub.name}-এর ${formatMoney(sub.amount)} বিল ${Math.abs(diffDays)} দিন আগে দেওয়ার কথা ছিল। বিলম্ব ফি এড়াতে দ্রুত পরিশোধ করুন।`,
          messageBn: `${sub.name}-এর ${formatMoney(sub.amount)} বিল ${Math.abs(diffDays)} দিন আগে দেওয়ার কথা ছিল। বিলম্ব ফি এড়াতে দ্রুত পরিশোধ করুন।`,
          severity: 'danger',
          date: todayStr,
          dueDate: sub.dueDate,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          amount: sub.amount,
          entityId: sub.id,
          targetTab: 'subscriptions',
          actionType: 'pay_bill',
          createdAt: todayStr,
        });
      } else if (diffDays === 0) {
        // Due Today
        const notifId = `notif-sub-today-${sub.id}-${sub.dueDate}`;
        list.push({
          id: notifId,
          type: 'bill_due',
          title: 'আজকে বিলের শেষ তারিখ!',
          titleBn: 'আজকে বিলের শেষ তারিখ!',
          message: `${sub.name}-এর ${formatMoney(sub.amount)} বিল আজকেই পরিশোধ করতে হবে।`,
          messageBn: `${sub.name}-এর ${formatMoney(sub.amount)} বিল আজকেই পরিশোধ করতে হবে।`,
          severity: 'danger',
          date: todayStr,
          dueDate: sub.dueDate,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          amount: sub.amount,
          entityId: sub.id,
          targetTab: 'subscriptions',
          actionType: 'pay_bill',
          createdAt: todayStr,
        });
      } else if (diffDays > 0 && diffDays <= notificationSettings.billDueDaysBefore) {
        // Due Soon (Advance notice)
        const notifId = `notif-sub-soon-${sub.id}-${sub.dueDate}`;
        list.push({
          id: notifId,
          type: 'bill_due',
          title: `বিল আসন্ন (${diffDays} দিন বাকি)`,
          titleBn: `বিল আসন্ন (${diffDays} দিন বাকি)`,
          message: `${sub.name}-এর ${formatMoney(sub.amount)} বিলের শেষ সময় ${sub.dueDate}। পর্যাপ্ত টাকা অ্যাকাউন্টে রাখুন।`,
          messageBn: `${sub.name}-এর ${formatMoney(sub.amount)} বিলের শেষ সময় ${sub.dueDate}। পর্যাপ্ত টাকা অ্যাকাউন্টে রাখুন।`,
          severity: 'warning',
          date: todayStr,
          dueDate: sub.dueDate,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          amount: sub.amount,
          entityId: sub.id,
          targetTab: 'subscriptions',
          actionType: 'pay_bill',
          createdAt: todayStr,
        });
      }
    });

    // 2. Budget Threshold Warnings
    const currentYearMonth = todayStr.slice(0, 7);
    budgets.forEach(b => {
      if (b.month && b.month !== currentYearMonth) return;
      const category = categories.find(c => c.id === b.categoryId);
      if (!category) return;

      const spent = transactions
        .filter(t => t.type === 'expense' && t.categoryId === b.categoryId && t.date.startsWith(currentYearMonth))
        .reduce((sum, t) => sum + t.amount, 0);

      const ratio = b.monthlyLimit > 0 ? spent / b.monthlyLimit : 0;
      const notifId = `notif-budget-${b.id}-${currentYearMonth}`;

      if (ratio >= 1) {
        list.push({
          id: notifId,
          type: 'budget_warning',
          title: 'বাজেট সীমা অতিক্রম করেছে!',
          titleBn: 'বাজেট সীমা অতিক্রম করেছে!',
          message: `${category.nameBn || category.name}-এ নির্ধারিত ${formatMoney(b.monthlyLimit)}-এর বিপরীতে খরচ হয়েছে ${formatMoney(spent)} (${Math.round(ratio * 100)}%)! অবিলম্বে খরচ নিয়ন্ত্রণ করুন।`,
          messageBn: `${category.nameBn || category.name}-এ নির্ধারিত ${formatMoney(b.monthlyLimit)}-এর বিপরীতে খরচ হয়েছে ${formatMoney(spent)} (${Math.round(ratio * 100)}%)! অবিলম্বে খরচ নিয়ন্ত্রণ করুন।`,
          severity: 'danger',
          date: todayStr,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          amount: spent,
          entityId: b.id,
          targetTab: 'budgets',
          actionType: 'view_budget',
          createdAt: todayStr,
        });
      } else if (ratio >= notificationSettings.budgetAlertThreshold) {
        list.push({
          id: notifId,
          type: 'budget_warning',
          title: `বাজেট সতর্কতা (${Math.round(ratio * 100)}% শেষ)`,
          titleBn: `বাজেট সতর্কতা (${Math.round(ratio * 100)}% শেষ)`,
          message: `${category.nameBn || category.name} ক্যাটাগরিতে বাজেটের প্রায় ${Math.round(ratio * 100)}% খরচ হয়ে গেছে (${formatMoney(spent)} / ${formatMoney(b.monthlyLimit)})। বাকি দিনগুলো বুঝে চলুন।`,
          messageBn: `${category.nameBn || category.name} ক্যাটাগরিতে বাজেটের প্রায় ${Math.round(ratio * 100)}% খরচ হয়ে গেছে (${formatMoney(spent)} / ${formatMoney(b.monthlyLimit)})। বাকি দিনগুলো বুঝে চলুন।`,
          severity: 'warning',
          date: todayStr,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          amount: spent,
          entityId: b.id,
          targetTab: 'budgets',
          actionType: 'view_budget',
          createdAt: todayStr,
        });
      }
    });

    // 3. Debts & Loans Due
    debts.forEach(d => {
      if (d.settled) return;
      const remaining = d.amount - d.paidAmount;
      if (remaining <= 0) return;

      const dueTime = new Date(d.dueDate).getTime();
      const diffDays = Math.round((dueTime - todayTime) / 86400000);
      const notifId = `notif-debt-${d.id}-${d.dueDate}`;

      if (diffDays <= 2) {
        if (d.type === 'borrowed') {
          list.push({
            id: notifId,
            type: 'debt_due',
            title: diffDays < 0 ? 'ঋণ পরিশোধের ডেডলাইন পার হয়েছে!' : 'ঋণ পরিশোধের সময় হয়েছে',
            titleBn: diffDays < 0 ? 'ঋণ পরিশোধের ডেডলাইন পার হয়েছে!' : 'ঋণ পরিশোধের সময় হয়েছে',
            message: `${d.personName}-কে ${formatMoney(remaining)} ফেরত দেওয়ার তারিখ ${d.dueDate}।`,
            messageBn: `${d.personName}-কে ${formatMoney(remaining)} ফেরত দেওয়ার তারিখ ${d.dueDate}।`,
            severity: diffDays <= 0 ? 'danger' : 'warning',
            date: todayStr,
            dueDate: d.dueDate,
            isRead: readNotificationIds.includes(notifId),
            isDismissed: dismissedNotificationIds.includes(notifId),
            snoozedUntil: snoozedNotifications[notifId],
            amount: remaining,
            entityId: d.id,
            targetTab: 'debts',
            actionType: 'collect_debt',
            createdAt: todayStr,
          });
        } else {
          list.push({
            id: notifId,
            type: 'debt_due',
            title: diffDays < 0 ? 'পাওনা টাকা আদায়ের সময় পার হয়েছে' : 'পাওনা টাকা তাগাদার সময় হয়েছে',
            titleBn: diffDays < 0 ? 'পাওনা টাকা আদায়ের সময় পার হয়েছে' : 'পাওনা টাকা তাগাদার সময় হয়েছে',
            message: `${d.personName}-এর কাছে ${formatMoney(remaining)} পাওনা রয়েছে (${d.dueDate})। এক ক্লিকেই হোয়াটসঅ্যাপ তাগাদা পাঠান।`,
            messageBn: `${d.personName}-এর কাছে ${formatMoney(remaining)} পাওনা রয়েছে (${d.dueDate})। এক ক্লিকেই হোয়াটসঅ্যাপ তাগাদা পাঠান।`,
            severity: 'info',
            date: todayStr,
            dueDate: d.dueDate,
            isRead: readNotificationIds.includes(notifId),
            isDismissed: dismissedNotificationIds.includes(notifId),
            snoozedUntil: snoozedNotifications[notifId],
            amount: remaining,
            entityId: d.id,
            targetTab: 'debts',
            actionType: 'collect_debt',
            createdAt: todayStr,
          });
        }
      }
    });

    // 4. Low Balance Alert
    const liquidAccounts = accounts.filter(a => ['cash', 'bank', 'mobile_wallet'].includes(a.type));
    const lowAccs = liquidAccounts.filter(a => a.balance < notificationSettings.lowBalanceThreshold);
    if (lowAccs.length > 0) {
      const notifId = `notif-low-balance-${todayStr}`;
      list.push({
        id: notifId,
        type: 'low_balance',
        title: 'লো-ব্যালেন্স সতর্কতা!',
        titleBn: 'লো-ব্যালেন্স সতর্কতা!',
        message: `${lowAccs.map(a => a.nameBn || a.name).join(', ')}-এ ব্যালেন্স ${formatMoney(notificationSettings.lowBalanceThreshold)}-এর কম। জরুরি খরচ বা বিলের জন্য ফান্ড যোগ করুন।`,
        messageBn: `${lowAccs.map(a => a.nameBn || a.name).join(', ')}-এ ব্যালেন্স ${formatMoney(notificationSettings.lowBalanceThreshold)}-এর কম। জরুরি খরচ বা বিলের জন্য ফান্ড যোগ করুন।`,
        severity: 'warning',
        date: todayStr,
        isRead: readNotificationIds.includes(notifId),
        isDismissed: dismissedNotificationIds.includes(notifId),
        snoozedUntil: snoozedNotifications[notifId],
        targetTab: 'wallets',
        actionType: 'view_account',
        createdAt: todayStr,
      });
    }

    // 5. Daily Expense Log Prompt
    if (notificationSettings.dailyReminderEnabled) {
      const hasTodayExpense = transactions.some(t => t.type === 'expense' && t.date === todayStr);
      if (!hasTodayExpense) {
        const notifId = `notif-daily-log-${todayStr}`;
        list.push({
          id: notifId,
          type: 'daily_log',
          title: 'আজকের খরচের হিসাব লিখেছেন?',
          titleBn: 'আজকের খরচের হিসাব লিখেছেন?',
          message: 'আজকের বাজার, যাতায়াত বা দৈনন্দিন ছোট ছোট খরচগুলো লিখে রাখুন যাতে মাস শেষে হিসাব মিল থাকে।',
          messageBn: 'আজকের বাজার, যাতায়াত বা দৈনন্দিন ছোট ছোট খরচগুলো লিখে রাখুন যাতে মাস শেষে হিসাব মিল থাকে।',
          severity: 'info',
          date: todayStr,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          targetTab: 'transactions',
          actionType: 'log_expense',
          createdAt: todayStr,
        });
      }
    }

    // 6. Custom Reminders
    customReminders.forEach(cr => {
      if (cr.completed) return;
      const dueTime = new Date(cr.dueDate).getTime();
      const diffDays = Math.round((dueTime - todayTime) / 86400000);
      const notifId = `notif-custom-${cr.id}-${cr.dueDate}`;

      if (diffDays <= 1) {
        list.push({
          id: notifId,
          type: 'custom_reminder',
          title: cr.title,
          titleBn: cr.title,
          message: `${cr.notes ? cr.notes + ' • ' : ''}${cr.amount ? 'টাকা: ' + formatMoney(cr.amount) + ' • ' : ''}তারিখ: ${cr.dueDate}${cr.dueTime ? ' ' + cr.dueTime : ''}`,
          messageBn: `${cr.notes ? cr.notes + ' • ' : ''}${cr.amount ? 'টাকা: ' + formatMoney(cr.amount) + ' • ' : ''}তারিখ: ${cr.dueDate}${cr.dueTime ? ' ' + cr.dueTime : ''}`,
          severity: diffDays < 0 ? 'danger' : 'info',
          date: todayStr,
          dueDate: cr.dueDate,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          amount: cr.amount,
          entityId: cr.id,
          createdAt: cr.createdAt || todayStr,
        });
      }
    });

    // 7. Smart Payment Priority Engine Alerts
    // A. Critical Shortfall Alert
    if (cashFlowAnalysis.hasShortfall && cashFlowAnalysis.shortfallRiskLevel === 'critical_shortfall') {
      const notifId = `notif-priority-shortfall-${todayStr}`;
      list.push({
        id: notifId,
        type: 'low_balance',
        title: 'ফান্ড ঘাটতি (Shortfall) সতর্কতা!',
        titleBn: 'ফান্ড ঘাটতি (Shortfall) সতর্কতা!',
        message: `আসন্ন জরুরি বিল ও কিস্তির তুলনায় একাউন্টে ${formatMoney(cashFlowAnalysis.shortfallAmount)} ঘাটতি রয়েছে। প্রায়োরিটি ইঞ্জিন অনুযায়ী জরুরি বিলগুলো আগে পরিশোধ করুন।`,
        messageBn: `আসন্ন জরুরি বিল ও কিস্তির তুলনায় একাউন্টে ${formatMoney(cashFlowAnalysis.shortfallAmount)} ঘাটতি রয়েছে। প্রায়োরিটি ইঞ্জিন অনুযায়ী জরুরি বিলগুলো আগে পরিশোধ করুন।`,
        severity: 'danger',
        date: todayStr,
        isRead: readNotificationIds.includes(notifId),
        isDismissed: dismissedNotificationIds.includes(notifId),
        snoozedUntil: snoozedNotifications[notifId],
        targetTab: 'payment_priority',
        actionType: 'view_budget',
        createdAt: todayStr,
      });
    }

    // B. Critical Priority Payments (Overdue or Due within lead days)
    rankedPaymentObligations.forEach((item) => {
      const ob = item.obligation;
      if (item.scoreBreakdown.level === 'critical' && (ob.isOverdue || ob.daysRemaining <= paymentEngineConfig.advanceReminderDays)) {
        const notifId = `notif-priority-crit-${ob.id}-${ob.dueDate}`;
        list.push({
          id: notifId,
          type: 'bill_due',
          title: ob.isOverdue ? '🚨 বকেয়া অতি-জরুরি পেমেন্ট!' : '⚠️ সর্বোচ্চ অগ্রাধিকার পেমেন্ট!',
          titleBn: ob.isOverdue ? '🚨 বকেয়া অতি-জরুরি পেমেন্ট!' : '⚠️ সর্বোচ্চ অগ্রাধিকার পেমেন্ট!',
          message: `${ob.nameBn || ob.name} — ${formatMoney(ob.amountConverted)}। ${item.scoreBreakdown.explanationSummaryBn}`,
          messageBn: `${ob.nameBn || ob.name} — ${formatMoney(ob.amountConverted)}। ${item.scoreBreakdown.explanationSummaryBn}`,
          severity: 'danger',
          date: todayStr,
          dueDate: ob.dueDate,
          isRead: readNotificationIds.includes(notifId),
          isDismissed: dismissedNotificationIds.includes(notifId),
          snoozedUntil: snoozedNotifications[notifId],
          amount: ob.amountConverted,
          entityId: ob.id,
          targetTab: 'payment_priority',
          actionType: 'pay_bill',
          createdAt: todayStr,
        });
      }
    });

    return list;
  }, [
    subscriptions,
    budgets,
    categories,
    transactions,
    debts,
    accounts,
    customReminders,
    notificationSettings,
    readNotificationIds,
    dismissedNotificationIds,
    snoozedNotifications,
    formatMoney,
    rankedPaymentObligations,
    cashFlowAnalysis,
    paymentEngineConfig.advanceReminderDays,
  ]);


  const notifications = useMemo(() => {
    const todayStr = new Date().toISOString().slice(0, 10);
    return allNotifications.filter(n => {
      if (n.isDismissed) return false;
      if (n.snoozedUntil && n.snoozedUntil > todayStr) return false;
      return true;
    });
  }, [allNotifications]);

  const unreadNotificationsCount = useMemo(() => {
    return notifications.filter(n => !n.isRead).length;
  }, [notifications]);

  const markNotificationAsRead = useCallback((id: string) => {
    setReadNotificationIds(prev => prev.includes(id) ? prev : [...prev, id]);
  }, []);

  const markAllNotificationsAsRead = useCallback(() => {
    setReadNotificationIds(prev => {
      const allIds = notifications.map(n => n.id);
      return Array.from(new Set([...prev, ...allIds]));
    });
  }, [notifications]);

  const dismissNotification = useCallback((id: string) => {
    setDismissedNotificationIds(prev => prev.includes(id) ? prev : [...prev, id]);
  }, []);

  const snoozeNotification = useCallback((id: string, days = 1) => {
    const targetDate = new Date();
    targetDate.setDate(targetDate.getDate() + days);
    const dateStr = targetDate.toISOString().slice(0, 10);
    setSnoozedNotifications(prev => ({ ...prev, [id]: dateStr }));
  }, []);

  const clearAllNotifications = useCallback(() => {
    const allIds = notifications.map(n => n.id);
    setDismissedNotificationIds(prev => Array.from(new Set([...prev, ...allIds])));
  }, [notifications]);

  const addCustomReminder = useCallback((reminder: Omit<CustomReminder, 'id' | 'createdAt' | 'completed'>) => {
    const newRem: CustomReminder = {
      ...reminder,
      id: `reminder-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      completed: false,
      createdAt: new Date().toISOString().slice(0, 10),
    };
    setCustomReminders(prev => [newRem, ...prev]);
    if (notificationSettings.enableSound) {
      playNotificationChime();
    }
  }, [notificationSettings.enableSound]);

  const deleteCustomReminder = useCallback((id: string) => {
    setCustomReminders(prev => prev.filter(r => r.id !== id));
  }, []);

  const toggleCustomReminder = useCallback((id: string) => {
    setCustomReminders(prev => prev.map(r => r.id === id ? { ...r, completed: !r.completed } : r));
  }, []);

  const updateNotificationSettings = useCallback((newSettings: Partial<NotificationSettings>) => {
    setNotificationSettings(prev => ({ ...prev, ...newSettings }));
  }, []);

  const requestBrowserPush = useCallback(async () => {
    const permission = await requestBrowserPushPermission();
    const granted = permission === 'granted';
    setNotificationSettings(prev => ({ ...prev, enableBrowserPush: granted }));
    return granted;
  }, []);

  const triggerTestNotification = useCallback(() => {
    if (notificationSettings.enableSound) {
      playNotificationChime();
    }
    if (notificationSettings.enableBrowserPush) {
      sendBrowserPushNotification(
        'Khoroc রিমাইন্ডার টেস্ট',
        'অভিনন্দন! আপনার নোটিফিকেশন সিস্টেম সফলভাবে চালু আছে।'
      );
    }
  }, [notificationSettings]);

  const playNotificationSound = useCallback(() => {
    playNotificationChime();
  }, []);

  const sendWhatsAppDebtReminder = useCallback((debt: Debt) => {
    const text = generateCourteousDebtReminderMessage(
      debt.personName,
      debt.amount - debt.paidAmount,
      currency.symbol,
      debt.dueDate,
      debt.type,
      language
    );
    const phoneClean = debt.phone ? debt.phone.replace(/[^0-9]/g, '') : '';
    const url = phoneClean 
      ? `https://wa.me/${phoneClean}?text=${encodeURIComponent(text)}`
      : `https://wa.me/?text=${encodeURIComponent(text)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  }, [currency.symbol, language]);

  // ==================== SMART PAYMENT PRIORITY ENGINE ACTIONS ====================
  const addCustomObligation = useCallback((obligation: CustomObligationInput) => {
    setCustomObligations(prev => [obligation, ...prev]);
    if (notificationSettings.enableSound) {
      playNotificationChime();
    }
  }, [notificationSettings.enableSound]);

  const updateCustomObligation = useCallback((index: number, obligation: CustomObligationInput) => {
    setCustomObligations(prev => {
      const copy = [...prev];
      copy[index] = obligation;
      return copy;
    });
  }, []);

  const deleteCustomObligation = useCallback((index: number) => {
    setCustomObligations(prev => prev.filter((_, i) => i !== index));
  }, []);

  const updatePaymentEngineConfig = useCallback((cfg: Partial<PaymentEngineConfig>) => {
    setPaymentEngineConfig(prev => ({
      ...prev,
      ...cfg,
      weights: { ...prev.weights, ...(cfg.weights || {}) },
      thresholds: { ...prev.thresholds, ...(cfg.thresholds || {}) },
    }));
  }, []);

  const markObligationPaid = useCallback((
    obligation: PaymentObligation,
    paymentDetails: { accountId: string; amount: number; date: string; note?: string }
  ) => {
    const payAmount = paymentDetails.amount;
    const noteText = paymentDetails.note || `${obligation.nameBn || obligation.name} পরিশোধ`;

    if (obligation.sourceType === 'bill') {
      paySubscriptionBill(obligation.sourceId, paymentDetails.accountId, obligation.linkedCardId, paymentDetails.date, payAmount, noteText);
    } else if (obligation.sourceType === 'debt_borrowed' || obligation.sourceType === 'emi_loan') {
      recordDebtPayment(obligation.sourceId, payAmount);
      addTransaction({
        type: 'expense',
        amount: payAmount,
        accountId: paymentDetails.accountId,
        categoryId: 'cat-others',
        date: paymentDetails.date,
        note: noteText,
      });
    } else if (obligation.sourceType === 'credit_card_min' || obligation.sourceType === 'credit_card_full') {
      if (obligation.linkedCardId) {
        setDigitalCards(prev => prev.map(c => {
          if (c.id === obligation.linkedCardId) {
            return {
              ...c,
              currentSpentThisMonth: Math.max(0, (c.currentSpentThisMonth || 0) - payAmount),
            };
          }
          return c;
        }));
      }
      addTransaction({
        type: 'expense',
        amount: payAmount,
        accountId: paymentDetails.accountId,
        categoryId: 'cat-bills',
        date: paymentDetails.date,
        note: `${obligation.nameBn || obligation.name} পেমেন্ট`,
        cardId: obligation.linkedCardId,
      });
    } else if (obligation.sourceType === 'dps_installment') {
      payDPSInstallment(obligation.sourceId, paymentDetails.accountId, payAmount, paymentDetails.date, noteText);
    } else if (obligation.sourceType === 'custom') {
      addTransaction({
        type: 'expense',
        amount: payAmount,
        accountId: paymentDetails.accountId,
        categoryId: 'cat-bills',
        date: paymentDetails.date,
        note: noteText,
      });
      // Filter out completed custom obligation
      setCustomObligations(prev => prev.filter(c => c.name !== obligation.name));
    }

    if (notificationSettings.enableSound) {
      playNotificationChime();
    }
  }, [paySubscriptionBill, recordDebtPayment, addTransaction, payDPSInstallment, notificationSettings.enableSound]);

  const rescheduleObligation = useCallback((obligationId: string, newDueDate: string) => {
    if (obligationId.startsWith('sub-')) {
      const subId = obligationId.replace('sub-', '');
      setSubscriptions(prev => prev.map(s => s.id === subId ? { ...s, dueDate: newDueDate } : s));
    } else if (obligationId.startsWith('debt-')) {
      const debtId = obligationId.replace('debt-', '');
      setDebts(prev => prev.map(d => d.id === debtId ? { ...d, dueDate: newDueDate } : d));
    } else if (obligationId.startsWith('custom-')) {
      setCustomObligations(prev => prev.map(c => {
        if (obligationId.includes(c.name.replace(/\s+/g, '-').toLowerCase())) {
          return { ...c, dueDate: newDueDate };
        }
        return c;
      }));
    }
  }, []);

  const runSimulation = useCallback((input: WhatIfSimulationInput): WhatIfSimulationResult => {
    return runWhatIfSimulation(
      allPaymentObligations,
      cashFlowAnalysis.availableBalance,
      input,
      paymentEngineConfig
    );
  }, [allPaymentObligations, cashFlowAnalysis.availableBalance, paymentEngineConfig]);

  return (
    <ExpenseContext.Provider
      value={{
        transactions,
        categories,
        accounts,
        budgets,
        goals,
        debts,
        billSplits,
        wishlistItems,
        digitalCards,
        subscriptions,
        aiHealthScore,
        aiAnomalies,
        aiActionProposals,
        aiActivityLogs,
        aiMemory,
        aiNetWorth,
        aiCashFlowForecast,
        aiChatMessages,
        executeAIAction,
        dismissAIAction,
        addAIActionProposal,
        addAIActivityLog,
        updateAIMemoryPreferences,
        recordCategoryCorrection,
        sendAICommand,
        activeActionConfirmationModal,
        setActiveActionConfirmationModal,
        generateAIReport,
        bazarItems,
        bazarMarketCommodities,
        addBazarItem,
        editBazarItem,
        deleteBazarItem,
        toggleBazarItemPurchased,
        updateBazarItemActualPrice,
        clearPurchasedBazarItems,
        clearAllBazarItems,
        resetBazarListToDefault,
        checkoutBazarList,
        addPriceHistoryLog,
        updateMarketCommodity,
        addMarketCommodity,
        estimatedBazarTotal,
        actualBazarSpent,
        bazarSavingsSoFar,
        bazarCompletedCount,
        bazarTotalCount,
        messData,
        setMessData,
        updateMessConfig,
        addMessMember,
        editMessMember,
        deleteMessMember,
        setMemberDailyMeal,
        quickIncrementMeal,
        addBazarEntry,
        deleteBazarEntry,
        addDepositEntry,
        deleteDepositEntry,
        addFixedCost,
        editFixedCost,
        deleteFixedCost,
        addBazarSchedule,
        deleteBazarSchedule,
        resetMessMonth,
        totalMessMeals,
        totalMessBazarCost,
        messMealRate,
        totalMessFixedCost,
        fixedCostPerMember,
        totalMessDeposits,
        messCashInHand,
        memberSummaries,
        investments,
        goldMarketRates,
        addInvestment,
        editInvestment,
        deleteInvestment,
        updateGoldRates,
        payDPSInstallment,
        recordInvestmentProfitPayout,
        totalPortfolioValue,
        totalInvestedPrincipal,
        totalUnrealizedGain,
        unrealizedGainPercentage,
        totalMonthlyEstimatedYield,
        totalGoldWeightBhori,
        totalGoldCurrentValue,
        totalGoldZakatPayable,
        upcomingDPSInstallments,
        trips,
        activeTrip,
        addTrip,
        editTrip,
        deleteTrip,
        setActiveTripStatus,
        addTripExpense,
        deleteTripExpense,
        addTripMember,
        deleteTripMember,
        recordTripMemberDeposit,
        toggleTripPackingItem,
        addTripPackingItem,
        deleteTripPackingItem,
        addTripItineraryDay,
        deleteTripItineraryDay,
        savingsChallenges,
        noSpendRecords,
        gamificationBadges,
        userXP,
        userLevel,
        currentNoSpendStreak,
        bestNoSpendStreak,
        totalSavedFromChallenges,
        toggleNoSpendDay,
        addSavingsChallenge,
        checkInChallengeDay,
        deleteSavingsChallenge,
        currency,
        language,
        activeTab,
        setActiveTab,
        walletSubTab,
        setWalletSubTab,
        subscriptionFilterTab,
        setSubscriptionFilterTab,
        setLanguage,
        setCurrency,
        safeToSpendConfig,
        setSafeToSpendConfig,
        todayExpense,
        todayDailySafeLimit,
        todayRemainingSafeToSpend,
        safeToSpendPercentUsed,
        safeToSpendStatus,
        daysRemainingInMonth,
        totalDaysInMonth,
        monthlySpendingCap,
        remainingMonthlyCap,
        projectedTomorrowSafeLimit,
        addTransaction,
        editTransaction,
        deleteTransaction,
        addAccount,
        editAccount,
        deleteAccount,
        transferMoney,
        setCategoryBudget,
        deleteBudget,
        addGoal,
        updateGoalSavings,
        deleteGoal,
        addDebt,
        recordDebtPayment,
        toggleDebtSettled,
        deleteDebt,
        addBillSplit,
        toggleSplitMemberPaid,
        deleteBillSplit,
        addWishlistItem,
        editWishlistItem,
        deleteWishlistItem,
        markWishlistPurchased,
        dropWishlistItem,
        totalMoneySavedFromImpulse,
        activeCoolingCount,
        readyDecisionCount,
        addDigitalCard,
        editDigitalCard,
        deleteDigitalCard,
        setDefaultDigitalCard,
        toggleFreezeDigitalCard,
        simulateCardTapPayment,
        addSubscription,
        editSubscription,
        deleteSubscription,
        togglePauseSubscription,
        paySubscriptionBill,
        totalMonthlyRecurring,
        totalYearlyRecurring,
        paidThisMonthRecurring,
        pendingThisMonthRecurring,
        upcomingBills,
        overdueBillsCount,
        dueSoonBillsCount,
        parseSmartQuickAdd,
        formatMoney,
        t,
        exportCSV,
        exportJSON,
        importJSON,
        resetAll,
        isResetModalOpen,
        setIsResetModalOpen,
        // Cloud Auth & Sync
        currentUser,
        authSession,
        isAuthLoading,
        isCloudSyncing,
        syncStatus,
        lastSyncedTime,
        authError,
        syncError,
        registerUser,
        loginUser,
        handleGoogleSignIn,
        handleSignOut,
        changePassword,
        checkUsernameAvailable,
        getSecurityQuestionsForRecovery,
        verifySecurityAnswersForRecovery,
        resetPasswordWithToken,
        updateSecurityQuestions,
        syncAllToCloudNow,
        pullFromCloudNow,
        isAuthModalOpen,
        setIsAuthModalOpen,
        // Sidebar Navigation Controls
        isSidebarOpen,
        setIsSidebarOpen,
        toggleSidebar,
        isSidebarCollapsed,
        setIsSidebarCollapsed,
        toggleSidebarCollapsed,

        // Advanced Reminder & Notification System
        notifications,
        unreadNotificationsCount,
        customReminders,
        notificationSettings,
        addCustomReminder,
        deleteCustomReminder,
        toggleCustomReminder,
        markNotificationAsRead,
        markAllNotificationsAsRead,
        dismissNotification,
        snoozeNotification,
        clearAllNotifications,
        updateNotificationSettings,
        requestBrowserPush,
        triggerTestNotification,
        sendWhatsAppDebtReminder,
        playNotificationSound,
        isNotificationCenterOpen,
        setIsNotificationCenterOpen,
        isAddReminderModalOpen,
        setIsAddReminderModalOpen,
        isNotificationSettingsModalOpen,
        setIsNotificationSettingsModalOpen,

        // Smart Payment Priority Engine
        allPaymentObligations,
        rankedPaymentObligations,
        cashFlowAnalysis,
        paymentEngineConfig,
        selectedPaymentStrategy,
        customObligations,
        addCustomObligation,
        updateCustomObligation,
        deleteCustomObligation,
        updatePaymentEngineConfig,
        setSelectedPaymentStrategy,
        markObligationPaid,
        rescheduleObligation,
        runSimulation,
        isPriorityConfigModalOpen,
        setIsPriorityConfigModalOpen,
        isAddCustomObligationModalOpen,
        setIsAddCustomObligationModalOpen,

        totalBalance,
        totalIncomeThisMonth,
        totalExpenseThisMonth,
        netSavingsThisMonth,
        savingsRateThisMonth,
      }}
    >
      {children}
    </ExpenseContext.Provider>
  );
};

export const useExpense = () => {
  const context = useContext(ExpenseContext);
  if (!context) {
    throw new Error('useExpense must be used within an ExpenseProvider');
  }
  return context;
};
