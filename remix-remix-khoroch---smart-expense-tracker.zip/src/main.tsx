import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register Workbox Service Worker for offline asset caching
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('[Workbox] New app content available, updating in background...');
  },
  onOfflineReady() {
    console.log('[Workbox] Essential static assets cached! App is ready for offline usage.');
  },
});

createRoot(document.getElementById('root')!).render(<App />);
