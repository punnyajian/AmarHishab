import React, { useState, useEffect } from 'react';
import { 
  DigitalCard, 
  DigitalCardNetwork, 
  DigitalCardType, 
  DigitalCardTheme 
} from '../types';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { DigitalCardItem } from './DigitalCardItem';
import { 
  X, 
  CreditCard, 
  Check, 
  Sparkles, 
  ShieldCheck, 
  Sliders, 
  Building 
} from 'lucide-react';

interface AddDigitalCardModalProps {
  isOpen: boolean;
  onClose: () => void;
  editCard?: DigitalCard | null;
}

export const AddDigitalCardModal: React.FC<AddDigitalCardModalProps> = ({
  isOpen,
  onClose,
  editCard,
}) => {
  useModalBehavior({ isOpen, onClose });

  const { 
    accounts, 
    addDigitalCard, 
    editDigitalCard, 
    language, 
    currency,
    currentUser,
  } = useExpense();

  const [cardholderName, setCardholderName] = useState(currentUser?.displayName?.toUpperCase() || '');
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [issuerName, setIssuerName] = useState('');
  const [type, setType] = useState<DigitalCardType>('credit');
  const [network, setNetwork] = useState<DigitalCardNetwork>('visa');
  const [theme, setTheme] = useState<DigitalCardTheme>('obsidian');
  const [linkedAccountId, setLinkedAccountId] = useState<string>('');
  const [creditLimit, setCreditLimit] = useState('150000');
  const [dailySpendLimit, setDailySpendLimit] = useState('50000');
  const [isDefault, setIsDefault] = useState(false);
  const [contactlessEnabled, setContactlessEnabled] = useState(true);

  // Bank issuer presets in Bangladesh and globally
  const issuerPresets = [
    { name: 'City Bank Platinum', network: 'visa', type: 'credit', theme: 'obsidian' },
    { name: 'BRAC Bank World Debit', network: 'mastercard', type: 'debit', theme: 'sapphire' },
    { name: 'Dutch-Bangla NexusPay', network: 'nexus', type: 'debit', theme: 'nexus' },
    { name: 'bKash Virtual Mastercard', network: 'mastercard', type: 'prepaid', theme: 'amethyst' },
    { name: 'Eastern Bank Visa Signature', network: 'visa', type: 'credit', theme: 'sunset' },
    { name: 'Standard Chartered Platinum', network: 'visa', type: 'credit', theme: 'platinum' },
  ];

  useEffect(() => {
    if (editCard) {
      setCardholderName(editCard.cardholderName);
      setCardNumber(editCard.cardNumberMasked);
      setExpiryDate(editCard.expiryDate);
      setCvv(editCard.cvv || '');
      setIssuerName(editCard.issuerName);
      setType(editCard.type);
      setNetwork(editCard.network);
      setTheme(editCard.theme);
      setLinkedAccountId(editCard.linkedAccountId || '');
      setCreditLimit(editCard.creditLimit ? editCard.creditLimit.toString() : '');
      setDailySpendLimit(editCard.dailySpendLimit ? editCard.dailySpendLimit.toString() : '');
      setIsDefault(!!editCard.isDefault);
      setContactlessEnabled(editCard.contactlessEnabled !== false);
    } else {
      setCardholderName(currentUser?.displayName?.toUpperCase() || '');
      setCardNumber('');
      setExpiryDate('');
      setCvv('');
      setIssuerName('');
      setType('debit');
      setNetwork('visa');
      setTheme('emerald');
      setLinkedAccountId(accounts[0]?.id || '');
      setCreditLimit('');
      setDailySpendLimit('');
      setIsDefault(false);
      setContactlessEnabled(true);
    }
  }, [editCard, accounts, isOpen, currentUser]);

  if (!isOpen) return null;

  // Auto-detect card network based on number
  const handleCardNumberChange = (raw: string) => {
    // Strip non-digits and non-spaces
    const cleaned = raw.replace(/[^\d]/g, '');
    // Format in chunks of 4
    let formatted = '';
    for (let i = 0; i < cleaned.length && i < 16; i++) {
      if (i > 0 && i % 4 === 0) formatted += ' ';
      formatted += cleaned[i];
    }
    setCardNumber(formatted);

    // Auto-detect brand
    if (cleaned.startsWith('4')) {
      setNetwork('visa');
    } else if (/^(5[1-5]|2[2-7])/.test(cleaned)) {
      setNetwork('mastercard');
    } else if (/^(34|37)/.test(cleaned)) {
      setNetwork('amex');
    } else if (cleaned.startsWith('6')) {
      setNetwork('nexus');
    }
  };

  const handleExpiryChange = (raw: string) => {
    const cleaned = raw.replace(/[^\d]/g, '');
    if (cleaned.length <= 2) {
      setExpiryDate(cleaned);
    } else {
      setExpiryDate(`${cleaned.slice(0, 2)}/${cleaned.slice(2, 4)}`);
    }
  };

  const handlePresetSelect = (preset: typeof issuerPresets[0]) => {
    setIssuerName(preset.name);
    setNetwork(preset.network as DigitalCardNetwork);
    setType(preset.type as DigitalCardType);
    setTheme(preset.theme as DigitalCardTheme);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!issuerName.trim() || !cardNumber.trim()) return;

    // Extract last 4 digits
    const digitsOnly = cardNumber.replace(/\D/g, '');
    const last4 = digitsOnly.slice(-4) || '1234';

    const cardPayload: Omit<DigitalCard, 'id' | 'addedAt'> = {
      cardholderName: cardholderName.trim().toUpperCase() || 'CARDHOLDER',
      cardNumberMasked: cardNumber.trim(),
      last4,
      network,
      type,
      issuerName: issuerName.trim(),
      expiryDate: expiryDate.trim() || '12/28',
      cvv: cvv.trim() || undefined,
      theme,
      isDefault,
      isFrozen: false,
      contactlessEnabled,
      creditLimit: type === 'credit' ? parseFloat(creditLimit) || undefined : undefined,
      dailySpendLimit: parseFloat(dailySpendLimit) || undefined,
      linkedAccountId: linkedAccountId || undefined,
      currentSpentThisMonth: editCard ? editCard.currentSpentThisMonth : 0,
    };

    if (editCard) {
      editDigitalCard({
        ...editCard,
        ...cardPayload,
      });
    } else {
      addDigitalCard(cardPayload);
    }

    onClose();
  };

  // Preview Card Object for live rendering
  const digitsOnly = cardNumber.replace(/\D/g, '');
  const previewLast4 = digitsOnly.slice(-4) || '9903';
  const previewCard: DigitalCard = {
    id: editCard?.id || 'preview-card',
    cardholderName: cardholderName.toUpperCase() || 'CARDHOLDER',
    cardNumberMasked: cardNumber || '•••• •••• •••• 9903',
    last4: previewLast4,
    network,
    type,
    issuerName: issuerName || 'City Bank Platinum',
    expiryDate: expiryDate || '08/29',
    cvv,
    theme,
    isDefault,
    isFrozen: false,
    contactlessEnabled,
    creditLimit: parseFloat(creditLimit) || 0,
    dailySpendLimit: parseFloat(dailySpendLimit) || 0,
    currentSpentThisMonth: editCard ? editCard.currentSpentThisMonth : 0,
    linkedAccountId,
    addedAt: '2026-01-01',
  };

  const themeOptions: { id: DigitalCardTheme; label: string; previewClass: string }[] = [
    { id: 'obsidian', label: 'Obsidian Black', previewClass: 'from-slate-950 via-slate-900 to-zinc-900' },
    { id: 'sapphire', label: 'Sapphire Blue', previewClass: 'from-blue-950 via-indigo-900 to-blue-800' },
    { id: 'emerald', label: 'Emerald Mint', previewClass: 'from-emerald-950 via-teal-900 to-emerald-800' },
    { id: 'amethyst', label: 'Neon Amethyst', previewClass: 'from-purple-950 via-fuchsia-900 to-indigo-900' },
    { id: 'sunset', label: 'Sunset Bronze', previewClass: 'from-amber-950 via-rose-900 to-orange-800' },
    { id: 'platinum', label: 'Platinum Silver', previewClass: 'from-slate-200 via-zinc-100 to-slate-300' },
    { id: 'nexus', label: 'DBBL Nexus', previewClass: 'from-sky-950 via-blue-900 to-cyan-900' },
  ];

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="bg-white rounded-t-3xl sm:rounded-3xl max-w-2xl w-full p-5 sm:p-6 shadow-2xl space-y-5 max-h-[92dvh] sm:max-h-[88vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6 relative"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />

        {/* Modal Top Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shadow-xs">
              <CreditCard className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-base text-slate-900">
                {editCard 
                  ? (language === 'bn' ? 'ডিজিটাল কার্ড এডিট করুন' : 'Edit Digital Card') 
                  : (language === 'bn' ? 'Google Wallet-এ নতুন কার্ড যোগ করুন' : 'Add Card to Google Wallet')}
              </h3>
              <p className="text-[11px] text-slate-500">
                {language === 'bn' ? 'নিরাপদ ভার্চুয়াল বা ফিজিক্যাল পেমেন্ট কার্ড' : 'Secure virtual or physical payment card'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Live Interactive Card Preview */}
        <div className="bg-slate-50/80 rounded-2xl p-3 sm:p-4 border border-slate-200/80">
          <div className="flex items-center justify-between mb-2 px-1">
            <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 flex items-center gap-1">
              <Sparkles className="w-3 h-3 text-amber-500" />
              {language === 'bn' ? 'লাইভ কার্ড প্রিভিউ' : 'Live Card Preview'}
            </span>
            <span className="text-[10px] text-slate-500 font-mono">
              {network.toUpperCase()} • {theme}
            </span>
          </div>

          <div className="max-w-md mx-auto">
            <DigitalCardItem card={previewCard} isDetailedView={false} />
          </div>
        </div>

        {/* Preset Bank Chips */}
        <div>
          <span className="text-[11px] font-bold text-slate-500 block mb-1.5">
            {language === 'bn' ? 'জনপ্রিয় কার্ড প্রিসেট নির্বাচন:' : 'Popular Card Presets:'}
          </span>
          <div className="flex flex-wrap gap-1.5">
            {issuerPresets.map((preset, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => handlePresetSelect(preset)}
                className={`px-2.5 py-1 text-xs font-semibold rounded-lg border transition-all ${
                  issuerName === preset.name
                    ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                    : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-100'
                }`}
              >
                {preset.name}
              </button>
            ))}
          </div>
        </div>

        {/* Add Card Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          {/* Card Name & Type */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'ব্যাংক বা কার্ডের নাম' : 'Bank / Card Name'}
              </label>
              <input
                type="text"
                required
                value={issuerName}
                onChange={e => setIssuerName(e.target.value)}
                placeholder="e.g. City Bank Platinum"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'কার্ডের ধরন' : 'Card Type'}
              </label>
              <select
                value={type}
                onChange={e => setType(e.target.value as DigitalCardType)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
              >
                <option value="credit">{language === 'bn' ? 'ক্রেডিট কার্ড (Credit)' : 'Credit Card'}</option>
                <option value="debit">{language === 'bn' ? 'ডেবিট কার্ড (Debit)' : 'Debit Card'}</option>
                <option value="prepaid">{language === 'bn' ? 'প্রিপেইড / ডুয়েল কারেন্সি (Virtual)' : 'Prepaid / Virtual Card'}</option>
                <option value="loyalty">{language === 'bn' ? 'মেম্বারশিপ / স্টোর কার্ড' : 'Loyalty Card'}</option>
              </select>
            </div>
          </div>

          {/* Card Number & Network */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'কার্ড নম্বর (১৬ ডিজিট)' : 'Card Number'}
              </label>
              <input
                type="text"
                required
                value={cardNumber}
                onChange={e => handleCardNumberChange(e.target.value)}
                placeholder="4289 1234 5678 9903"
                maxLength={19}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900 focus:outline-hidden focus:ring-2 focus:ring-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'কার্ড নেটওয়ার্ক' : 'Network'}
              </label>
              <select
                value={network}
                onChange={e => setNetwork(e.target.value as DigitalCardNetwork)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
              >
                <option value="visa">Visa</option>
                <option value="mastercard">Mastercard</option>
                <option value="amex">American Express</option>
                <option value="nexus">DBBL NexusPay</option>
                <option value="unionpay">UnionPay</option>
                <option value="other">Other</option>
              </select>
            </div>
          </div>

          {/* Cardholder Name, Expiry, CVV */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <div className="sm:col-span-2">
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'কার্ডহোল্ডারের নাম' : 'Cardholder Name'}
              </label>
              <input
                type="text"
                required
                value={cardholderName}
                onChange={e => setCardholderName(e.target.value.toUpperCase())}
                placeholder="FAYSAL RANA"
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold uppercase text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'মেয়াদ (MM/YY)' : 'Expiry (MM/YY)'}
              </label>
              <input
                type="text"
                required
                value={expiryDate}
                onChange={e => handleExpiryChange(e.target.value)}
                placeholder="08/29"
                maxLength={5}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'CVV কোড' : 'CVV'}
              </label>
              <input
                type="password"
                maxLength={4}
                value={cvv}
                onChange={e => setCvv(e.target.value)}
                placeholder="•••"
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono font-bold text-slate-900"
              />
            </div>
          </div>

          {/* Theme Color Selection */}
          <div>
            <label className="block text-xs font-bold text-slate-600 mb-1.5">
              {language === 'bn' ? 'কার্ডের থিম ডিজাইন' : 'Card Visual Theme'}
            </label>
            <div className="grid grid-cols-4 sm:grid-cols-7 gap-2">
              {themeOptions.map(th => (
                <button
                  key={th.id}
                  type="button"
                  onClick={() => setTheme(th.id)}
                  className={`h-11 rounded-xl bg-gradient-to-br ${th.previewClass} border-2 flex items-center justify-center transition-all ${
                    theme === th.id
                      ? 'scale-105 border-slate-900 shadow-md ring-2 ring-slate-900/20'
                      : 'border-transparent opacity-80 hover:opacity-100'
                  }`}
                  title={th.label}
                >
                  {theme === th.id && (
                    <Check className={`w-4 h-4 ${th.id === 'platinum' ? 'text-slate-900' : 'text-white'}`} />
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Financial Limits & Account Link */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            {type === 'credit' ? (
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  {language === 'bn' ? 'ক্রেডিট লিমিট' : 'Credit Limit'}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">
                    {currency.symbol}
                  </span>
                  <input
                    type="number"
                    step="any"
                    value={creditLimit}
                    onChange={e => setCreditLimit(e.target.value)}
                    placeholder="150000"
                    className="w-full pl-7 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>
            ) : (
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  {language === 'bn' ? 'দৈনিক খরচ সীমা' : 'Daily Spend Limit'}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">
                    {currency.symbol}
                  </span>
                  <input
                    type="number"
                    step="any"
                    value={dailySpendLimit}
                    onChange={e => setDailySpendLimit(e.target.value)}
                    placeholder="50000"
                    className="w-full pl-7 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'সংযুক্ত ব্যাংক/ওয়ালেট অ্যাকাউন্ট' : 'Linked Account'}
              </label>
              <select
                value={linkedAccountId}
                onChange={e => setLinkedAccountId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
              >
                <option value="">{language === 'bn' ? '-- কোনো অ্যাকাউন্ট নেই (ভার্চুয়াল) --' : '-- Standalone Card --'}</option>
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>
                    {language === 'bn' ? acc.nameBn : acc.name} ({acc.type})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Switches: Default card & Contactless */}
          <div className="flex flex-col sm:flex-row gap-3 pt-1">
            <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={isDefault}
                onChange={e => setIsDefault(e.target.checked)}
                className="rounded-md text-slate-900 focus:ring-slate-900 w-4 h-4"
              />
              <span>{language === 'bn' ? 'Google Wallet-এর ডিফল্ট পেমেন্ট কার্ড করুন' : 'Set as default Google Wallet card'}</span>
            </label>

            <label className="flex items-center gap-2 text-xs font-bold text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={contactlessEnabled}
                onChange={e => setContactlessEnabled(e.target.checked)}
                className="rounded-md text-slate-900 focus:ring-slate-900 w-4 h-4"
              />
              <span>{language === 'bn' ? 'কন্ট্যাক্টলেস ট্যাপ পেমেন্ট সক্রিয় রাখুন' : 'Enable Contactless Tap'}</span>
            </label>
          </div>

          {/* Form Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-6 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors"
            >
              {editCard 
                ? (language === 'bn' ? 'আপডেট করুন' : 'Update Card')
                : (language === 'bn' ? 'কার্ড যুক্ত করুন' : 'Save to Wallet')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
