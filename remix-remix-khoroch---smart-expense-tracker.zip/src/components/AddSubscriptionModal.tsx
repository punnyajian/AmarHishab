import React, { useState, useEffect } from 'react';
import { SubscriptionBill, BillCategory, BillingCycle } from '../types';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import {
  X,
  Plus,
  Receipt,
  Zap,
  Droplets,
  Flame,
  Wifi,
  Tv,
  Headphones,
  Home,
  Dumbbell,
  Bot,
  Smartphone,
  Calendar,
  CreditCard,
  Building2,
  Banknote,
  Sparkles,
  Check,
} from 'lucide-react';

interface AddSubscriptionModalProps {
  isOpen: boolean;
  onClose: () => void;
  editBill?: SubscriptionBill | null;
}

interface PresetItem {
  name: string;
  nameBn: string;
  category: BillCategory;
  defaultAmount: number;
  providerName: string;
  color: string;
  iconName: string;
  subscriberLabel?: string;
  sampleSubscriber?: string;
}

const PRESETS: PresetItem[] = [
  {
    name: 'DESCO বিদ্যুৎ বিল',
    nameBn: 'DESCO বিদ্যুৎ বিল',
    category: 'utility',
    defaultAmount: 2450,
    providerName: 'DESCO',
    color: '#f59e0b',
    iconName: 'Zap',
    subscriberLabel: 'মিটার / একাউন্ট নং',
    sampleSubscriber: '0419827361',
  },
  {
    name: 'DPDC বিদ্যুৎ বিল',
    nameBn: 'DPDC বিদ্যুৎ বিল',
    category: 'utility',
    defaultAmount: 2200,
    providerName: 'DPDC',
    color: '#eab308',
    iconName: 'Zap',
    subscriberLabel: 'কাস্টমার নং',
    sampleSubscriber: 'DPDC-109283',
  },
  {
    name: 'Titas গ্যাস বিল',
    nameBn: 'তিতাস গ্যাস বিল',
    category: 'utility',
    defaultAmount: 1080,
    providerName: 'Titas Gas',
    color: '#ef4444',
    iconName: 'Flame',
    subscriberLabel: 'গ্রাহক সংকেত',
    sampleSubscriber: 'GAS-10294',
  },
  {
    name: 'Dhaka WASA পানির বিল',
    nameBn: 'ঢাকা ওয়াসা বিল',
    category: 'utility',
    defaultAmount: 650,
    providerName: 'Dhaka WASA',
    color: '#3b82f6',
    iconName: 'Droplets',
    subscriberLabel: 'একাউন্ট নং',
    sampleSubscriber: 'WAS-99214',
  },
  {
    name: 'Dot / Carnival ব্রডব্যান্ড',
    nameBn: 'ব্রডব্যান্ড ইন্টারনেট',
    category: 'internet',
    defaultAmount: 1200,
    providerName: 'Fiber Broadband',
    color: '#06b6d4',
    iconName: 'Wifi',
    subscriberLabel: 'কানেকশন আইডি',
    sampleSubscriber: 'DOT-88421',
  },
  {
    name: 'বাসা ভাড়া (House Rent)',
    nameBn: 'বাসা ভাড়া',
    category: 'rent',
    defaultAmount: 15000,
    providerName: 'Landlord',
    color: '#059669',
    iconName: 'Home',
    subscriberLabel: 'ফ্ল্যাট নং',
    sampleSubscriber: 'Flat 4B',
  },
  {
    name: 'Netflix Premium 4K',
    nameBn: 'নেটফ্লিক্স',
    category: 'streaming',
    defaultAmount: 1150,
    providerName: 'Netflix',
    color: '#e50914',
    iconName: 'Tv',
  },
  {
    name: 'Spotify Premium Duo',
    nameBn: 'স্পটিফাই',
    category: 'streaming',
    defaultAmount: 399,
    providerName: 'Spotify',
    color: '#1db954',
    iconName: 'Headphones',
  },
  {
    name: 'YouTube Premium',
    nameBn: 'ইউটিউব প্রিমিয়াম',
    category: 'streaming',
    defaultAmount: 239,
    providerName: 'Google LLC',
    color: '#ff0000',
    iconName: 'Tv',
  },
  {
    name: 'ChatGPT Plus (OpenAI)',
    nameBn: 'চ্যাটজিপিটি প্লাস',
    category: 'software',
    defaultAmount: 2450,
    providerName: 'OpenAI',
    color: '#10a37f',
    iconName: 'Bot',
  },
  {
    name: 'FitZone জিম মেম্বারশিপ',
    nameBn: 'জিম মেম্বারশিপ',
    category: 'fitness',
    defaultAmount: 1500,
    providerName: 'FitZone Gym',
    color: '#f97316',
    iconName: 'Dumbbell',
    subscriberLabel: 'মেম্বার আইডি',
    sampleSubscriber: 'FZ-3091',
  },
  {
    name: 'Grameenphone / Robi বিল',
    nameBn: 'মোবাইল পোস্টপেইড বিল',
    category: 'mobile',
    defaultAmount: 600,
    providerName: 'Telecom',
    color: '#0284c7',
    iconName: 'Smartphone',
    subscriberLabel: 'মোবাইল নং',
    sampleSubscriber: '017XXXXXXXX',
  },
];

export const AddSubscriptionModal: React.FC<AddSubscriptionModalProps> = ({
  isOpen,
  onClose,
  editBill,
}) => {
  useModalBehavior({ isOpen, onClose });

  const {
    addSubscription,
    editSubscription,
    accounts,
    digitalCards,
    currency,
    language,
    formatMoney,
  } = useExpense();

  const [name, setName] = useState('');
  const [category, setCategory] = useState<BillCategory>('utility');
  const [amount, setAmount] = useState('');
  const [billingCycle, setBillingCycle] = useState<BillingCycle>('monthly');
  const [dueDate, setDueDate] = useState('');
  const [providerName, setProviderName] = useState('');
  const [subscriberId, setSubscriberId] = useState('');
  const [accountId, setAccountId] = useState('');
  const [cardId, setCardId] = useState('');
  const [reminderDaysBefore, setReminderDaysBefore] = useState(3);
  const [notes, setNotes] = useState('');
  const [color, setColor] = useState('#10b981');
  const [iconName, setIconName] = useState('Zap');
  const [autoPay, setAutoPay] = useState(false);

  useEffect(() => {
    if (editBill) {
      setName(editBill.name);
      setCategory(editBill.category);
      setAmount(editBill.amount.toString());
      setBillingCycle(editBill.billingCycle);
      setDueDate(editBill.dueDate);
      setProviderName(editBill.providerName || '');
      setSubscriberId(editBill.subscriberIdOrMeterNo || '');
      setAccountId(editBill.accountId || '');
      setCardId(editBill.cardId || '');
      setReminderDaysBefore(editBill.reminderDaysBefore || 3);
      setNotes(editBill.notes || '');
      setColor(editBill.color || '#10b981');
      setIconName(editBill.iconName || 'Zap');
      setAutoPay(!!editBill.autoPay);
    } else {
      setName('');
      setCategory('utility');
      setAmount('');
      setBillingCycle('monthly');
      // Default due date: in 5 days
      const d = new Date();
      d.setDate(d.getDate() + 5);
      setDueDate(d.toISOString().split('T')[0]);
      setProviderName('');
      setSubscriberId('');
      setAccountId(accounts[0]?.id || '');
      setCardId('');
      setReminderDaysBefore(3);
      setNotes('');
      setColor('#f59e0b');
      setIconName('Zap');
      setAutoPay(false);
    }
  }, [editBill, isOpen, accounts]);

  if (!isOpen) return null;

  const handleApplyPreset = (p: PresetItem) => {
    setName(p.name);
    setCategory(p.category);
    setAmount(p.defaultAmount.toString());
    setProviderName(p.providerName);
    setColor(p.color);
    setIconName(p.iconName);
    if (p.sampleSubscriber && !subscriberId) {
      setSubscriberId(p.sampleSubscriber);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (!name.trim() || isNaN(parsedAmount) || parsedAmount <= 0) return;

    if (editBill) {
      editSubscription({
        ...editBill,
        name: name.trim(),
        category,
        amount: parsedAmount,
        billingCycle,
        dueDate,
        providerName: providerName.trim() || undefined,
        subscriberIdOrMeterNo: subscriberId.trim() || undefined,
        accountId: accountId || undefined,
        cardId: cardId || undefined,
        reminderDaysBefore,
        notes: notes.trim() || undefined,
        color,
        iconName,
        autoPay,
      });
    } else {
      addSubscription({
        name: name.trim(),
        category,
        amount: parsedAmount,
        billingCycle,
        dueDate,
        status: 'active',
        providerName: providerName.trim() || undefined,
        subscriberIdOrMeterNo: subscriberId.trim() || undefined,
        accountId: accountId || undefined,
        cardId: cardId || undefined,
        reminderDaysBefore,
        notes: notes.trim() || undefined,
        color,
        iconName,
        autoPay,
      });
    }

    onClose();
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92dvh] sm:max-h-[88vh]"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="px-5 py-4 bg-gradient-to-r from-emerald-600 to-teal-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-2xl bg-white/20 flex items-center justify-center text-white">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black tracking-tight">
                {editBill
                  ? language === 'bn'
                    ? 'বিল বা সাবস্ক্রিপশন সম্পাদনা'
                    : 'Edit Subscription / Bill'
                  : language === 'bn'
                  ? 'নতুন ইউটিলিটি বিল / সাবস্ক্রিপশন'
                  : 'Add New Bill / Subscription'}
              </h2>
              <p className="text-xs text-emerald-100">
                {language === 'bn'
                  ? 'নির্ধারিত সময়ে বিল দেওয়ার হিসাব রাখুন'
                  : 'Track and never miss a recurring payment'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors text-white active:scale-95"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-5 overflow-y-auto space-y-4">
          {/* Quick Presets Carousel (if adding new) */}
          {!editBill && (
            <div className="space-y-1.5 pb-1">
              <span className="text-[11px] font-bold text-slate-500 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                <span>{language === 'bn' ? '১-ক্লিকে জনপ্রিয় সেবা নির্বাচন করুন:' : '1-Click Popular Presets:'}</span>
              </span>
              <div className="flex gap-2 overflow-x-auto pb-1.5 scrollbar-none">
                {PRESETS.map((p, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => handleApplyPreset(p)}
                    className="shrink-0 px-2.5 py-1.5 rounded-xl border border-slate-200/90 hover:border-emerald-500 bg-slate-50 hover:bg-emerald-50/60 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-all active:scale-95"
                  >
                    <span
                      className="w-2.5 h-2.5 rounded-full"
                      style={{ backgroundColor: p.color }}
                    />
                    <span>{p.name}</span>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Name & Provider */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'বিলের নাম *' : 'Bill Name *'}
              </label>
              <input
                type="text"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: DESCO বিদ্যুৎ বিল' : 'e.g. DESCO Electricity'}
                required
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'সেবাদানকারী প্রতিষ্ঠান' : 'Provider / Company'}
              </label>
              <input
                type="text"
                value={providerName}
                onChange={e => setProviderName(e.target.value)}
                placeholder="e.g. DESCO / Netflix / Landlord"
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Category & Amount */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
              </label>
              <select
                value={category}
                onChange={e => setCategory(e.target.value as BillCategory)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              >
                <option value="utility">💡 বিদ্যুৎ, গ্যাস ও পানি (Utility)</option>
                <option value="internet">🌐 ইন্টারনেট ও ওয়াইফাই (Internet)</option>
                <option value="rent">🏠 বাসা ভাড়া ও হাউজিং (Rent)</option>
                <option value="mobile">📱 মোবাইল ও রিচার্জ (Telecom)</option>
                <option value="streaming">🎬 স্ট্রিমিং ও বিনোদন (Streaming)</option>
                <option value="software">💻 সফটওয়্যার ও ক্লাউড (Software/AI)</option>
                <option value="fitness">🏋️ জিম ও ফিটনেস (Fitness)</option>
                <option value="education">🎓 শিক্ষা ও টিউশন (Education)</option>
                <option value="insurance">🛡️ ইন্স্যুরেন্স ও ডিপিএস (Insurance)</option>
                <option value="other">📦 অন্যান্য নিয়মিত খরচ (Other)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'টাকার অঙ্ক *' : 'Amount *'} ({currency.symbol})
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-xs">
                  {currency.symbol}
                </span>
                <input
                  type="number"
                  step="any"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  placeholder="0.00"
                  required
                  className="w-full pl-8 pr-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Billing Cycle & Next Due Date */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'বিলিং চক্র' : 'Billing Cycle'}
              </label>
              <select
                value={billingCycle}
                onChange={e => setBillingCycle(e.target.value as BillingCycle)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              >
                <option value="monthly">মাসিক (Monthly)</option>
                <option value="yearly">বাৎসরিক (Yearly)</option>
                <option value="quarterly">ত্রৈমাসিক (Every 3 Months)</option>
                <option value="weekly">সাপ্তাহিক (Weekly)</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                <span>{language === 'bn' ? 'পরবর্তী শেষ তারিখ *' : 'Next Due Date *'}</span>
              </label>
              <input
                type="date"
                value={dueDate}
                onChange={e => setDueDate(e.target.value)}
                required
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>
          </div>

          {/* Customer / Meter / Subscriber ID */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {language === 'bn' ? 'মিটার নং / সাবস্ক্রাইবার বা একাউন্ট আইডি' : 'Meter No / Subscriber ID (Optional)'}
            </label>
            <input
              type="text"
              value={subscriberId}
              onChange={e => setSubscriberId(e.target.value)}
              placeholder="e.g. 0419827361 or DOT-88421"
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-mono text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          {/* Linked Payment Method (Account or Card) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'পরিশোধের প্রধান অ্যাকাউন্ট' : 'Default Account'}
              </label>
              <select
                value={accountId}
                onChange={e => setAccountId(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              >
                <option value="">{language === 'bn' ? 'নির্দিষ্ট নয়' : 'None'}</option>
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>
                    {language === 'bn' ? acc.nameBn || acc.name : acc.name} ({formatMoney(acc.balance)})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'সংযুক্ত Google Wallet কার্ড' : 'Linked Digital Card'}
              </label>
              <select
                value={cardId}
                onChange={e => setCardId(e.target.value)}
                className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              >
                <option value="">{language === 'bn' ? 'কোনো কার্ড ছাড়া' : 'None'}</option>
                {digitalCards.map(c => (
                  <option key={c.id} value={c.id}>
                    💳 {c.issuerName} (•••• {c.last4})
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Reminder Days */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {language === 'bn' ? 'কত দিন আগে সতর্কবার্তা দেখাবে?' : 'Reminder Days Before Due Date'}
            </label>
            <div className="flex gap-2">
              {[1, 2, 3, 5, 7].map(days => (
                <button
                  key={days}
                  type="button"
                  onClick={() => setReminderDaysBefore(days)}
                  className={`flex-1 py-1.5 rounded-xl border text-xs font-bold transition-all ${
                    reminderDaysBefore === days
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-800'
                      : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {days} {language === 'bn' ? 'দিন' : 'd'}
                </button>
              ))}
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {language === 'bn' ? 'নোট বা মন্তব্য' : 'Notes / Instructions'}
            </label>
            <input
              type="text"
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder={language === 'bn' ? 'যেমন: প্রতি মাসের ৫ তারিখের মধ্যে দেওয়া ভালো' : 'Notes...'}
              className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-2xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-extrabold shadow-sm active:scale-95 transition-all"
            >
              {editBill
                ? language === 'bn'
                  ? 'হালনাগাদ করুন'
                  : 'Update'
                : language === 'bn'
                ? 'সংরক্ষণ করুন'
                : 'Save Bill'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
