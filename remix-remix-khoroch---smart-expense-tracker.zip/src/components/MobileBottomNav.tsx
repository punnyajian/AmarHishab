import React, { useState } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { ActiveTab } from '../types';
import {
  LayoutDashboard,
  Calendar,
  ReceiptText,
  Target,
  Plus,
  MoreHorizontal,
  WalletCards,
  PiggyBank,
  HandCoins,
  UsersRound,
  PieChart,
  Settings as SettingsIcon,
  User,
  X,
  ArrowRightLeft,
  Sparkles,
  Hourglass,
  CalendarClock,
  CookingPot,
  Landmark,
  Compass,
  Scale,
  Flame,
  RotateCcw,
  ShoppingBag,
  BrainCircuit,
  CreditCard,
  TrendingUp,
  FileBarChart,
  PanelLeftOpen,
  Bell,
  ShieldAlert,
} from 'lucide-react';

import { useLockBodyScroll } from '../utils/useLockBodyScroll';

interface MobileBottomNavProps {
  onOpenAddModal: () => void;
  onOpenTransferModal?: () => void;
  onOpenAIModal?: () => void;
  onOpenAffordModal?: () => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ 
  onOpenAddModal,
  onOpenTransferModal,
  onOpenAIModal,
  onOpenAffordModal,
}) => {
  const { 
    activeTab, 
    setActiveTab, 
    setWalletSubTab,
    setSubscriptionFilterTab,
    setIsSidebarOpen,
    t, 
    language, 
    activeTrip, 
    currentNoSpendStreak, 
    setIsResetModalOpen,
    bazarCompletedCount,
    bazarTotalCount,
    aiActionProposals,
    aiHealthScore,
    currentUser,
    unreadNotificationsCount,
    setIsNotificationCenterOpen,
  } = useExpense();
  const [showMoreMenu, setShowMoreMenu] = useState(false);

  useLockBodyScroll(showMoreMenu);

  React.useEffect(() => {
    if (!showMoreMenu) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowMoreMenu(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showMoreMenu]);

  const pendingAIActionCount = aiActionProposals.filter(p => p.status === 'pending').length;

  interface MenuNavigationItem {
    id: ActiveTab;
    label: string;
    desc: string;
    icon: any;
    color: string;
    badge?: string;
    action?: () => void;
    isActive?: boolean;
  }

  // 1. Core Financial Workflow (Exact match with Sidebar Core Menu)
  const coreMenuItems: MenuNavigationItem[] = [
    {
      id: 'dashboard',
      label: language === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard',
      desc: language === 'bn' ? 'মূল আর্থিক সংক্ষিপ্ত বিবরণ' : 'Financial summary & cash flow',
      icon: LayoutDashboard,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold',
      isActive: activeTab === 'dashboard',
    },
    {
      id: 'calendar',
      label: language === 'bn' ? 'ক্যাশফ্লো ক্যালেন্ডার' : 'Cashflow Calendar',
      desc: language === 'bn' ? 'খরচের হিটম্যাপ ও বিলের ক্যালেন্ডার' : 'Heatmap & upcoming bills calendar',
      icon: Calendar,
      color: 'bg-teal-50 text-teal-800 border-teal-300 font-bold',
      isActive: activeTab === 'calendar',
    },
    {
      id: 'payment_priority',
      label: language === 'bn' ? 'পেমেন্ট প্রায়োরিটি' : 'Payment Priority',
      desc: language === 'bn' ? 'স্মার্ট বিল ও ঋণ অগ্রাধিকার' : 'Smart payment rank & shortfall',
      icon: ShieldAlert,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold',
      isActive: activeTab === 'payment_priority',
    },
    {
      id: 'transactions',
      label: language === 'bn' ? 'লেনদেন' : 'Transactions',
      desc: language === 'bn' ? 'সকল আয় ও খরচের খতিয়ান' : 'Income & expense log',
      icon: ReceiptText,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold',
      isActive: activeTab === 'transactions',
    },
    {
      id: 'budgets',
      label: language === 'bn' ? 'বাজেট' : 'Budgets',
      desc: language === 'bn' ? 'ক্যাটাগরি বাজেট সীমা' : 'Category spending limits',
      icon: Target,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold',
      isActive: activeTab === 'budgets',
    },
    {
      id: 'wallets',
      label: language === 'bn' ? 'অ্যাকাউন্ট' : 'Accounts',
      desc: language === 'bn' ? 'নগদ, বিকাশ ও ব্যাংক ব্যালেন্স' : 'Cash, bKash & bank balances',
      icon: Landmark,
      color: 'bg-teal-50 text-teal-800 border-teal-200',
      action: () => {
        setActiveTab('wallets');
        setWalletSubTab('accounts');
      },
      isActive: activeTab === 'wallets',
    },
    {
      id: 'wallets',
      label: language === 'bn' ? 'কার্ড ও লিমিট' : 'Cards & Limits',
      desc: language === 'bn' ? 'ক্রেডিট ও ডেবিট কার্ড ট্র্যাকিং' : 'Credit & debit card limits',
      icon: CreditCard,
      color: 'bg-teal-50 text-teal-800 border-teal-200',
      action: () => {
        setActiveTab('wallets');
        setWalletSubTab('cards');
      },
      isActive: activeTab === 'wallets',
    },
    {
      id: 'debts',
      label: language === 'bn' ? 'ঋণ ও ইএমআই' : 'Loans & EMI',
      desc: language === 'bn' ? 'দেনা ও পাওনা খাতা' : 'Lent & Borrowed debts',
      icon: HandCoins,
      color: 'bg-rose-50 text-rose-700 border-rose-200',
      isActive: activeTab === 'debts',
    },
    {
      id: 'subscriptions',
      label: language === 'bn' ? 'সাবস্ক্রিপশন' : 'Subscriptions',
      desc: language === 'bn' ? 'নিয়মিত মাসিক সার্ভিস' : 'Recurring services & plans',
      icon: CalendarClock,
      color: 'bg-cyan-50 text-cyan-800 border-cyan-200',
      action: () => {
        setActiveTab('subscriptions');
        setSubscriptionFilterTab('all');
      },
      isActive: activeTab === 'subscriptions',
    },
    {
      id: 'subscriptions',
      label: language === 'bn' ? 'নোটিফিকেশন ও রিমাইন্ডার' : 'Alerts & Reminders Hub',
      desc: language === 'bn' ? 'বিল ডেডলাইন ও জরুরি সতর্কবার্তা' : 'Due dates & emergency alerts',
      icon: Bell,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      badge: unreadNotificationsCount > 0 ? String(unreadNotificationsCount) : undefined,
      action: () => {
        setShowMoreMenu(false);
        setIsNotificationCenterOpen(true);
      },
      isActive: false,
    },
    {
      id: 'goals',
      label: language === 'bn' ? 'সঞ্চয় লক্ষ্য' : 'Savings Goals',
      desc: language === 'bn' ? 'টার্গেট ও সঞ্চয়ের অগ্রগতি' : 'Target savings & milestones',
      icon: PiggyBank,
      color: 'bg-amber-50 text-amber-700 border-amber-200',
      isActive: activeTab === 'goals',
    },
    {
      id: 'analytics',
      label: language === 'bn' ? 'নেট ওর্থ' : 'Net Worth',
      desc: language === 'bn' ? 'মোট সম্পদ ও দায় বিশ্লেষণ' : 'Assets, liabilities & net wealth',
      icon: TrendingUp,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      isActive: activeTab === 'analytics',
    },
    {
      id: 'analytics',
      label: language === 'bn' ? 'রিপোর্টস ও চার্ট' : 'Reports & Charts',
      desc: language === 'bn' ? 'খরচের ধারা ও ভিজ্যুয়াল রিপোর্ট' : 'Visual spending trends',
      icon: FileBarChart,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
      isActive: activeTab === 'analytics',
    },
  ];

  // 2. Specialized Modules (Exact match with Sidebar Specialized Tools)
  const specializedMenuItems: MenuNavigationItem[] = [
    { 
      id: 'ai_control', 
      label: language === 'bn' ? 'সেন্ট্রাল এআই' : 'Central AI Control', 
      desc: language === 'bn' ? 'স্বয়ংক্রিয় আর্থিক বুদ্ধি ও অডিট' : 'Central Intelligence & Audit',
      icon: BrainCircuit,
      color: 'bg-indigo-50 text-indigo-900 border-indigo-300 font-bold',
      badge: pendingAIActionCount > 0 ? `${pendingAIActionCount}` : (aiHealthScore?.overallScore ? `${aiHealthScore.overallScore}%` : undefined),
      isActive: activeTab === 'ai_control',
    },
    { 
      id: 'bazar', 
      label: language === 'bn' ? 'কাঁচাবাজার' : 'Smart Bazar', 
      desc: language === 'bn' ? 'বাজারের ফর্দ ও টিসিবি দরদাম' : 'Checklist & TCB market prices',
      icon: ShoppingBag,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold',
      badge: bazarTotalCount > 0 ? `${bazarCompletedCount}/${bazarTotalCount}` : undefined,
      isActive: activeTab === 'bazar',
    },
    { 
      id: 'investments', 
      label: language === 'bn' ? 'বিনিয়োগ ও স্বর্ণ' : 'Investments & Gold', 
      desc: language === 'bn' ? 'ডিপিএস, এফডিআর ও স্বর্ণ' : 'DPS, FDR, Bonds & Gold',
      icon: Landmark,
      color: 'bg-teal-50 text-teal-800 border-teal-200',
      isActive: activeTab === 'investments',
    },
    { 
      id: 'tax_zakat', 
      label: language === 'bn' ? 'ট্যাক্স ও যাকাত' : 'Tax & Zakat', 
      desc: language === 'bn' ? 'আয়কর ও নিসাবভিত্তিক যাকাত' : 'Income Tax & Nisab Zakat',
      icon: Scale,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      isActive: activeTab === 'tax_zakat',
    },
    { 
      id: 'mess', 
      label: language === 'bn' ? 'মেস ম্যানেজার' : 'Mess Manager', 
      desc: language === 'bn' ? 'মিল রেট, বাজার ও মেস হিসাব' : 'Meal Rate & Mess Tracker',
      icon: CookingPot,
      color: 'bg-teal-50 text-teal-800 border-teal-200',
      isActive: activeTab === 'mess',
    },
    { 
      id: 'trips', 
      label: language === 'bn' ? 'ট্যুর প্ল্যানার' : 'Trips & Tours', 
      desc: language === 'bn' ? (activeTrip ? `চলতি: ${activeTrip.titleBn || activeTrip.title}` : 'ট্যুর, পিকনিক ও ইভেন্ট বাজেট') : (activeTrip ? `Active: ${activeTrip.title}` : 'Tour, Picnic & Event Mode'),
      icon: Compass,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-300 font-bold',
      badge: activeTrip ? (language === 'bn' ? 'চলতি' : 'Active') : undefined,
      isActive: activeTab === 'trips',
    },
    { 
      id: 'challenges', 
      label: language === 'bn' ? 'চ্যালেঞ্জ ও স্ট্রিক' : 'Savings Challenges', 
      desc: language === 'bn' ? 'নো-স্পেন্ড স্ট্রিক ও চ্যালেঞ্জ' : 'No-Spend Streak & Savings',
      icon: Flame,
      color: 'bg-amber-50 text-amber-900 border-amber-300 font-bold',
      badge: currentNoSpendStreak > 0 ? `🔥 ${currentNoSpendStreak}${language === 'bn' ? ' দিন' : 'd'}` : undefined,
      isActive: activeTab === 'challenges',
    },
    { 
      id: 'wishlist', 
      label: language === 'bn' ? 'উইশলিস্ট ও কুলিং' : 'Mindful Wishlist', 
      desc: language === 'bn' ? '৩০ দিনের কুলিং রুল' : '30-Day Delay Rule',
      icon: Hourglass,
      color: 'bg-indigo-50 text-indigo-700 border-indigo-200',
      isActive: activeTab === 'wishlist',
    },
    { 
      id: 'split', 
      label: language === 'bn' ? 'বিল ভাগাভাগি' : 'Split Group Bill', 
      desc: language === 'bn' ? 'গ্রুপ বিল ভাগাভাগি' : 'Split Group Bill',
      icon: UsersRound,
      color: 'bg-sky-50 text-sky-700 border-sky-200',
      isActive: activeTab === 'split',
    },
    { 
      id: 'profile', 
      label: currentUser ? (currentUser.displayName || currentUser.email?.split('@')[0] || (language === 'bn' ? 'প্রোফাইল' : 'Profile')) : (language === 'bn' ? 'প্রোফাইল' : 'Profile'), 
      desc: currentUser ? (language === 'bn' ? 'গুগল অ্যাকাউন্ট ও ডিভাইস' : 'Google Account & Sync') : (language === 'bn' ? 'লগইন ও ব্যাকআপ' : 'Login & Backup'),
      icon: User,
      color: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      isActive: activeTab === 'profile',
    },
  ];

  // 3. System & Settings
  const systemMenuItems: MenuNavigationItem[] = [
    { 
      id: 'settings', 
      label: language === 'bn' ? 'সেটিংস' : 'Settings', 
      desc: language === 'bn' ? 'মুদ্রা, ভাষা ও ব্যাকআপ' : 'Currency, Language & Backup',
      icon: SettingsIcon,
      color: 'bg-slate-100 text-slate-700 border-slate-200',
      isActive: activeTab === 'settings',
    },
  ];

  const handleItemClick = (item: MenuNavigationItem) => {
    if (item.action) {
      item.action();
    } else {
      setActiveTab(item.id);
    }
    setShowMoreMenu(false);
  };

  return (
    <>
      {/* Complete 3-Dot (⋮) Overflow Menu & Features Bottom Sheet for Mobile */}
      {showMoreMenu && (
        <div 
          className="md:hidden fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex flex-col justify-end animate-in fade-in duration-200 no-print"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setShowMoreMenu(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl p-5 shadow-2xl space-y-4 max-h-[85vh] overflow-y-auto overscroll-contain pb-[calc(env(safe-area-inset-bottom,0px)+2rem)] custom-scrollbar"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            {/* Sheet Handle and Title */}
            <div className="flex flex-col items-center shrink-0">
              <div className="w-12 h-1.5 bg-slate-200 rounded-full mb-3" />
              <div className="w-full flex items-center justify-between pb-2 border-b border-slate-100">
                <div>
                  <span className="font-extrabold text-base text-slate-900">
                    {language === 'bn' ? 'সকল মেনু অপশন ও ফিচার' : 'All Sidebar & App Options'}
                  </span>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? 'যেকোনো অপশনে সরাসরি প্রবেশ করুন' : 'Full access to all navigation sections'}
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowMoreMenu(false)}
                  className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 active:scale-95 cursor-pointer"
                  aria-label="Close menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>

            {/* Direct Link to Open Complete Sidebar Drawer */}
            <button
              type="button"
              onClick={() => {
                setShowMoreMenu(false);
                setIsSidebarOpen(true);
              }}
              className="w-full flex items-center justify-between p-3.5 bg-gradient-to-r from-emerald-700 to-emerald-600 text-white rounded-2xl shadow-sm active:scale-[0.99] transition-all cursor-pointer"
            >
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-xl bg-white/20 flex items-center justify-center shrink-0">
                  <PanelLeftOpen className="w-4 h-4 text-white" />
                </div>
                <div className="text-left">
                  <div className="text-xs font-black tracking-tight leading-snug">
                    {language === 'bn' ? 'সম্পূর্ণ সাইডবার ড্রয়ার খুলুন' : 'Open Complete Sidebar Drawer'}
                  </div>
                  <div className="text-[10px] text-emerald-100 font-medium">
                    {language === 'bn' ? 'বাম পাশের ফুল নেভিগেশন প্যানেল দেখুন' : 'View full side navigation drawer'}
                  </div>
                </div>
              </div>
              <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-white/25 text-white">
                {language === 'bn' ? 'খুলুন' : 'Open'}
              </span>
            </button>

            {/* Quick Action Buttons in Sheet */}
            <div className="grid grid-cols-2 gap-2 pt-1">
              {onOpenTransferModal && (
                <button
                  type="button"
                  onClick={() => {
                    setShowMoreMenu(false);
                    onOpenTransferModal();
                  }}
                  className="flex items-center gap-2 p-2.5 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-2xl text-emerald-800 text-xs font-bold transition-all text-left cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0">
                    <ArrowRightLeft className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="leading-tight">{t('transfer')}</div>
                    <span className="text-[10px] text-emerald-600 font-normal">
                      {language === 'bn' ? 'ওয়ালেট বদল' : 'Between wallets'}
                    </span>
                  </div>
                </button>
              )}

              {onOpenAIModal && (
                <button
                  type="button"
                  onClick={() => {
                    setShowMoreMenu(false);
                    onOpenAIModal();
                  }}
                  className="flex items-center gap-2 p-2.5 bg-emerald-500 hover:bg-emerald-600 text-white rounded-2xl text-xs font-bold transition-all text-left shadow-xs cursor-pointer"
                >
                  <div className="w-8 h-8 rounded-xl bg-white/20 text-white flex items-center justify-center shrink-0">
                    <Sparkles className="w-4 h-4 animate-pulse" />
                  </div>
                  <div>
                    <div className="leading-tight">{language === 'bn' ? 'স্মার্ট টিপস' : 'AI Advisor'}</div>
                    <span className="text-[10px] text-emerald-100 font-normal">
                      {language === 'bn' ? 'খরচের বুদ্ধি' : 'Smart insights'}
                    </span>
                  </div>
                </button>
              )}
            </div>

            {/* "Can I Afford This?" Tool for Mobile */}
            {onOpenAffordModal && (
              <button
                type="button"
                onClick={() => {
                  setShowMoreMenu(false);
                  onOpenAffordModal();
                }}
                className="w-full flex items-center justify-between p-3 bg-teal-50 hover:bg-teal-100 border border-teal-200/80 rounded-2xl text-teal-900 text-xs font-bold transition-all text-left cursor-pointer"
              >
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-teal-600 text-white flex items-center justify-center shrink-0">
                    <Scale className="w-4 h-4" />
                  </div>
                  <div>
                    <div className="leading-tight">{language === 'bn' ? '“আমি কি এটা কিনতে পারি?”' : '“Can I Afford This?”'}</div>
                    <span className="text-[10px] text-teal-700 font-normal">
                      {language === 'bn' ? 'পরিকল্পিত কেনাকাটার সামর্থ্য ও লাইফ-এনার্জি যাচাই' : 'Check purchase readiness and work-hours cost'}
                    </span>
                  </div>
                </div>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 font-extrabold uppercase">
                  {language === 'bn' ? 'যাচাই' : 'Test'}
                </span>
              </button>
            )}

            {/* One-Tap Data Reset Action for Mobile */}
            <button
              type="button"
              onClick={() => {
                setShowMoreMenu(false);
                setIsResetModalOpen(true);
              }}
              className="w-full flex items-center justify-between p-3 bg-rose-50 hover:bg-rose-100 border border-rose-200/80 rounded-2xl text-rose-700 text-xs font-bold transition-all text-left cursor-pointer"
            >
              <div className="flex items-center gap-2.5">
                <div className="w-8 h-8 rounded-xl bg-rose-600 text-white flex items-center justify-center shrink-0">
                  <RotateCcw className="w-4 h-4" />
                </div>
                <div>
                  <div className="leading-tight">{language === 'bn' ? 'এক ট্যাপে সমস্ত ডেটা রিসেট' : 'One-Tap Full Data Reset'}</div>
                  <span className="text-[10px] text-rose-500 font-normal">
                    {language === 'bn' ? 'সব ডেমো হিসাব মুছে ফ্রেশ ০ ব্যালেন্স করুন' : 'Wipe all records and reset to clean state'}
                  </span>
                </div>
              </div>
              <span className="text-[10px] px-2 py-0.5 rounded-full bg-rose-100 text-rose-800 font-extrabold uppercase">
                {language === 'bn' ? 'রিসেট' : 'Reset'}
              </span>
            </button>

            {/* Section 1: Core Navigation Options */}
            <div className="pt-2">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 pb-2 px-1">
                {language === 'bn' ? 'প্রধান মেনু অপশন' : 'Core Navigation Options'}
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {coreMenuItems.map((item, idx) => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={`core-${item.id}-${idx}`}
                      type="button"
                      onClick={() => handleItemClick(item)}
                      className={`flex items-start gap-2.5 p-3 rounded-2xl border text-left transition-all active:scale-[0.98] cursor-pointer ${
                        item.isActive
                          ? 'border-emerald-500 bg-emerald-50/80 ring-2 ring-emerald-500/20'
                          : 'border-slate-100 bg-slate-50/70 hover:bg-slate-100'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${item.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className={`text-xs font-bold leading-snug truncate ${item.isActive ? 'text-emerald-900' : 'text-slate-800'}`}>
                          {item.label}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate mt-0.5">
                          {item.desc}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Section 2: Specialized Tools */}
            <div className="pt-2">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 pb-2 px-1">
                {language === 'bn' ? 'বিশেষ সুবিধাসমূহ' : 'Specialized Tools'}
              </div>
              <div className="grid grid-cols-2 gap-2.5">
                {specializedMenuItems.map(item => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={`specialized-${item.id}`}
                      type="button"
                      onClick={() => handleItemClick(item)}
                      className={`flex items-start gap-2.5 p-3 rounded-2xl border text-left transition-all active:scale-[0.98] cursor-pointer ${
                        item.isActive
                          ? 'border-emerald-500 bg-emerald-50/80 ring-2 ring-emerald-500/20'
                          : 'border-slate-100 bg-slate-50/70 hover:bg-slate-100'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${item.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-1.5">
                          <span className={`text-xs font-bold leading-snug truncate ${item.isActive ? 'text-emerald-900' : 'text-slate-800'}`}>
                            {item.label}
                          </span>
                          {item.badge && (
                            <span className="text-[9px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-black shrink-0">
                              {item.badge}
                            </span>
                          )}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate mt-0.5">
                          {item.desc}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Section 3: System & Settings */}
            <div className="pt-2 pb-2">
              <div className="text-[11px] font-extrabold uppercase tracking-wider text-slate-400 pb-2 px-1">
                {language === 'bn' ? 'সিস্টেম' : 'System & Settings'}
              </div>
              <div className="grid grid-cols-1 gap-2.5">
                {systemMenuItems.map(item => {
                  const Icon = item.icon;
                  return (
                    <button
                      key={`system-${item.id}`}
                      type="button"
                      onClick={() => handleItemClick(item)}
                      className={`flex items-center gap-3 p-3 rounded-2xl border text-left transition-all active:scale-[0.98] cursor-pointer ${
                        item.isActive
                          ? 'border-emerald-500 bg-emerald-50/80 ring-2 ring-emerald-500/20'
                          : 'border-slate-100 bg-slate-50/70 hover:bg-slate-100'
                      }`}
                    >
                      <div className={`w-9 h-9 rounded-xl border flex items-center justify-center shrink-0 ${item.color}`}>
                        <Icon className="w-5 h-5" />
                      </div>
                      <div className="min-w-0">
                        <div className={`text-xs font-bold leading-snug truncate ${item.isActive ? 'text-emerald-900' : 'text-slate-800'}`}>
                          {item.label}
                        </div>
                        <div className="text-[10px] text-slate-500 truncate mt-0.5">
                          {item.desc}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Fixed bottom navigation */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white/95 backdrop-blur-md border-t border-slate-200/90 shadow-[0_-4px_16px_rgba(0,0,0,0.04)] px-2 pt-1.5 pb-[calc(env(safe-area-inset-bottom,0px)+0.4rem)] no-print">
        <div className="flex items-center justify-around max-w-md mx-auto">
          
          {/* Dashboard */}
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`flex flex-col items-center justify-center min-w-[56px] py-1 px-1.5 rounded-xl transition-colors active:scale-95 ${
              activeTab === 'dashboard' ? 'text-emerald-700 font-bold' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors ${activeTab === 'dashboard' ? 'bg-emerald-50' : ''}`}>
              <LayoutDashboard className={`w-5 h-5 ${activeTab === 'dashboard' ? 'text-emerald-600 stroke-[2.5]' : 'stroke-[1.8]'}`} />
            </div>
            <span className="text-[10px] tracking-tight">{t('dashboard')}</span>
          </button>

          {/* Transactions */}
          <button
            onClick={() => setActiveTab('transactions')}
            className={`flex flex-col items-center justify-center min-w-[56px] py-1 px-1.5 rounded-xl transition-colors active:scale-95 ${
              activeTab === 'transactions' ? 'text-emerald-700 font-bold' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors ${activeTab === 'transactions' ? 'bg-emerald-50' : ''}`}>
              <ReceiptText className={`w-5 h-5 ${activeTab === 'transactions' ? 'text-emerald-600 stroke-[2.5]' : 'stroke-[1.8]'}`} />
            </div>
            <span className="text-[10px] tracking-tight">{t('transactions')}</span>
          </button>

          {/* Center Floating Plus Button */}
          <div className="relative -top-3">
            <button
              onClick={onOpenAddModal}
              className="w-12 h-12 rounded-full bg-gradient-to-tr from-emerald-600 to-emerald-400 text-white flex items-center justify-center shadow-lg shadow-emerald-500/35 active:scale-90 transition-transform ring-4 ring-white"
              aria-label="Add transaction"
            >
              <Plus className="w-6 h-6 stroke-[3]" />
            </button>
          </div>

          {/* Budgets */}
          <button
            onClick={() => setActiveTab('budgets')}
            className={`flex flex-col items-center justify-center min-w-[56px] py-1 px-1.5 rounded-xl transition-colors active:scale-95 ${
              activeTab === 'budgets' ? 'text-emerald-700 font-bold' : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors ${activeTab === 'budgets' ? 'bg-emerald-50' : ''}`}>
              <Target className={`w-5 h-5 ${activeTab === 'budgets' ? 'text-emerald-600 stroke-[2.5]' : 'stroke-[1.8]'}`} />
            </div>
            <span className="text-[10px] tracking-tight">{t('budgets')}</span>
          </button>

          {/* More menu */}
          <button
            onClick={() => setShowMoreMenu(true)}
            className={`flex flex-col items-center justify-center min-w-[56px] py-1 px-1.5 rounded-xl transition-colors active:scale-95 ${
              showMoreMenu || ['calendar', 'ai_control', 'bazar', 'trips', 'challenges', 'tax_zakat', 'investments', 'mess', 'subscriptions', 'analytics', 'wallets', 'goals', 'debts', 'split', 'settings', 'wishlist'].includes(activeTab)
                ? 'text-emerald-700 font-bold'
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <div className={`p-1 rounded-xl transition-colors ${['calendar', 'ai_control', 'bazar', 'trips', 'challenges', 'tax_zakat', 'investments', 'mess', 'subscriptions', 'analytics', 'wallets', 'goals', 'debts', 'split', 'settings', 'wishlist'].includes(activeTab) ? 'bg-emerald-50 text-emerald-600' : ''}`}>
              <MoreHorizontal className="w-5 h-5 stroke-[1.8]" />
            </div>
            <span className="text-[10px] tracking-tight">{language === 'bn' ? 'আরও' : 'More'}</span>
          </button>

        </div>
      </nav>
    </>
  );
};
