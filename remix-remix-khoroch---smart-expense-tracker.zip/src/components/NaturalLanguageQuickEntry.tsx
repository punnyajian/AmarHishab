import React, { useState, useMemo, useRef, useEffect } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { parseNaturalLanguageTransaction, ParsedTransactionResult } from '../utils/naturalLanguageParser';
import { CategoryIcon } from './CategoryIcon';
import {
  Sparkles,
  Send,
  Calendar,
  Clock,
  Wallet,
  Tag,
  CheckCircle2,
  AlertCircle,
  ArrowRight,
  HelpCircle,
  Flame,
  Check,
  Zap,
} from 'lucide-react';
import { useOnClickOutside } from '../utils/useOnClickOutside';
import confetti from 'canvas-confetti';

interface NaturalLanguageQuickEntryProps {
  className?: string;
  onSuccess?: () => void;
}

export const NaturalLanguageQuickEntry: React.FC<NaturalLanguageQuickEntryProps> = ({
  className = '',
  onSuccess,
}) => {
  const {
    accounts,
    categories,
    addTransaction,
    language,
    formatMoney,
    currency,
  } = useExpense();

  const [input, setInput] = useState('');
  const [feedback, setFeedback] = useState<{ message: string; isError?: boolean } | null>(null);
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const [selectedAccountId, setSelectedAccountId] = useState<string | null>(null);
  const [showCategoryPicker, setShowCategoryPicker] = useState(false);
  const [showAccountPicker, setShowAccountPicker] = useState(false);

  const categoryPickerRef = useRef<HTMLDivElement>(null);
  const accountPickerRef = useRef<HTMLDivElement>(null);

  useOnClickOutside(categoryPickerRef, () => setShowCategoryPicker(false), showCategoryPicker);
  useOnClickOutside(accountPickerRef, () => setShowAccountPicker(false), showAccountPicker);

  useEffect(() => {
    if (!showCategoryPicker && !showAccountPicker) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setShowCategoryPicker(false);
        setShowAccountPicker(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showCategoryPicker, showAccountPicker]);

  const inputRef = useRef<HTMLInputElement>(null);

  // Live Real-Time Parse
  const parsed: ParsedTransactionResult = useMemo(() => {
    return parseNaturalLanguageTransaction(input, accounts, categories, language);
  }, [input, accounts, categories, language]);

  // Keep overrides in sync or reset on empty input
  useEffect(() => {
    if (!input.trim()) {
      setSelectedCategoryId(null);
      setSelectedAccountId(null);
      setShowCategoryPicker(false);
      setShowAccountPicker(false);
    }
  }, [input]);

  const activeCategoryId = selectedCategoryId || parsed.categoryId;
  const activeAccountId = selectedAccountId || parsed.accountId;

  const currentCategory = categories.find(c => c.id === activeCategoryId) || categories[0];
  const currentAccount = accounts.find(a => a.id === activeAccountId) || accounts[0];

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!input.trim()) return;

    if (!parsed.success || parsed.amount <= 0) {
      setFeedback({
        message: language === 'bn' ? 'অনুগ্রহ করে টাকার পরিমাণ উল্লেখ করুন (যেমন: ৪৫০ টাকা)' : 'Please specify a valid amount',
        isError: true,
      });
      setTimeout(() => setFeedback(null), 3500);
      return;
    }

    // Save transaction with parsed values and any overrides
    addTransaction({
      type: parsed.type,
      amount: parsed.amount,
      categoryId: activeCategoryId,
      accountId: activeAccountId,
      date: parsed.date,
      time: parsed.time,
      note: parsed.note || input.trim(),
    });

    confetti({ particleCount: 35, spread: 60, origin: { y: 0.6 } });

    const successMsg = language === 'bn'
      ? `✓ ${parsed.meta.detectedDateLabel || 'আজ'} ${formatMoney(parsed.amount)} (${currentCategory.nameBn}) সফলভাবে যুক্ত হয়েছে!`
      : `✓ Added ${formatMoney(parsed.amount)} for ${currentCategory.name} on ${parsed.date}!`;

    setFeedback({ message: successMsg });
    setInput('');
    setSelectedCategoryId(null);
    setSelectedAccountId(null);
    setShowCategoryPicker(false);
    setShowAccountPicker(false);

    if (onSuccess) onSuccess();
    setTimeout(() => setFeedback(null), 4500);
  };

  const samplePrompts = [
    {
      text: 'আজ দুপুরে বন্ধুর সাথে ৪৫০ টাকা খরচ',
      label: language === 'bn' ? '🍱 দুপুরে বন্ধুর সাথে ৪৫০' : '🍱 Lunch with friend 450',
    },
    {
      text: 'গতকাল রাতে রিকশা ভাড়া ১২০ টাকা ক্যাশ',
      label: language === 'bn' ? '🛺 রিকশা ১২০' : '🛺 Rickshaw 120',
    },
    {
      text: 'আজ সকালে চা ও নাস্তা ৬৫ নগদ',
      label: language === 'bn' ? '☕ চা-নাস্তা ৬৫' : '☕ Coffee 65',
    },
    {
      text: 'মুদি কাঁচাবাজার ১২০০ টাকা বিকাশ',
      label: language === 'bn' ? '🛒 বাজার ১২০০' : '🛒 Grocery 1200',
    },
    {
      text: 'টিউশনি থেকে আয় ৫০০০ টাকা ব্যাংক',
      label: language === 'bn' ? '💰 টিউশনি আয় ৫,০০০' : '💰 Tutoring Income 5k',
    },
  ];

  return (
    <div className={`space-y-3 ${className}`}>
      
      {/* Input Field with Sparkle AI Icon */}
      <form onSubmit={handleSubmit} className="relative flex items-center">
        <div className="absolute left-3.5 sm:left-4 flex items-center pointer-events-none text-emerald-600">
          <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 animate-pulse" />
        </div>

        <input
          ref={inputRef}
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={
            language === 'bn'
              ? "যেমন: 'আজ দুপুরে বন্ধুর সাথে ৪৫০ টাকা খরচ' বা 'রিকশা ভাড়া ১২০ বিকাশ'..."
              : "e.g. 'Lunch with friend 450 today' or 'Grocery 1200 bkash'..."
          }
          className="w-full pl-10 sm:pl-12 pr-24 sm:pr-28 py-3 sm:py-3.5 bg-white border border-emerald-300/80 rounded-2xl text-xs sm:text-sm font-semibold text-slate-900 placeholder:text-slate-400 shadow-xs focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all"
        />

        <button
          type="submit"
          disabled={!input.trim()}
          className="absolute right-2 sm:right-2.5 px-3.5 sm:px-4 py-2 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white rounded-xl text-xs sm:text-sm font-black flex items-center gap-1.5 shadow-xs transition-all active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
        >
          <span>{language === 'bn' ? 'যোগ করুন' : 'Add'}</span>
          <Send className="w-3.5 h-3.5" />
        </button>
      </form>

      {/* Real-time Dynamic AI Interpretation Card */}
      {input.trim().length > 3 && parsed.amount > 0 && (
        <div className="p-3.5 sm:p-4 rounded-2xl bg-gradient-to-br from-emerald-50/90 via-teal-50/60 to-white border border-emerald-200/90 shadow-sm space-y-3 animate-in fade-in slide-in-from-top-2 duration-150">
          
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5 text-amber-500 fill-amber-500" />
              <span>{language === 'bn' ? 'স্বয়ংক্রিয় সনাক্তকরণ (AI Live Interpretation):' : 'AI Live Parse Preview:'}</span>
            </span>
            <span className="text-[10px] text-slate-500">
              {language === 'bn' ? 'যেকোনো ট্যাগ ক্লিক করে পরিবর্তন করা যাবে' : 'Click any chip to customize'}
            </span>
          </div>

          {/* Parsed Badges / Chips */}
          <div className="flex flex-wrap items-center gap-2">
            
            {/* Amount & Type Badge */}
            <div className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 shadow-2xs ${
              parsed.type === 'income' ? 'bg-emerald-600 text-white' : 'bg-slate-900 text-white'
            }`}>
              <span>{parsed.type === 'income' ? '+' : '-'}</span>
              <span>{formatMoney(parsed.amount)}</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-white/20 uppercase font-mono">
                {parsed.type === 'income' ? (language === 'bn' ? 'আয়' : 'Income') : (language === 'bn' ? 'ব্যয়' : 'Expense')}
              </span>
            </div>

            {/* Category Chip (Interactive) */}
            <div className="relative" ref={categoryPickerRef}>
              <button
                type="button"
                onClick={() => {
                  setShowCategoryPicker(!showCategoryPicker);
                  setShowAccountPicker(false);
                }}
                className="px-2.5 py-1.5 rounded-xl bg-white border border-slate-200/90 hover:border-emerald-400 text-slate-800 text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                title="Change Category"
              >
                <div
                  className="w-4 h-4 rounded-md flex items-center justify-center shrink-0"
                  style={{ backgroundColor: `${currentCategory.color}25`, color: currentCategory.color }}
                >
                  <CategoryIcon iconName={currentCategory.icon} size={11} />
                </div>
                <span>{language === 'bn' ? currentCategory.nameBn || currentCategory.name : currentCategory.name}</span>
                <span className="text-[10px] text-slate-400">▼</span>
              </button>

              {/* Category Picker Popover */}
              {showCategoryPicker && (
                <div className="absolute top-full left-0 mt-1.5 z-40 bg-white border border-slate-200 rounded-2xl p-2 shadow-xl min-w-[210px] max-h-56 overflow-y-auto space-y-1">
                  {categories.map(c => (
                    <button
                      key={c.id}
                      type="button"
                      onClick={() => {
                        setSelectedCategoryId(c.id);
                        setShowCategoryPicker(false);
                      }}
                      className={`w-full p-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors text-left cursor-pointer ${
                        c.id === currentCategory.id ? 'bg-emerald-50 text-emerald-900 font-bold' : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div
                        className="w-4 h-4 rounded-md flex items-center justify-center shrink-0"
                        style={{ backgroundColor: `${c.color}25`, color: c.color }}
                      >
                        <CategoryIcon iconName={c.icon} size={11} />
                      </div>
                      <span className="truncate">{language === 'bn' ? c.nameBn || c.name : c.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Date Badge */}
            <div className="px-2.5 py-1.5 rounded-xl bg-white border border-slate-200/90 text-slate-700 text-xs font-semibold flex items-center gap-1.5 shadow-2xs">
              <Calendar className="w-3.5 h-3.5 text-emerald-600" />
              <span>
                {parsed.meta.detectedDateLabel ? `${parsed.meta.detectedDateLabel} (${parsed.date})` : parsed.date}
              </span>
            </div>

            {/* Time Badge */}
            {parsed.time && (
              <div className="px-2.5 py-1.5 rounded-xl bg-white border border-slate-200/90 text-slate-700 text-xs font-semibold flex items-center gap-1.5 shadow-2xs">
                <Clock className="w-3.5 h-3.5 text-teal-600" />
                <span>{parsed.meta.detectedTimeLabel || parsed.time}</span>
              </div>
            )}

            {/* Account / Wallet Chip (Interactive) */}
            <div className="relative" ref={accountPickerRef}>
              <button
                type="button"
                onClick={() => {
                  setShowAccountPicker(!showAccountPicker);
                  setShowCategoryPicker(false);
                }}
                className="px-2.5 py-1.5 rounded-xl bg-white border border-slate-200/90 hover:border-emerald-400 text-slate-800 text-xs font-bold flex items-center gap-1.5 shadow-2xs transition-colors cursor-pointer"
                title="Change Account"
              >
                <Wallet className="w-3.5 h-3.5 text-emerald-600" />
                <span>{language === 'bn' ? currentAccount.nameBn || currentAccount.name : currentAccount.name}</span>
                <span className="text-[10px] text-slate-400">▼</span>
              </button>

              {/* Account Picker Popover */}
              {showAccountPicker && (
                <div className="absolute top-full left-0 mt-1.5 z-40 bg-white border border-slate-200 rounded-2xl p-2 shadow-xl min-w-[200px] space-y-1">
                  {accounts.map(a => (
                    <button
                      key={a.id}
                      type="button"
                      onClick={() => {
                        setSelectedAccountId(a.id);
                        setShowAccountPicker(false);
                      }}
                      className={`w-full p-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition-colors text-left cursor-pointer ${
                        a.id === currentAccount.id ? 'bg-emerald-50 text-emerald-900 font-bold' : 'hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: a.color }} />
                      <span className="truncate">{language === 'bn' ? a.nameBn || a.name : a.name}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {/* Clean Note Preview */}
            {parsed.note && (
              <div className="px-2.5 py-1.5 rounded-xl bg-emerald-100/60 border border-emerald-200 text-emerald-950 text-xs font-medium italic">
                "{parsed.note}"
              </div>
            )}

          </div>

          {/* Confirm Button */}
          <div className="pt-1 flex items-center justify-end">
            <button
              type="button"
              onClick={() => handleSubmit()}
              className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-xs transition-all active:scale-95 cursor-pointer flex items-center gap-1.5"
            >
              <span>{language === 'bn' ? 'এই হিসাবে এন্ট্রি করুন' : 'Confirm & Save'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

        </div>
      )}

      {/* Feedback Alert Banner */}
      {feedback && (
        <div
          className={`px-4 py-2.5 rounded-2xl text-xs font-bold flex items-center justify-between animate-in fade-in duration-150 border ${
            feedback.isError
              ? 'bg-rose-50 text-rose-800 border-rose-200'
              : 'bg-emerald-50 text-emerald-900 border-emerald-200 shadow-2xs'
          }`}
        >
          <div className="flex items-center gap-2">
            {feedback.isError ? (
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            )}
            <span>{feedback.message}</span>
          </div>
          <button
            onClick={() => setFeedback(null)}
            className="text-[11px] underline opacity-80 hover:opacity-100 cursor-pointer ml-3"
          >
            {language === 'bn' ? 'ঠিক আছে' : 'OK'}
          </button>
        </div>
      )}

      {/* Quick Suggestion Pills */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs text-slate-500 no-scrollbar">
        <span className="font-semibold text-slate-400 shrink-0 text-[11px]">
          {language === 'bn' ? 'স্মার্ট উদাহরণ:' : 'Examples:'}
        </span>
        {samplePrompts.map((s, idx) => (
          <button
            key={idx}
            type="button"
            onClick={() => {
              setInput(s.text);
              if (inputRef.current) inputRef.current.focus();
            }}
            className="px-2.5 py-1 bg-white hover:bg-emerald-50 hover:text-emerald-800 border border-slate-200/80 rounded-lg text-slate-700 font-medium whitespace-nowrap text-[11px] shrink-0 transition-colors cursor-pointer"
          >
            {s.label}
          </button>
        ))}
      </div>

    </div>
  );
};
