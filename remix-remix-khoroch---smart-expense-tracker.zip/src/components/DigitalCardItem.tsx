import React, { useState } from 'react';
import { DigitalCard, DigitalCardTheme } from '../types';
import { useExpense } from '../context/ExpenseContext';
import { 
  Wifi, 
  Lock, 
  Unlock, 
  Star, 
  Eye, 
  EyeOff, 
  Zap, 
  Edit2, 
  Trash2, 
  CreditCard,
  Building,
  CheckCircle2,
  Sliders
} from 'lucide-react';

interface DigitalCardItemProps {
  card: DigitalCard;
  onTapToPay?: (card: DigitalCard) => void;
  onEdit?: (card: DigitalCard) => void;
  onFilterTransactions?: (card: DigitalCard) => void;
  isDetailedView?: boolean;
}

export const DigitalCardItem: React.FC<DigitalCardItemProps> = ({
  card,
  onTapToPay,
  onEdit,
  onFilterTransactions,
  isDetailedView = true,
}) => {
  const { 
    formatMoney, 
    accounts, 
    toggleFreezeDigitalCard, 
    setDefaultDigitalCard, 
    deleteDigitalCard,
    language 
  } = useExpense();

  const [showFullNumber, setShowFullNumber] = useState(false);
  const [showCvv, setShowCvv] = useState(false);

  const linkedAccount = accounts.find(a => a.id === card.linkedAccountId);

  // Theme gradient configurations matching luxury Google Wallet finishes
  const getThemeClasses = (theme: DigitalCardTheme) => {
    switch (theme) {
      case 'obsidian':
        return {
          bg: 'bg-gradient-to-br from-slate-950 via-slate-900 to-zinc-900',
          text: 'text-white',
          subtext: 'text-zinc-400',
          chip: 'from-amber-200 via-yellow-400 to-amber-600',
          border: 'border-slate-800/80',
          accent: 'bg-zinc-800 text-zinc-200',
          glow: 'shadow-slate-950/40',
        };
      case 'sapphire':
        return {
          bg: 'bg-gradient-to-br from-blue-950 via-indigo-900 to-blue-800',
          text: 'text-white',
          subtext: 'text-blue-200',
          chip: 'from-amber-200 via-yellow-400 to-amber-500',
          border: 'border-blue-700/50',
          accent: 'bg-blue-800/80 text-blue-100',
          glow: 'shadow-blue-900/30',
        };
      case 'emerald':
        return {
          bg: 'bg-gradient-to-br from-emerald-950 via-teal-900 to-emerald-800',
          text: 'text-white',
          subtext: 'text-emerald-200',
          chip: 'from-amber-200 via-yellow-400 to-amber-600',
          border: 'border-emerald-700/50',
          accent: 'bg-emerald-800/80 text-emerald-100',
          glow: 'shadow-emerald-900/30',
        };
      case 'amethyst':
        return {
          bg: 'bg-gradient-to-br from-purple-950 via-fuchsia-900 to-indigo-900',
          text: 'text-white',
          subtext: 'text-purple-200',
          chip: 'from-amber-200 via-yellow-400 to-amber-500',
          border: 'border-purple-700/50',
          accent: 'bg-purple-800/80 text-purple-100',
          glow: 'shadow-purple-900/30',
        };
      case 'sunset':
        return {
          bg: 'bg-gradient-to-br from-amber-950 via-rose-900 to-orange-800',
          text: 'text-white',
          subtext: 'text-amber-200',
          chip: 'from-amber-200 via-yellow-300 to-amber-500',
          border: 'border-amber-700/50',
          accent: 'bg-amber-800/80 text-amber-100',
          glow: 'shadow-orange-900/30',
        };
      case 'platinum':
        return {
          bg: 'bg-gradient-to-br from-slate-200 via-zinc-100 to-slate-300',
          text: 'text-slate-900',
          subtext: 'text-slate-600',
          chip: 'from-amber-300 via-yellow-500 to-amber-600',
          border: 'border-slate-300',
          accent: 'bg-slate-300/80 text-slate-800',
          glow: 'shadow-slate-400/20',
        };
      case 'nexus':
      default:
        return {
          bg: 'bg-gradient-to-br from-sky-950 via-blue-900 to-cyan-900',
          text: 'text-white',
          subtext: 'text-sky-200',
          chip: 'from-amber-200 via-yellow-400 to-amber-500',
          border: 'border-sky-700/50',
          accent: 'bg-sky-800/80 text-sky-100',
          glow: 'shadow-sky-900/30',
        };
    }
  };

  const themeStyle = getThemeClasses(card.theme);

  // Network badge / visual representation
  const renderNetworkLogo = () => {
    switch (card.network) {
      case 'visa':
        return (
          <div className="font-black italic text-lg sm:text-xl tracking-tighter select-none">
            <span className="text-white drop-shadow-xs">VISA</span>
          </div>
        );
      case 'mastercard':
        return (
          <div className="flex items-center -space-x-2 select-none">
            <div className="w-5 h-5 rounded-full bg-rose-500 opacity-90 shadow-xs" />
            <div className="w-5 h-5 rounded-full bg-amber-400 opacity-90 shadow-xs" />
          </div>
        );
      case 'amex':
        return (
          <div className="px-1.5 py-0.5 rounded-sm bg-blue-600 text-white font-black text-[11px] tracking-wider select-none">
            AMEX
          </div>
        );
      case 'nexus':
        return (
          <div className="flex items-center gap-1 select-none">
            <div className="flex items-center -space-x-1">
              <span className="w-3.5 h-3.5 rounded-sm bg-emerald-500 rotate-45 inline-block" />
              <span className="w-3.5 h-3.5 rounded-sm bg-sky-500 rotate-45 inline-block" />
            </div>
            <span className="text-[10px] font-black tracking-tight text-white uppercase">NexusPay</span>
          </div>
        );
      default:
        return (
          <div className="flex items-center gap-1 select-none">
            <CreditCard className="w-4 h-4" />
            <span className="text-[11px] font-bold tracking-tight uppercase">Card</span>
          </div>
        );
    }
  };

  // Card type label
  const getCardTypeLabel = () => {
    switch (card.type) {
      case 'credit':
        return language === 'bn' ? 'ক্রেডিট কার্ড' : 'Credit Card';
      case 'debit':
        return language === 'bn' ? 'ডেবিট কার্ড' : 'Debit Card';
      case 'prepaid':
        return language === 'bn' ? 'প্রিপেইড / ডুয়েল কারেন্সি' : 'Prepaid / Virtual';
      case 'loyalty':
        return language === 'bn' ? 'মেম্বারশিপ কার্ড' : 'Loyalty Card';
    }
  };

  // Number masking logic
  const displayCardNumber = showFullNumber 
    ? (card.cardNumberMasked || `•••• •••• •••• ${card.last4}`)
    : `•••• •••• •••• ${card.last4}`;

  return (
    <div className="flex flex-col space-y-3">
      {/* Visual Google Wallet Card Container */}
      <div 
        className={`relative w-full aspect-[1.586/1] rounded-3xl p-5 sm:p-6 shadow-xl ${themeStyle.glow} ${themeStyle.bg} border ${themeStyle.border} overflow-hidden select-none transition-all duration-300 hover:scale-[1.01]`}
      >
        {/* Subtle holographic sheen overlay */}
        <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/5 to-white/10 pointer-events-none rounded-3xl" />

        {/* Frozen icy overlay if card is locked */}
        {card.isFrozen && (
          <div className="absolute inset-0 z-20 bg-slate-950/75 backdrop-blur-[2px] flex flex-col items-center justify-center p-4 text-center animate-in fade-in duration-200">
            <div className="w-12 h-12 rounded-2xl bg-sky-500/20 border border-sky-400/40 flex items-center justify-center text-sky-300 mb-2 shadow-lg shadow-sky-500/10">
              <Lock className="w-6 h-6 stroke-[2.5]" />
            </div>
            <p className="text-sm font-bold text-white tracking-wide">
              {language === 'bn' ? 'কার্ডটি সাময়িকভাবে লক/ফ্রিজ' : 'Card Temporarily Frozen'}
            </p>
            <p className="text-[11px] text-sky-200/80 max-w-[200px] mt-0.5">
              {language === 'bn' ? 'নিরাপত্তার স্বার্থে কোনো লেনদেন হবে না' : 'All contactless & online charges paused'}
            </p>
          </div>
        )}

        {/* Top Header of Card: Bank/Issuer name + Contactless Icon + Network Logo */}
        <div className="relative z-10 flex items-start justify-between">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-xl bg-white/10 backdrop-blur-xs flex items-center justify-center text-white/90 border border-white/10">
              <Building className="w-3.5 h-3.5" />
            </div>
            <div>
              <h4 className={`text-xs sm:text-sm font-bold tracking-tight ${themeStyle.text} leading-tight`}>
                {card.issuerName}
              </h4>
              <span className={`text-[10px] font-semibold tracking-wider uppercase ${themeStyle.subtext}`}>
                {getCardTypeLabel()}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {card.contactlessEnabled && (
              <span title="Contactless Enabled">
                <Wifi className={`w-4 h-4 rotate-90 ${themeStyle.subtext} opacity-80`} />
              </span>
            )}
            {renderNetworkLogo()}
          </div>
        </div>

        {/* Center: Metallic EMV Chip */}
        <div className="relative z-10 mt-4 sm:mt-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            {/* Realistic Golden EMV Contact Chip */}
            <div className={`w-10 h-7 rounded-md bg-gradient-to-br ${themeStyle.chip} p-0.5 shadow-sm border border-amber-300/40 relative overflow-hidden`}>
              <div className="w-full h-full border border-amber-900/30 rounded-xs flex flex-col justify-between p-0.5">
                <div className="h-0.5 bg-amber-900/20 w-full" />
                <div className="flex justify-between">
                  <div className="w-2.5 h-1.5 border border-amber-900/30 rounded-xs" />
                  <div className="w-2.5 h-1.5 border border-amber-900/30 rounded-xs" />
                </div>
                <div className="h-0.5 bg-amber-900/20 w-full" />
              </div>
            </div>

            {/* Default Card Star Indicator */}
            {card.isDefault && (
              <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-400/20 border border-amber-300/40 text-amber-200">
                <Star className="w-2.5 h-2.5 fill-amber-300 text-amber-300" />
                <span>{language === 'bn' ? 'ডিফল্ট' : 'Default'}</span>
              </span>
            )}
          </div>

          {/* Quick Reveal / Hide Number Toggle */}
          <button
            onClick={() => setShowFullNumber(!showFullNumber)}
            className="p-1.5 text-white/70 hover:text-white rounded-lg hover:bg-white/10 transition-colors"
            title={showFullNumber ? 'Hide full number' : 'Show card number'}
          >
            {showFullNumber ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* Bottom Section: Card Number, Expiry, CVV, Cardholder Name */}
        <div className="relative z-10 mt-auto pt-3">
          <div className={`text-base sm:text-lg font-mono font-bold tracking-widest ${themeStyle.text} drop-shadow-xs`}>
            {displayCardNumber}
          </div>

          <div className="flex items-end justify-between mt-2 pt-1 border-t border-white/10">
            <div>
              <span className={`text-[9px] uppercase tracking-wider block ${themeStyle.subtext} font-medium`}>
                Cardholder
              </span>
              <div className={`text-xs sm:text-sm font-semibold tracking-wider uppercase ${themeStyle.text} truncate max-w-[170px]`}>
                {card.cardholderName || 'CARDHOLDER'}
              </div>
            </div>

            <div className="flex items-center gap-3 text-right">
              <div>
                <span className={`text-[9px] uppercase tracking-wider block ${themeStyle.subtext} font-medium`}>
                  Expires
                </span>
                <span className={`text-xs font-mono font-bold ${themeStyle.text}`}>
                  {card.expiryDate || '12/28'}
                </span>
              </div>

              {card.cvv && (
                <div 
                  onClick={() => setShowCvv(!showCvv)} 
                  className="cursor-pointer group"
                  title="Click to reveal CVV"
                >
                  <span className={`text-[9px] uppercase tracking-wider block ${themeStyle.subtext} font-medium`}>
                    CVV
                  </span>
                  <span className={`text-xs font-mono font-bold ${themeStyle.text} group-hover:text-amber-300`}>
                    {showCvv ? card.cvv : '•••'}
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Card Info & Spending Limit Tracker (Only if detailed view) */}
      {isDetailedView && (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs space-y-3">
          {/* Card Financial Details & Limits */}
          <div className="flex items-center justify-between text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                {card.type === 'credit' 
                  ? (language === 'bn' ? 'চলতি মাসের খরচ' : 'Spent This Month')
                  : (language === 'bn' ? 'সংযুক্ত অ্যাকাউন্ট স্থিতি' : 'Linked Account Balance')}
              </span>
              <span className="text-sm font-black text-slate-800">
                {card.type === 'credit' 
                  ? formatMoney(card.currentSpentThisMonth || 0)
                  : formatMoney(linkedAccount ? linkedAccount.balance : 0)}
              </span>
            </div>

            {card.creditLimit && card.type === 'credit' && (
              <div className="text-right">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                  {language === 'bn' ? 'ক্রেডিট লিমিট' : 'Credit Limit'}
                </span>
                <span className="text-xs font-bold text-slate-700">
                  {formatMoney(card.creditLimit)}
                </span>
              </div>
            )}

            {card.dailySpendLimit && card.type !== 'credit' && (
              <div className="text-right">
                <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block">
                  {language === 'bn' ? 'দৈনিক খরচ সীমা' : 'Daily Spend Limit'}
                </span>
                <span className="text-xs font-bold text-slate-700">
                  {formatMoney(card.dailySpendLimit)}
                </span>
              </div>
            )}
          </div>

          {/* Progress bar for credit card utilization */}
          {card.type === 'credit' && card.creditLimit && (
            <div className="space-y-1">
              <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                <div 
                  className={`h-full rounded-full transition-all duration-300 ${
                    ((card.currentSpentThisMonth || 0) / card.creditLimit) > 0.8
                      ? 'bg-rose-500'
                      : 'bg-emerald-500'
                  }`}
                  style={{
                    width: `${Math.min(100, Math.round(((card.currentSpentThisMonth || 0) / card.creditLimit) * 100))}%`
                  }}
                />
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-medium">
                <span>
                  {Math.round(((card.currentSpentThisMonth || 0) / card.creditLimit) * 100)}% {language === 'bn' ? 'ব্যবহৃত' : 'utilized'}
                </span>
                <span>
                  {language === 'bn' ? 'অবশিষ্ট:' : 'Avail:'} {formatMoney(Math.max(0, card.creditLimit - (card.currentSpentThisMonth || 0)))}
                </span>
              </div>
            </div>
          )}

          {/* Interactive Google Wallet Actions Bar */}
          <div className="pt-2 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-1.5">
              {/* Tap to Pay Simulation Button */}
              {onTapToPay && (
                <button
                  onClick={() => onTapToPay(card)}
                  disabled={card.isFrozen}
                  className={`inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl shadow-xs transition-all ${
                    card.isFrozen
                      ? 'bg-slate-100 text-slate-400 cursor-not-allowed'
                      : 'bg-slate-900 hover:bg-slate-800 text-white active:scale-95'
                  }`}
                >
                  <Zap className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                  <span>{language === 'bn' ? 'ট্যাপ পেমেন্ট' : 'Tap to Pay'}</span>
                </button>
              )}

              {/* View Transactions for this card */}
              {onFilterTransactions && (
                <button
                  onClick={() => onFilterTransactions(card)}
                  className="px-2.5 py-1.5 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-xl transition-colors"
                >
                  {language === 'bn' ? 'লেনদেন দেখুন' : 'Transactions'}
                </button>
              )}
            </div>

            <div className="flex items-center gap-1">
              {/* Freeze / Unfreeze Card Toggle */}
              <button
                onClick={() => toggleFreezeDigitalCard(card.id)}
                className={`p-1.5 rounded-xl text-xs font-medium transition-colors ${
                  card.isFrozen
                    ? 'text-sky-700 bg-sky-50 hover:bg-sky-100'
                    : 'text-slate-500 hover:text-rose-600 hover:bg-rose-50'
                }`}
                title={card.isFrozen ? 'Unfreeze Card' : 'Freeze / Lock Card'}
              >
                {card.isFrozen ? <Unlock className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
              </button>

              {/* Set as Default Card */}
              {!card.isDefault && (
                <button
                  onClick={() => setDefaultDigitalCard(card.id)}
                  className="p-1.5 text-slate-400 hover:text-amber-600 hover:bg-amber-50 rounded-xl transition-colors"
                  title="Set as Default Google Wallet Card"
                >
                  <Star className="w-4 h-4" />
                </button>
              )}

              {/* Edit Card */}
              {onEdit && (
                <button
                  onClick={() => onEdit(card)}
                  className="p-1.5 text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl transition-colors"
                  title="Edit Card"
                >
                  <Edit2 className="w-4 h-4" />
                </button>
              )}

              {/* Delete Card */}
              <button
                onClick={() => {
                  if (window.confirm(language === 'bn' ? `আপনি কি ${card.issuerName} কার্ডটি মুছে ফেলতে চান?` : `Delete ${card.issuerName}?`)) {
                    deleteDigitalCard(card.id);
                  }
                }}
                className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                title="Remove Card"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
