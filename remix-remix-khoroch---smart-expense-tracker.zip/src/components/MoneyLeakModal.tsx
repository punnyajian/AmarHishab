import React, { useState, useMemo } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { analyzeMoneyLeaks } from '../utils/moneyLeakDetector';
import { MoneyLeakItem } from '../types';
import {
  X,
  Droplets,
  AlertTriangle,
  CheckCircle2,
  TrendingDown,
  Sparkles,
  Sliders,
  ShieldCheck,
  ChevronRight,
  ChevronDown,
  ArrowRight,
  Coffee,
  Car,
  ShoppingBag,
  Wine,
  Smartphone,
  Tag,
  Receipt,
  Flame,
  Award,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface MoneyLeakModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectCategory?: (categoryId: string) => void;
}

export const MoneyLeakModal: React.FC<MoneyLeakModalProps> = ({ isOpen, onClose }) => {
  useModalBehavior({ isOpen, onClose });

  const {
    transactions,
    categories,
    totalExpenseThisMonth,
    formatMoney,
    language,
    setActiveTab,
  } = useExpense();

  const [reductionPercentage, setReductionPercentage] = useState<number>(40); // default 40% plug target
  const [expandedLeakId, setExpandedLeakId] = useState<string | null>(null);
  const [pluggedLeakIds, setPluggedLeakIds] = useState<string[]>([]);

  // Compute Leak Analysis
  const analysis = useMemo(() => {
    return analyzeMoneyLeaks(transactions, categories, totalExpenseThisMonth, language);
  }, [transactions, categories, totalExpenseThisMonth, language]);

  if (!isOpen) return null;

  // Potential Monthly & Yearly Savings based on reduction slider
  const potentialMonthlySaved = Math.round((analysis.totalMonthlyLeak * reductionPercentage) / 100);
  const potentialYearlySaved = potentialMonthlySaved * 12;

  const handlePlugLeak = (leakId: string) => {
    if (pluggedLeakIds.includes(leakId)) {
      setPluggedLeakIds(prev => prev.filter(id => id !== leakId));
    } else {
      setPluggedLeakIds(prev => [...prev, leakId]);
      try {
        confetti({
          particleCount: 45,
          spread: 60,
          origin: { y: 0.7 },
        });
      } catch {
        // ignore
      }
    }
  };

  const getLeakIcon = (iconName: string) => {
    switch (iconName) {
      case 'Coffee': return Coffee;
      case 'Car': return Car;
      case 'ShoppingBag': return ShoppingBag;
      case 'Wine': return Wine;
      case 'Smartphone': return Smartphone;
      case 'Tag': return Tag;
      default: return Receipt;
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90dvh] flex flex-col"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-br from-slate-950 via-rose-950 to-slate-900 text-white p-5 sm:p-6 relative overflow-hidden shrink-0">
          <div className="absolute top-0 right-0 w-64 h-64 bg-rose-500/10 rounded-full blur-3xl pointer-events-none" />
          
          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-rose-500/20 border border-rose-400/30 text-rose-300 flex items-center justify-center shadow-inner">
                <Droplets className="w-6 h-6 animate-pulse" />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-rose-500/20 border border-rose-400/30 text-rose-200 text-[10px] font-bold uppercase tracking-wider">
                  <Sparkles className="w-3 h-3" />
                  <span>{language === 'bn' ? 'স্মার্ট মানি লিক ডিটেক্টর' : 'AI Money Leak Detector'}</span>
                </div>
                <h2 className="text-lg sm:text-xl font-black text-white tracking-tight mt-0.5">
                  {language === 'bn' ? 'কোথায় অলক্ষ্যে টাকা গলে যাচ্ছে?' : 'Uncover Silent Money Leaks'}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Metrics Banner inside Header */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 mt-5 relative z-10 pt-3 border-t border-white/10">
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
              <span className="text-[10px] text-rose-200 font-semibold block uppercase">
                {language === 'bn' ? 'মাসে মোট লিকেজ' : 'Monthly Leaks'}
              </span>
              <span className="text-base sm:text-lg font-black text-white mt-0.5 block">
                {formatMoney(analysis.totalMonthlyLeak)}
              </span>
              <span className="text-[10px] text-rose-200/80">
                {analysis.detectedLeaksCount} {language === 'bn' ? 'টি খাদ চিহ্নিত' : 'areas detected'}
              </span>
            </div>

            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
              <span className="text-[10px] text-amber-200 font-semibold block uppercase">
                {language === 'bn' ? 'বছরে সম্ভাব্য অপচয়' : 'Yearly Drain'}
              </span>
              <span className="text-base sm:text-lg font-black text-amber-300 mt-0.5 block">
                {formatMoney(analysis.totalYearlyLeak)}
              </span>
              <span className="text-[10px] text-amber-200/80">
                {language === 'bn' ? 'একটানা চললে' : 'If left unchecked'}
              </span>
            </div>

            <div className="col-span-2 sm:col-span-1 bg-white/10 backdrop-blur-md rounded-2xl p-3 border border-white/10">
              <span className="text-[10px] text-emerald-200 font-semibold block uppercase">
                {language === 'bn' ? 'ব্যয়ের কত শতাংশ' : '% of Total Spend'}
              </span>
              <span className="text-base sm:text-lg font-black text-emerald-300 mt-0.5 block">
                {analysis.leakPercentageOfExpense}%
              </span>
              <span className="text-[10px] text-emerald-200/80">
                {language === 'bn' ? 'খুচরা খরচে যায়' : 'in micro-expenses'}
              </span>
            </div>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-700 flex-1">
          
          {/* AI Assessment Bar */}
          <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <strong className="block font-bold mb-0.5">
                {language === 'bn' ? '🤖 এআই বিশ্লেষণ সারসংক্ষেপ:' : '🤖 AI Diagnostic Insight:'}
              </strong>
              {language === 'bn' ? analysis.insightSummaryBn : analysis.insightSummaryEn}
            </div>
          </div>

          {/* Interactive Simulation Slider: "Plug the Leaks" */}
          {analysis.totalMonthlyLeak > 0 && (
            <div className="bg-gradient-to-br from-emerald-50 via-teal-50 to-emerald-50/60 border border-emerald-200 rounded-3xl p-4 sm:p-5 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                    <Sliders className="w-4 h-4" />
                  </div>
                  <div>
                    <h3 className="text-xs sm:text-sm font-bold text-emerald-950">
                      {language === 'bn' ? 'লিকেজ নিয়ন্ত্রণ সিমুলেটর' : 'Leak Reduction Simulator'}
                    </h3>
                    <p className="text-[11px] text-emerald-700">
                      {language === 'bn' ? 'ছোট ছোট খরচ কমালে কত টাকা সঞ্চয় হবে?' : 'See compounding savings by curtailing leaks'}
                    </p>
                  </div>
                </div>

                <span className="text-xs font-black bg-emerald-600 text-white px-2.5 py-1 rounded-full shadow-2xs">
                  {reductionPercentage}% {language === 'bn' ? 'হ্রাস' : 'Reduction'}
                </span>
              </div>

              <div className="space-y-1 pt-1">
                <input
                  type="range"
                  min="10"
                  max="90"
                  step="5"
                  value={reductionPercentage}
                  onChange={e => setReductionPercentage(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
                <div className="flex justify-between text-[10px] text-emerald-800 font-semibold">
                  <span>10% (মৃদু নিয়ন্ত্রণ)</span>
                  <span>50% (ভারসাম্যপূর্ণ)</span>
                  <span>90% (কঠোর শৃঙ্খলা)</span>
                </div>
              </div>

              <div className="pt-2 border-t border-emerald-200/70 grid grid-cols-2 gap-3 text-center">
                <div className="bg-white/80 rounded-2xl p-2.5 border border-emerald-200">
                  <span className="text-[10px] text-emerald-700 uppercase font-semibold block">
                    {language === 'bn' ? 'মাসিক সম্ভাব্য সঞ্চয়' : 'Monthly Potential Gain'}
                  </span>
                  <span className="text-sm sm:text-base font-extrabold text-emerald-800 mt-0.5 block">
                    +{formatMoney(potentialMonthlySaved)}
                  </span>
                </div>

                <div className="bg-white/80 rounded-2xl p-2.5 border border-emerald-200">
                  <span className="text-[10px] text-emerald-700 uppercase font-semibold block">
                    {language === 'bn' ? 'বছরে সঞ্চয় বৃদ্ধি' : 'Yearly Compounded Gain'}
                  </span>
                  <span className="text-sm sm:text-base font-extrabold text-emerald-800 mt-0.5 block">
                    +{formatMoney(potentialYearlySaved)}
                  </span>
                </div>
              </div>
            </div>
          )}

          {/* List of Identified Leaks */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs sm:text-sm font-bold text-slate-800 flex items-center gap-1.5">
                <Droplets className="w-4 h-4 text-rose-500" />
                <span>{language === 'bn' ? 'শনাক্তকৃত ছোট খরচের খাতসমূহ' : 'Detected Micro-Spending Leaks'}</span>
                <span className="text-xs bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full font-bold ml-1">
                  {analysis.leaks.length}
                </span>
              </h3>

              {pluggedLeakIds.length > 0 && (
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{pluggedLeakIds.length} {language === 'bn' ? 'টি রোধ করা হয়েছে' : 'plugged'}</span>
                </span>
              )}
            </div>

            {analysis.leaks.length === 0 ? (
              <div className="bg-emerald-50/70 border border-emerald-200 rounded-3xl p-8 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-inner">
                  <ShieldCheck className="w-8 h-8" />
                </div>
                <div>
                  <h4 className="text-sm font-black text-emerald-950">
                    {language === 'bn' ? 'কোনো অর্থের লিকেজ নেই!' : 'No Money Leaks Detected!'}
                  </h4>
                  <p className="text-xs text-emerald-800/80 max-w-sm mx-auto mt-1 leading-relaxed">
                    {language === 'bn'
                      ? 'আপনার দৈনন্দিন খরচে কোনো অপ্রয়োজনীয় ছোটখাটো পুনরাবৃত্ত খরচের অপচয় পাওয়া যায়নি। আপনার বাজেট ডিসিপ্লিন চমৎকার!'
                      : 'You do not have repetitive micro-expenses draining funds without your knowledge. Great budgeting!'}
                  </p>
                </div>
              </div>
            ) : (
              <div className="space-y-3">
                {analysis.leaks.map(leak => {
                  const Icon = getLeakIcon(leak.icon);
                  const isExpanded = expandedLeakId === leak.id;
                  const isPlugged = pluggedLeakIds.includes(leak.id);

                  // Extract transactions matching this leak
                  const matchedTxs = transactions.filter(t => leak.matchedTransactionIds.includes(t.id));

                  return (
                    <div
                      key={leak.id}
                      className={`rounded-2xl border transition-all overflow-hidden ${
                        isPlugged
                          ? 'bg-slate-50 border-emerald-300 opacity-90'
                          : 'bg-white border-slate-200 hover:border-rose-200 shadow-2xs'
                      }`}
                    >
                      {/* Main Card Header */}
                      <div className="p-4 flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3 min-w-0">
                          <div
                            className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-xs"
                            style={{ backgroundColor: `${leak.color}15`, color: leak.color }}
                          >
                            <Icon className="w-5 h-5" />
                          </div>

                          <div className="min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4 className="text-xs sm:text-sm font-bold text-slate-800 truncate">
                                {language === 'bn' ? leak.titleBn : leak.title}
                              </h4>
                              
                              {/* Severity Badge */}
                              <span
                                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                                  leak.severity === 'high'
                                    ? 'bg-rose-100 text-rose-800'
                                    : leak.severity === 'medium'
                                    ? 'bg-amber-100 text-amber-800'
                                    : 'bg-slate-100 text-slate-700'
                                }`}
                              >
                                {leak.severity === 'high'
                                  ? (language === 'bn' ? 'তীব্র লিক' : 'High Leak')
                                  : leak.severity === 'medium'
                                  ? (language === 'bn' ? 'মাঝারি লিক' : 'Medium')
                                  : (language === 'bn' ? 'সাধারণ' : 'Low')}
                              </span>

                              {isPlugged && (
                                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                                  ✓ {language === 'bn' ? 'নিয়ন্ত্রণে' : 'Plugged'}
                                </span>
                              )}
                            </div>

                            <p className="text-[11px] text-slate-400 mt-0.5">
                              {leak.count} {language === 'bn' ? 'বার খরচ' : 'times'} • {language === 'bn' ? 'গড়ে' : 'avg'} {formatMoney(leak.averageAmount)}
                            </p>
                          </div>
                        </div>

                        {/* Amount projection */}
                        <div className="text-right shrink-0">
                          <span className="text-sm sm:text-base font-black text-rose-600 block">
                            -{formatMoney(leak.monthlyAmount)}
                          </span>
                          <span className="text-[10px] text-slate-400 block">
                            {language === 'bn' ? 'বছরে' : 'yr'}: {formatMoney(leak.yearlyProjected)}
                          </span>
                        </div>
                      </div>

                      {/* AI Advice Pill */}
                      <div className="px-4 pb-3.5 pt-0">
                        <div className="bg-slate-50 border border-slate-100 rounded-xl p-2.5 text-xs text-slate-600 flex items-start gap-2">
                          <Sparkles className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />
                          <p className="text-[11px] leading-relaxed">
                            <strong>{language === 'bn' ? 'এআই পরামর্শ:' : 'AI Tip:'}</strong>{' '}
                            {language === 'bn' ? leak.recommendationBn : leak.recommendation}
                          </p>
                        </div>
                      </div>

                      {/* Card Bottom Actions */}
                      <div className="px-4 py-2.5 bg-slate-50/70 border-t border-slate-100 flex items-center justify-between text-xs">
                        <button
                          type="button"
                          onClick={() => setExpandedLeakId(isExpanded ? null : leak.id)}
                          className="text-slate-500 hover:text-slate-800 font-semibold flex items-center gap-1 cursor-pointer"
                        >
                          <span>{language === 'bn' ? `লেনদেনগুলো দেখুন (${matchedTxs.length})` : `View Entries (${matchedTxs.length})`}</span>
                          {isExpanded ? <ChevronDown className="w-3.5 h-3.5" /> : <ChevronRight className="w-3.5 h-3.5" />}
                        </button>

                        <button
                          type="button"
                          onClick={() => handlePlugLeak(leak.id)}
                          className={`px-3 py-1.5 rounded-xl font-bold text-xs transition-all flex items-center gap-1.5 cursor-pointer ${
                            isPlugged
                              ? 'bg-emerald-600 text-white shadow-2xs'
                              : 'bg-white hover:bg-emerald-50 text-emerald-800 border border-emerald-300'
                          }`}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{isPlugged ? (language === 'bn' ? 'নিয়ন্ত্রিত' : 'Controlled') : (language === 'bn' ? 'লিক বন্ধ করুন' : 'Plug Leak')}</span>
                        </button>
                      </div>

                      {/* Expanded Transaction Records Drawer */}
                      {isExpanded && (
                        <div className="border-t border-slate-200 bg-white p-3 divide-y divide-slate-100 animate-in fade-in duration-150">
                          <p className="text-[11px] font-bold text-slate-400 mb-2 px-1 uppercase tracking-wider">
                            {language === 'bn' ? 'যেসব খরচ যুক্ত আছে:' : 'Matched Transactions:'}
                          </p>
                          {matchedTxs.map(tx => (
                            <div key={tx.id} className="py-2 px-1 flex items-center justify-between text-xs">
                              <div>
                                <span className="font-semibold text-slate-800">{tx.note || 'Expense'}</span>
                                <span className="text-[10px] text-slate-400 block">{tx.date}</span>
                              </div>
                              <span className="font-bold text-rose-600">-{formatMoney(tx.amount)}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            )}
          </div>

          {/* Opportunity Cost Banner: "What You Could Have Bought" */}
          {analysis.totalYearlyLeak > 0 && (
            <div className="bg-slate-900 text-white rounded-3xl p-4 sm:p-5 border border-slate-800 space-y-2.5">
              <div className="flex items-center gap-2">
                <Award className="w-5 h-5 text-amber-400" />
                <h4 className="text-xs sm:text-sm font-bold text-white">
                  {language === 'bn' ? '💡 এই টাকা দিয়ে কী করা যেত?' : '💡 Equivalent Opportunity Value'}
                </h4>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {language === 'bn'
                  ? `আপনি যদি এই ছোট ছোট লিকগুলো নিয়ন্ত্রণ করেন, বছরে বেঁচে যাওয়া ৳${analysis.totalYearlyLeak.toLocaleString('bn-BD')} টাকা দিয়ে একটি সম্পূর্ণ নতুন সঞ্চয়পত্র/DPS শুরু করা যায় অথবা পরিবারের সাথে দারুণ একটি ট্যুর সম্পন্ন করা সম্ভব!`
                  : `By curtailing these micro-leaks, your saved ৳${analysis.totalYearlyLeak.toLocaleString()} yearly could fund a comprehensive DPS investment scheme or a memorable vacation trip!`}
              </p>
              <div className="pt-1 flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => {
                    onClose();
                    setActiveTab('challenges');
                  }}
                  className="px-3.5 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <Flame className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'নো-স্পেন্ড চ্যালেঞ্জ শুরু করুন' : 'Start No-Spend Challenge'}</span>
                </button>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/80 flex items-center justify-end shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
};
