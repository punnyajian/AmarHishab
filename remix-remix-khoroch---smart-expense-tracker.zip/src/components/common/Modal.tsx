import React from 'react';
import { X } from 'lucide-react';
import { useModalBehavior } from '../../utils/useModalBehavior';

export interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  title?: React.ReactNode;
  subtitle?: React.ReactNode;
  headerIcon?: React.ReactNode;
  headerActions?: React.ReactNode;
  children: React.ReactNode;
  footer?: React.ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl' | 'full';
  dismissible?: boolean;
  showCloseButton?: boolean;
  className?: string;
  bodyClassName?: string;
  role?: string;
  ariaLabel?: string;
}

const sizeClasses: Record<NonNullable<ModalProps['size']>, string> = {
  sm: 'max-w-sm',
  md: 'max-w-md',
  lg: 'max-w-lg',
  xl: 'max-w-xl',
  '2xl': 'max-w-2xl',
  '3xl': 'max-w-3xl',
  full: 'max-w-5xl',
};

export const Modal: React.FC<ModalProps> = ({
  isOpen,
  onClose,
  title,
  subtitle,
  headerIcon,
  headerActions,
  children,
  footer,
  size = 'lg',
  dismissible = true,
  showCloseButton = true,
  className = '',
  bodyClassName = '',
  role = 'dialog',
  ariaLabel,
}) => {
  useModalBehavior({ isOpen, onClose, dismissible });

  if (!isOpen) return null;

  const sizeClass = sizeClasses[size] || sizeClasses.lg;

  return (
    <div
      role={role}
      aria-modal="true"
      aria-label={typeof title === 'string' ? title : ariaLabel}
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-0 sm:p-4 bg-slate-900/60 backdrop-blur-xs overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget && dismissible) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
        }
      }}
    >
      <div
        className={`bg-white rounded-t-3xl sm:rounded-3xl w-full shadow-2xl border border-slate-100 flex flex-col max-h-[92dvh] sm:max-h-[88vh] overflow-hidden animate-in slide-in-from-bottom-4 sm:zoom-in-95 duration-200 pb-[calc(env(safe-area-inset-bottom,0px)+0.8rem)] sm:pb-0 ${sizeClass} ${className}`}
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {/* Mobile drag handle */}
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden mt-2.5 -mb-1 shrink-0" />

        {/* Modal Header (if title or close button) */}
        {(title || showCloseButton) && (
          <div className="flex items-center justify-between px-5 pt-3.5 pb-3 sm:px-6 sm:pt-5 border-b border-slate-100 shrink-0">
            <div className="flex items-center gap-3 min-w-0 pr-2">
              {headerIcon && <div className="shrink-0">{headerIcon}</div>}
              <div className="min-w-0">
                {title && (
                  <h2 className="text-base sm:text-lg font-bold text-slate-800 truncate leading-snug">
                    {title}
                  </h2>
                )}
                {subtitle && (
                  <p className="text-xs text-slate-400 truncate mt-0.5">
                    {subtitle}
                  </p>
                )}
              </div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              {headerActions}
              {showCloseButton && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    onClose();
                  }}
                  className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
                  aria-label="Close"
                >
                  <X className="w-5 h-5" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Modal Scrollable Body */}
        <div className={`flex-1 overflow-y-auto p-4 sm:p-6 overscroll-contain ${bodyClassName}`}>
          {children}
        </div>

        {/* Modal Footer (optional) */}
        {footer && (
          <div className="px-5 py-3 sm:px-6 sm:py-4 bg-slate-50/80 border-t border-slate-100 shrink-0 flex items-center justify-end gap-2.5">
            {footer}
          </div>
        )}
      </div>
    </div>
  );
};
