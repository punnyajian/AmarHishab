import React, { useState } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import {
  AlertTriangle,
  RotateCcw,
  Download,
  Trash2,
  X,
  CheckCircle2,
  ShieldAlert,
  ArrowRight,
  Sparkles,
} from 'lucide-react';

export const ResetConfirmModal: React.FC = () => {
  const {
    isResetModalOpen,
    setIsResetModalOpen,
    resetAll,
    exportJSON,
    setActiveTab,
    language,
    transactions,
    accounts,
  } = useExpense();

  useModalBehavior({
    isOpen: isResetModalOpen,
    onClose: () => setIsResetModalOpen(false),
  });

  const [isResetting, setIsResetting] = useState(false);
  const [hasExported, setHasExported] = useState(false);

  if (!isResetModalOpen) return null;

  const handleBackup = () => {
    exportJSON();
    setHasExported(true);
  };

  const handleExecuteReset = () => {
    setIsResetting(true);
    setTimeout(() => {
      resetAll();
      setIsResetting(false);
      setIsResetModalOpen(false);
      setActiveTab('dashboard');
    }, 250);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          setIsResetModalOpen(false);
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-lg shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[90dvh] overflow-y-auto"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        {/* Top Header with Warning Icon */}
        <div className="bg-gradient-to-br from-rose-500 via-rose-600 to-red-700 text-white p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-white/10 rounded-full blur-2xl pointer-events-none" />
          
          <div className="flex items-center justify-between relative z-10">
            <div className="w-12 h-12 rounded-2xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center text-white shadow-inner">
              <RotateCcw className="w-6 h-6 animate-spin-reverse" />
            </div>

            <button
              onClick={() => setIsResetModalOpen(false)}
              className="p-2 rounded-full text-white/80 hover:text-white hover:bg-white/20 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="mt-4 relative z-10 space-y-1">
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-bold tracking-wide uppercase">
              <AlertTriangle className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'সতর্কতা · এক ট্যাপে ডেটা রিসেট' : 'Danger Zone · One-Tap Reset'}</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              {language === 'bn' ? 'অ্যাপের সমস্ত ডেটা রিসেট করবেন?' : 'Reset All App Data?'}
            </h2>
            <p className="text-xs sm:text-sm text-rose-100 leading-relaxed">
              {language === 'bn'
                ? 'এক ট্যাপেই সমস্ত হিসাব মুছে অ্যাপ একদম নতুন ফ্রেশ অবস্থায় (০ ব্যালেন্সে) ফিরে যাবে।'
                : 'Instantly erase all records and return the app to a clean, fresh state.'}
            </p>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 space-y-4 text-xs text-slate-600">
          
          {/* Summary checklist of what will be reset */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-2.5">
            <span className="font-bold text-slate-800 uppercase tracking-wider text-[11px] block">
              {language === 'bn' ? 'যা যা মুছে সম্পূর্ণ খালি করা হবে:' : 'Items that will be cleared:'}
            </span>
            <ul className="space-y-2 text-slate-600">
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold shrink-0">✕</span>
                <span>
                  <strong>{language === 'bn' ? 'সকল লেনদেন:' : 'Transactions:'}</strong>{' '}
                  {language === 'bn' ? `বর্তমানে থাকা ${transactions.length}টি আয়/ব্যয় হিসাব মুছে যাবে` : `All ${transactions.length} recorded entries will be deleted`}
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold shrink-0">✕</span>
                <span>
                  <strong>{language === 'bn' ? 'অ্যাকাউন্ট ব্যালেন্স:' : 'Wallet Balances:'}</strong>{' '}
                  {language === 'bn' ? 'ক্যাশ, ব্যাংক, বিকাশ ও নগদ ব্যালেন্স ৳০-তে রিসেট হবে' : 'All account balances reset to 0'}
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold shrink-0">✕</span>
                <span>
                  <strong>{language === 'bn' ? 'বাজেট ও সেভিংস গোল:' : 'Budgets & Goals:'}</strong>{' '}
                  {language === 'bn' ? 'মাসিক বাজেট, সঞ্চয় লক্ষ্য, ঋণ ও উইশলিস্ট খালি হবে' : 'Budgets, savings goals, debts & wishlist reset'}
                </span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-rose-500 font-bold shrink-0">✕</span>
                <span>
                  <strong>{language === 'bn' ? 'মেস, ট্যুর ও ইনভেস্টমেন্ট:' : 'Mess, Trips & Investments:'}</strong>{' '}
                  {language === 'bn' ? 'মেস মিল শিট, ট্যুর বাজেট ও ডিপিএস পোর্টফোলিও খালি হবে' : 'Mess logs, trip records & investments erased'}
                </span>
              </li>
            </ul>
          </div>

          {/* Backup Download Helper Card */}
          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-center justify-between gap-3">
            <div className="space-y-0.5">
              <span className="font-bold text-emerald-900 text-xs flex items-center gap-1">
                <Download className="w-3.5 h-3.5 text-emerald-600" />
                <span>{language === 'bn' ? 'ডেটা ব্যাকআপ ডাউনলোড' : 'Download Backup File'}</span>
              </span>
              <p className="text-[11px] text-emerald-800/80">
                {language === 'bn'
                  ? 'রিসেট করার আগে এক ক্লিকে ব্যাকআপ JSON ফাইল ডাউনলোড করে রাখতে পারেন।'
                  : 'Save your current data as JSON before wiping.'}
              </p>
            </div>

            <button
              type="button"
              onClick={handleBackup}
              className={`px-3 py-1.5 rounded-xl font-bold text-xs shrink-0 transition-all cursor-pointer shadow-2xs ${
                hasExported
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white hover:bg-emerald-100 text-emerald-800 border border-emerald-300'
              }`}
            >
              {hasExported ? (
                <span className="flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'ডাউনলোড সম্পন্ন' : 'Downloaded'}</span>
                </span>
              ) : (
                <span>{language === 'bn' ? 'ব্যাকআপ নিন' : 'Export JSON'}</span>
              )}
            </button>
          </div>

          {/* Action Buttons */}
          <div className="pt-2 flex flex-col sm:flex-row items-center gap-2.5">
            <button
              type="button"
              disabled={isResetting}
              onClick={handleExecuteReset}
              className="w-full sm:flex-1 py-3 px-4 rounded-2xl bg-gradient-to-r from-rose-600 to-red-600 hover:from-rose-500 hover:to-red-500 text-white font-black text-xs sm:text-sm shadow-md shadow-rose-600/20 active:scale-95 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
            >
              <Trash2 className="w-4 h-4" />
              <span>
                {isResetting
                  ? (language === 'bn' ? 'রিসেট হচ্ছে...' : 'Resetting...')
                  : (language === 'bn' ? 'এক ট্যাপে সব ডেটা মুছুন' : 'One-Tap Reset Everything')}
              </span>
            </button>

            <button
              type="button"
              onClick={() => setIsResetModalOpen(false)}
              className="w-full sm:w-auto py-3 px-5 rounded-2xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
          </div>

        </div>
      </div>
    </div>
  );
};
