import React, { useMemo } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { analyzeMoneyLeaks } from '../utils/moneyLeakDetector';
import {
  Droplets,
  ChevronRight,
  Sparkles,
  ShieldCheck,
  TrendingDown,
  AlertCircle,
} from 'lucide-react';

interface MoneyLeakWidgetProps {
  onOpenDetails: () => void;
}

export const MoneyLeakWidget: React.FC<MoneyLeakWidgetProps> = ({ onOpenDetails }) => {
  const {
    transactions,
    categories,
    totalExpenseThisMonth,
    formatMoney,
    language,
  } = useExpense();

  // Run detection
  const analysis = useMemo(() => {
    return analyzeMoneyLeaks(transactions, categories, totalExpenseThisMonth, language);
  }, [transactions, categories, totalExpenseThisMonth, language]);

  const hasLeaks = analysis.detectedLeaksCount > 0;
  const topLeak = analysis.topLeak;

  return (
    <div
      onClick={onOpenDetails}
      className={`rounded-3xl p-5 shadow-xs border transition-all cursor-pointer hover:shadow-md group relative overflow-hidden ${
        hasLeaks
          ? 'bg-gradient-to-br from-slate-950 via-rose-950/70 to-slate-900 text-white border-rose-900/60 hover:border-rose-400'
          : 'bg-gradient-to-br from-slate-950 via-emerald-950/70 to-slate-900 text-white border-emerald-900/60 hover:border-emerald-400'
      }`}
    >
      {/* Background glow */}
      <div
        className={`absolute top-0 right-0 w-44 h-44 rounded-full blur-3xl pointer-events-none ${
          hasLeaks ? 'bg-rose-500/10' : 'bg-emerald-500/10'
        }`}
      />

      <div className="relative z-10 space-y-3.5">
        
        {/* Top Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform ${
                hasLeaks
                  ? 'bg-rose-500/20 text-rose-300 border border-rose-400/30'
                  : 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
              }`}
            >
              {hasLeaks ? <Droplets className="w-5 h-5 animate-pulse" /> : <ShieldCheck className="w-5 h-5" />}
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/10 text-slate-300 border border-white/10 inline-flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>{language === 'bn' ? 'মানি লিক ডিটেক্টর' : 'Money Leak Detector'}</span>
              </span>
              <h3 className="text-sm font-bold text-white group-hover:text-rose-200 transition-colors mt-0.5">
                {hasLeaks
                  ? (language === 'bn' ? 'ছোট খরচের গোপন অপচয়' : 'Silent Micro-Spending Leaks')
                  : (language === 'bn' ? 'নিখুঁত ব্যয় নিয়ন্ত্রণ' : 'Zero Money Leaks')}
              </h3>
            </div>
          </div>

          <div className="p-1.5 rounded-xl bg-white/10 group-hover:bg-white/20 transition-colors">
            <ChevronRight className="w-4 h-4 text-slate-300" />
          </div>
        </div>

        {/* Core Figure & Status */}
        {hasLeaks ? (
          <div className="space-y-1.5">
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-2xl sm:text-3xl font-black text-white tracking-tight">
                -{formatMoney(analysis.totalMonthlyLeak)}
                <span className="text-xs font-semibold text-rose-300 ml-1.5">/ {language === 'bn' ? 'মাস' : 'mo'}</span>
              </span>
              <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-rose-500/30 text-rose-200 border border-rose-400/30">
                {analysis.detectedLeaksCount} {language === 'bn' ? 'টি খাত' : 'leaks'}
              </span>
            </div>

            <p className="text-xs text-rose-200/90 leading-relaxed truncate">
              {language === 'bn' ? 'প্রধান লিক:' : 'Top leak:'}{' '}
              <strong className="text-white font-bold">{language === 'bn' ? topLeak?.titleBn : topLeak?.title}</strong>{' '}
              ({formatMoney(topLeak?.monthlyAmount || 0)})
            </p>

            {/* Projection strip */}
            <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-slate-300">
              <span>{language === 'bn' ? 'বছরে সম্ভাব্য অপচয়:' : 'Yearly compounding:'}</span>
              <span className="font-extrabold text-amber-300">{formatMoney(analysis.totalYearlyLeak)}</span>
            </div>
          </div>
        ) : (
          <div className="space-y-1.5">
            <div className="flex items-center gap-2">
              <span className="text-lg font-black text-emerald-300">
                {language === 'bn' ? 'কোনো গোপন অপচয় পাওয়া যায়নি' : 'No Leaks Detected'}
              </span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              {language === 'bn'
                ? 'আপনার ছোটখাটো খুচরা খরচে কোনো অস্বস্তিকর অপচয় চিহ্নিত হয়নি।'
                : 'Your micro-spending patterns are safe and disciplined.'}
            </p>
            <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px] text-emerald-300 font-semibold">
              <span>{language === 'bn' ? 'এআই অডিট স্ট্যাটাস:' : 'AI Audit Status:'}</span>
              <span>100% {language === 'bn' ? 'সুরক্ষিত' : 'Clean'}</span>
            </div>
          </div>
        )}

      </div>
    </div>
  );
};
