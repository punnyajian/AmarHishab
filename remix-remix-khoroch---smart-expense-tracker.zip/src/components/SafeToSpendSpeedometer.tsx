import React, { useState } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { SafeToSpendMode } from '../types';
import { 
  Gauge, 
  Settings2, 
  TrendingUp, 
  TrendingDown, 
  AlertCircle, 
  CheckCircle, 
  HelpCircle, 
  Calendar,
  Sparkles,
  ArrowRight,
  X,
} from 'lucide-react';
import { useModalBehavior } from '../utils/useModalBehavior';

export const SafeToSpendSpeedometer: React.FC = () => {
  const {
    todayExpense,
    todayDailySafeLimit,
    todayRemainingSafeToSpend,
    safeToSpendPercentUsed,
    safeToSpendStatus,
    daysRemainingInMonth,
    monthlySpendingCap,
    remainingMonthlyCap,
    projectedTomorrowSafeLimit,
    safeToSpendConfig,
    setSafeToSpendConfig,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const [isConfigOpen, setIsConfigOpen] = useState(false);

  useModalBehavior({ isOpen: isConfigOpen, onClose: () => setIsConfigOpen(false) });

  React.useEffect(() => {
    if (!isConfigOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setIsConfigOpen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isConfigOpen]);

  const [selectedMode, setSelectedMode] = useState<SafeToSpendMode>(safeToSpendConfig.mode);
  const [customCapInput, setCustomCapInput] = useState<string>(
    safeToSpendConfig.customMonthlyCap ? safeToSpendConfig.customMonthlyCap.toString() : '35000'
  );

  // SVG Gauge Math for a clean 180-degree semi-circle speedometer
  // Radius = 85, Center = (110, 100)
  const radius = 80;
  const cx = 110;
  const cy = 95;
  const circumference = Math.PI * radius; // Half-circle arc length ~ 251.3
  
  // Angle clamp: 0 to 180 degrees
  const clampedPercent = Math.min(100, Math.max(0, safeToSpendPercentUsed));
  // Needle angle in degrees: 0% -> -90deg (pointing left), 100% -> 90deg (pointing right)
  const needleAngle = -90 + (clampedPercent / 100) * 180;

  // Arc stroke offset
  const strokeDashoffset = circumference - (clampedPercent / 100) * circumference;

  const handleSaveConfig = (e: React.FormEvent) => {
    e.preventDefault();
    const cap = parseFloat(customCapInput);
    setSafeToSpendConfig({
      mode: selectedMode,
      customMonthlyCap: !isNaN(cap) && cap > 0 ? cap : 35000,
    });
    setIsConfigOpen(false);
  };

  const isOver = todayRemainingSafeToSpend < 0;

  return (
    <div className="bg-white border border-slate-200/90 rounded-3xl p-4 sm:p-6 shadow-xs relative overflow-hidden transition-all">
      {/* Background soft ambient tint */}
      <div 
        className={`absolute top-0 right-0 w-48 h-48 rounded-full blur-3xl pointer-events-none -mr-16 -mt-16 transition-colors duration-500 ${
          safeToSpendStatus === 'safe'
            ? 'bg-emerald-500/10'
            : safeToSpendStatus === 'caution'
            ? 'bg-amber-500/10'
            : 'bg-rose-500/10'
        }`}
      />

      {/* Header zone */}
      <div className="flex items-center justify-between relative z-10 pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2.5">
          <div 
            className={`w-9 h-9 rounded-xl flex items-center justify-center transition-colors ${
              safeToSpendStatus === 'safe'
                ? 'bg-emerald-50 text-emerald-700 border border-emerald-100'
                : safeToSpendStatus === 'caution'
                ? 'bg-amber-50 text-amber-700 border border-amber-100'
                : 'bg-rose-50 text-rose-700 border border-rose-100'
            }`}
          >
            <Gauge className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-extrabold text-slate-900 leading-tight">
                {language === 'bn' ? 'Safe-to-Spend স্পিডোমিটার' : 'Safe-to-Spend Speedometer'}
              </h2>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                {language === 'bn' ? 'দৈনিক লিমিট' : 'Daily Allowance'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              {language === 'bn' ? 'মাসের বাজেট ঠিক রাখতে আজকের নিরাপদ ব্যয়ের সীমা' : 'Calculated dynamic allowance for today'}
            </p>
          </div>
        </div>

        {/* Configure / Mode Toggle button */}
        <button
          onClick={() => setIsConfigOpen(true)}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 text-xs font-semibold transition-all active:scale-95"
          title={language === 'bn' ? 'হিসাব পদ্ধতি কনফিগার করুন' : 'Configure Limit Mode'}
        >
          <Settings2 className="w-3.5 h-3.5 text-slate-500" />
          <span className="hidden sm:inline">
            {safeToSpendConfig.mode === 'budget' 
              ? (language === 'bn' ? 'বাজেট ভিত্তিক' : 'Budget Mode')
              : safeToSpendConfig.mode === 'income'
              ? (language === 'bn' ? 'আয় ভিত্তিক' : 'Income Mode')
              : (language === 'bn' ? 'কাস্টম ক্যাপ' : 'Custom Cap')}
          </span>
        </button>
      </div>

      {/* Main Speedometer & Highlights Grid */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center pt-4 relative z-10">
        
        {/* Speedometer Radial Gauge Graphic (Col 1-5) */}
        <div className="md:col-span-5 flex flex-col items-center justify-center">
          <div className="relative w-[220px] h-[130px] flex items-end justify-center">
            <svg 
              viewBox="0 0 220 125" 
              className="w-full h-full overflow-visible"
              aria-label="Daily spending gauge"
            >
              {/* Definitions for gradient strokes */}
              <defs>
                <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                  <stop offset="0%" stopColor="#10b981" />
                  <stop offset="65%" stopColor="#34d399" />
                  <stop offset="80%" stopColor="#f59e0b" />
                  <stop offset="100%" stopColor="#f43f5e" />
                </linearGradient>
              </defs>

              {/* Background semi-circular track */}
              <path
                d={`M ${cx - radius} ${cy} A ${radius} ${radius} 0 0 1 ${cx + radius} ${cy}`}
                fill="none"
                stroke="#e2e8f0"
                strokeWidth="14"
                strokeLinecap="round"
              />

              {/* Active colored progress arc */}
              <path
                d={`M ${cx - radius} ${cy} A ${radius} ${radius} 0 0 1 ${cx + radius} ${cy}`}
                fill="none"
                stroke="url(#gaugeGradient)"
                strokeWidth="14"
                strokeLinecap="round"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                className="transition-all duration-700 ease-out"
              />

              {/* Ticks on gauge (0%, 50%, 100%) */}
              <circle cx={cx - radius} cy={cy} r="2" fill="#94a3b8" />
              <circle cx={cx} cy={cy - radius} r="2" fill="#94a3b8" />
              <circle cx={cx + radius} cy={cy} r="2" fill="#94a3b8" />

              {/* Center Needle Indicator */}
              <g 
                transform={`translate(${cx}, ${cy}) rotate(${needleAngle})`}
                className="transition-transform duration-700 ease-out origin-center"
              >
                <line
                  x1="0"
                  y1="0"
                  x2="0"
                  y2={-(radius - 12)}
                  stroke="#1e293b"
                  strokeWidth="3.5"
                  strokeLinecap="round"
                />
                <circle cx="0" cy="0" r="7" fill="#1e293b" />
                <circle cx="0" cy="0" r="3.5" fill="#ffffff" />
              </g>

              {/* Gauge End Labels */}
              <text x={cx - radius - 5} y={cy + 16} fontSize="10" fontWeight="bold" fill="#64748b" textAnchor="middle">
                0%
              </text>
              <text x={cx} y={cy - radius - 6} fontSize="9" fontWeight="semibold" fill="#94a3b8" textAnchor="middle">
                50%
              </text>
              <text x={cx + radius + 5} y={cy + 16} fontSize="10" fontWeight="bold" fill="#64748b" textAnchor="middle">
                100%
              </text>
            </svg>
          </div>

          {/* Status Capsule under gauge */}
          <div className="mt-1 flex items-center gap-1.5">
            {safeToSpendStatus === 'safe' && (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
                <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                {language === 'bn' ? 'নিরাপদ জোন (Safe Zone)' : 'Safe Zone'}
              </span>
            )}
            {safeToSpendStatus === 'caution' && (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-amber-800 bg-amber-50 border border-amber-200 px-3 py-1 rounded-full">
                <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
                {language === 'bn' ? 'সতর্ক জোন (Caution: >75%)' : 'Caution Zone (>75%)'}
              </span>
            )}
            {safeToSpendStatus === 'exceeded' && (
              <span className="inline-flex items-center gap-1 text-xs font-bold text-rose-800 bg-rose-50 border border-rose-200 px-3 py-1 rounded-full">
                <AlertCircle className="w-3.5 h-3.5 text-rose-600" />
                {language === 'bn' ? 'আজকের লিমিট পার হয়েছে!' : 'Daily Limit Exceeded!'}
              </span>
            )}
          </div>
        </div>

        {/* Speedometer Values & Breakdown (Col 6-12) */}
        <div className="md:col-span-7 space-y-3.5">
          
          {/* Big Focus Value: Remaining Allowance Today */}
          <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200/70">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500">
                {language === 'bn' ? 'আজকের অবশিষ্ট নিরাপদ খরচ' : 'Remaining Safe-to-Spend Today'}
              </span>
              <span className="text-[11px] font-mono font-bold text-slate-500 tabular-nums">
                {safeToSpendPercentUsed}% {language === 'bn' ? 'ব্যবহৃত' : 'used'}
              </span>
            </div>

            <div className="mt-1 flex items-baseline gap-2">
              <span 
                className={`text-2xl sm:text-3xl font-black font-mono tracking-tight tabular-nums ${
                  isOver ? 'text-rose-600' : 'text-slate-900'
                }`}
              >
                {formatMoney(Math.abs(todayRemainingSafeToSpend))}
              </span>
              {isOver && (
                <span className="text-xs font-bold text-rose-600">
                  ({language === 'bn' ? 'অতিরিক্ত খরচ!' : 'Over budget!'})
                </span>
              )}
            </div>

            {/* Quick Progress Bar for Today's Limit */}
            <div className="w-full bg-slate-200 rounded-full h-2 mt-2 overflow-hidden">
              <div 
                className={`h-2 rounded-full transition-all duration-500 ${
                  safeToSpendStatus === 'safe'
                    ? 'bg-emerald-600'
                    : safeToSpendStatus === 'caution'
                    ? 'bg-amber-500'
                    : 'bg-rose-600'
                }`}
                style={{ width: `${Math.min(100, safeToSpendPercentUsed)}%` }}
              />
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1.5">
              <span>{language === 'bn' ? 'আজ খরচ:' : 'Spent today:'} <strong className="font-mono text-slate-700">{formatMoney(todayExpense)}</strong></span>
              <span>{language === 'bn' ? 'দৈনিক বরাদ্দ:' : 'Daily cap:'} <strong className="font-mono text-slate-700">{formatMoney(todayDailySafeLimit)}</strong></span>
            </div>
          </div>

          {/* Key 3-Stat Strip: Remaining Days, Monthly Cap, Tomorrow's Forecast */}
          <div className="grid grid-cols-3 gap-2 text-center">
            
            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                {language === 'bn' ? 'মাসের বাকি' : 'Days Left'}
              </div>
              <div className="text-sm sm:text-base font-extrabold font-mono text-slate-800 mt-0.5 tabular-nums">
                {daysRemainingInMonth} {language === 'bn' ? 'দিন' : 'days'}
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100">
              <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                {language === 'bn' ? 'মাসিক বাকি' : 'Monthly Left'}
              </div>
              <div className="text-sm sm:text-base font-extrabold font-mono text-slate-800 mt-0.5 tabular-nums truncate">
                {formatMoney(Math.max(0, remainingMonthlyCap))}
              </div>
            </div>

            <div className="p-2.5 rounded-xl bg-indigo-50/70 border border-indigo-100/80">
              <div className="text-[10px] text-indigo-700 font-bold uppercase tracking-wider">
                {language === 'bn' ? 'কালকের পূর্বাভাস' : 'Tomorrow'}
              </div>
              <div className="text-sm sm:text-base font-extrabold font-mono text-indigo-900 mt-0.5 tabular-nums truncate">
                {formatMoney(projectedTomorrowSafeLimit)}
              </div>
            </div>

          </div>

          {/* Dynamic Smart Insight Tip */}
          <div className="flex items-start gap-2 text-xs text-slate-600 bg-emerald-50/50 border border-emerald-100 rounded-xl p-2.5">
            <Sparkles className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <p className="leading-snug">
              {isOver ? (
                language === 'bn' ? (
                  <>
                    আজকের বরাদ্দ ছাড়িয়ে যাওয়ায় আগামী দিনগুলোর গড় দৈনিক লিমিট <strong className="font-mono text-rose-700">{formatMoney(projectedTomorrowSafeLimit)}</strong> টাকায় পুনর্নির্ধারণ করা হয়েছে।
                  </>
                ) : (
                  <>
                    Because today's limit was exceeded, tomorrow's daily allowance is automatically adjusted to <strong className="font-mono text-rose-700">{formatMoney(projectedTomorrowSafeLimit)}</strong>.
                  </>
                )
              ) : (
                language === 'bn' ? (
                  <>
                    আজকের বাকি <strong className="font-mono text-emerald-700">{formatMoney(todayRemainingSafeToSpend)}</strong> টাকা খরচ না করলে, আগামীকালের নিরাপদ বরাদ্দ বৃদ্ধি পেয়ে <strong className="font-mono text-emerald-700">{formatMoney(projectedTomorrowSafeLimit)}</strong> টাকায় দাঁড়াবে!
                  </>
                ) : (
                  <>
                    If you don't spend the remaining <strong className="font-mono text-emerald-700">{formatMoney(todayRemainingSafeToSpend)}</strong> today, tomorrow's safe allowance increases to <strong className="font-mono text-emerald-700">{formatMoney(projectedTomorrowSafeLimit)}</strong>!
                  </>
                )
              )}
            </p>
          </div>

        </div>

      </div>

      {/* Configuration Modal */}
      {isConfigOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsConfigOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div
            className="bg-white rounded-3xl max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 animate-in zoom-in-95 duration-200 border border-slate-200 max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-slate-100 text-slate-700 flex items-center justify-center">
                  <Settings2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {language === 'bn' ? 'Safe-to-Spend কনফিগারেশন' : 'Safe-to-Spend Configuration'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? 'দৈনিক লিমিট গণনার ভিত্তি নির্বাচন করুন' : 'Select basis for daily allowance'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsConfigOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveConfig} className="space-y-4">
              <div className="space-y-2">
                <label className="block text-xs font-bold text-slate-700">
                  {language === 'bn' ? 'গণনার মোড (Calculation Basis)' : 'Calculation Mode'}
                </label>

                {/* Mode 1: Category Budget Plan */}
                <label 
                  className={`flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedMode === 'budget' 
                      ? 'border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/20' 
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="mode"
                    value="budget"
                    checked={selectedMode === 'budget'}
                    onChange={() => setSelectedMode('budget')}
                    className="mt-1 accent-emerald-600"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      {language === 'bn' ? '১. মাসিক ক্যাটাগরি বাজেট প্ল্যান (সুপারিশকৃত)' : '1. Monthly Category Budget Plan (Recommended)'}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {language === 'bn'
                        ? 'আপনার নির্ধারিত মোট ক্যাটাগরি বাজেট থেকে খরচ বাদ দিয়ে বাকি দিনগুলোতে ভাগ করবে।'
                        : 'Divides remaining category budget limit over remaining days.'}
                    </p>
                  </div>
                </label>

                {/* Mode 2: Net Monthly Income */}
                <label 
                  className={`flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedMode === 'income' 
                      ? 'border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/20' 
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="mode"
                    value="income"
                    checked={selectedMode === 'income'}
                    onChange={() => setSelectedMode('income')}
                    className="mt-1 accent-emerald-600"
                  />
                  <div>
                    <div className="text-xs font-bold text-slate-900">
                      {language === 'bn' ? '২. চলতি মাসের মোট আয় (Income Basis)' : '2. Total Current Month Income'}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {language === 'bn'
                        ? 'এ মাসের মোট উপার্জিত আয়কে সিলিং ধরে প্রতিদিনের নিরাপদ সীমা নির্ধারণ করবে।'
                        : 'Uses total income earned this month as the spending ceiling.'}
                    </p>
                  </div>
                </label>

                {/* Mode 3: Custom Monthly Cap */}
                <label 
                  className={`flex items-start gap-3 p-3 rounded-2xl border cursor-pointer transition-all ${
                    selectedMode === 'custom' 
                      ? 'border-emerald-500 bg-emerald-50/50 ring-2 ring-emerald-500/20' 
                      : 'border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <input
                    type="radio"
                    name="mode"
                    value="custom"
                    checked={selectedMode === 'custom'}
                    onChange={() => setSelectedMode('custom')}
                    className="mt-1 accent-emerald-600"
                  />
                  <div className="w-full">
                    <div className="text-xs font-bold text-slate-900">
                      {language === 'bn' ? '৩. কাস্টম মাসিক খরচের সিলিং (Custom Monthly Cap)' : '3. Custom Monthly Spending Cap'}
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      {language === 'bn'
                        ? 'আপনার ইচ্ছামতো নির্দিষ্ট একটি মাসিক সর্বোচ্চ খরচের লক্ষ্য সেট করুন।'
                        : 'Set a custom total monthly spending limit.'}
                    </p>

                    {selectedMode === 'custom' && (
                      <div className="mt-2 relative">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-xs">
                          {currency.symbol}
                        </span>
                        <input
                          type="number"
                          value={customCapInput}
                          onChange={e => setCustomCapInput(e.target.value)}
                          placeholder="35000"
                          className="w-full pl-7 pr-3 py-1.5 text-xs font-mono font-bold bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-emerald-500 tabular-nums"
                        />
                      </div>
                    )}
                  </div>
                </label>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsConfigOpen(false)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs active:scale-95"
                >
                  {language === 'bn' ? 'সেভ করুন' : 'Save Changes'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
