import React from 'react';
import { useExpense } from '../context/ExpenseContext';
import {
  Scale,
  Sparkles,
  ChevronRight,
  ShieldCheck,
  Coins,
  Clock,
} from 'lucide-react';

interface CanIAffordThisWidgetProps {
  onOpen: () => void;
}

export const CanIAffordThisWidget: React.FC<CanIAffordThisWidgetProps> = ({ onOpen }) => {
  const { language, totalBalance, formatMoney } = useExpense();

  return (
    <div
      onClick={onOpen}
      className="bg-gradient-to-br from-slate-950 via-teal-950/80 to-slate-900 text-white rounded-3xl p-5 shadow-xs border border-teal-800/50 hover:border-teal-400 cursor-pointer transition-all hover:shadow-md group relative overflow-hidden"
    >
      {/* Glow */}
      <div className="absolute top-0 right-0 w-48 h-48 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

      <div className="relative z-10 space-y-3.5">
        
        {/* Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-teal-500/20 text-teal-300 border border-teal-400/30 flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform">
              <Scale className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/10 text-slate-300 border border-white/10 inline-flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-300" />
                <span>{language === 'bn' ? 'ক্রয় সামর্থ্য যাচাই' : 'Affordability Test'}</span>
              </span>
              <h3 className="text-sm font-bold text-white group-hover:text-teal-200 transition-colors mt-0.5">
                {language === 'bn' ? '“আমি কি এটা কিনতে পারি?”' : '“Can I Afford This?”'}
              </h3>
            </div>
          </div>

          <div className="p-1.5 rounded-xl bg-white/10 group-hover:bg-white/20 transition-colors">
            <ChevronRight className="w-4 h-4 text-slate-300" />
          </div>
        </div>

        {/* Content Teaser */}
        <p className="text-xs text-slate-300 leading-relaxed">
          {language === 'bn'
            ? 'নতুন ফোন, গ্যাজেট বা শখের কেনাকাটার আগে দেখুন এতে আপনার কত দিনের পরিশ্রম খরচ হবে এবং রিজার্ভ নিরাপদ থাকবে কিনা।'
            : 'Check if you can safely afford that new gadget or splurge without risking cash reserves.'}
        </p>

        {/* Metrics strip */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between text-[11px]">
          <span className="text-slate-400">
            {language === 'bn' ? 'বর্তমান মোট ব্যালেন্স:' : 'Current Balance:'}{' '}
            <strong className="text-white">{formatMoney(totalBalance)}</strong>
          </span>
          <span className="text-teal-300 font-bold flex items-center gap-1 group-hover:translate-x-0.5 transition-transform">
            <span>{language === 'bn' ? 'টেস্ট করুন' : 'Test Now'}</span>
            <ChevronRight className="w-3.5 h-3.5" />
          </span>
        </div>

      </div>
    </div>
  );
};
