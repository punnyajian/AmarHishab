import React from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { useExpense } from '../context/ExpenseContext';
import { WifiOff, HardDriveDownload } from 'lucide-react';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const { language } = useExpense();
  const isBn = language === 'bn';

  if (isOnline) return null;

  return (
    <div className="fixed bottom-20 sm:bottom-6 left-4 right-4 sm:right-auto sm:left-6 z-50 animate-fade-in no-print">
      <div className="flex items-center gap-3 bg-slate-900/90 text-white backdrop-blur-md px-4 py-2.5 rounded-2xl shadow-xl border border-slate-700/80 max-w-md">
        <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center shrink-0">
          <WifiOff className="w-4 h-4 animate-pulse" />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-white">
              {isBn ? 'অফলাইন মোড সক্রিয়' : 'Offline Mode Active'}
            </span>
            <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping" />
          </div>
          <p className="text-[11px] text-slate-300 truncate">
            {isBn
              ? 'ক্যাশড সম্পদ ও লোকাল ডাটা ব্যবহার হচ্ছে। হিসাব সংরক্ষণ অব্যাহত থাকবে।'
              : 'Using Workbox cached assets. Your records remain safe offline.'}
          </p>
        </div>
        <div className="hidden sm:flex items-center gap-1 text-[10px] text-emerald-400 font-semibold px-2 py-0.5 rounded-md bg-emerald-500/10 border border-emerald-500/20">
          <HardDriveDownload className="w-3 h-3" />
          <span>Cached</span>
        </div>
      </div>
    </div>
  );
};
