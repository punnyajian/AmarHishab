import React, { useState, useEffect } from 'react';
import { SubscriptionBill } from '../types';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import {
  X,
  CheckCircle2,
  Calendar,
  CreditCard,
  Building2,
  Smartphone,
  Banknote,
  Receipt,
  AlertCircle,
  Zap,
  ArrowRight,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PayBillModalProps {
  bill: SubscriptionBill | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PayBillModal: React.FC<PayBillModalProps> = ({ bill, isOpen, onClose }) => {
  useModalBehavior({ isOpen, onClose });

  const { accounts, digitalCards, paySubscriptionBill, formatMoney, language, currency } = useExpense();

  const [selectedAccountId, setSelectedAccountId] = useState('');
  const [selectedCardId, setSelectedCardId] = useState('');
  const [amount, setAmount] = useState('');
  const [date, setDate] = useState('');
  const [note, setNote] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (bill && isOpen) {
      setSelectedAccountId(bill.accountId || accounts[0]?.id || '');
      setSelectedCardId(bill.cardId || '');
      setAmount(bill.amount.toString());
      setDate(new Date().toISOString().split('T')[0]);
      setNote(
        bill.subscriberIdOrMeterNo
          ? `${bill.name} (আইডি: ${bill.subscriberIdOrMeterNo}) বিল পরিশোধ`
          : `${bill.name} পরিশোধ`
      );
      setIsSuccess(false);
      setErrorMsg('');
    }
  }, [bill, isOpen, accounts]);

  if (!isOpen || !bill) return null;

  const playSuccessChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      // Note 1: C5 (523Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(523.25, now);
      gain1.gain.setValueAtTime(0.12, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.18);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.2);

      // Note 2: G5 (783Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(783.99, now + 0.12);
      gain2.gain.setValueAtTime(0.15, now + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.38);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.12);
      osc2.stop(now + 0.4);
    } catch {
      // Audio not supported or blocked
    }
  };

  const handlePay = (e: React.FormEvent) => {
    e.preventDefault();
    const payNum = parseFloat(amount);
    if (isNaN(payNum) || payNum <= 0) {
      setErrorMsg(language === 'bn' ? 'সঠিক টাকার অঙ্ক লিখুন।' : 'Please enter a valid amount.');
      return;
    }

    const selectedAcc = accounts.find(a => a.id === selectedAccountId);
    if (selectedAcc && selectedAcc.balance < payNum && selectedAcc.type !== 'credit_card') {
      setErrorMsg(
        language === 'bn'
          ? `অপর্যাপ্ত ব্যালেন্স! ${selectedAcc.nameBn || selectedAcc.name}-এ আছে ${formatMoney(selectedAcc.balance)}`
          : `Insufficient balance! ${selectedAcc.name} only has ${formatMoney(selectedAcc.balance)}`
      );
      return;
    }

    const res = paySubscriptionBill(
      bill.id,
      selectedAccountId,
      selectedCardId || undefined,
      date,
      payNum,
      note
    );

    if (res.success) {
      playSuccessChime();
      confetti({
        particleCount: 50,
        spread: 60,
        origin: { y: 0.65 },
        colors: ['#10b981', '#3b82f6', '#f59e0b', '#06b6d4'],
      });
      setIsSuccess(true);
      setTimeout(() => {
        onClose();
      }, 1600);
    } else {
      setErrorMsg(res.message);
    }
  };

  const getAccountIcon = (type: string) => {
    switch (type) {
      case 'bank':
        return Building2;
      case 'mobile_wallet':
        return Smartphone;
      case 'credit_card':
        return CreditCard;
      default:
        return Banknote;
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-md overflow-y-auto overscroll-contain animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="relative w-full max-w-lg bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden flex flex-col max-h-[92dvh] sm:max-h-[88vh]"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative px-5 py-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-md flex items-center justify-center text-white">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base font-black tracking-tight">
                {language === 'bn' ? 'বিল পরিশোধ করুন' : 'Pay Subscription / Bill'}
              </h2>
              <p className="text-xs text-emerald-100 truncate max-w-[240px] sm:max-w-xs">
                {bill.name} {bill.providerName ? `· ${bill.providerName}` : ''}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full hover:bg-white/20 transition-colors text-white/90 active:scale-90"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        {isSuccess ? (
          <div className="p-8 text-center space-y-4">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 mx-auto flex items-center justify-center animate-bounce">
              <CheckCircle2 className="w-10 h-10" />
            </div>
            <div>
              <h3 className="text-lg font-black text-slate-900">
                {language === 'bn' ? 'বিল পরিশোধ সফল হয়েছে!' : 'Payment Recorded Successfully!'}
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                {formatMoney(parseFloat(amount) || bill.amount)} {language === 'bn' ? 'খরচে যুক্ত হয়েছে ও পরবর্তী বিলের তারিখ হালনাগাদ করা হয়েছে।' : 'has been deducted and next billing cycle updated.'}
              </p>
            </div>
          </div>
        ) : (
          <form onSubmit={handlePay} className="p-5 overflow-y-auto space-y-4">
            {errorMsg && (
              <div className="p-3 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0 text-rose-500" />
                <span>{errorMsg}</span>
              </div>
            )}

            {/* Bill Overview Banner */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-400">
                  {language === 'bn' ? 'বিল তথ্য' : 'Bill Details'}
                </span>
                <p className="text-sm font-extrabold text-slate-800">{bill.name}</p>
                {bill.subscriberIdOrMeterNo && (
                  <p className="text-xs text-slate-500 font-mono">
                    {language === 'bn' ? 'আইডি/মিটার:' : 'ID/Meter:'} {bill.subscriberIdOrMeterNo}
                  </p>
                )}
              </div>
              <div className="text-right">
                <span className="text-[10px] font-bold text-slate-400">
                  {language === 'bn' ? 'ধার্য পরিমাণ' : 'Standard'}
                </span>
                <p className="text-sm font-black text-slate-900">{formatMoney(bill.amount)}</p>
              </div>
            </div>

            {/* Amount input */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'পরিশোধের টাকার অঙ্ক' : 'Payment Amount'} ({currency.symbol})
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                  {currency.symbol}
                </span>
                <input
                  type="number"
                  step="any"
                  value={amount}
                  onChange={e => setAmount(e.target.value)}
                  placeholder="0.00"
                  required
                  className="w-full pl-9 pr-4 py-2.5 bg-white border border-slate-200 rounded-2xl text-base font-extrabold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
              <span className="text-[10px] text-slate-400 mt-1 block">
                {language === 'bn'
                  ? '*মিটার রিডিং বা ভ্যাট অনুযায়ী অঙ্ক পরিবর্তন করতে পারেন।'
                  : '*You can adjust the amount for variable bills like electricity/water.'}
              </span>
            </div>

            {/* Payment Account */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                {language === 'bn' ? 'যে অ্যাকাউন্ট থেকে কাটবে' : 'Pay From Account'}
              </label>
              <div className="grid grid-cols-2 gap-2 max-h-36 overflow-y-auto">
                {accounts.map(acc => {
                  const AccIcon = getAccountIcon(acc.type);
                  const isSelected = selectedAccountId === acc.id;
                  return (
                    <button
                      key={acc.id}
                      type="button"
                      onClick={() => setSelectedAccountId(acc.id)}
                      className={`p-2.5 rounded-2xl border text-left transition-all flex items-center gap-2.5 ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50/80 ring-2 ring-emerald-500/20'
                          : 'border-slate-200 hover:bg-slate-50'
                      }`}
                    >
                      <div
                        className="w-7 h-7 rounded-xl flex items-center justify-center text-white shrink-0 text-xs font-bold"
                        style={{ backgroundColor: acc.color }}
                      >
                        <AccIcon className="w-3.5 h-3.5" />
                      </div>
                      <div className="min-w-0">
                        <div className="text-xs font-bold text-slate-800 truncate">
                          {language === 'bn' ? acc.nameBn || acc.name : acc.name}
                        </div>
                        <div className="text-[10px] text-slate-500 font-semibold truncate">
                          {formatMoney(acc.balance)}
                        </div>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Linked Google Wallet Card (Optional) */}
            {digitalCards.length > 0 && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'Google Wallet কার্ড ট্যাগ (ঐচ্ছিক)' : 'Google Wallet Card Tag (Optional)'}
                </label>
                <select
                  value={selectedCardId}
                  onChange={e => setSelectedCardId(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                >
                  <option value="">{language === 'bn' ? 'কোনো কার্ড ছাড়া' : 'None / Not Paid by Card'}</option>
                  {digitalCards.map(c => (
                    <option key={c.id} value={c.id}>
                      💳 {c.issuerName} (•••• {c.last4})
                    </option>
                  ))}
                </select>
              </div>
            )}

            {/* Date and Note */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                  <Calendar className="w-3.5 h-3.5 text-slate-400" />
                  <span>{language === 'bn' ? 'পরিশোধের তারিখ' : 'Payment Date'}</span>
                </label>
                <input
                  type="date"
                  value={date}
                  onChange={e => setDate(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'রসিদ / ট্রানজেকশন আইডি' : 'Receipt / TrxID'}
                </label>
                <input
                  type="text"
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  placeholder="e.g. TrxID: 9X29A"
                  className="w-full px-3 py-2 bg-white border border-slate-200 rounded-2xl text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>

            {/* Submit Buttons */}
            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-2xl border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50 transition-colors"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-extrabold shadow-sm flex items-center gap-2 active:scale-95 transition-all"
              >
                <span>{language === 'bn' ? 'পরিশোধ নিশ্চিত করুন' : 'Confirm Payment'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
