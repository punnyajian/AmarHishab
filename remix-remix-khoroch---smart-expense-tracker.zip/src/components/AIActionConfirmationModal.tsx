import React from 'react';
import { AIActionProposal } from '../types';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { AlertTriangle, Check, X, ShieldAlert, Sparkles, ArrowRight } from 'lucide-react';

interface AIActionConfirmationModalProps {
  proposal: AIActionProposal | null;
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (proposal: AIActionProposal) => void;
}

export const AIActionConfirmationModal: React.FC<AIActionConfirmationModalProps> = ({
  proposal,
  isOpen,
  onClose,
  onConfirm,
}) => {
  useModalBehavior({ isOpen, onClose });

  const { language } = useExpense();
  const isBn = language === 'bn';

  if (!isOpen || !proposal) return null;

  const isCritical = proposal.severity === 'critical';
  const isWarning = proposal.severity === 'warning';

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-emerald-100 p-6 space-y-5 animate-in zoom-in-95 duration-150 max-h-[90dvh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        
        {/* Header with Shield / AI Icon */}
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-center gap-3">
            <div
              className={`w-12 h-12 rounded-2xl flex items-center justify-center shadow-xs shrink-0 ${
                isCritical
                  ? 'bg-rose-100 text-rose-700'
                  : isWarning
                  ? 'bg-amber-100 text-amber-800'
                  : 'bg-emerald-100 text-emerald-800'
              }`}
            >
              {isCritical ? (
                <ShieldAlert className="w-6 h-6 animate-pulse" />
              ) : isWarning ? (
                <AlertTriangle className="w-6 h-6" />
              ) : (
                <Sparkles className="w-6 h-6 text-emerald-600" />
              )}
            </div>
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                {isBn ? 'এআই স্বয়ংক্রিয় অ্যাকশন প্রটোকল' : 'AI Action Protocol'}
              </span>
              <h3 className="text-base sm:text-lg font-black text-slate-900 mt-1">
                {isBn ? 'এআই এই পরিবর্তনটি করতে চাচ্ছে' : 'AI wants to perform this action'}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Structured Spec Card (As requested in User Prompt) */}
        <div className="bg-slate-50 rounded-2xl p-4.5 border border-slate-200/80 space-y-3 text-xs sm:text-sm">
          <div className="flex items-start justify-between gap-2 pb-2.5 border-b border-slate-200/70">
            <span className="font-bold text-slate-500">{isBn ? 'অ্যাকশন:' : 'Action:'}</span>
            <span className="font-extrabold text-slate-900 text-right">
              {isBn ? proposal.titleBn || proposal.title : proposal.title}
            </span>
          </div>

          {proposal.currentValue && (
            <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-200/70">
              <span className="font-semibold text-slate-500">{isBn ? 'বর্তমান মান:' : 'Current:'}</span>
              <span className="font-bold text-slate-600">{proposal.currentValue}</span>
            </div>
          )}

          <div className="flex items-center justify-between gap-2 pb-2.5 border-b border-slate-200/70">
            <span className="font-semibold text-slate-500">{isBn ? 'নতুন প্রস্তাবিত মান:' : 'New:'}</span>
            <span className="font-black text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
              {proposal.newValue}
            </span>
          </div>

          <div className="space-y-1 pt-0.5">
            <span className="font-semibold text-slate-500 block">{isBn ? 'কারণ (Reason):' : 'Reason:'}</span>
            <p className="text-slate-800 font-medium leading-relaxed bg-white p-2.5 rounded-xl border border-slate-200/60">
              {isBn ? proposal.reasonBn || proposal.reason : proposal.reason}
            </p>
          </div>
        </div>

        {/* Security & Explicit Confirmation Note */}
        <p className="text-[11px] text-slate-500 italic leading-snug">
          🔒 {isBn
            ? 'আপনার সুস্পষ্ট অনুমতি ছাড়া কোনো স্থায়ী পরিবর্তন বা ট্রানজ্যাকশন সম্পন্ন হবে না।'
            : 'No permanent change or transaction will be executed without your explicit permission.'}
        </p>

        {/* Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm font-bold text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
          >
            {isBn ? 'বাতিল (Cancel)' : 'Cancel'}
          </button>

          <button
            type="button"
            onClick={() => onConfirm(proposal)}
            className="inline-flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white text-xs sm:text-sm font-bold shadow-xs transition-all cursor-pointer"
          >
            <Check className="w-4 h-4 stroke-[2.5]" />
            <span>{isBn ? 'নিশ্চিত করুন (Confirm)' : 'Confirm'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
