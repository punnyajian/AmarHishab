import React from 'react';
import * as LucideIcons from 'lucide-react';

interface CategoryIconProps {
  iconName: string;
  className?: string;
  size?: number;
}

export const CategoryIcon: React.FC<CategoryIconProps> = ({ iconName, className = 'w-5 h-5', size = 20 }) => {
  // Safe lookup for lucide icons
  const IconComponent = (LucideIcons as any)[iconName] || LucideIcons.CircleDot;
  return <IconComponent className={className} size={size} />;
};
