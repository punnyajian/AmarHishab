import React, { useState, useMemo } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useModalBehavior } from '../../utils/useModalBehavior';
import { WhatIfSimulationInput } from '../../types/paymentPriority';
import {
  X,
  Play,
  RotateCcw,
  Sparkles,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ShieldCheck,
  CreditCard,
  DollarSign,
  ArrowRight,
  Layers,
  Clock,
} from 'lucide-react';

interface WhatIfSimulatorModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const WhatIfSimulatorModal: React.FC<WhatIfSimulatorModalProps> = ({
  isOpen,
  onClose,
}) => {
  useModalBehavior({ isOpen, onClose });

  const {
    cashFlowAnalysis,
    runSimulation,
    formatMoney,
    currency,
    language,
  } = useExpense();

  // State for What-If scenario parameters
  const [fundsOverride, setFundsOverride] = useState<string>('');
  const [payCreditCardFirst, setPayCreditCardFirst] = useState(false);
  const [payOnlyMinimums, setPayOnlyMinimums] = useState(false);
  const [delayNonEssentialsDays, setDelayNonEssentialsDays] = useState(0);
  const [salaryDelayDays, setSalaryDelayDays] = useState(0);
  const [extraDebtAmount, setExtraDebtAmount] = useState<string>('');

  // Default initial simulation
  const simulationInput: WhatIfSimulationInput = useMemo(() => {
    const parsedFunds = parseFloat(fundsOverride);
    const parsedExtra = parseFloat(extraDebtAmount);
    return {
      availableFundsOverride: !isNaN(parsedFunds) && parsedFunds >= 0 ? parsedFunds : null,
      salaryDelayDays,
      payCreditCardFirst,
      payOnlyMinimums,
      delayNonEssentialsDays,
      extraDebtPaymentAmount: !isNaN(parsedExtra) && parsedExtra > 0 ? parsedExtra : 0,
    };
  }, [fundsOverride, salaryDelayDays, payCreditCardFirst, payOnlyMinimums, delayNonEssentialsDays, extraDebtAmount]);

  const simResult = useMemo(() => {
    return runSimulation(simulationInput);
  }, [runSimulation, simulationInput]);

  if (!isOpen) return null;

  // Preset Scenario Handlers
  const applyPreset = (preset: 'credit_card_first' | 'min_only' | 'delay_subs' | 'salary_delay' | 'tight_cash' | 'extra_debt') => {
    switch (preset) {
      case 'credit_card_first':
        setPayCreditCardFirst(true);
        setPayOnlyMinimums(false);
        break;
      case 'min_only':
        setPayOnlyMinimums(true);
        setPayCreditCardFirst(false);
        break;
      case 'delay_subs':
        setDelayNonEssentialsDays(7);
        break;
      case 'salary_delay':
        setSalaryDelayDays(3);
        break;
      case 'tight_cash':
        setFundsOverride('5000');
        break;
      case 'extra_debt':
        setExtraDebtAmount('2000');
        break;
    }
  };

  const handleReset = () => {
    setFundsOverride('');
    setPayCreditCardFirst(false);
    setPayOnlyMinimums(false);
    setDelayNonEssentialsDays(0);
    setSalaryDelayDays(0);
    setExtraDebtAmount('');
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-50/70 to-teal-50/30">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-base font-black text-slate-800">
                  {language === 'bn' ? 'হোয়াট-ইফ পেমেন্ট সিমুলেটর' : 'What-If Payment Simulator'}
                </h3>
                <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  Sandbox Mode
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                {language === 'bn'
                  ? 'প্রকৃত কোনো লেনদেন পরিবর্তন না করে বিভিন্ন পেমেন্ট কৌশলের প্রভাব পরীক্ষা করুন।'
                  : 'Simulate financial outcomes without altering real transactions.'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-white rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm">
          {/* Quick Presets Carousel */}
          <div>
            <p className="text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">
              {language === 'bn' ? 'দ্রুত দৃশ্যপট নির্বাচন (Quick Scenarios)' : 'Select Instant Scenarios'}
            </p>
            <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
              <button
                type="button"
                onClick={() => applyPreset('credit_card_first')}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                  payCreditCardFirst
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                💳 {language === 'bn' ? 'আগে ক্রেডিট কার্ড দিলে?' : 'Pay Credit Card First'}
              </button>
              <button
                type="button"
                onClick={() => applyPreset('min_only')}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                  payOnlyMinimums
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                🛡️ {language === 'bn' ? 'শুধুমাত্র ন্যূনতম দিলে?' : 'Pay Minimums Only'}
              </button>
              <button
                type="button"
                onClick={() => applyPreset('tight_cash')}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                  fundsOverride === '5000'
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                💰 {language === 'bn' ? 'হাতে মাত্র ৳৫,০০০ থাকলে?' : 'Only ৳5,000 Available'}
              </button>
              <button
                type="button"
                onClick={() => applyPreset('delay_subs')}
                className={`px-3 py-1.5 rounded-xl border text-xs font-bold shrink-0 transition-colors cursor-pointer ${
                  delayNonEssentialsDays > 0
                    ? 'bg-emerald-600 text-white border-emerald-600'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                }`}
              >
                ⏸️ {language === 'bn' ? 'সাবস্ক্রিপশন ৭ দিন পিছিয়ে দিলে?' : 'Delay Non-Essentials'}
              </button>
            </div>
          </div>

          {/* Scenario Controls Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 p-4 rounded-2xl bg-slate-50 border border-slate-100">
            {/* Custom Funds Override */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'হাতে থাকা ব্যালেন্স টেস্ট করুন' : 'Test Available Balance'}
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2 text-xs font-black text-slate-400">
                  {currency.symbol}
                </span>
                <input
                  type="number"
                  placeholder={cashFlowAnalysis.availableBalance.toString()}
                  value={fundsOverride}
                  onChange={(e) => setFundsOverride(e.target.value)}
                  className="w-full pl-7 pr-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold bg-white"
                />
              </div>
            </div>

            {/* Delay Non-essentials */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'ঐচ্ছিক ব্যয় কতদিন পেছাবেন?' : 'Delay Non-Essentials'}
              </label>
              <select
                value={delayNonEssentialsDays}
                onChange={(e) => setDelayNonEssentialsDays(parseInt(e.target.value) || 0)}
                className="w-full px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-bold bg-white"
              >
                <option value="0">{language === 'bn' ? 'যথাসময়ে রাখুন' : 'No delay'}</option>
                <option value="3">+3 {language === 'bn' ? 'দিন' : 'days'}</option>
                <option value="7">+7 {language === 'bn' ? 'দিন' : 'days'}</option>
                <option value="14">+14 {language === 'bn' ? 'দিন' : 'days'}</option>
              </select>
            </div>

            {/* Toggles */}
            <div className="flex items-center justify-between sm:col-span-2 pt-2 border-t border-slate-200/60">
              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                <input
                  type="checkbox"
                  checked={payCreditCardFirst}
                  onChange={(e) => setPayCreditCardFirst(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                />
                <span>{language === 'bn' ? 'উচ্চ সুদের ক্রেডিট কার্ড আগে দিন (Avalanche)' : 'Prioritize Highest Interest Debt'}</span>
              </label>

              <label className="flex items-center gap-2 cursor-pointer text-xs font-bold text-slate-700">
                <input
                  type="checkbox"
                  checked={payOnlyMinimums}
                  onChange={(e) => setPayOnlyMinimums(e.target.checked)}
                  className="rounded text-emerald-600 focus:ring-emerald-500 w-4 h-4 cursor-pointer"
                />
                <span>{language === 'bn' ? 'শুধুমাত্র ন্যূনতম পরিমাণ দিন (Min Only)' : 'Pay Minimum Amounts Only'}</span>
              </label>
            </div>
          </div>

          {/* SIMULATED RESULTS DASHBOARD */}
          <div className="space-y-3">
            <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
              <Play className="w-3.5 h-3.5 text-emerald-600 fill-emerald-600" />
              {language === 'bn' ? 'সিমুলেশন ফলাফল ও বিশ্লেষণ' : 'Simulated Real-time Impact'}
            </h4>

            {/* Metric Cards Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  {language === 'bn' ? 'অবশিষ্ট ব্যালেন্স' : 'Simulated Left'}
                </p>
                <p className="text-base font-black text-slate-900 mt-0.5">
                  {formatMoney(simResult.simulatedRemainingBalance)}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  {language === 'bn' ? 'ফান্ড ঘাটতি' : 'Shortfall'}
                </p>
                <p
                  className={`text-base font-black mt-0.5 ${
                    simResult.simulatedShortfall > 0 ? 'text-red-600' : 'text-emerald-700'
                  }`}
                >
                  {simResult.simulatedShortfall > 0
                    ? formatMoney(simResult.simulatedShortfall)
                    : language === 'bn'
                    ? '০ (ঘাটতি নেই)'
                    : '৳0 (No shortfall)'}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  {language === 'bn' ? 'জরিমানা সাশ্রয়' : 'Penalties Saved'}
                </p>
                <p className="text-base font-black text-emerald-700 mt-0.5">
                  +{formatMoney(simResult.simulatedPenaltiesAvoided)}
                </p>
              </div>

              <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  {language === 'bn' ? 'জরুরি ব্যয় কাভারেজ' : 'Essential Coverage'}
                </p>
                <p className="text-base font-black text-slate-800 mt-0.5">
                  {simResult.simulatedEssentialCoveragePercent}%
                </p>
              </div>
            </div>

            {/* Impact Text Banner */}
            <div
              className={`p-4 rounded-2xl border text-xs font-medium leading-relaxed flex items-start gap-3 ${
                simResult.simulatedShortfall > 0
                  ? 'bg-amber-50/70 border-amber-200 text-amber-900'
                  : 'bg-emerald-50/70 border-emerald-200 text-emerald-900'
              }`}
            >
              {simResult.simulatedShortfall > 0 ? (
                <AlertTriangle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              ) : (
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
              )}
              <div>
                <p className="font-bold">
                  {language === 'bn'
                    ? simResult.simulatedShortfall > 0
                      ? 'ঘাটতি সতর্কতা: কিছু দায় অপূর্ণ থেকে যাচ্ছে'
                      : 'চমৎকার! প্রস্তাবিত পরিকল্পনায় সকল দায় পরিশোধযোগ্য'
                    : simResult.simulatedShortfall > 0
                    ? 'Shortfall Alert: Some obligations remain uncovered'
                    : 'Optimal Scenario: All prioritized payments covered'}
                </p>
                <p className="mt-0.5 text-xs">
                  {language === 'bn' ? simResult.impactSummaryBn : simResult.impactSummary}
                </p>
              </div>
            </div>

            {/* Breakdown of simulated obligations */}
            <div className="space-y-2">
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                {language === 'bn' ? 'সিমুলেটেড পেমেন্ট তালিকা' : 'Simulated Payment Execution Order'}
              </p>
              <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                {simResult.rankedItems.map((item) => (
                  <div
                    key={item.obligation.id}
                    className="p-2.5 rounded-xl border border-slate-100 bg-white flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="font-black text-slate-400 text-[11px]">#{item.rank}</span>
                      <div>
                        <p className="font-bold text-slate-800">
                          {language === 'bn' ? item.obligation.nameBn || item.obligation.name : item.obligation.name}
                        </p>
                        <p className="text-[10px] text-slate-400">
                          {formatMoney(item.obligation.amountConverted)} • {item.obligation.dueDate}
                        </p>
                      </div>
                    </div>

                    <div className="text-right">
                      <span
                        className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          item.coverageStatus === 'fully_covered'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.coverageStatus === 'minimum_covered_only'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {item.coverageStatus === 'fully_covered'
                          ? language === 'bn'
                            ? 'সম্পূর্ণ পরিশোধ'
                            : 'Fully Paid'
                          : item.coverageStatus === 'minimum_covered_only'
                          ? language === 'bn'
                            ? 'ন্যূনতম পরিশোধ'
                            : 'Min Paid'
                          : language === 'bn'
                          ? 'ঘাটতি (বাকি)'
                          : 'Uncovered'}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50/60 flex items-center justify-between">
          <button
            type="button"
            onClick={handleReset}
            className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'সিমুলেশন রিসেট' : 'Reset Scenario'}</span>
          </button>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-900 text-white font-bold text-xs shadow-sm transition-all cursor-pointer"
          >
            {language === 'bn' ? 'সিমুলেটর বন্ধ করুন' : 'Done & Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
