import React, { useState } from 'react';
import { RankedObligation, PaymentObligation } from '../../types/paymentPriority';
import { useExpense } from '../../context/ExpenseContext';
import { useModalBehavior } from '../../utils/useModalBehavior';
import {
  X,
  ShieldAlert,
  AlertTriangle,
  Clock,
  Calendar,
  CreditCard,
  Building2,
  DollarSign,
  TrendingDown,
  Info,
  CheckCircle2,
  Zap,
  HelpCircle,
  ArrowRight,
  Flame,
} from 'lucide-react';

interface PaymentDetailsModalProps {
  item: RankedObligation | null;
  isOpen: boolean;
  onClose: () => void;
  onPayNow: (obligation: PaymentObligation) => void;
  onReschedule: (obligation: PaymentObligation) => void;
}

export const PaymentDetailsModal: React.FC<PaymentDetailsModalProps> = ({
  item,
  isOpen,
  onClose,
  onPayNow,
  onReschedule,
}) => {
  useModalBehavior({ isOpen, onClose });

  const { formatMoney, language, currency } = useExpense();

  if (!isOpen || !item) return null;

  const { obligation, scoreBreakdown, rank } = item;

  const getSeverityBadge = () => {
    switch (scoreBreakdown.level) {
      case 'critical':
        return {
          bg: 'bg-red-50 text-red-700 border-red-200',
          dot: 'bg-red-500',
          label: language === 'bn' ? 'জরুরি (Critical)' : 'Critical Priority',
        };
      case 'high':
        return {
          bg: 'bg-amber-50 text-amber-700 border-amber-200',
          dot: 'bg-amber-500',
          label: language === 'bn' ? 'উচ্চ (High)' : 'High Priority',
        };
      case 'medium':
        return {
          bg: 'bg-emerald-50 text-emerald-700 border-emerald-200',
          dot: 'bg-emerald-500',
          label: language === 'bn' ? 'মাঝারি (Medium)' : 'Medium Priority',
        };
      default:
        return {
          bg: 'bg-slate-100 text-slate-700 border-slate-200',
          dot: 'bg-slate-400',
          label: language === 'bn' ? 'নিম্ন (Low)' : 'Low Priority',
        };
    }
  };

  const badge = getSeverityBadge();

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl max-w-xl w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-start justify-between bg-gradient-to-r from-emerald-50/50 to-teal-50/20">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white shadow-2xs border border-emerald-100 flex items-center justify-center text-emerald-600 shrink-0 font-black text-lg">
              #{rank}
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span
                  className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${badge.bg}`}
                >
                  <span className={`w-1.5 h-1.5 rounded-full ${badge.dot}`} />
                  {badge.label}
                </span>
                <span className="text-xs font-black text-slate-600 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                  {scoreBreakdown.score} / 100 pts
                </span>
                {obligation.isEssential && (
                  <span className="text-[10px] font-bold bg-emerald-600 text-white px-2 py-0.5 rounded-full">
                    {language === 'bn' ? 'জীবনধারণের জন্য জরুরি' : 'Essential Living'}
                  </span>
                )}
              </div>
              <h3 className="text-lg font-black text-slate-800 mt-1 leading-snug">
                {language === 'bn' ? obligation.nameBn || obligation.name : obligation.name}
              </h3>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-white rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 overflow-y-auto space-y-5 text-sm">
          {/* Key Financial Amounts */}
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                {language === 'bn' ? 'মোট বকেয়া পরিমাণ' : 'Total Amount Due'}
              </p>
              <p className="text-lg font-black text-slate-900 mt-0.5">
                {formatMoney(obligation.amountConverted)}
              </p>
              {obligation.currencyCode !== currency.code && (
                <p className="text-[10px] text-slate-400 font-medium">
                  ({obligation.currencyCode} {obligation.amount.toLocaleString()})
                </p>
              )}
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100">
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                {language === 'bn' ? 'ন্যূনতম পরিশোধ' : 'Minimum Payable'}
              </p>
              <p className="text-lg font-black text-emerald-700 mt-0.5">
                {formatMoney(obligation.minimumAmountDue || obligation.amountConverted)}
              </p>
              <p className="text-[10px] text-slate-400 font-medium">
                {obligation.minimumAmountDue < obligation.amountConverted
                  ? language === 'bn'
                    ? 'আংশিক পরিশোধ সম্ভব'
                    : 'Partial min allowed'
                  : language === 'bn'
                  ? 'সম্পূর্ণ বাধ্যতামূলক'
                  : 'Full amount required'}
              </p>
            </div>

            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 col-span-2 sm:col-span-1">
              <p className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                {language === 'bn' ? 'সময়সীমা (Due Date)' : 'Due Date & Status'}
              </p>
              <p
                className={`text-base font-black mt-0.5 ${
                  obligation.isOverdue
                    ? 'text-red-600'
                    : obligation.daysRemaining <= 1
                    ? 'text-amber-600'
                    : 'text-slate-800'
                }`}
              >
                {obligation.dueDate}
              </p>
              <p className="text-[10px] font-bold mt-0.5">
                {obligation.isOverdue
                  ? language === 'bn'
                    ? `⚠️ ${obligation.overdueDays} দিন আগে মেয়াদ শেষ!`
                    : `⚠️ ${obligation.overdueDays} days overdue!`
                  : obligation.daysRemaining === 0
                  ? language === 'bn'
                    ? '🔥 আজকেই শেষ দিন!'
                    : '🔥 Due today!'
                  : language === 'bn'
                  ? `⏳ ${obligation.daysRemaining} দিন বাকি`
                  : `⏳ ${obligation.daysRemaining} days left`}
              </p>
            </div>
          </div>

          {/* Hard Rule Override Notice */}
          {scoreBreakdown.hardOverrideApplied && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-300/60 flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <h4 className="text-xs font-black text-amber-900 uppercase tracking-wide">
                  {language === 'bn' ? 'ফাইন্যান্সিয়াল সেফটি ওভাররাইড' : 'Safety Override Enforced'}
                </h4>
                <p className="text-xs text-amber-800 font-medium mt-0.5 leading-relaxed">
                  {language === 'bn'
                    ? scoreBreakdown.overrideReasonBn || scoreBreakdown.overrideReason
                    : scoreBreakdown.overrideReason}
                </p>
              </div>
            </div>
          )}

          {/* Consequence of Missing Payment */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
            <div className="flex items-center gap-2 text-slate-700">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              <h4 className="font-bold text-xs uppercase tracking-wider">
                {language === 'bn' ? 'দেরি করলে সম্ভাব্য পরিণতি ও ঝুঁকি' : 'Consequences of Delay'}
              </h4>
            </div>
            <p className="text-xs text-slate-700 leading-relaxed font-medium">
              {language === 'bn' ? obligation.consequenceDescBn : obligation.consequenceDesc}
            </p>
          </div>

          {/* Transparent Score Dimension Breakdown */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Info className="w-4 h-4 text-emerald-600" />
                {language === 'bn' ? 'স্কোর নির্ধারণের বিস্তারিত হিসাব (0-100)' : 'Scoring Model Factor Breakdown'}
              </h4>
            </div>

            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center">
                <span className="text-slate-600 font-medium">{language === 'bn' ? 'জরুরিতা (Urgency)' : 'Due Urgency'}</span>
                <span className="font-black text-slate-800">{scoreBreakdown.urgencyScore} / 100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center">
                <span className="text-slate-600 font-medium">{language === 'bn' ? 'বিলম্ব মেয়াদ (Overdue)' : 'Overdue Status'}</span>
                <span className="font-black text-slate-800">{scoreBreakdown.overdueScore} / 100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center">
                <span className="text-slate-600 font-medium">{language === 'bn' ? 'জরিমানা ঝুঁকি (Penalty)' : 'Late Fee Risk'}</span>
                <span className="font-black text-slate-800">{scoreBreakdown.penaltyScore} / 100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center">
                <span className="text-slate-600 font-medium">{language === 'bn' ? 'সুদের হার (Interest)' : 'APR Interest'}</span>
                <span className="font-black text-slate-800">{scoreBreakdown.interestScore} / 100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center">
                <span className="text-slate-600 font-medium">{language === 'bn' ? 'পরিণতি (Consequence)' : 'Severity'}</span>
                <span className="font-black text-slate-800">{scoreBreakdown.consequenceScore} / 100</span>
              </div>
              <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-100 flex justify-between items-center">
                <span className="text-slate-600 font-medium">{language === 'bn' ? 'জীবনযাত্রার গুরুত্ব' : 'Essential Need'}</span>
                <span className="font-black text-slate-800">{scoreBreakdown.essentialScore} / 100</span>
              </div>
            </div>
          </div>

          {/* Credit Card Specific Tradeoff (if applicable) */}
          {obligation.sourceType === 'credit_card_full' && (
            <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-200/60 text-xs text-blue-900 space-y-1.5">
              <h5 className="font-bold flex items-center gap-1.5 text-blue-800">
                <CreditCard className="w-4 h-4" />
                {language === 'bn' ? 'ক্রেডিট কার্ড কৌশলগত পরামর্শ' : 'Credit Card Safety Trade-off'}
              </h5>
              <p className="leading-relaxed">
                {language === 'bn'
                  ? 'আপনার হাতে যদি ক্যাশ কম থাকে, তবে পুরো টাকা দেওয়া জরুরি নয়। শুধুমাত্র ন্যূনতম (Minimum Due) পরিশোধ করলে আপনার ক্রেডিট স্কোর সুরক্ষিত থাকবে এবং জরিমানা এড়ানো যাবে।'
                  : 'If liquid cash is tight, prioritize the minimum payment to prevent penalties and protect your credit score. Full balance can be settled once essential living obligations are covered.'}
              </p>
            </div>
          )}

          {/* Recommended Action */}
          <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200/80 flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <h4 className="text-xs font-black text-emerald-900 uppercase tracking-wide">
                {language === 'bn' ? 'ইঞ্জিন প্রস্তাবিত পরবর্তী পদক্ষেপ' : 'Recommended Action'}
              </h4>
              <p className="text-xs text-emerald-800 font-semibold mt-0.5">
                {language === 'bn' ? scoreBreakdown.recommendedActionBn : scoreBreakdown.recommendedAction}
              </p>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 sm:p-5 border-t border-slate-100 bg-slate-50/60 flex items-center justify-between gap-3">
          <button
            onClick={() => {
              onClose();
              onReschedule(obligation);
            }}
            className="px-4 py-2.5 rounded-xl border border-slate-200 bg-white hover:bg-slate-100 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
          >
            {language === 'bn' ? 'তারিখ পরিবর্তন (Reschedule)' : 'Reschedule Due Date'}
          </button>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-slate-500 hover:text-slate-700 font-bold text-xs transition-colors cursor-pointer"
            >
              {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
            </button>
            <button
              onClick={() => {
                onClose();
                onPayNow(obligation);
              }}
              className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all cursor-pointer"
            >
              <span>{language === 'bn' ? 'পরিশোধ করুন' : 'Pay Now'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
