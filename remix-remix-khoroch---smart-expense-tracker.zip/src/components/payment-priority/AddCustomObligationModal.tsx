import React, { useState } from 'react';
import { CustomObligationInput, ConsequenceSeverity } from '../../types/paymentPriority';
import { useExpense } from '../../context/ExpenseContext';
import { useModalBehavior } from '../../utils/useModalBehavior';
import {
  X,
  Plus,
  Calendar,
  AlertCircle,
  ShieldAlert,
  Percent,
  CheckCircle2,
  DollarSign,
  HeartPulse,
  GraduationCap,
  Building,
  Sparkles,
} from 'lucide-react';

interface AddCustomObligationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddCustomObligationModal: React.FC<AddCustomObligationModalProps> = ({
  isOpen,
  onClose,
}) => {
  useModalBehavior({ isOpen, onClose });

  const { addCustomObligation, currency, language } = useExpense();

  const [name, setName] = useState('');
  const [category, setCategory] = useState('education');
  const [amount, setAmount] = useState('');
  const [currencyCode, setCurrencyCode] = useState(currency.code || 'BDT');
  const [dueDate, setDueDate] = useState('');
  const [minimumAmountDue, setMinimumAmountDue] = useState('');
  const [lateFeeAmount, setLateFeeAmount] = useState('');
  const [interestRateAPR, setInterestRateAPR] = useState('');
  const [consequenceSeverity, setConsequenceSeverity] = useState<ConsequenceSeverity>('financial_penalty');
  const [isEssential, setIsEssential] = useState(true);
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (!name.trim()) {
      setErrorMsg(language === 'bn' ? 'দায়ের নাম লিখুন।' : 'Please enter obligation name.');
      return;
    }
    if (isNaN(numAmount) || numAmount <= 0) {
      setErrorMsg(language === 'bn' ? 'সঠিক পরিমাণ লিখুন।' : 'Please enter a valid amount.');
      return;
    }
    if (!dueDate) {
      setErrorMsg(language === 'bn' ? 'পরিশোধের শেষ তারিখ দিন।' : 'Please select a due date.');
      return;
    }

    const minDue = parseFloat(minimumAmountDue);
    const lateFee = parseFloat(lateFeeAmount);
    const apr = parseFloat(interestRateAPR);

    addCustomObligation({
      name: name.trim(),
      nameBn: name.trim(),
      category,
      amount: numAmount,
      currencyCode,
      dueDate,
      minimumAmountDue: !isNaN(minDue) && minDue > 0 ? minDue : undefined,
      lateFeeAmount: !isNaN(lateFee) && lateFee > 0 ? lateFee : undefined,
      interestRateAPR: !isNaN(apr) && apr > 0 ? apr : undefined,
      consequenceSeverity,
      isEssential,
      notes: notes.trim() || undefined,
    });

    onClose();
  };

  const categories = [
    { id: 'education', name: 'Education & Tuition', nameBn: 'টিউশন ও শিক্ষা ফি', icon: GraduationCap },
    { id: 'medical', name: 'Medical & Healthcare', nameBn: 'চিকিৎসা ও ওষুধ', icon: HeartPulse },
    { id: 'insurance', name: 'Insurance Premium', nameBn: 'বীমা প্রিমিয়াম', icon: ShieldAlert },
    { id: 'emi_loan', name: 'Loan Installment / EMI', nameBn: 'ঋণ বা ইএমআই কিস্তি', icon: Building },
    { id: 'utility', name: 'Essential Utility', nameBn: 'জরুরি বিল / সেবা', icon: Sparkles },
    { id: 'custom', name: 'Other Custom Obligation', nameBn: 'অন্যান্য কাস্টম দায়', icon: Plus },
  ];

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between bg-emerald-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <Plus className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-800">
                {language === 'bn' ? 'নতুন আর্থিক দায় যোগ করুন' : 'Add Financial Obligation'}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {language === 'bn'
                  ? 'টিউশন ফি, মেডিকেল বিল, বীমা বা কাস্টম ঋণ'
                  : 'Tuition fees, medical expenses, EMI, or custom debts'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-white rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 overflow-y-auto space-y-4">
          {errorMsg && (
            <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs font-bold border border-red-200">
              {errorMsg}
            </div>
          )}

          {/* Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
              {language === 'bn' ? 'দায়ের নাম / শিরোনাম' : 'Obligation Name / Title'} *
            </label>
            <input
              type="text"
              required
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder={language === 'bn' ? 'যেমন: সন্তানের স্কুল টিউশন ফি' : 'e.g. Semester Tuition Fee'}
              className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-bold"
            />
          </div>

          {/* Category Selector Grid */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
              {language === 'bn' ? 'ক্যাটাগরি পছন্দ' : 'Select Category'}
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {categories.map((cat) => {
                const Icon = cat.icon;
                const isSelected = category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => {
                      setCategory(cat.id);
                      if (cat.id === 'education' || cat.id === 'medical' || cat.id === 'utility') {
                        setIsEssential(true);
                      }
                    }}
                    className={`p-2.5 rounded-xl border text-left flex items-center gap-2 transition-all cursor-pointer ${
                      isSelected
                        ? 'border-emerald-600 bg-emerald-50/70 font-bold text-emerald-900 shadow-2xs'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <Icon className="w-4 h-4 text-emerald-600 shrink-0" />
                    <span className="text-[11px] truncate">{language === 'bn' ? cat.nameBn : cat.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Amount & Currency */}
          <div className="grid grid-cols-3 gap-2">
            <div className="col-span-2">
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'মোট পরিমাণ' : 'Amount'} *
              </label>
              <div className="relative">
                <span className="absolute left-3 top-2.5 font-black text-slate-400">
                  {currency.symbol}
                </span>
                <input
                  type="number"
                  step="any"
                  required
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-bold"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'মুদ্রা' : 'Currency'}
              </label>
              <select
                value={currencyCode}
                onChange={(e) => setCurrencyCode(e.target.value)}
                className="w-full px-2 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-white"
              >
                <option value="BDT">BDT (৳)</option>
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="INR">INR (₹)</option>
                <option value="GBP">GBP (£)</option>
              </select>
            </div>
          </div>

          {/* Due Date & Minimum Payable */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'পরিশোধের শেষ তারিখ' : 'Due Date'} *
              </label>
              <input
                type="date"
                required
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'ন্যূনতম পরিমাণ (যদি থাকে)' : 'Minimum Due'}
              </label>
              <input
                type="number"
                step="any"
                value={minimumAmountDue}
                onChange={(e) => setMinimumAmountDue(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: ৫০০০' : 'e.g. 5000'}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-medium"
              />
            </div>
          </div>

          {/* Late Penalty & APR Interest Rate */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'বিলম্ব জরিমানা (Late Fee)' : 'Late Fee Penalty'}
              </label>
              <input
                type="number"
                value={lateFeeAmount}
                onChange={(e) => setLateFeeAmount(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: ২০০' : 'e.g. 200'}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'বার্ষিক সুদের হার (APR %)' : 'Annual APR %'}
              </label>
              <input
                type="number"
                step="0.1"
                value={interestRateAPR}
                onChange={(e) => setInterestRateAPR(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: ১২%' : 'e.g. 12%'}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-medium"
              />
            </div>
          </div>

          {/* Consequence Severity */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
              {language === 'bn' ? 'দেরি করলে সম্ভাব্য পরিণতির তীব্রতা' : 'Consequence Severity'}
            </label>
            <select
              value={consequenceSeverity}
              onChange={(e) => setConsequenceSeverity(e.target.value as ConsequenceSeverity)}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs font-bold bg-white"
            >
              <option value="disconnection">{language === 'bn' ? 'লাইন বা পরিষেবা বিচ্ছিন্ন (Disconnection)' : 'Service Disconnection'}</option>
              <option value="legal_contractual">{language === 'bn' ? 'চুক্তি লঙ্ঘন বা আইনি নোটিশ (Contractual Default)' : 'Contractual Default / Legal'}</option>
              <option value="credit_damage">{language === 'bn' ? 'ক্রেডিট স্কোর ক্ষতি / ব্যাংক রিপোর্ট (Credit Score Hit)' : 'Credit Score Degradation'}</option>
              <option value="service_interruption">{language === 'bn' ? 'সাময়িক স্থগিত (Temporary Pause)' : 'Temporary Service Suspension'}</option>
              <option value="financial_penalty">{language === 'bn' ? 'শুধুমাত্র আর্থিক জরিমানা (Late Fine Only)' : 'Pure Late Fine Only'}</option>
              <option value="mild">{language === 'bn' ? 'সাধারণ বা মৃদু (Mild / Friendly)' : 'Mild / Friendly Notice'}</option>
            </select>
          </div>

          {/* Essential Living Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-slate-50 border border-slate-100">
            <div>
              <p className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'এটি কি জীবনধারণের জন্য অপরিহার্য?' : 'Essential Living Obligation?'}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn'
                  ? 'খাবার, বাসা ভাড়া, বিদ্যুৎ ও জরুরি চিকিৎসা অগ্রাধিকার পাবে।'
                  : 'Food, rent, power, and medical needs are safeguarded first.'}
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={isEssential}
                onChange={(e) => setIsEssential(e.target.checked)}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-emerald-600"></div>
            </label>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
              {language === 'bn' ? 'মন্তব্য বা শর্তাদি' : 'Notes & Conditions'}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder={language === 'bn' ? 'অতিরিক্ত কোনো শর্ত বা তথ্য...' : 'Any terms, account numbers, or notes...'}
              className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-medium resize-none"
            />
          </div>

          {/* Submit */}
          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl text-slate-500 hover:text-slate-700 font-bold text-xs transition-colors cursor-pointer"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all cursor-pointer"
            >
              {language === 'bn' ? 'সংরক্ষণ করুন' : 'Save Obligation'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
