import React, { useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useModalBehavior } from '../../utils/useModalBehavior';
import { DEFAULT_PRIORITY_CONFIG } from '../../services/paymentPriorityEngine';
import {
  X,
  Sliders,
  RotateCcw,
  CheckCircle2,
  ShieldCheck,
  Scale,
  Sparkles,
  Info,
} from 'lucide-react';

interface PriorityConfigModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PriorityConfigModal: React.FC<PriorityConfigModalProps> = ({
  isOpen,
  onClose,
}) => {
  useModalBehavior({ isOpen, onClose });

  const {
    paymentEngineConfig,
    updatePaymentEngineConfig,
    language,
    currency,
  } = useExpense();

  const [weights, setWeights] = useState({ ...paymentEngineConfig.weights });
  const [thresholds, setThresholds] = useState({ ...paymentEngineConfig.thresholds });
  const [reserve, setReserve] = useState(paymentEngineConfig.essentialLivingReserve);
  const [advanceDays, setAdvanceDays] = useState(paymentEngineConfig.advanceReminderDays);

  if (!isOpen) return null;

  const totalWeight =
    weights.urgency +
    weights.overdue +
    weights.penalty +
    weights.interest +
    weights.consequence +
    weights.essential;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updatePaymentEngineConfig({
      weights,
      thresholds,
      essentialLivingReserve: reserve,
      advanceReminderDays: advanceDays,
    });
    onClose();
  };

  const handleReset = () => {
    setWeights({ ...DEFAULT_PRIORITY_CONFIG.weights });
    setThresholds({ ...DEFAULT_PRIORITY_CONFIG.thresholds });
    setReserve(DEFAULT_PRIORITY_CONFIG.essentialLivingReserve);
    setAdvanceDays(DEFAULT_PRIORITY_CONFIG.advanceReminderDays);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl max-w-lg w-full max-h-[92vh] flex flex-col shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between bg-emerald-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-800">
                {language === 'bn' ? 'স্কোরিং মডেল ও প্রায়োরিটি সেটিংস' : 'Priority Scoring & Safety Engine'}
              </h3>
              <p className="text-xs text-slate-500 font-medium">
                {language === 'bn'
                  ? 'ওজন (Weights), থ্রেশহোল্ড ও এসেনশিয়াল ক্যাশ বাফার'
                  : 'Configurable weights, thresholds & essential cash buffer'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-white rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSave} className="p-5 sm:p-6 overflow-y-auto space-y-5">
          {/* Section 1: Scoring Weights Sliders */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider flex items-center gap-1.5">
                <Scale className="w-4 h-4 text-emerald-600" />
                {language === 'bn' ? 'ফ্যাক্টর ওজন (Scoring Weights - মোট ১০০%)' : 'Evaluation Factor Weights (Total 100%)'}
              </h4>
              <span
                className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                  totalWeight === 100
                    ? 'bg-emerald-100 text-emerald-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {totalWeight}%
              </span>
            </div>

            {/* Slider 1: Urgency */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-800">
                <span>{language === 'bn' ? 'নির্দিষ্ট তারিখের সান্নিধ্য (Due Urgency)' : 'Due-Date Urgency'}</span>
                <span className="text-emerald-700">{weights.urgency}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="50"
                value={weights.urgency}
                onChange={(e) => setWeights({ ...weights, urgency: parseInt(e.target.value) || 0 })}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            {/* Slider 2: Overdue */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-800">
                <span>{language === 'bn' ? 'বকেয়া মেয়াদ (Overdue Multiplier)' : 'Overdue Severity Multiplier'}</span>
                <span className="text-emerald-700">{weights.overdue}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                value={weights.overdue}
                onChange={(e) => setWeights({ ...weights, overdue: parseInt(e.target.value) || 0 })}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            {/* Slider 3: Penalty */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-800">
                <span>{language === 'bn' ? 'বিলম্ব জরিমানা ও পেনাল্টি (Late Fee Penalty)' : 'Late Fee & Penalties'}</span>
                <span className="text-emerald-700">{weights.penalty}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                value={weights.penalty}
                onChange={(e) => setWeights({ ...weights, penalty: parseInt(e.target.value) || 0 })}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            {/* Slider 4: Interest */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-800">
                <span>{language === 'bn' ? 'সুদের হার ও অতিরিক্ত ব্যয় (APR Interest)' : 'Additional Interest / APR'}</span>
                <span className="text-emerald-700">{weights.interest}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                value={weights.interest}
                onChange={(e) => setWeights({ ...weights, interest: parseInt(e.target.value) || 0 })}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            {/* Slider 5: Consequence */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-800">
                <span>{language === 'bn' ? 'পরিণতির গুরুত্ব (Consequence Severity)' : 'Consequence Severity'}</span>
                <span className="text-emerald-700">{weights.consequence}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="40"
                value={weights.consequence}
                onChange={(e) => setWeights({ ...weights, consequence: parseInt(e.target.value) || 0 })}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>

            {/* Slider 6: Essential Needs */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100 space-y-1.5">
              <div className="flex justify-between text-xs font-bold text-slate-800">
                <span>{language === 'bn' ? 'জীবনধারণের মৌলিক প্রয়োজন (Essential Living)' : 'Essential Living Needs'}</span>
                <span className="text-emerald-700">{weights.essential}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="30"
                value={weights.essential}
                onChange={(e) => setWeights({ ...weights, essential: parseInt(e.target.value) || 0 })}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>
          </div>

          {/* Section 2: Priority Thresholds */}
          <div className="space-y-2">
            <h4 className="text-xs font-black text-slate-700 uppercase tracking-wider">
              {language === 'bn' ? 'অগ্রাধিকার লেভেল থ্রেশহোল্ড (Thresholds)' : 'Priority Level Cutoffs'}
            </h4>
            <div className="grid grid-cols-3 gap-2">
              <div className="p-3 rounded-2xl bg-red-50/50 border border-red-200">
                <span className="text-[10px] font-bold text-red-700 uppercase">
                  {language === 'bn' ? 'জরুরি (Critical)' : 'Critical'}
                </span>
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-xs font-bold text-slate-400">≥</span>
                  <input
                    type="number"
                    value={thresholds.critical}
                    onChange={(e) => setThresholds({ ...thresholds, critical: parseInt(e.target.value) || 85 })}
                    className="w-full px-2 py-1 rounded-lg border border-red-200 font-bold text-xs bg-white"
                  />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-amber-50/50 border border-amber-200">
                <span className="text-[10px] font-bold text-amber-700 uppercase">
                  {language === 'bn' ? 'উচ্চ (High)' : 'High'}
                </span>
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-xs font-bold text-slate-400">≥</span>
                  <input
                    type="number"
                    value={thresholds.high}
                    onChange={(e) => setThresholds({ ...thresholds, high: parseInt(e.target.value) || 65 })}
                    className="w-full px-2 py-1 rounded-lg border border-amber-200 font-bold text-xs bg-white"
                  />
                </div>
              </div>

              <div className="p-3 rounded-2xl bg-emerald-50/50 border border-emerald-200">
                <span className="text-[10px] font-bold text-emerald-700 uppercase">
                  {language === 'bn' ? 'মাঝারি (Medium)' : 'Medium'}
                </span>
                <div className="flex items-center gap-1 mt-1">
                  <span className="text-xs font-bold text-slate-400">≥</span>
                  <input
                    type="number"
                    value={thresholds.medium}
                    onChange={(e) => setThresholds({ ...thresholds, medium: parseInt(e.target.value) || 40 })}
                    className="w-full px-2 py-1 rounded-lg border border-emerald-200 font-bold text-xs bg-white"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Essential Living Buffer Reserve */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 space-y-2">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs font-bold text-slate-800">
                  {language === 'bn' ? 'জরুরি জীবনযাত্রার ক্যাশ রিজার্ভ বাফার' : 'Essential Living Cash Reserve'}
                </p>
                <p className="text-[11px] text-slate-500">
                  {language === 'bn'
                    ? 'খাবার, বাসা ও ওষুধ নিশ্চিত না করে অতিরিক্ত ঋণ পরিশোধে নিষেধ।'
                    : 'Protects funds for groceries/medicine before paying discretionary debts.'}
                </p>
              </div>
              <div className="relative w-28">
                <span className="absolute left-2.5 top-1.5 font-bold text-slate-400 text-xs">
                  {currency.symbol}
                </span>
                <input
                  type="number"
                  value={reserve}
                  onChange={(e) => setReserve(parseFloat(e.target.value) || 0)}
                  className="w-full pl-6 pr-2 py-1.5 rounded-xl border border-slate-200 font-bold text-xs bg-white text-right"
                />
              </div>
            </div>
          </div>

          {/* Section 4: Advance Reminder Lead Days */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
            <div>
              <p className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'কতদিন আগে আগাম রিমাইন্ডার পাবেন?' : 'Advance Warning Lead Days'}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn' ? 'মেয়াদ শেষের নির্দিষ্ট দিন পূর্বে সতর্কতা।' : 'Days before due date to alert.'}
              </p>
            </div>
            <select
              value={advanceDays}
              onChange={(e) => setAdvanceDays(parseInt(e.target.value) || 3)}
              className="px-3 py-1.5 rounded-xl border border-slate-200 font-bold text-xs bg-white"
            >
              <option value="1">1 {language === 'bn' ? 'দিন' : 'day'}</option>
              <option value="2">2 {language === 'bn' ? 'দিন' : 'days'}</option>
              <option value="3">3 {language === 'bn' ? 'দিন' : 'days'}</option>
              <option value="5">5 {language === 'bn' ? 'দিন' : 'days'}</option>
              <option value="7">7 {language === 'bn' ? 'দিন' : 'days'}</option>
            </select>
          </div>

          {/* Actions */}
          <div className="pt-2 flex items-center justify-between">
            <button
              type="button"
              onClick={handleReset}
              className="flex items-center gap-1.5 text-xs font-bold text-slate-500 hover:text-slate-800 transition-colors cursor-pointer"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'ডিফল্ট সেটিংস রিসেট' : 'Reset to Defaults'}</span>
            </button>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-slate-500 hover:text-slate-700 font-bold text-xs transition-colors cursor-pointer"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all cursor-pointer"
              >
                {language === 'bn' ? 'সেভ করুন' : 'Apply Settings'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
