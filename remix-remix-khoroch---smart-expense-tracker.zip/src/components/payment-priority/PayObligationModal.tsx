import React, { useState, useEffect } from 'react';
import { PaymentObligation } from '../../types/paymentPriority';
import { useExpense } from '../../context/ExpenseContext';
import { useModalBehavior } from '../../utils/useModalBehavior';
import {
  X,
  CheckCircle2,
  Calendar,
  CreditCard,
  Building2,
  Wallet,
  Receipt,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Sparkles,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PayObligationModalProps {
  obligation: PaymentObligation | null;
  isOpen: boolean;
  onClose: () => void;
}

export const PayObligationModal: React.FC<PayObligationModalProps> = ({
  obligation,
  isOpen,
  onClose,
}) => {
  useModalBehavior({ isOpen, onClose });

  const {
    accounts,
    markObligationPaid,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const [selectedAccountId, setSelectedAccountId] = useState('');
  const [payMode, setPayMode] = useState<'full' | 'min' | 'custom'>('full');
  const [customAmount, setCustomAmount] = useState('');
  const [date, setDate] = useState('');
  const [note, setNote] = useState('');
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  // Liquid accounts for payment
  const liquidAccounts = accounts.filter(
    (a) => ['cash', 'bank', 'mobile_wallet', 'savings'].includes(a.type)
  );

  useEffect(() => {
    if (obligation && isOpen) {
      const defaultAcc = liquidAccounts.find((a) => a.balance >= obligation.amountConverted) || liquidAccounts[0];
      setSelectedAccountId(obligation.linkedAccountId || defaultAcc?.id || accounts[0]?.id || '');
      setPayMode('full');
      setCustomAmount(obligation.amountConverted.toString());
      setDate(new Date().toISOString().slice(0, 10));
      setNote(`${obligation.nameBn || obligation.name} পরিশোধ`);
      setIsSuccess(false);
      setErrorMsg('');
    }
  }, [obligation, isOpen]);

  if (!isOpen || !obligation) return null;

  const selectedAccount = accounts.find((a) => a.id === selectedAccountId);

  // Compute final payment amount based on pay mode
  const getEffectiveAmount = (): number => {
    if (payMode === 'full') return obligation.amountConverted;
    if (payMode === 'min') return obligation.minimumAmountDue || obligation.amountConverted;
    const parsed = parseFloat(customAmount);
    return isNaN(parsed) ? 0 : parsed;
  };

  const effectiveAmount = getEffectiveAmount();
  const willCauseOverdraft = selectedAccount ? selectedAccount.balance < effectiveAmount : false;

  const handleConfirmPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedAccountId) {
      setErrorMsg(language === 'bn' ? 'অনুগ্রহ করে একটি অ্যাকাউন্ট সিলেক্ট করুন।' : 'Please select an account.');
      return;
    }
    if (effectiveAmount <= 0) {
      setErrorMsg(language === 'bn' ? 'পরিশোধের পরিমাণ অবশ্যই ০-এর বেশি হতে হবে।' : 'Amount must be greater than 0.');
      return;
    }

    markObligationPaid(obligation, {
      accountId: selectedAccountId,
      amount: effectiveAmount,
      date: date || new Date().toISOString().slice(0, 10),
      note: note.trim() || undefined,
    });

    try {
      confetti({
        particleCount: 60,
        spread: 60,
        origin: { y: 0.7 },
      });
    } catch {}

    setIsSuccess(true);
    setTimeout(() => {
      setIsSuccess(false);
      onClose();
    }, 1400);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-xs transition-opacity animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-3xl max-w-md w-full shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 sm:p-6 border-b border-slate-100 flex items-center justify-between bg-emerald-50/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-600 text-white flex items-center justify-center shadow-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black text-slate-800">
                {language === 'bn' ? 'পেমেন্ট নিশ্চিতকরণ' : 'Confirm Payment'}
              </h3>
              <p className="text-xs text-slate-500 font-medium truncate max-w-[240px]">
                {language === 'bn' ? obligation.nameBn || obligation.name : obligation.name}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-slate-600 hover:bg-white rounded-xl transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {isSuccess ? (
          <div className="p-10 text-center space-y-3">
            <div className="w-16 h-16 rounded-3xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto animate-bounce">
              <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
            </div>
            <h4 className="text-lg font-black text-slate-800">
              {language === 'bn' ? 'পেমেন্ট সফলভাবে সংরক্ষিত হয়েছে!' : 'Payment Successfully Recorded!'}
            </h4>
            <p className="text-xs text-slate-500 font-medium">
              {language === 'bn'
                ? 'আপনার ওয়ালেট ও লেনদেন হিস্ট্রিতে হিসাব আপডেট করা হয়েছে।'
                : 'Wallet balance and transaction ledger have been updated.'}
            </p>
          </div>
        ) : (
          <form onSubmit={handleConfirmPayment} className="p-5 sm:p-6 space-y-4">
            {errorMsg && (
              <div className="p-3 rounded-xl bg-red-50 text-red-700 text-xs font-bold border border-red-200">
                {errorMsg}
              </div>
            )}

            {/* Payment Mode Selector (Full vs Min vs Custom) */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                {language === 'bn' ? 'পরিশোধের ধরন' : 'Payment Option'}
              </label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setPayMode('full')}
                  className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                    payMode === 'full'
                      ? 'border-emerald-600 bg-emerald-50/50 shadow-2xs font-black'
                      : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <p className="text-[11px] text-slate-500">{language === 'bn' ? 'সম্পূর্ণ বকেয়া' : 'Full Balance'}</p>
                  <p className="text-sm font-black text-slate-900 mt-0.5">
                    {formatMoney(obligation.amountConverted)}
                  </p>
                </button>

                {obligation.minimumAmountDue > 0 && obligation.minimumAmountDue < obligation.amountConverted ? (
                  <button
                    type="button"
                    onClick={() => setPayMode('min')}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      payMode === 'min'
                        ? 'border-emerald-600 bg-emerald-50/50 shadow-2xs font-black'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <p className="text-[11px] text-emerald-700 font-bold">{language === 'bn' ? 'ন্যূনতম (Min Due)' : 'Minimum Due'}</p>
                    <p className="text-sm font-black text-emerald-700 mt-0.5">
                      {formatMoney(obligation.minimumAmountDue)}
                    </p>
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={() => setPayMode('custom')}
                    className={`p-3 rounded-2xl border text-left transition-all cursor-pointer ${
                      payMode === 'custom'
                        ? 'border-emerald-600 bg-emerald-50/50 shadow-2xs font-black'
                        : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                    }`}
                  >
                    <p className="text-[11px] text-slate-500">{language === 'bn' ? 'কাস্টম পরিমাণ' : 'Custom Amount'}</p>
                    <p className="text-sm font-bold text-slate-800 mt-0.5">
                      {language === 'bn' ? 'অন্য পরিমাণ' : 'Other'}
                    </p>
                  </button>
                )}
              </div>
            </div>

            {/* Custom Amount Input if mode === 'custom' */}
            {payMode === 'custom' && (
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'পরিশোধের পরিমাণ' : 'Amount to Pay'}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 font-black text-slate-400">
                    {currency.symbol}
                  </span>
                  <input
                    type="number"
                    step="any"
                    value={customAmount}
                    onChange={(e) => setCustomAmount(e.target.value)}
                    className="w-full pl-8 pr-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 font-bold text-sm"
                  />
                </div>
              </div>
            )}

            {/* Account Selector */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 uppercase tracking-wider">
                {language === 'bn' ? 'যে অ্যাকাউন্ট থেকে দেওয়া হবে' : 'Debit Account'}
              </label>
              <select
                value={selectedAccountId}
                onChange={(e) => setSelectedAccountId(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-bold bg-white"
              >
                {liquidAccounts.map((acc) => (
                  <option key={acc.id} value={acc.id}>
                    {acc.nameBn || acc.name} — (ব্যালেন্স: {formatMoney(acc.balance)})
                  </option>
                ))}
              </select>
            </div>

            {/* Overdraft Warning Notice */}
            {willCauseOverdraft && (
              <div className="p-3 rounded-xl bg-amber-50 text-amber-800 border border-amber-200 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  {language === 'bn'
                    ? 'সতর্কতা: নির্বাচিত অ্যাকাউন্টের ব্যালেন্সের চেয়ে পেমেন্টের পরিমাণ বেশি।'
                    : 'Warning: Selected account balance is lower than the payment amount.'}
                </span>
              </div>
            )}

            {/* Date */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'পরিশোধের তারিখ' : 'Payment Date'}
              </label>
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-bold"
              />
            </div>

            {/* Note */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 uppercase tracking-wider">
                {language === 'bn' ? 'নোট / রেফারেন্স' : 'Note / Reference'}
              </label>
              <input
                type="text"
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: বিদ্যুৎ বিল মার্চ পরিশোধ' : 'e.g. Utility bill payment'}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 text-xs font-medium"
              />
            </div>

            {/* Actions */}
            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 rounded-xl text-slate-500 hover:text-slate-700 font-bold text-xs transition-colors cursor-pointer"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all cursor-pointer"
              >
                <span>{language === 'bn' ? 'নিশ্চিত ও সংরক্ষণ' : 'Confirm Payment'}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
