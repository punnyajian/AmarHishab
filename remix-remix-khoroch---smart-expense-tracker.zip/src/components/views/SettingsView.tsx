import React, { useRef, useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { CURRENCIES } from '../../data/defaultData';
import {
  Settings as SettingsIcon,
  Globe,
  Coins,
  Download,
  Upload,
  RefreshCw,
  Smartphone,
  Laptop,
  Monitor,
  CheckCircle2,
  AlertTriangle,
  Shield,
  HelpCircle,
  Trash2,
  Cloud,
  Database,
  Lock,
  Wifi,
  WifiOff,
  HardDriveDownload,
} from 'lucide-react';
import { useOnlineStatus } from '../../hooks/useOnlineStatus';
import { PWAInstallButton } from '../PWAInstallButton';

export const SettingsView: React.FC = () => {
  const {
    currency,
    setCurrency,
    language,
    setLanguage,
    exportCSV,
    exportJSON,
    importJSON,
    resetAll,
    setIsResetModalOpen,
    currentUser,
    setIsAuthModalOpen,
    isCloudSyncing,
    lastSyncedTime,
    syncAllToCloudNow,
    transactions,
    accounts,
    bazarItems,
    setActiveTab,
    t,
  } = useExpense();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const isOnline = useOnlineStatus();
  const [toastMessage, setToastMessage] = useState<{ text: string; isError?: boolean } | null>(null);

  const handleFileImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = event => {
      try {
        const content = event.target?.result as string;
        const success = importJSON(content);
        if (success) {
          setToastMessage({
            text: language === 'bn' ? 'ডাটা ব্যাকআপ সফলভাবে রিস্টোর হয়েছে!' : 'Data restored successfully!',
          });
        } else {
          setToastMessage({
            text: language === 'bn' ? 'ফাইলটি সঠিক ব্যাকআপ ফাইল নয়।' : 'Invalid backup file format.',
            isError: true,
          });
        }
      } catch {
        setToastMessage({
          text: language === 'bn' ? 'ফাইল লোড করতে ব্যর্থ হয়েছে।' : 'Failed to parse file.',
          isError: true,
        });
      }
      setTimeout(() => setToastMessage(null), 4000);
    };
    reader.readAsText(file);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const handleQuickOneTapReset = () => {
    resetAll();
    setToastMessage({
      text: language === 'bn' ? 'অ্যাপের সমস্ত ডেটা ও হিসাব সফলভাবে মুছে ০-তে রিসেট করা হয়েছে!' : 'All records & data successfully cleared (reset to 0)!',
    });
    setTimeout(() => setToastMessage(null), 4000);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200 max-w-4xl">
      
      {/* Header */}
      <div>
        <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
          {t('settings')}
        </h1>
        <p className="text-xs sm:text-sm text-slate-500">
          {language === 'bn'
            ? 'অ্যাপ কনফিগারেশন, ভাষা, মুদ্রা এবং ব্যাকআপ ব্যবস্থাপনা'
            : 'Configure currency, language, and data backups'}
        </p>
      </div>

      {/* Toast Alert */}
      {toastMessage && (
        <div
          className={`p-3.5 rounded-2xl text-xs font-semibold flex items-center justify-between animate-in fade-in duration-150 ${
            toastMessage.isError
              ? 'bg-rose-50 text-rose-700 border border-rose-200'
              : 'bg-emerald-50 text-emerald-800 border border-emerald-200'
          }`}
        >
          <span>{toastMessage.text}</span>
          <button onClick={() => setToastMessage(null)} className="text-[10px] underline ml-2">
            Dismiss
          </button>
        </div>
      )}

      {/* Cloud Sync & Account Card */}
      <div className="bg-white border border-emerald-200/80 rounded-3xl p-6 shadow-xs space-y-4 overflow-hidden relative">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <Cloud className="w-4 h-4 text-emerald-600" />
            {language === 'bn' ? 'ক্লাউড সিঙ্ক ও অ্যাকাউন্ট ব্যাকআপ' : 'Cloud Synchronization & Account'}
          </h2>
          <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold ${
            currentUser ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-600'
          }`}>
            <span className={`w-2 h-2 rounded-full ${currentUser ? 'bg-emerald-500 animate-pulse' : 'bg-slate-400'}`}></span>
            {currentUser ? (language === 'bn' ? 'রিয়েল-টাইম ক্লাউড সিঙ্ক চালু' : 'Cloud Sync Active') : (language === 'bn' ? 'লগইন করা নেই (লোকাল মোড)' : 'Local Mode Only')}
          </span>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          {language === 'bn'
            ? 'যেকোনো মোবাইল, ল্যাপটপ বা কম্পিউটার থেকে লগইন করলে পূর্বের সকল লেনদেন, বাজেট এবং কাঁচাবাজারের ডেটা সরাসরি পেতে গুগল অ্যাকাউন্টে লগইন করে রাখুন।'
            : 'Sign in with your Google account to automatically synchronize and restore your financial data on any device or browser.'}
        </p>

        {currentUser ? (
          <div className="p-4 bg-emerald-50/60 border border-emerald-100 rounded-2xl flex items-center justify-between flex-wrap gap-3">
            <div className="flex items-center gap-3 min-w-0">
              {currentUser.photoURL ? (
                <img src={currentUser.photoURL} alt="" className="w-10 h-10 rounded-full border border-emerald-400 object-cover" />
              ) : (
                <div className="w-10 h-10 rounded-full bg-emerald-600 text-white font-bold flex items-center justify-center text-sm shadow-xs">
                  {currentUser.displayName ? currentUser.displayName[0] : 'U'}
                </div>
              )}
              <div className="min-w-0">
                <p className="text-xs font-bold text-slate-800 truncate">{currentUser.displayName || 'User'}</p>
                <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={async () => {
                  await syncAllToCloudNow();
                  setToastMessage({ text: language === 'bn' ? 'ক্লাউডে সফলভাবে সিঙ্ক সম্পন্ন হয়েছে!' : 'Cloud sync completed!' });
                }}
                disabled={isCloudSyncing}
                className="px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${isCloudSyncing ? 'animate-spin' : ''}`} />
                <span>{language === 'bn' ? 'এখনই সিঙ্ক করুন' : 'Sync Now'}</span>
              </button>
              <button
                onClick={() => setActiveTab('profile')}
                className="px-3 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-200 rounded-xl text-xs font-semibold transition-all cursor-pointer"
              >
                {language === 'bn' ? 'অ্যাকাউন্ট বিবরণ' : 'Manage Account'}
              </button>
            </div>
          </div>
        ) : (
          <div className="p-4 bg-slate-50 border border-slate-200/80 rounded-2xl flex items-center justify-between flex-wrap gap-3">
            <div>
              <p className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'বর্তমানে ডাটা শুধুমাত্র এই ব্রাউজারে সংরক্ষিত' : 'Currently stored in this browser only'}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn'
                  ? 'গুগল দিয়ে লগইন করলে অন্য যেকোনো ডিভাইসেও এই সব ডাটা পাওয়া যাবে।'
                  : 'Log in with Google to access this data from any phone or computer.'}
              </p>
            </div>
            <button
              onClick={() => setActiveTab('profile')}
              className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-2 cursor-pointer"
            >
              <Cloud className="w-4 h-4" />
              <span>{language === 'bn' ? 'গুগল দিয়ে লগইন ও সিঙ্ক' : 'Sign In with Google'}</span>
            </button>
          </div>
        )}
      </div>

      {/* Language & Currency Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-5">
        <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Globe className="w-4 h-4 text-emerald-600" />
          {language === 'bn' ? 'ভাষা ও মুদ্রা পছন্দ' : 'Language & Currency'}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Language Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1.5">
              {language === 'bn' ? 'অ্যাপের ভাষা' : 'Display Language'}
            </label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setLanguage('bn')}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                  language === 'bn'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-900 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                বাংলা (Bengali)
              </button>
              <button
                type="button"
                onClick={() => setLanguage('en')}
                className={`py-2.5 px-3 rounded-xl text-xs font-bold border transition-all ${
                  language === 'en'
                    ? 'border-emerald-500 bg-emerald-50 text-emerald-900 shadow-xs'
                    : 'border-slate-200 hover:bg-slate-50 text-slate-700'
                }`}
              >
                English
              </button>
            </div>
          </div>

          {/* Currency Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1.5">
              {language === 'bn' ? 'ডিফল্ট মুদ্রা' : 'Default Currency'}
            </label>
            <select
              value={currency.code}
              onChange={e => {
                const found = CURRENCIES.find(c => c.code === e.target.value);
                if (found) setCurrency(found);
              }}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            >
              {CURRENCIES.map(curr => (
                <option key={curr.code} value={curr.code}>
                  {curr.symbol} - {curr.name} ({curr.code})
                </option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Multi-Device & PWA Readiness Info Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Smartphone className="w-4 h-4 text-emerald-600" />
          {language === 'bn' ? 'সকল ডিভাইসে ব্যবহার (Phone, Laptop, PC)' : 'Multi-Device & PWA Support'}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-3">
            <Smartphone className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <p className="text-xs font-bold text-slate-800">{language === 'bn' ? 'স্মার্টফোন / মোবাইল' : 'Smartphone'}</p>
              <p className="text-[11px] text-slate-400">{language === 'bn' ? 'বটম বার ও ওয়ান-ট্যাপ নেভিগেশন' : 'Optimized touch navigation'}</p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-3">
            <Laptop className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <p className="text-xs font-bold text-slate-800">{language === 'bn' ? 'ল্যাপটপ' : 'Laptop'}</p>
              <p className="text-[11px] text-slate-400">{language === 'bn' ? 'সাইডবার ও সম্পূর্ণ ড্যাশবোর্ড' : 'Responsive widescreen view'}</p>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-100 flex items-center gap-3">
            <Monitor className="w-6 h-6 text-emerald-600 shrink-0" />
            <div>
              <p className="text-xs font-bold text-slate-800">{language === 'bn' ? 'ডেস্কটপ ও পিসি' : 'Desktop & PC'}</p>
              <p className="text-[11px] text-slate-400">{language === 'bn' ? 'ওয়েব অ্যাপ ও এক্সেল প্রিন্ট রেডি' : 'Printable PDF & keyboard shortcuts'}</p>
            </div>
          </div>
        </div>

        <div className="p-3 rounded-2xl bg-emerald-50 text-emerald-800 text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-600" />
          <span>
            {language === 'bn'
              ? 'মোবাইলে হোম স্ক্রিনে যোগ করতে ব্রাউজার মেন্যু থেকে "Add to Home Screen" বা "Install App" চাপুন।'
              : 'To install on mobile, tap "Add to Home Screen" or "Install App" in your browser menu.'}
          </span>
        </div>
      </div>

      {/* Data Management & Backup Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-4">
        <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <Download className="w-4 h-4 text-emerald-600" />
          {language === 'bn' ? 'ডাটা ব্যাকআপ ও এক্সপোর্ট' : 'Data Management & Backup'}
        </h2>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          
          {/* Export CSV */}
          <button
            onClick={exportCSV}
            className="p-4 rounded-2xl border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/40 text-left transition-all group"
          >
            <Download className="w-5 h-5 text-emerald-600 mb-2 group-hover:scale-110 transition-transform" />
            <h3 className="text-xs font-bold text-slate-800">{t('exportData')}</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn' ? 'এক্সেল বা গুগল শিটে দেখার জন্য' : 'Download spreadsheet file'}
            </p>
          </button>

          {/* Backup JSON */}
          <button
            onClick={exportJSON}
            className="p-4 rounded-2xl border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/40 text-left transition-all group"
          >
            <Download className="w-5 h-5 text-emerald-600 mb-2 group-hover:scale-110 transition-transform" />
            <h3 className="text-xs font-bold text-slate-800">{t('backupData')}</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn' ? 'সকল তথ্য একটি ফাইলে সংরক্ষণ' : 'Full system backup JSON'}
            </p>
          </button>

          {/* Restore JSON */}
          <label className="p-4 rounded-2xl border border-slate-200 hover:border-emerald-300 hover:bg-emerald-50/40 text-left transition-all group cursor-pointer block">
            <Upload className="w-5 h-5 text-emerald-600 mb-2 group-hover:scale-110 transition-transform" />
            <h3 className="text-xs font-bold text-slate-800">{t('restoreData')}</h3>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn' ? 'পূর্বে সংরক্ষিত ব্যাকআপ আনুন' : 'Load from JSON file'}
            </p>
            <input
              ref={fileInputRef}
              type="file"
              accept=".json"
              onChange={handleFileImport}
              className="hidden"
            />
          </label>

        </div>

        {/* One-Tap Reset Section */}
        <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              <p className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'এক ট্যাপে সমস্ত ডেটা রিসেট ও ডিলিট' : 'One-Tap Data Reset'}
              </p>
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn'
                ? 'অ্যাপের সমস্ত লেনদেন, ওয়ালেট ব্যালেন্স ও বাজেট এক ট্যাপে মুছে ০ করে ফেলুন।'
                : 'Erase all transactions, balances, and budgets to start fresh from 0.'}
            </p>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={handleQuickOneTapReset}
              className="px-3.5 py-2 text-xs font-bold text-white bg-rose-600 hover:bg-rose-700 active:scale-95 rounded-xl transition-all flex items-center gap-1.5 shadow-xs cursor-pointer"
              title={language === 'bn' ? 'এক ট্যাপে সব ডেটা মুছুন' : 'One-Tap Reset'}
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'এক ট্যাপে রিসেট' : 'One-Tap Reset'}</span>
            </button>
            <button
              type="button"
              onClick={() => setIsResetModalOpen(true)}
              className="px-3 py-2 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors flex items-center gap-1 cursor-pointer"
              title={language === 'bn' ? 'ব্যাকআপ সহ নিশ্চিত করুন' : 'Confirm with Backup'}
            >
              <RefreshCw className="w-3 h-3 text-slate-500" />
              <span>{language === 'bn' ? 'ব্যাকআপ ও ডায়ালগ' : 'Backup & Reset'}</span>
            </button>
          </div>
        </div>

      </div>

      {/* Progressive Web App (PWA) & Workbox Offline System */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
              <HardDriveDownload className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900">
                {language === 'bn' ? 'অফলাইন মোড ও PWA সার্ভিস ওয়ার্কার' : 'Offline Mode & Workbox Service Worker'}
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'bn'
                  ? 'ইন্টারনেট ছাড়াই সমস্ত খরচ ও হিসাব সংরক্ষণ অব্যাহত থাকবে'
                  : 'Full offline access enabled via Workbox asset precaching'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span
              className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${
                isOnline
                  ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                  : 'bg-amber-50 text-amber-700 border border-amber-200'
              }`}
            >
              {isOnline ? (
                <>
                  <Wifi className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'bn' ? 'অনলাইন' : 'Online'}</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
                  <span>{language === 'bn' ? 'অফলাইন মোড কার্যকর' : 'Offline Mode Active'}</span>
                </>
              )}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'স্ট্যাটিক ক্যাশিং' : 'Static Pre-caching'}
            </p>
            <p className="text-xs font-bold text-slate-800">HTML, CSS, JS & Fonts</p>
            <p className="text-[11px] text-slate-500">
              {language === 'bn'
                ? 'Workbox দ্বারা অ্যাপের মূল অ্যাসেটসমূহ সংরক্ষিত'
                : 'Workbox precaches app bundle & Google fonts'}
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'অফলাইন ডাটা স্টোরেজ' : 'Offline Data Vault'}
            </p>
            <p className="text-xs font-bold text-slate-800">
              {language === 'bn' ? 'লোকাল ব্রাউজার স্টোরেজ' : 'Encrypted Local Storage'}
            </p>
            <p className="text-[11px] text-slate-500">
              {language === 'bn'
                ? 'ইন্টারনেট না থাকলেও প্রতিটি ট্রানজ্যাকশন সেভ থাকে'
                : 'Zero data loss when disconnected'}
            </p>
          </div>

          <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-100 space-y-1">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'স্বয়ংক্রিয় ব্যাকগ্রাউন্ড সিঙ্ক' : 'Auto Cloud Sync'}
            </p>
            <p className="text-xs font-bold text-slate-800">
              {language === 'bn' ? 'পুনরায় সংযোগে আপডেট' : 'Syncs On Reconnect'}
            </p>
            <p className="text-[11px] text-slate-500">
              {language === 'bn'
                ? 'ইন্টারনেট ফিরে এলে ক্লাউডে স্বয়ংক্রিয়ভাবে সিঙ্ক হবে'
                : 'Pushes offline changes when network restores'}
            </p>
          </div>
        </div>

        {/* In-app Install Trigger */}
        <div className="pt-2">
          <PWAInstallButton variant="full" />
        </div>
      </div>
      <div className="bg-slate-50 border border-slate-200/80 rounded-3xl p-5 flex items-start gap-3 text-xs text-slate-600">
        <Shield className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
        <div>
          <p className="font-bold text-slate-800">
            {language === 'bn' ? '১০০% গোপনীয় ও ব্যক্তিগত' : '100% Private & Device-Stored'}
          </p>
          <p className="text-slate-500 mt-0.5 leading-relaxed">
            {language === 'bn'
              ? 'আপনার আর্থিক হিসাব ও তথ্য আপনার ডিভাইসের ব্রাউজারে সুরক্ষিত থাকে। কোনো গোপন তথ্য তৃতীয় পক্ষের সাথে শেয়ার করা হয় না।'
              : 'Your financial information stays saved securely inside your own local browser storage.'}
          </p>
        </div>
      </div>

    </div>
  );
};
