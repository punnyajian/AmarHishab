import React, { useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { Account, AccountType, DigitalCard } from '../../types';
import { CategoryIcon } from '../CategoryIcon';
import { DigitalCardItem } from '../DigitalCardItem';
import { ContactlessTapModal } from '../ContactlessTapModal';
import { AddDigitalCardModal } from '../AddDigitalCardModal';
import {
  Wallet,
  Plus,
  ArrowRightLeft,
  Building2,
  Banknote,
  Smartphone,
  CreditCard,
  PiggyBank,
  Edit2,
  Trash2,
  X,
  History,
  Zap,
  Star,
  ShieldCheck,
  Sparkles,
  Lock,
  Unlock,
  CheckCircle2
} from 'lucide-react';

import { useLockBodyScroll } from '../../utils/useLockBodyScroll';

interface WalletsViewProps {
  onOpenTransferModal: () => void;
}

export const WalletsView: React.FC<WalletsViewProps> = ({ onOpenTransferModal }) => {
  const {
    accounts,
    transactions,
    categories,
    digitalCards,
    addAccount,
    editAccount,
    deleteAccount,
    formatMoney,
    language,
    t,
    totalBalance,
    walletSubTab,
    setWalletSubTab,
  } = useExpense();

  // Active sub-tab: 'cards' (Google Wallet) vs 'accounts' (Bank & Accounts)
  const activeSubTab = walletSubTab;
  const setActiveSubTab = setWalletSubTab;

  // Digital Cards Modal states
  const [isAddCardModalOpen, setIsAddCardModalOpen] = useState(false);
  const [editingCard, setEditingCard] = useState<DigitalCard | null>(null);
  const [tapCard, setTapCard] = useState<DigitalCard | null>(null);
  const [isTapModalOpen, setIsTapModalOpen] = useState(false);
  const [selectedCardHistory, setSelectedCardHistory] = useState<DigitalCard | null>(null);

  // Accounts Modal states
  const [isAddAccountModalOpen, setIsAddAccountModalOpen] = useState(false);
  const [editingAcc, setEditingAcc] = useState<Account | null>(null);
  const [selectedAccHistory, setSelectedAccHistory] = useState<Account | null>(null);

  useLockBodyScroll(!!(selectedCardHistory || selectedAccHistory || isAddAccountModalOpen));

  React.useEffect(() => {
    const hasOpen = selectedCardHistory || selectedAccHistory || isAddAccountModalOpen;
    if (!hasOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        setSelectedCardHistory(null);
        setSelectedAccHistory(null);
        setIsAddAccountModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedCardHistory, selectedAccHistory, isAddAccountModalOpen]);

  // Form states for Account
  const [name, setName] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [type, setType] = useState<AccountType>('bank');
  const [balance, setBalance] = useState('');
  const [color, setColor] = useState('#10b981');
  const [accountNumberLast4, setAccountNumberLast4] = useState('');

  // Handle Account operations
  const handleOpenAddAccount = () => {
    setEditingAcc(null);
    setName('');
    setNameBn('');
    setType('bank');
    setBalance('');
    setColor('#10b981');
    setAccountNumberLast4('');
    setIsAddAccountModalOpen(true);
  };

  const handleOpenEditAccount = (acc: Account) => {
    setEditingAcc(acc);
    setName(acc.name);
    setNameBn(acc.nameBn);
    setType(acc.type);
    setBalance(acc.balance.toString());
    setColor(acc.color);
    setAccountNumberLast4(acc.accountNumberLast4 || '');
    setIsAddAccountModalOpen(true);
  };

  const handleSaveAccount = (e: React.FormEvent) => {
    e.preventDefault();
    const numBalance = parseFloat(balance) || 0;
    if (!name.trim()) return;

    if (editingAcc) {
      editAccount({
        ...editingAcc,
        name: name.trim(),
        nameBn: nameBn.trim() || name.trim(),
        type,
        balance: numBalance,
        color,
        accountNumberLast4: accountNumberLast4.trim() || undefined,
      });
    } else {
      addAccount({
        name: name.trim(),
        nameBn: nameBn.trim() || name.trim(),
        type,
        balance: numBalance,
        initialBalance: numBalance,
        color,
        icon: type === 'bank' ? 'Building2' : type === 'mobile_wallet' ? 'Smartphone' : type === 'credit_card' ? 'CreditCard' : 'Banknote',
        accountNumberLast4: accountNumberLast4.trim() || undefined,
      });
    }

    setIsAddAccountModalOpen(false);
  };

  const getAccountIcon = (type: AccountType) => {
    switch (type) {
      case 'bank':
        return Building2;
      case 'mobile_wallet':
        return Smartphone;
      case 'credit_card':
        return CreditCard;
      case 'savings':
        return PiggyBank;
      default:
        return Banknote;
    }
  };

  // Digital Card Actions
  const handleOpenAddCard = () => {
    setEditingCard(null);
    setIsAddCardModalOpen(true);
  };

  const handleOpenEditCard = (card: DigitalCard) => {
    setEditingCard(card);
    setIsAddCardModalOpen(true);
  };

  const handleTriggerTap = (card: DigitalCard) => {
    setTapCard(card);
    setIsTapModalOpen(true);
  };

  // Default card if set
  const defaultCard = digitalCards.find(c => c.isDefault) || digitalCards[0];

  // Transactions for selected card
  const cardTransactions = selectedCardHistory
    ? transactions.filter(
        t => t.cardId === selectedCardHistory.id || 
             (selectedCardHistory.linkedAccountId && t.accountId === selectedCardHistory.linkedAccountId)
      )
    : [];

  // Transactions for selected account
  const accountTransactions = selectedAccHistory
    ? transactions.filter(
        t => t.accountId === selectedAccHistory.id || t.targetAccountId === selectedAccHistory.id
      )
    : [];

  // Total credit limit and credit spent
  const totalCreditLimit = digitalCards
    .filter(c => c.type === 'credit' && c.creditLimit)
    .reduce((sum, c) => sum + (c.creditLimit || 0), 0);

  const totalCreditSpent = digitalCards
    .filter(c => c.type === 'credit')
    .reduce((sum, c) => sum + (c.currentSpentThisMonth || 0), 0);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* View Header with Sub-tab Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight flex items-center gap-2">
            <span>{language === 'bn' ? 'ওয়ালেট ও কার্ডস' : 'Wallets & Digital Cards'}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {language === 'bn'
              ? 'Google Wallet-এর মতো ভার্চুয়াল/ফিজিক্যাল কার্ড ও ব্যাংক অ্যাকাউন্টের সম্পূর্ণ হিসাব'
              : 'Google Wallet style digital cards and centralized banking overview'}
          </p>
        </div>

        {/* Action Buttons based on active tab */}
        <div className="flex items-center gap-2">
          {activeSubTab === 'cards' ? (
            <>
              {defaultCard && !defaultCard.isFrozen && (
                <button
                  onClick={() => handleTriggerTap(defaultCard)}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-bold text-slate-800 bg-amber-300 hover:bg-amber-400 rounded-xl shadow-xs transition-all active:scale-95"
                >
                  <Zap className="w-3.5 h-3.5 text-slate-950 fill-slate-950" />
                  <span>{language === 'bn' ? 'ট্যাপ পেমেন্ট' : 'Tap to Pay'}</span>
                </button>
              )}
              <button
                onClick={handleOpenAddCard}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-xs transition-colors"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>{language === 'bn' ? 'নতুন কার্ড' : 'Add Card'}</span>
              </button>
            </>
          ) : (
            <>
              <button
                onClick={onOpenTransferModal}
                className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors"
              >
                <ArrowRightLeft className="w-3.5 h-3.5 text-slate-600" />
                <span>{t('transfer')}</span>
              </button>

              <button
                onClick={handleOpenAddAccount}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>{t('addAccount')}</span>
              </button>
            </>
          )}
        </div>
      </div>

      {/* Segmented Top Tabs: Google Wallet vs Bank Accounts */}
      <div className="flex items-center gap-1 p-1 bg-slate-200/70 rounded-2xl max-w-md">
        <button
          onClick={() => setActiveSubTab('cards')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
            activeSubTab === 'cards'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <CreditCard className="w-4 h-4 text-slate-700" />
          <span>{language === 'bn' ? 'Google Wallet (কার্ডসমূহ)' : 'Google Wallet (Cards)'}</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-mono">
            {digitalCards.length}
          </span>
        </button>

        <button
          onClick={() => setActiveSubTab('accounts')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-xl transition-all flex items-center justify-center gap-2 ${
            activeSubTab === 'accounts'
              ? 'bg-white text-slate-900 shadow-xs'
              : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          <Building2 className="w-4 h-4 text-emerald-600" />
          <span>{language === 'bn' ? 'ব্যাংক ও ওয়ালেট' : 'Bank & Wallets'}</span>
          <span className="text-[10px] px-1.5 py-0.5 rounded-full bg-slate-100 text-slate-700 font-mono">
            {accounts.length}
          </span>
        </button>
      </div>

      {/* TAB 1: GOOGLE WALLET DIGITAL CARDS */}
      {activeSubTab === 'cards' && (
        <div className="space-y-6">
          {/* Google Wallet Header Banner */}
          <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-zinc-900 rounded-3xl p-6 text-white shadow-md relative overflow-hidden">
            <div className="absolute right-0 top-0 w-64 h-64 bg-radial from-amber-500/10 via-rose-500/5 to-transparent rounded-full blur-2xl pointer-events-none" />

            <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-[11px] font-bold tracking-wider uppercase text-amber-300 flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    {language === 'bn' ? 'Google Wallet স্টাইল ডিজিটাল পোর্টফোলিও' : 'Google Wallet Digital Portfolio'}
                  </span>
                </div>
                <h2 className="text-2xl sm:text-3xl font-black mt-1 tracking-tight text-white">
                  {digitalCards.length} {language === 'bn' ? 'টি কার্ড সংযুক্ত' : 'Cards Connected'}
                </h2>
                <p className="text-xs text-slate-300 mt-0.5 max-w-lg">
                  {language === 'bn'
                    ? 'আপনার ভিসা, মাস্টারকার্ড, নেক্সাসপে ও ভার্চুয়াল কার্ড সংরক্ষণ করুন। যেকোনো কার্ড দিয়ে কন্ট্যাক্টলেস ট্যাপ পেমেন্ট করুন।'
                    : 'Manage Visa, Mastercard, NexusPay & dual-currency cards with tap-to-pay simulation.'}
                </p>
              </div>

              {/* Quick Card Metrics */}
              <div className="grid grid-cols-2 gap-3 text-left">
                <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
                  <span className="text-[10px] uppercase font-bold text-slate-300 block">
                    {language === 'bn' ? 'চলতি মাসে কার্ড খরচ' : 'Monthly Card Spend'}
                  </span>
                  <span className="text-base sm:text-lg font-black text-amber-300 mt-0.5 block">
                    {formatMoney(totalCreditSpent)}
                  </span>
                </div>

                <div className="bg-white/10 backdrop-blur-xs rounded-2xl p-3 border border-white/10">
                  <span className="text-[10px] uppercase font-bold text-slate-300 block">
                    {language === 'bn' ? 'মোট ক্রেডিট লিমিট' : 'Total Credit Limit'}
                  </span>
                  <span className="text-base sm:text-lg font-black text-white mt-0.5 block">
                    {formatMoney(totalCreditLimit)}
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Cards Grid */}
          {digitalCards.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-3xl p-12 text-center space-y-4">
              <div className="w-16 h-16 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <CreditCard className="w-8 h-8" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-800">
                  {language === 'bn' ? 'কোনো ডিজিটাল কার্ড যোগ করা নেই' : 'No Digital Cards Added'}
                </h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1">
                  {language === 'bn'
                    ? 'Google Wallet-এর মতো আপনার ডেবিট বা ক্রেডিট কার্ড যুক্ত করে সহজেই খরচ পরিচালনা করুন।'
                    : 'Add your debit, credit, or virtual prepaid cards to start managing card payments.'}
                </p>
              </div>
              <button
                onClick={handleOpenAddCard}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl transition-all"
              >
                <Plus className="w-4 h-4" />
                <span>{language === 'bn' ? 'প্রথম কার্ড যুক্ত করুন' : 'Add First Card'}</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {digitalCards.map(card => (
                <DigitalCardItem
                  key={card.id}
                  card={card}
                  onTapToPay={handleTriggerTap}
                  onEdit={handleOpenEditCard}
                  onFilterTransactions={c => setSelectedCardHistory(c)}
                  isDetailedView={true}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: BANK & WALLET ACCOUNTS */}
      {activeSubTab === 'accounts' && (
        <div className="space-y-6">
          {/* Total Balance Banner */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-3xl p-6 text-white shadow-sm flex items-center justify-between">
            <div>
              <span className="text-xs uppercase tracking-wider text-emerald-100 font-semibold flex items-center gap-1.5">
                <Wallet className="w-3.5 h-3.5" />
                {t('totalBalance')}
              </span>
              <div className="text-3xl sm:text-4xl font-black mt-1">
                {formatMoney(totalBalance)}
              </div>
              <span className="text-xs text-emerald-100/90 mt-0.5 block">
                {accounts.length} {language === 'bn' ? 'টি সক্রিয় অ্যাকাউন্ট ও ওয়ালেট' : 'active accounts connected'}
              </span>
            </div>
          </div>

          {/* Wallets Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {accounts.map(acc => {
              const IconComp = getAccountIcon(acc.type);
              const txCount = transactions.filter(
                t => t.accountId === acc.id || t.targetAccountId === acc.id
              ).length;

              return (
                <div
                  key={acc.id}
                  className="bg-white border border-slate-200/80 hover:border-emerald-300 rounded-3xl p-5 shadow-xs transition-all flex flex-col justify-between space-y-4"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-11 h-11 rounded-2xl flex items-center justify-center text-white shadow-xs"
                        style={{ backgroundColor: acc.color }}
                      >
                        <IconComp className="w-5 h-5" />
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-800">
                          {language === 'bn' ? acc.nameBn : acc.name}
                        </h3>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 capitalize">
                          <span>{acc.type.replace('_', ' ')}</span>
                          {acc.accountNumberLast4 && (
                            <span>• •••• {acc.accountNumberLast4}</span>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleOpenEditAccount(acc)}
                        className="p-1.5 text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl transition-colors"
                        title="Edit account"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      {accounts.length > 1 && (
                        <button
                          onClick={() => {
                            if (window.confirm(language === 'bn' ? 'অ্যাকাউন্টটি মুছে ফেলতে চান?' : 'Delete this account?')) {
                              deleteAccount(acc.id);
                            }
                          }}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
                          title="Delete account"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Balance */}
                  <div className="pt-2 border-t border-slate-100 flex items-end justify-between">
                    <div>
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
                        {language === 'bn' ? 'বর্তমান স্থিতি' : 'Current Balance'}
                      </span>
                      <div className="text-xl sm:text-2xl font-black text-slate-900 mt-0.5">
                        {formatMoney(acc.balance)}
                      </div>
                    </div>

                    <button
                      onClick={() => setSelectedAccHistory(acc)}
                      className="px-3 py-1.5 bg-slate-50 hover:bg-emerald-50 text-slate-600 hover:text-emerald-700 rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
                    >
                      <History className="w-3.5 h-3.5" />
                      <span>{txCount} {language === 'bn' ? 'লেনদেন' : 'records'}</span>
                    </button>
                  </div>

                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Card History / Transactions Drawer */}
      {selectedCardHistory && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setSelectedCardHistory(null);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-lg w-full max-h-[88dvh] sm:max-h-[85vh] flex flex-col shadow-2xl overflow-hidden pb-[calc(env(safe-area-inset-bottom,0px)+1rem)] sm:pb-0"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden mt-3 mb-1" />
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-800">
                  {selectedCardHistory.issuerName}
                </h3>
                <p className="text-xs text-slate-500">
                  {selectedCardHistory.cardNumberMasked} • {language === 'bn' ? 'কার্ড দিয়ে মোট লেনদেন:' : 'Transactions with this card:'} {cardTransactions.length}
                </p>
              </div>
              <button
                onClick={() => setSelectedCardHistory(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto flex-1 divide-y divide-slate-100">
              {cardTransactions.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  {language === 'bn' ? 'এই কার্ডের মাধ্যমে এখনো কোনো লেনদেন হয়নি।' : 'No transactions recorded for this card.'}
                </div>
              ) : (
                cardTransactions.map(t => {
                  const cat = categories.find(c => c.id === t.categoryId);
                  return (
                    <div key={t.id} className="py-3 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-8 h-8 rounded-xl flex items-center justify-center"
                          style={{
                            backgroundColor: `${cat?.color || '#10b981'}15`,
                            color: cat?.color || '#10b981',
                          }}
                        >
                          <CategoryIcon iconName={cat?.icon || 'CreditCard'} size={16} />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800">
                            {t.note || (cat ? (language === 'bn' ? cat.nameBn : cat.name) : 'Card Transaction')}
                          </p>
                          <p className="text-[10px] text-slate-400">{t.date} • {t.time || ''}</p>
                        </div>
                      </div>
                      <div className="text-xs font-bold text-rose-600">
                        -{formatMoney(t.amount)}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Account History Drawer */}
      {selectedAccHistory && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setSelectedAccHistory(null);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-lg w-full max-h-[88dvh] sm:max-h-[85vh] flex flex-col shadow-2xl overflow-hidden pb-[calc(env(safe-area-inset-bottom,0px)+1rem)] sm:pb-0"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden mt-3 mb-1" />
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <div>
                <h3 className="font-bold text-base text-slate-800">
                  {language === 'bn' ? selectedAccHistory.nameBn : selectedAccHistory.name}
                </h3>
                <p className="text-xs text-slate-500">
                  {language === 'bn' ? 'ব্যালেন্স:' : 'Balance:'} {formatMoney(selectedAccHistory.balance)}
                </p>
              </div>
              <button
                onClick={() => setSelectedAccHistory(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-5 overflow-y-auto flex-1 divide-y divide-slate-100">
              {accountTransactions.length === 0 ? (
                <div className="text-center py-8 text-xs text-slate-400">
                  {language === 'bn' ? 'এই অ্যাকাউন্টে কোনো লেনদেন নেই।' : 'No transactions in this account.'}
                </div>
              ) : (
                accountTransactions.map(t => {
                  const cat = categories.find(c => c.id === t.categoryId);
                  const isExp = t.type === 'expense';
                  const isInc = t.type === 'income';

                  return (
                    <div key={t.id} className="py-3 flex items-center justify-between">
                      <div className="flex items-center gap-2.5">
                        <div
                          className="w-8 h-8 rounded-xl flex items-center justify-center"
                          style={{
                            backgroundColor: `${cat?.color || '#10b981'}15`,
                            color: cat?.color || '#10b981',
                          }}
                        >
                          <CategoryIcon iconName={cat?.icon || 'CircleDot'} size={16} />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-800">
                            {t.note || (cat ? (language === 'bn' ? cat.nameBn : cat.name) : 'Transaction')}
                          </p>
                          <p className="text-[10px] text-slate-400">{t.date} • {t.time || ''}</p>
                        </div>
                      </div>
                      <div className={`text-xs font-bold ${isExp ? 'text-rose-600' : isInc ? 'text-emerald-700' : 'text-sky-600'}`}>
                        {isExp ? '-' : isInc ? '+' : ''}{formatMoney(t.amount)}
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Account Modal */}
      {isAddAccountModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddAccountModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[88dvh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {editingAcc
                  ? (language === 'bn' ? 'অ্যাকাউন্ট সম্পাদনা' : 'Edit Account')
                  : (language === 'bn' ? 'নতুন অ্যাকাউন্ট যোগ করুন' : 'Add New Account')}
              </h3>
              <button
                onClick={() => setIsAddAccountModalOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveAccount} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {t('accountName')}
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'bn' ? 'যেমন: ব্র্যাক ব্যাংক, বা নগদ' : 'e.g. BRAC Bank, bKash, Cash'}
                  value={name}
                  onChange={e => {
                    setName(e.target.value);
                    if (!nameBn) setNameBn(e.target.value);
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'অ্যাকাউন্টের ধরন' : 'Account Type'}
                  </label>
                  <select
                    value={type}
                    onChange={e => setType(e.target.value as AccountType)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  >
                    <option value="bank">{language === 'bn' ? 'ব্যাংক একাউন্ট' : 'Bank Account'}</option>
                    <option value="mobile_wallet">{language === 'bn' ? 'মোবাইল ওয়ালেট (বিকাশ/নগদ)' : 'Mobile Wallet'}</option>
                    <option value="cash">{language === 'bn' ? 'হাতে নগদ ক্যাশ' : 'Cash in Hand'}</option>
                    <option value="credit_card">{language === 'bn' ? 'ক্রেডিট কার্ড' : 'Credit Card'}</option>
                    <option value="savings">{language === 'bn' ? 'সঞ্চয়ী ভল্ট' : 'Savings'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ব্যালেন্স' : 'Current Balance'}
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    placeholder="0"
                    value={balance}
                    onChange={e => setBalance(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'অ্যাকাউন্ট বা কার্ডের শেষ ৪ ডিজিট (ঐচ্ছিক)' : 'Last 4 Digits (Optional)'}
                </label>
                <input
                  type="text"
                  maxLength={4}
                  placeholder="e.g. 4821"
                  value={accountNumberLast4}
                  onChange={e => setAccountNumberLast4(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'রং নির্বাচন' : 'Accent Color'}
                </label>
                <div className="flex gap-2">
                  {['#10b981', '#059669', '#0284c7', '#e11d48', '#ea580c', '#8b5cf6', '#64748b'].map(c => (
                    <button
                      key={c}
                      type="button"
                      onClick={() => setColor(c)}
                      className={`w-7 h-7 rounded-full border-2 transition-transform ${
                        color === c ? 'scale-110 border-slate-900' : 'border-transparent'
                      }`}
                      style={{ backgroundColor: c }}
                    />
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddAccountModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add / Edit Digital Card Modal */}
      <AddDigitalCardModal
        isOpen={isAddCardModalOpen}
        onClose={() => {
          setIsAddCardModalOpen(false);
          setEditingCard(null);
        }}
        editCard={editingCard}
      />

      {/* Contactless Tap to Pay Simulator Modal */}
      <ContactlessTapModal
        isOpen={isTapModalOpen}
        onClose={() => {
          setIsTapModalOpen(false);
          setTapCard(null);
        }}
        card={tapCard}
      />

    </div>
  );
};
