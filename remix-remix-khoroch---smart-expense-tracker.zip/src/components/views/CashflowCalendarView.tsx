import React, { useState, useMemo } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import {
  Calendar as CalendarIcon,
  ChevronLeft,
  ChevronRight,
  TrendingDown,
  TrendingUp,
  Receipt,
  CreditCard,
  AlertCircle,
  CheckCircle2,
  Clock,
  Plus,
  Zap,
  Home,
  Flame,
  Droplets,
  Wifi,
  Tv,
  Smartphone,
  Building2,
  HandCoins,
  ArrowRight,
  Sparkles,
  Info,
  CalendarCheck,
  X,
} from 'lucide-react';
import { SubscriptionBill, Debt, Transaction } from '../../types';

interface CashflowCalendarViewProps {
  onOpenAddModal?: (date?: string) => void;
}

export const CashflowCalendarView: React.FC<CashflowCalendarViewProps> = ({ onOpenAddModal }) => {
  const {
    transactions,
    subscriptions,
    debts,
    categories,
    accounts,
    formatMoney,
    currency,
    language,
    paySubscriptionBill,
    recordDebtPayment,
    toggleDebtSettled,
  } = useExpense();

  // Current selected month & year (0-indexed month)
  const today = new Date();
  const [currentYear, setCurrentYear] = useState<number>(today.getFullYear());
  const [currentMonth, setCurrentMonth] = useState<number>(today.getMonth()); // 0 = Jan, 9 = Oct

  // Selected date for day detail drill-down (YYYY-MM-DD)
  const todayDateString = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, '0')}-${String(today.getDate()).padStart(2, '0')}`;
  const [selectedDate, setSelectedDate] = useState<string>(todayDateString);

  // Active view tab: 'calendar' or 'timeline'
  const [activeTabMode, setActiveTabMode] = useState<'calendar' | 'timeline'>('calendar');

  // Timeline filter
  const [timelineFilter, setTimelineFilter] = useState<'all' | 'unpaid' | 'debts' | 'paid'>('all');

  // Payment feedback toast
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Month navigation
  const handlePrevMonth = () => {
    if (currentMonth === 0) {
      setCurrentMonth(11);
      setCurrentYear(prev => prev - 1);
    } else {
      setCurrentMonth(prev => prev - 1);
    }
  };

  const handleNextMonth = () => {
    if (currentMonth === 11) {
      setCurrentMonth(0);
      setCurrentYear(prev => prev + 1);
    } else {
      setCurrentMonth(prev => prev + 1);
    }
  };

  const handleJumpToToday = () => {
    setCurrentYear(today.getFullYear());
    setCurrentMonth(today.getMonth());
    setSelectedDate(todayDateString);
  };

  // Month names
  const monthNamesBn = [
    'জানুয়ারি', 'ফেব্রুয়ারি', 'মার্চ', 'এপ্রিল', 'মে', 'জুন',
    'জুলাই', 'আগস্ট', 'সেপ্টেম্বর', 'অক্টোবর', 'নভেম্বর', 'ডিসেম্বর'
  ];
  const monthNamesEn = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const currentMonthName = language === 'bn' ? monthNamesBn[currentMonth] : monthNamesEn[currentMonth];

  // Helper to format English/Bengali numbers
  const formatNum = (num: number | string) => {
    if (language !== 'bn') return num.toString();
    const bnDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toString().replace(/\d/g, d => bnDigits[parseInt(d, 10)]);
  };

  // Week days
  const weekDaysBn = ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'];
  const weekDaysEn = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const weekDays = language === 'bn' ? weekDaysBn : weekDaysEn;

  // Days in current month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  // First day of month (0 = Sun, 1 = Mon, ..., 6 = Sat)
  const firstDayOfWeek = new Date(currentYear, currentMonth, 1).getDay();

  // Prefix for matching date strings: "YYYY-MM"
  const currentMonthPrefix = `${currentYear}-${String(currentMonth + 1).padStart(2, '0')}`;

  // Transactions in current month
  const monthTransactions = useMemo(() => {
    return transactions.filter(t => t.date && t.date.startsWith(currentMonthPrefix));
  }, [transactions, currentMonthPrefix]);

  // Aggregate spending & income by day
  const dailyMetrics = useMemo(() => {
    const map: Record<string, { expense: number; income: number; count: number }> = {};
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${currentMonthPrefix}-${String(day).padStart(2, '0')}`;
      map[dateStr] = { expense: 0, income: 0, count: 0 };
    }

    monthTransactions.forEach(t => {
      if (map[t.date]) {
        if (t.type === 'expense') {
          map[t.date].expense += t.amount;
          map[t.date].count += 1;
        } else if (t.type === 'income') {
          map[t.date].income += t.amount;
        }
      }
    });

    return map;
  }, [monthTransactions, currentMonthPrefix, daysInMonth]);

  // Total month expense & income
  const totalMonthExpense = useMemo(() => {
    return monthTransactions
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [monthTransactions]);

  const totalMonthIncome = useMemo(() => {
    return monthTransactions
      .filter(t => t.type === 'income')
      .reduce((sum, t) => sum + t.amount, 0);
  }, [monthTransactions]);

  // Daily average expense for non-zero days
  const averageDailyExpense = useMemo(() => {
    const expenseDays = Object.values(dailyMetrics).filter(d => d.expense > 0);
    if (expenseDays.length === 0) return 0;
    return totalMonthExpense / expenseDays.length;
  }, [dailyMetrics, totalMonthExpense]);

  // Bills due in this month
  const monthBills = useMemo(() => {
    return subscriptions.filter(s => {
      if (!s.dueDate) return false;
      // Match if dueDate is in this month
      return s.dueDate.startsWith(currentMonthPrefix);
    });
  }, [subscriptions, currentMonthPrefix]);

  // Map bills by date
  const billsByDate = useMemo(() => {
    const map: Record<string, SubscriptionBill[]> = {};
    monthBills.forEach(b => {
      if (!map[b.dueDate]) map[b.dueDate] = [];
      map[b.dueDate].push(b);
    });
    return map;
  }, [monthBills]);

  // Debts / EMI due in this month
  const monthDebts = useMemo(() => {
    return debts.filter(d => {
      if (!d.dueDate) return false;
      return d.dueDate.startsWith(currentMonthPrefix);
    });
  }, [debts, currentMonthPrefix]);

  // Map debts by date
  const debtsByDate = useMemo(() => {
    const map: Record<string, Debt[]> = {};
    monthDebts.forEach(d => {
      if (!map[d.dueDate]) map[d.dueDate] = [];
      map[d.dueDate].push(d);
    });
    return map;
  }, [monthDebts]);

  // Helper to check if a bill is paid for the current month
  const isBillPaid = (bill: SubscriptionBill, monthPrefix: string = currentMonthPrefix) => {
    return !!(bill.lastPaidDate && bill.lastPaidDate.startsWith(monthPrefix));
  };

  // Total upcoming unpaid bills in month
  const unpaidBillsSum = useMemo(() => {
    return monthBills
      .filter(b => !isBillPaid(b))
      .reduce((sum, b) => sum + b.amount, 0);
  }, [monthBills, currentMonthPrefix]);

  const unpaidDebtsSum = useMemo(() => {
    return monthDebts
      .filter(d => !d.settled && d.type === 'borrowed')
      .reduce((sum, d) => sum + (d.amount - (d.paidAmount || 0)), 0);
  }, [monthDebts]);

  // Selected Day Details
  const selectedDayMetrics = dailyMetrics[selectedDate] || { expense: 0, income: 0, count: 0 };
  const selectedDayTransactions = useMemo(() => {
    return transactions.filter(t => t.date === selectedDate);
  }, [transactions, selectedDate]);
  const selectedDayBills = billsByDate[selectedDate] || [];
  const selectedDayDebts = debtsByDate[selectedDate] || [];

  // Parse selected date for readable header
  const selectedDateObj = new Date(selectedDate);
  const formattedSelectedDate = isNaN(selectedDateObj.getTime())
    ? selectedDate
    : selectedDateObj.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
        weekday: 'long',
        day: 'numeric',
        month: 'long',
        year: 'numeric',
      });

  // Heatmap Color helper
  const getHeatmapColor = (expense: number) => {
    if (expense === 0) {
      return 'bg-white hover:bg-slate-50 border-slate-200/80 text-slate-700';
    }
    if (expense < averageDailyExpense * 0.6) {
      return 'bg-emerald-50/80 hover:bg-emerald-100/80 border-emerald-200/90 text-emerald-950';
    }
    if (expense <= averageDailyExpense * 1.3) {
      return 'bg-teal-50/90 hover:bg-teal-100 border-teal-300 text-teal-950';
    }
    if (expense <= averageDailyExpense * 2.2) {
      return 'bg-amber-50 hover:bg-amber-100 border-amber-300 text-amber-950';
    }
    // High spike
    return 'bg-rose-50 hover:bg-rose-100 border-rose-300 text-rose-950 font-bold';
  };

  // Bill category icon resolver
  const getBillIcon = (cat: string) => {
    switch (cat) {
      case 'electricity':
        return <Zap className="w-3.5 h-3.5 text-amber-500" />;
      case 'gas':
        return <Flame className="w-3.5 h-3.5 text-orange-500" />;
      case 'water':
        return <Droplets className="w-3.5 h-3.5 text-cyan-500" />;
      case 'internet':
        return <Wifi className="w-3.5 h-3.5 text-blue-500" />;
      case 'streaming':
        return <Tv className="w-3.5 h-3.5 text-indigo-500" />;
      case 'mobile':
        return <Smartphone className="w-3.5 h-3.5 text-emerald-500" />;
      case 'rent':
        return <Home className="w-3.5 h-3.5 text-rose-500" />;
      default:
        return <Receipt className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  // Direct Pay Action
  const handlePayBill = (bill: SubscriptionBill) => {
    const res = paySubscriptionBill(bill.id);
    if (res.success) {
      showToast(language === 'bn' ? `“${bill.name}” বিল পরিশোধ সম্পন্ন হয়েছে!` : `"${bill.name}" marked as paid!`);
    } else {
      showToast(res.message);
    }
  };

  // Combined timeline items for this month
  const timelineItems = useMemo(() => {
    const items: Array<{
      type: 'bill' | 'debt';
      date: string;
      title: string;
      subtitle: string;
      amount: number;
      isPaid: boolean;
      rawBill?: SubscriptionBill;
      rawDebt?: Debt;
      category?: string;
    }> = [];

    monthBills.forEach(b => {
      items.push({
        type: 'bill',
        date: b.dueDate,
        title: language === 'bn' ? (b.nameBn || b.name) : b.name,
        subtitle: b.providerName || b.category,
        amount: b.amount,
        isPaid: isBillPaid(b),
        rawBill: b,
        category: b.category,
      });
    });

    monthDebts.forEach(d => {
      items.push({
        type: 'debt',
        date: d.dueDate,
        title: d.personName,
        subtitle: d.type === 'borrowed' ? (language === 'bn' ? 'দেনা / ঋণের কিস্তি' : 'Loan / EMI') : (language === 'bn' ? 'পাওনা টাকা' : 'Lent money'),
        amount: d.amount - (d.paidAmount || 0),
        isPaid: d.settled,
        rawDebt: d,
      });
    });

    // Sort chronologically by date
    items.sort((a, b) => a.date.localeCompare(b.date));

    // Apply filter
    if (timelineFilter === 'unpaid') {
      return items.filter(i => !i.isPaid && i.type === 'bill');
    }
    if (timelineFilter === 'debts') {
      return items.filter(i => i.type === 'debt');
    }
    if (timelineFilter === 'paid') {
      return items.filter(i => i.isPaid);
    }

    return items;
  }, [monthBills, monthDebts, timelineFilter, language]);

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-18 right-4 sm:right-8 z-50 bg-slate-900 text-white text-xs font-semibold px-4 py-2.5 rounded-xl shadow-xl flex items-center gap-2 animate-in slide-in-from-top-2 duration-150">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs">
        <div className="space-y-1">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center shadow-xs">
              <CalendarIcon className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-extrabold text-slate-900 tracking-tight">
                {language === 'bn' ? 'ক্যাশফ্লো ও বিল ক্যালেন্ডার' : 'Cashflow & Bills Calendar'}
              </h1>
              <p className="text-xs text-slate-500 font-medium">
                {language === 'bn'
                  ? 'দৈনিক খরচের হিটম্যাপ ও আসন্ন ইউটিলিটি বিল, বাসা ভাড়া এবং ঋণের কিস্তি (EMI) ট্র্যাকার'
                  : 'Daily expense heatmap & timeline of upcoming utility bills, rent, and loan EMI payments'}
              </p>
            </div>
          </div>
        </div>

        {/* View Switcher & Month Navigation */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Calendar / Timeline toggle */}
          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-200/80">
            <button
              type="button"
              onClick={() => setActiveTabMode('calendar')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTabMode === 'calendar'
                  ? 'bg-white text-emerald-800 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'হিটম্যাপ ক্যালেন্ডার' : 'Heatmap Calendar'}
            </button>
            <button
              type="button"
              onClick={() => setActiveTabMode('timeline')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                activeTabMode === 'timeline'
                  ? 'bg-white text-emerald-800 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'বিল টাইমলাইন' : 'Dues Timeline'}
            </button>
          </div>

          {/* Month Controls */}
          <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl px-2 py-1">
            <button
              type="button"
              onClick={handlePrevMonth}
              className="p-1 rounded-lg text-slate-600 hover:bg-slate-200/70 transition-colors cursor-pointer"
              title={language === 'bn' ? 'পূর্ববর্তী মাস' : 'Previous Month'}
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <span className="text-xs font-extrabold text-slate-800 px-1 min-w-[110px] text-center">
              {currentMonthName} {formatNum(currentYear)}
            </span>

            <button
              type="button"
              onClick={handleNextMonth}
              className="p-1 rounded-lg text-slate-600 hover:bg-slate-200/70 transition-colors cursor-pointer"
              title={language === 'bn' ? 'পরবর্তী মাস' : 'Next Month'}
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              type="button"
              onClick={handleJumpToToday}
              className="text-[10px] font-bold px-2 py-1 rounded-md bg-emerald-600 text-white hover:bg-emerald-700 transition-colors ml-1 cursor-pointer"
            >
              {language === 'bn' ? 'আজ' : 'Today'}
            </button>
          </div>
        </div>
      </div>

      {/* Summary KPI Cards for Active Month */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Month Expense */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? 'মাসের মোট খরচ' : 'Monthly Spent'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center">
              <TrendingDown className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-slate-900 tracking-tight">
            {formatMoney(totalMonthExpense)}
          </div>
          <p className="text-[10px] text-slate-400">
            {language === 'bn'
              ? `দৈনিক গড়: ${formatMoney(Math.round(averageDailyExpense))}`
              : `Daily Avg: ${formatMoney(Math.round(averageDailyExpense))}`}
          </p>
        </div>

        {/* Month Income */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? 'মাসের মোট আয়' : 'Monthly Income'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-emerald-700 tracking-tight">
            {formatMoney(totalMonthIncome)}
          </div>
          <p className="text-[10px] text-slate-400">
            {language === 'bn'
              ? `নেট সঞ্চয়: ${formatMoney(totalMonthIncome - totalMonthExpense)}`
              : `Net Savings: ${formatMoney(totalMonthIncome - totalMonthExpense)}`}
          </p>
        </div>

        {/* Upcoming Bills & Rent */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? 'বকেয়া বিল ও ভাড়া' : 'Unpaid Bills & Rent'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-cyan-50 text-cyan-600 flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-cyan-800 tracking-tight">
            {formatMoney(unpaidBillsSum)}
          </div>
          <p className="text-[10px] text-slate-400">
            {language === 'bn'
              ? `${formatNum(monthBills.filter(b => !isBillPaid(b)).length)} টি বিল প্রদেয়`
              : `${monthBills.filter(b => !isBillPaid(b)).length} bills due`}
          </p>
        </div>

        {/* Upcoming Debts & EMI */}
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs space-y-1">
          <div className="flex items-center justify-between text-slate-400">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? 'আসন্ন ঋণের কিস্তি/দেনা' : 'Debts & EMI Due'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center">
              <HandCoins className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-xl font-extrabold text-amber-800 tracking-tight">
            {formatMoney(unpaidDebtsSum)}
          </div>
          <p className="text-[10px] text-slate-400">
            {language === 'bn'
              ? `${formatNum(monthDebts.filter(d => !d.settled && d.type === 'borrowed').length)} টি কিস্তি প্রদেয়`
              : `${monthDebts.filter(d => !d.settled && d.type === 'borrowed').length} installments due`}
          </p>
        </div>
      </div>

      {/* Main Content Area based on activeTabMode */}
      {activeTabMode === 'calendar' ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Heatmap Calendar Grid (8 cols) */}
          <div className="lg:col-span-8 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
            {/* Heatmap Legend */}
            <div className="flex flex-wrap items-center justify-between gap-3 text-[11px] pb-2 border-b border-slate-100">
              <span className="font-bold text-slate-500">
                {language === 'bn' ? 'খরচের ইনটেনসিটি ও নির্দেশিকা:' : 'Spending Intensity Legend:'}
              </span>
              <div className="flex items-center gap-3 text-[10px] text-slate-600">
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-md bg-white border border-slate-300 inline-block" />
                  {language === 'bn' ? '০ টাকা' : '৳0'}
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-md bg-emerald-100 border border-emerald-300 inline-block" />
                  {language === 'bn' ? 'স্বাভাবিক' : 'Low'}
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-md bg-amber-100 border border-amber-300 inline-block" />
                  {language === 'bn' ? 'মাঝারি' : 'Medium'}
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-3 h-3 rounded-md bg-rose-100 border border-rose-300 inline-block" />
                  {language === 'bn' ? 'অতিরিক্ত' : 'High Spike'}
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-cyan-500 inline-block" />
                  {language === 'bn' ? 'বিল/ভাড়া' : 'Bills'}
                </span>
                <span className="flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-amber-500 inline-block" />
                  {language === 'bn' ? 'কিস্তি' : 'EMI'}
                </span>
              </div>
            </div>

            {/* Days of week Header */}
            <div className="grid grid-cols-7 gap-1.5 text-center">
              {weekDays.map((wDay, idx) => (
                <div
                  key={`wd-${idx}`}
                  className="py-1.5 text-xs font-bold text-slate-400 uppercase tracking-wider"
                >
                  {wDay}
                </div>
              ))}
            </div>

            {/* Calendar Days Matrix */}
            <div className="grid grid-cols-7 gap-1.5 sm:gap-2">
              {/* Padding days before month starts */}
              {Array.from({ length: firstDayOfWeek }).map((_, padIdx) => (
                <div
                  key={`pad-${padIdx}`}
                  className="min-h-[72px] sm:min-h-[88px] rounded-2xl bg-slate-50/40 border border-transparent"
                />
              ))}

              {/* Month Days */}
              {Array.from({ length: daysInMonth }).map((_, dayIndex) => {
                const dayNum = dayIndex + 1;
                const dateStr = `${currentMonthPrefix}-${String(dayNum).padStart(2, '0')}`;
                const metrics = dailyMetrics[dateStr] || { expense: 0, income: 0, count: 0 };
                const dayBills = billsByDate[dateStr] || [];
                const dayDebts = debtsByDate[dateStr] || [];
                const isToday = dateStr === todayDateString;
                const isSelected = dateStr === selectedDate;
                const heatmapClass = getHeatmapColor(metrics.expense);

                return (
                  <button
                    key={dateStr}
                    type="button"
                    onClick={() => setSelectedDate(dateStr)}
                    className={`min-h-[76px] sm:min-h-[92px] p-1.5 sm:p-2 rounded-2xl border text-left flex flex-col justify-between transition-all relative group cursor-pointer ${heatmapClass} ${
                      isSelected
                        ? 'ring-2 ring-emerald-600 ring-offset-1 shadow-md scale-[1.02] z-10'
                        : 'hover:shadow-xs'
                    }`}
                  >
                    {/* Top Row: Date number & Today tag */}
                    <div className="flex items-center justify-between w-full">
                      <span
                        className={`text-xs sm:text-sm font-extrabold flex items-center justify-center ${
                          isToday
                            ? 'w-6 h-6 rounded-full bg-emerald-600 text-white shadow-2xs'
                            : 'text-slate-800'
                        }`}
                      >
                        {formatNum(dayNum)}
                      </span>

                      {/* Indicator dots for bills or debts */}
                      <div className="flex items-center gap-1">
                        {dayBills.length > 0 && (
                          <span
                            className="w-2 h-2 rounded-full bg-cyan-500 animate-pulse"
                            title={language === 'bn' ? `${formatNum(dayBills.length)}টি বিল প্রদেয়` : `${dayBills.length} bill(s) due`}
                          />
                        )}
                        {dayDebts.length > 0 && (
                          <span
                            className="w-2 h-2 rounded-full bg-amber-500"
                            title={language === 'bn' ? `${formatNum(dayDebts.length)}টি কিস্তি প্রদেয়` : `${dayDebts.length} loan/EMI due`}
                          />
                        )}
                        {metrics.income > 0 && (
                          <span
                            className="w-2 h-2 rounded-full bg-emerald-500"
                            title={language === 'bn' ? 'আয় যোগ হয়েছে' : 'Income received'}
                          />
                        )}
                      </div>
                    </div>

                    {/* Middle: Scheduled Bill/Debt Mini Badges if any */}
                    <div className="space-y-0.5 my-1 overflow-hidden">
                      {dayBills.slice(0, 1).map(bill => (
                        <div
                          key={`b-preview-${bill.id}`}
                          className={`text-[9px] font-bold px-1 py-0.5 rounded truncate flex items-center gap-1 ${
                            isBillPaid(bill)
                              ? 'bg-emerald-100/80 text-emerald-800'
                              : 'bg-cyan-100 text-cyan-900 border border-cyan-200'
                          }`}
                        >
                          <span className="truncate">{bill.name}</span>
                        </div>
                      ))}

                      {dayDebts.slice(0, 1).map(debt => (
                        <div
                          key={`d-preview-${debt.id}`}
                          className={`text-[9px] font-bold px-1 py-0.5 rounded truncate flex items-center gap-1 ${
                            debt.settled
                              ? 'bg-emerald-100/80 text-emerald-800'
                              : 'bg-amber-100 text-amber-900 border border-amber-200'
                          }`}
                        >
                          <span className="truncate">{debt.personName}</span>
                        </div>
                      ))}
                    </div>

                    {/* Bottom: Expense Amount */}
                    <div className="w-full text-right">
                      {metrics.expense > 0 ? (
                        <span className="text-[10px] sm:text-xs font-black tracking-tight block truncate">
                          {formatMoney(metrics.expense)}
                        </span>
                      ) : (
                        <span className="text-[10px] text-slate-300 font-semibold">
                          {language === 'bn' ? '০' : '0'}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Right: Selected Day Deep-Dive Detail (4 cols) */}
          <div className="lg:col-span-4 bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-5 sticky top-20">
            {/* Day Header */}
            <div className="flex items-start justify-between border-b border-slate-100 pb-3">
              <div>
                <span className="text-[10px] font-bold uppercase tracking-wider text-emerald-700">
                  {language === 'bn' ? 'নির্বাচিত তারিখের খতিয়ান' : 'Selected Date Details'}
                </span>
                <h3 className="text-base font-extrabold text-slate-900 capitalize leading-snug">
                  {formattedSelectedDate}
                </h3>
              </div>
              {onOpenAddModal && (
                <button
                  type="button"
                  onClick={() => onOpenAddModal(selectedDate)}
                  className="flex items-center gap-1 px-2.5 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/80 rounded-xl text-xs font-bold transition-colors cursor-pointer"
                  title={language === 'bn' ? 'এই তারিখে খরচ যোগ করুন' : 'Add expense on this date'}
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'যোগ' : 'Add'}</span>
                </button>
              )}
            </div>

            {/* Day Quick Stats */}
            <div className="grid grid-cols-2 gap-2 bg-slate-50 p-3 rounded-2xl border border-slate-100">
              <div>
                <span className="text-[10px] font-semibold text-slate-400">
                  {language === 'bn' ? 'মোট খরচ' : 'Total Spent'}
                </span>
                <div className="text-sm font-extrabold text-slate-900">
                  {formatMoney(selectedDayMetrics.expense)}
                </div>
              </div>
              <div>
                <span className="text-[10px] font-semibold text-slate-400">
                  {language === 'bn' ? 'মোট আয়' : 'Total Income'}
                </span>
                <div className="text-sm font-extrabold text-emerald-700">
                  {formatMoney(selectedDayMetrics.income)}
                </div>
              </div>
            </div>

            {/* Scheduled Bills Due on this day */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                <span className="flex items-center gap-1.5">
                  <Zap className="w-3.5 h-3.5 text-cyan-600" />
                  <span>{language === 'bn' ? 'প্রদেয় ইউটিলিটি ও বিল' : 'Scheduled Bills Due'}</span>
                </span>
                <span className="text-[10px] text-slate-400">
                  ({formatNum(selectedDayBills.length)})
                </span>
              </div>

              {selectedDayBills.length === 0 ? (
                <div className="p-3 bg-slate-50/60 rounded-xl border border-dashed border-slate-200 text-center text-xs text-slate-400 font-medium">
                  {language === 'bn' ? 'এই তারিখে কোনো বিলের তারিখ নেই।' : 'No bills due on this date.'}
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedDayBills.map(bill => (
                    <div
                      key={bill.id}
                      className="p-3 bg-cyan-50/60 border border-cyan-200/80 rounded-2xl space-y-2"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded-xl bg-cyan-100 flex items-center justify-center shrink-0">
                            {getBillIcon(bill.category)}
                          </div>
                          <div>
                            <div className="text-xs font-bold text-slate-900 leading-snug">
                              {language === 'bn' ? (bill.nameBn || bill.name) : bill.name}
                            </div>
                            <span className="text-[10px] text-slate-500 capitalize">
                              {bill.providerName || bill.category}
                            </span>
                          </div>
                        </div>

                        <div className="text-right">
                          <div className="text-xs font-black text-cyan-950">
                            {formatMoney(bill.amount)}
                          </div>
                          <span
                            className={`text-[9px] font-extrabold px-1.5 py-0.5 rounded-full inline-block ${
                              isBillPaid(bill)
                                ? 'bg-emerald-100 text-emerald-800'
                                : 'bg-rose-100 text-rose-800'
                            }`}
                          >
                            {isBillPaid(bill)
                              ? (language === 'bn' ? 'পরিশোধিত' : 'Paid')
                              : (language === 'bn' ? 'বকেয়া' : 'Unpaid')}
                          </span>
                        </div>
                      </div>

                      {!isBillPaid(bill) && (
                        <button
                          type="button"
                          onClick={() => handlePayBill(bill)}
                          className="w-full py-1.5 px-3 bg-cyan-600 hover:bg-cyan-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-2xs cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'এখনই পে করুন' : 'Pay Now'}</span>
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Scheduled Debts & EMI Due on this day */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                <span className="flex items-center gap-1.5">
                  <HandCoins className="w-3.5 h-3.5 text-amber-600" />
                  <span>{language === 'bn' ? 'ঋণের কিস্তি / দেনা-পাওনা' : 'Loans & EMI Due'}</span>
                </span>
                <span className="text-[10px] text-slate-400">
                  ({formatNum(selectedDayDebts.length)})
                </span>
              </div>

              {selectedDayDebts.length === 0 ? (
                <div className="p-3 bg-slate-50/60 rounded-xl border border-dashed border-slate-200 text-center text-xs text-slate-400 font-medium">
                  {language === 'bn' ? 'এই তারিখে কোনো কিস্তির তারিখ নেই।' : 'No loan/EMI installments due.'}
                </div>
              ) : (
                <div className="space-y-2">
                  {selectedDayDebts.map(debt => (
                    <div
                      key={debt.id}
                      className="p-3 bg-amber-50/60 border border-amber-200/80 rounded-2xl flex items-center justify-between"
                    >
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
                          <HandCoins className="w-3.5 h-3.5" />
                        </div>
                        <div>
                          <div className="text-xs font-bold text-slate-900 leading-snug">
                            {debt.personName}
                          </div>
                          <span className="text-[10px] text-amber-800 font-medium">
                            {debt.type === 'borrowed'
                              ? (language === 'bn' ? 'পরিশোধ করতে হবে' : 'Must payback')
                              : (language === 'bn' ? 'পাওনা টাকা' : 'To receive')}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <div className="text-xs font-black text-amber-950">
                          {formatMoney(debt.amount - (debt.paidAmount || 0))}
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            toggleDebtSettled(debt.id);
                            showToast(language === 'bn' ? 'কিস্তির স্ট্যাটাস আপডেট হয়েছে!' : 'Status updated!');
                          }}
                          className={`text-[9px] font-extrabold px-2 py-0.5 rounded-full cursor-pointer transition-colors ${
                            debt.settled
                              ? 'bg-emerald-100 text-emerald-800'
                              : 'bg-amber-200 text-amber-900 hover:bg-amber-300'
                          }`}
                        >
                          {debt.settled
                            ? (language === 'bn' ? 'পরিশোধিত ✓' : 'Settled ✓')
                            : (language === 'bn' ? 'পরিশোধ চিহ্নিত করুন' : 'Mark Settled')}
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Daily Transactions List */}
            <div className="space-y-2">
              <div className="flex items-center justify-between text-xs font-bold text-slate-600">
                <span className="flex items-center gap-1.5">
                  <Receipt className="w-3.5 h-3.5 text-emerald-600" />
                  <span>{language === 'bn' ? 'দৈনিক লেনদেনসমূহ' : 'Daily Transactions'}</span>
                </span>
                <span className="text-[10px] text-slate-400">
                  ({formatNum(selectedDayTransactions.length)})
                </span>
              </div>

              {selectedDayTransactions.length === 0 ? (
                <div className="p-4 bg-emerald-50/40 rounded-2xl border border-dashed border-emerald-200 text-center space-y-1">
                  <div className="text-base">🎉</div>
                  <div className="text-xs font-bold text-emerald-900">
                    {language === 'bn' ? 'নো-স্পেন্ড ডে!' : 'Zero Expense Day!'}
                  </div>
                  <p className="text-[10px] text-emerald-700">
                    {language === 'bn'
                      ? 'এই তারিখে কোনো টাকা খরচ হয়নি। দুর্দান্ত সঞ্চয়!'
                      : 'No expenses were logged on this date.'}
                  </p>
                </div>
              ) : (
                <div className="space-y-1.5 max-h-[260px] overflow-y-auto pr-1 custom-scrollbar">
                  {selectedDayTransactions.map(tx => {
                    const cat = categories.find(c => c.id === tx.categoryId);
                    const acc = accounts.find(a => a.id === tx.accountId);
                    const isExpense = tx.type === 'expense';

                    return (
                      <div
                        key={tx.id}
                        className="p-2.5 rounded-xl border border-slate-100 bg-slate-50/60 hover:bg-slate-50 flex items-center justify-between transition-colors"
                      >
                        <div className="flex items-center gap-2 min-w-0">
                          <div
                            className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 text-white text-xs"
                            style={{ backgroundColor: cat?.color || '#10b981' }}
                          >
                            {cat?.icon || '•'}
                          </div>
                          <div className="min-w-0">
                            <div className="text-xs font-bold text-slate-800 truncate leading-snug">
                              {tx.note || (language === 'bn' ? cat?.nameBn : cat?.name) || tx.type}
                            </div>
                            <span className="text-[10px] text-slate-400 truncate block">
                              {acc ? (language === 'bn' ? acc.nameBn || acc.name : acc.name) : ''}
                            </span>
                          </div>
                        </div>

                        <div className="text-right shrink-0">
                          <span
                            className={`text-xs font-extrabold ${
                              isExpense ? 'text-slate-900' : 'text-emerald-700'
                            }`}
                          >
                            {isExpense ? '-' : '+'}
                            {formatMoney(tx.amount)}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        /* Timeline View of Dues */
        <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-4">
          {/* Timeline Filter Tabs */}
          <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
            <div>
              <h3 className="text-base font-extrabold text-slate-900 leading-snug">
                {currentMonthName} {formatNum(currentYear)} - {language === 'bn' ? 'বিল ও কিস্তির টাইমলাইন' : 'Dues Timeline'}
              </h3>
              <p className="text-xs text-slate-400">
                {language === 'bn'
                  ? 'মাসের কোন তারিখে কোন বিল বা ঋণের কিস্তি দিতে হবে তার তারিখভিত্তিক তালিকা'
                  : 'Chronological timeline of all bills and installments due this month'}
              </p>
            </div>

            <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
              <button
                type="button"
                onClick={() => setTimelineFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  timelineFilter === 'all'
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {language === 'bn' ? 'সব' : 'All'}
              </button>
              <button
                type="button"
                onClick={() => setTimelineFilter('unpaid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  timelineFilter === 'unpaid'
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {language === 'bn' ? 'বকেয়া বিল' : 'Unpaid Bills'}
              </button>
              <button
                type="button"
                onClick={() => setTimelineFilter('debts')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  timelineFilter === 'debts'
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {language === 'bn' ? 'ঋণ ও কিস্তি' : 'Debts/EMI'}
              </button>
              <button
                type="button"
                onClick={() => setTimelineFilter('paid')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                  timelineFilter === 'paid'
                    ? 'bg-white text-emerald-800 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {language === 'bn' ? 'পরিশোধিত' : 'Paid'}
              </button>
            </div>
          </div>

          {/* Timeline List */}
          {timelineItems.length === 0 ? (
            <div className="p-12 text-center space-y-2">
              <CalendarCheck className="w-10 h-10 text-emerald-500 mx-auto stroke-[1.5]" />
              <h4 className="text-sm font-bold text-slate-800">
                {language === 'bn' ? 'কোনো প্রদেয় আইটেম নেই!' : 'No dues found!'}
              </h4>
              <p className="text-xs text-slate-400 max-w-sm mx-auto">
                {language === 'bn'
                  ? 'এই মাসে ফিল্টার অনুযায়ী কোনো বিল বা ঋণের কিস্তি নেই।'
                  : 'No scheduled bills or installments match your selected filter for this month.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3">
              {timelineItems.map((item, idx) => {
                const itemDate = new Date(item.date);
                const dayNum = itemDate.getDate();
                const isOverdue = !item.isPaid && item.date < todayDateString;
                const isToday = item.date === todayDateString;

                return (
                  <div
                    key={`timeline-${idx}-${item.title}`}
                    className={`p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                      item.isPaid
                        ? 'bg-slate-50/70 border-slate-200/80 opacity-75'
                        : isOverdue
                        ? 'bg-rose-50/60 border-rose-200'
                        : isToday
                        ? 'bg-amber-50/70 border-amber-300 ring-2 ring-amber-400/20'
                        : 'bg-white border-slate-200/90 hover:border-emerald-200'
                    }`}
                  >
                    {/* Left: Date Badge & Details */}
                    <div className="flex items-center gap-3.5">
                      {/* Date Badge */}
                      <div
                        className={`w-12 h-12 rounded-2xl flex flex-col items-center justify-center font-black text-center shrink-0 ${
                          item.isPaid
                            ? 'bg-slate-200 text-slate-700'
                            : isOverdue
                            ? 'bg-rose-600 text-white shadow-xs'
                            : isToday
                            ? 'bg-amber-500 text-white shadow-xs'
                            : 'bg-emerald-100 text-emerald-900'
                        }`}
                      >
                        <span className="text-[10px] font-bold uppercase leading-none">
                          {currentMonthName.slice(0, 3)}
                        </span>
                        <span className="text-base font-extrabold leading-none mt-0.5">
                          {formatNum(dayNum)}
                        </span>
                      </div>

                      {/* Info */}
                      <div>
                        <div className="flex items-center gap-2">
                          <h4 className="text-sm font-bold text-slate-900 leading-snug">
                            {item.title}
                          </h4>
                          {isOverdue && (
                            <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-full bg-rose-100 text-rose-800">
                              {language === 'bn' ? 'বকেয়া মেয়াদোত্তীর্ণ' : 'Overdue'}
                            </span>
                          )}
                          {isToday && (
                            <span className="text-[9px] font-extrabold px-1.5 py-0.2 rounded-full bg-amber-100 text-amber-800">
                              {language === 'bn' ? 'আজকের শেষ তারিখ' : 'Due Today'}
                            </span>
                          )}
                        </div>
                        <p className="text-xs text-slate-500 capitalize">
                          {item.type === 'bill'
                            ? (language === 'bn' ? `ইউটিলিটি বিল • ${item.subtitle}` : `Bill • ${item.subtitle}`)
                            : (language === 'bn' ? `ঋণ ও কিস্তি • ${item.subtitle}` : `Loan • ${item.subtitle}`)}
                        </p>
                      </div>
                    </div>

                    {/* Right: Amount & Action Button */}
                    <div className="flex items-center justify-between sm:justify-end gap-3.5 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-100">
                      <div className="text-left sm:text-right">
                        <div className="text-sm sm:text-base font-black text-slate-900">
                          {formatMoney(item.amount)}
                        </div>
                        <span
                          className={`text-[10px] font-bold ${
                            item.isPaid ? 'text-emerald-700' : 'text-slate-400'
                          }`}
                        >
                          {item.isPaid
                            ? (language === 'bn' ? 'পরিশোধিত ✓' : 'Paid ✓')
                            : (language === 'bn' ? 'অপ্রদত্ত' : 'Unpaid')}
                        </span>
                      </div>

                      {!item.isPaid && item.rawBill && (
                        <button
                          type="button"
                          onClick={() => handlePayBill(item.rawBill!)}
                          className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'পে করুন' : 'Pay Now'}</span>
                        </button>
                      )}

                      {!item.isPaid && item.rawDebt && (
                        <button
                          type="button"
                          onClick={() => {
                            toggleDebtSettled(item.rawDebt!.id);
                            showToast(language === 'bn' ? 'ঋণ পরিশোধিত চিহ্নিত হয়েছে!' : 'Marked as settled!');
                          }}
                          className="px-3.5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-all shadow-xs flex items-center gap-1.5 cursor-pointer"
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'পরিশোধিত' : 'Settle'}</span>
                        </button>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
