import React, { useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { BillSplit } from '../../types';
import {
  UsersRound,
  Plus,
  Trash2,
  CheckCircle,
  Receipt,
  X,
  UserPlus,
  Calculator,
  ArrowRight,
} from 'lucide-react';

export const SplitBillView: React.FC = () => {
  const {
    billSplits,
    addBillSplit,
    toggleSplitMemberPaid,
    deleteBillSplit,
    addTransaction,
    categories,
    accounts,
    formatMoney,
    language,
    t,
    currency,
  } = useExpense();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [successToast, setSuccessToast] = useState<string | null>(null);

  // New Split Form state
  const [title, setTitle] = useState('');
  const [totalAmount, setTotalAmount] = useState('');
  const [taxPercent, setTaxPercent] = useState('0');
  const [paidBy, setPaidBy] = useState('Me');
  const [memberNames, setMemberNames] = useState<string[]>(['Me', 'Friend 1', 'Friend 2']);

  const handleOpenAdd = () => {
    setTitle('');
    setTotalAmount('');
    setTaxPercent('0');
    setPaidBy('Me');
    setMemberNames(['Me', 'Friend 1', 'Friend 2']);
    setIsAddModalOpen(true);
  };

  const handleAddMemberInput = () => {
    setMemberNames(prev => [...prev, `Friend ${prev.length}`]);
  };

  const handleRemoveMemberInput = (index: number) => {
    if (memberNames.length <= 2) return;
    setMemberNames(prev => prev.filter((_, i) => i !== index));
  };

  const handleMemberNameChange = (index: number, val: string) => {
    setMemberNames(prev => {
      const copy = [...prev];
      copy[index] = val;
      return copy;
    });
  };

  const handleCreateSplit = (e: React.FormEvent) => {
    e.preventDefault();
    const baseTotal = parseFloat(totalAmount);
    const tax = parseFloat(taxPercent) || 0;
    if (isNaN(baseTotal) || baseTotal <= 0 || !title.trim()) return;

    const grandTotal = baseTotal + (baseTotal * tax) / 100;
    const count = Math.max(1, memberNames.length);
    const perPerson = Math.round((grandTotal / count) * 100) / 100;

    const members = memberNames.map((name, i) => ({
      id: 'm-' + Date.now() + '-' + i,
      name: name.trim() || `Person ${i + 1}`,
      amount: perPerson,
      paid: name.toLowerCase().includes('me') || i === 0,
    }));

    addBillSplit({
      title: title.trim(),
      totalAmount: grandTotal,
      taxOrTipPercentage: tax,
      paidBy: paidBy.trim() || 'Me',
      date: new Date().toISOString().split('T')[0],
      members,
    });

    setIsAddModalOpen(false);
  };

  const handleConvertMyShareToExpense = (split: BillSplit, myShareAmount: number) => {
    const defaultExpenseCat = categories.find(c => c.id === 'cat-food') || categories[0];
    const defaultAcc = accounts[0];

    addTransaction({
      type: 'expense',
      amount: myShareAmount,
      categoryId: defaultExpenseCat.id,
      accountId: defaultAcc.id,
      date: split.date,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      note: `${language === 'bn' ? 'বিল ভাগাভাগি' : 'Split bill'}: ${split.title}`,
    });

    setSuccessToast(
      language === 'bn'
        ? `আপনার ভাগের ${formatMoney(myShareAmount)} সফলভাবে খরচে যুক্ত হয়েছে!`
        : `Added ${formatMoney(myShareAmount)} to your expenses!`
    );
    setTimeout(() => setSuccessToast(null), 3500);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {t('billSplitter')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {language === 'bn'
              ? 'বন্ধুদের সাথে খাবার, ফ্ল্যাট ভাড়া বা ভ্রমণের বিল সহজে ভাগ করুন'
              : 'Easily split shared group expenses, dinner, trips, and flat rent'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>{language === 'bn' ? 'নতুন বিল ভাগ' : 'New Split'}</span>
        </button>
      </div>

      {/* Success Toast Banner */}
      {successToast && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-800 p-3 rounded-2xl text-xs font-semibold flex items-center justify-between animate-in fade-in duration-150">
          <span>{successToast}</span>
          <button onClick={() => setSuccessToast(null)} className="text-[10px] underline ml-2">
            OK
          </button>
        </div>
      )}

      {/* List of Bill Splits */}
      {billSplits.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs">
          <Calculator className="w-12 h-12 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-bold text-slate-700">
            {language === 'bn' ? 'কোনো সক্রিয় বিল ভাগাভাগি নেই।' : 'No bill splits created yet.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {billSplits.map(split => {
            const paidCount = split.members.filter(m => m.paid).length;
            const myMember = split.members.find(
              m => m.name.toLowerCase().includes('me') || m.name.toLowerCase().includes('আমি')
            ) || split.members[0];

            return (
              <div
                key={split.id}
                className="bg-white border border-slate-200/80 hover:border-emerald-300 rounded-3xl p-5 shadow-xs transition-all flex flex-col justify-between space-y-4"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-bold text-base text-slate-800">{split.title}</h3>
                      <p className="text-xs text-slate-400 mt-0.5">
                        {split.date} • {language === 'bn' ? 'পেমেন্ট করেছে:' : 'Paid by:'}{' '}
                        <strong>{split.paidBy}</strong>
                      </p>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-sm font-black text-slate-900 bg-slate-100 px-2.5 py-1 rounded-xl">
                        {formatMoney(split.totalAmount)}
                      </span>
                      <button
                        onClick={() => {
                          if (window.confirm(language === 'bn' ? 'মুছে ফেলতে চান?' : 'Delete split?')) {
                            deleteBillSplit(split.id);
                          }
                        }}
                        className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  {/* Members checklist */}
                  <div className="mt-4 space-y-2">
                    <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                      {language === 'bn' ? 'সদস্যদের ভাগের হিসাব' : 'Member Shares'} ({paidCount}/{split.members.length} {language === 'bn' ? 'পরিশোধিত' : 'paid'})
                    </span>

                    <div className="space-y-1.5 max-h-48 overflow-y-auto pr-1">
                      {split.members.map(member => (
                        <div
                          key={member.id}
                          onClick={() => toggleSplitMemberPaid(split.id, member.id)}
                          className={`flex items-center justify-between p-2.5 rounded-xl border text-xs cursor-pointer transition-colors ${
                            member.paid
                              ? 'bg-emerald-50/70 border-emerald-200 text-emerald-900 font-semibold'
                              : 'bg-slate-50 border-slate-200/70 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          <div className="flex items-center gap-2">
                            <div
                              className={`w-4 h-4 rounded-full flex items-center justify-center text-white text-[10px] ${
                                member.paid ? 'bg-emerald-600' : 'border border-slate-300'
                              }`}
                            >
                              {member.paid && '✓'}
                            </div>
                            <span>{member.name}</span>
                          </div>

                          <div className="flex items-center gap-2">
                            <span className="font-bold">{formatMoney(member.amount)}</span>
                            <span className="text-[10px] text-slate-400">
                              {member.paid ? (language === 'bn' ? 'পরিশোধিত' : 'Paid') : (language === 'bn' ? 'বাকি' : 'Due')}
                            </span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Convert share to expense button */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-500">
                    {language === 'bn' ? 'আপনার অংশ:' : 'Your share:'}{' '}
                    <strong className="text-slate-800">{formatMoney(myMember?.amount || 0)}</strong>
                  </span>

                  <button
                    onClick={() => handleConvertMyShareToExpense(split, myMember?.amount || 0)}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold transition-colors"
                  >
                    <span>{language === 'bn' ? 'খরচে যোগ করুন' : 'Log My Expense'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Add Bill Split Modal */}
      {isAddModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          onClick={() => setIsAddModalOpen(false)}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[88vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
            onClick={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'নতুন গ্রুপ বিল ভাগাভাগি' : 'Split New Bill'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateSplit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'বিলের শিরোনাম' : 'Bill Title'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'bn' ? 'যেমন: রেস্তোরাঁয় ডিনার বা কক্সবাজার ট্যুর' : 'e.g. Weekend BBQ, Office Lunch'}
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'মোট বিল' : 'Total Bill'} ({currency.symbol})
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="1"
                    placeholder="0"
                    value={totalAmount}
                    onChange={e => setTotalAmount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ভ্যাট / টিপস (%)' : 'Tax / Tip %'}
                  </label>
                  <input
                    type="number"
                    min="0"
                    placeholder="0"
                    value={taxPercent}
                    onChange={e => setTaxPercent(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'কে পরিশোধ করেছে?' : 'Paid By'}
                </label>
                <input
                  type="text"
                  placeholder="Me / Faysal"
                  value={paidBy}
                  onChange={e => setPaidBy(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              {/* Members */}
              <div>
                <div className="flex items-center justify-between mb-1.5">
                  <label className="text-xs font-bold text-slate-500">
                    {language === 'bn' ? 'সদস্যদের তালিকা' : 'Friends / Members'} ({memberNames.length})
                  </label>
                  <button
                    type="button"
                    onClick={handleAddMemberInput}
                    className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'সদস্য যোগ করুন' : 'Add Person'}</span>
                  </button>
                </div>

                <div className="space-y-2 max-h-36 overflow-y-auto pr-1">
                  {memberNames.map((name, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={e => handleMemberNameChange(idx, e.target.value)}
                        className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-medium"
                      />
                      {memberNames.length > 2 && (
                        <button
                          type="button"
                          onClick={() => handleRemoveMemberInput(idx)}
                          className="p-1.5 text-slate-300 hover:text-rose-600 rounded-md"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'বিল ভাগ সম্পন্ন' : 'Calculate & Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
