import React, { useState, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import { BazarItem, BazarCategory, BazarMarketCommodity } from '../../types';
import confetti from 'canvas-confetti';
import {
  ShoppingBag,
  TrendingDown,
  TrendingUp,
  Minus,
  CheckCircle2,
  Circle,
  Plus,
  Trash2,
  Edit2,
  Share2,
  ShoppingCart,
  Sparkles,
  HelpCircle,
  AlertCircle,
  Clock,
  ArrowRight,
  Filter,
  Check,
  RotateCcw,
  Tag,
  DollarSign,
  LineChart as LineChartIcon,
  Lightbulb,
  X,
  Copy,
  ChevronRight,
  CheckCheck,
} from 'lucide-react';
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from 'recharts';

export const BazarView: React.FC = () => {
  const {
    bazarItems,
    bazarMarketCommodities,
    addBazarItem,
    editBazarItem,
    deleteBazarItem,
    toggleBazarItemPurchased,
    updateBazarItemActualPrice,
    clearPurchasedBazarItems,
    clearAllBazarItems,
    checkoutBazarList,
    addPriceHistoryLog,
    estimatedBazarTotal,
    actualBazarSpent,
    bazarSavingsSoFar,
    bazarCompletedCount,
    bazarTotalCount,
    accounts,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const isBn = language === 'bn';

  // Active view mode: checklist, trends, tips
  const [activeSubTab, setActiveSubTab] = useState<'checklist' | 'trends' | 'tips'>('checklist');

  // Category filter for checklist
  const [selectedCategory, setSelectedCategory] = useState<string>('all');

  // Modals state
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<BazarItem | null>(null);
  const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
  const [selectedCheckoutAccountId, setSelectedCheckoutAccountId] = useState<string>(
    accounts[0]?.id || 'acc-cash'
  );
  const [checkoutNote, setCheckoutNote] = useState('');
  const [isLogPriceModalOpen, setIsLogPriceModalOpen] = useState(false);
  const [selectedCommodityForLog, setSelectedCommodityForLog] = useState<BazarMarketCommodity | null>(null);
  const [logPriceInput, setLogPriceInput] = useState('');
  const [logMarketNameInput, setLogMarketNameInput] = useState('');
  const [copiedToast, setCopiedToast] = useState(false);

  const isAnyBazarModalOpen = isAddItemModalOpen || isCheckoutModalOpen || isLogPriceModalOpen;
  useLockBodyScroll(isAnyBazarModalOpen);

  useEffect(() => {
    if (!isAnyBazarModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setIsAddItemModalOpen(false);
        setIsCheckoutModalOpen(false);
        setIsLogPriceModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAnyBazarModalOpen]);

  // Selected commodity for trend chart
  const [selectedCommodityForChart, setSelectedCommodityForChart] = useState<string>(
    bazarMarketCommodities[0]?.id || 'comm-onion'
  );

  // New item form state
  const [itemNameInput, setItemNameInput] = useState('');
  const [itemCategoryInput, setItemCategoryInput] = useState<BazarCategory>('vegetables');
  const [itemQuantityInput, setItemQuantityInput] = useState('১ কেজি');
  const [itemEstimatedPriceInput, setItemEstimatedPriceInput] = useState('');
  const [itemPriorityInput, setItemPriorityInput] = useState<'essential' | 'optional'>('essential');
  const [itemNotesInput, setItemNotesInput] = useState('');

  // Category labels and badges
  const categoryLabels: Record<BazarCategory, { en: string; bn: string; color: string; icon: string }> = {
    vegetables: { en: 'Vegetables', bn: 'শাকসবজি', color: 'bg-emerald-100 text-emerald-800 border-emerald-200', icon: '🥬' },
    fish_meat: { en: 'Fish & Meat', bn: 'মাছ ও মাংস', color: 'bg-rose-100 text-rose-800 border-rose-200', icon: '🥩' },
    grocery: { en: 'Grocery & Oil', bn: 'মুদি ও তেল', color: 'bg-amber-100 text-amber-800 border-amber-200', icon: '🛢️' },
    spices: { en: 'Spices', bn: 'মসলা ও মরিচ', color: 'bg-orange-100 text-orange-800 border-orange-200', icon: '🌶️' },
    dairy_eggs: { en: 'Eggs & Dairy', bn: 'ডিম ও দুধ', color: 'bg-yellow-100 text-yellow-800 border-yellow-200', icon: '🥚' },
    fruits: { en: 'Fruits', bn: 'ফলমূল', color: 'bg-teal-100 text-teal-800 border-teal-200', icon: '🍎' },
    other: { en: 'Others', bn: 'অন্যান্য', color: 'bg-slate-100 text-slate-800 border-slate-200', icon: '🛒' },
  };

  // Popular preset grocery items for quick 1-tap add
  const quickPresets: { nameBn: string; nameEn: string; category: BazarCategory; quantity: string; est: number; icon: string }[] = [
    { nameBn: 'দেশি পেঁয়াজ', nameEn: 'Deshi Onion', category: 'vegetables', quantity: '১ কেজি', est: 110, icon: '🧅' },
    { nameBn: 'গোল আলু', nameEn: 'Round Potato', category: 'vegetables', quantity: '২ কেজি', est: 110, icon: '🥔' },
    { nameBn: 'ফার্মের লাল ডিম', nameEn: 'Farm Eggs', category: 'dairy_eggs', quantity: '১ ডজন', est: 145, icon: '🥚' },
    { nameBn: 'সয়াবিন তেল', nameEn: 'Soybean Oil', category: 'grocery', quantity: '২ লিটার', est: 334, icon: '🛢️' },
    { nameBn: 'ব্রয়লার মুরগি', nameEn: 'Broiler Chicken', category: 'fish_meat', quantity: '১ কেজি', est: 185, icon: '🍗' },
    { nameBn: 'কাঁচামরিচ', nameEn: 'Green Chili', category: 'spices', quantity: '২৫০ গ্রাম', est: 45, icon: '🌶️' },
    { nameBn: 'রুই মাছ', nameEn: 'Rui Fish', category: 'fish_meat', quantity: '১ কেজি', est: 340, icon: '🐟' },
    { nameBn: 'দেশি রসুন', nameEn: 'Deshi Garlic', category: 'spices', quantity: '২৫০ গ্রাম', est: 55, icon: '🧄' },
    { nameBn: 'মিনিকেট চাল', nameEn: 'Miniket Rice', category: 'grocery', quantity: '৫ কেজি', est: 360, icon: '🍚' },
    { nameBn: 'টমেটো', nameEn: 'Tomato', category: 'vegetables', quantity: '৫০০ গ্রাম', est: 60, icon: '🍅' },
  ];

  // Filter items
  const filteredItems = bazarItems.filter(item => {
    if (selectedCategory === 'all') return true;
    if (selectedCategory === 'pending') return !item.isPurchased;
    if (selectedCategory === 'purchased') return item.isPurchased;
    return item.category === selectedCategory;
  });

  const progressPercent = bazarTotalCount > 0 ? Math.round((bazarCompletedCount / bazarTotalCount) * 100) : 0;

  // Open add/edit modal
  const handleOpenAddModal = () => {
    setEditingItem(null);
    setItemNameInput('');
    setItemCategoryInput('vegetables');
    setItemQuantityInput('১ কেজি');
    setItemEstimatedPriceInput('');
    setItemPriorityInput('essential');
    setItemNotesInput('');
    setIsAddItemModalOpen(true);
  };

  const handleOpenEditModal = (item: BazarItem) => {
    setEditingItem(item);
    setItemNameInput(isBn ? item.nameBn : item.name);
    setItemCategoryInput(item.category);
    setItemQuantityInput(item.quantity);
    setItemEstimatedPriceInput(item.estimatedPrice.toString());
    setItemPriorityInput(item.priority);
    setItemNotesInput(item.notes || '');
    setIsAddItemModalOpen(true);
  };

  const handleSaveItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (!itemNameInput.trim()) return;

    const estPrice = parseFloat(itemEstimatedPriceInput) || 0;

    if (editingItem) {
      editBazarItem({
        ...editingItem,
        name: itemNameInput,
        nameBn: itemNameInput,
        category: itemCategoryInput,
        quantity: itemQuantityInput,
        estimatedPrice: estPrice,
        priority: itemPriorityInput,
        notes: itemNotesInput,
      });
    } else {
      addBazarItem({
        name: itemNameInput,
        nameBn: itemNameInput,
        category: itemCategoryInput,
        quantity: itemQuantityInput,
        estimatedPrice: estPrice,
        isPurchased: false,
        priority: itemPriorityInput,
        notes: itemNotesInput,
      });
    }

    setIsAddItemModalOpen(false);
  };

  const handleAddQuickPreset = (preset: typeof quickPresets[0]) => {
    addBazarItem({
      name: preset.nameEn,
      nameBn: preset.nameBn,
      category: preset.category,
      quantity: preset.quantity,
      estimatedPrice: preset.est,
      isPurchased: false,
      priority: 'essential',
    });
  };

  // WhatsApp formatted share text
  const handleCopyBazarList = () => {
    const listLines = bazarItems.map((item, idx) => {
      const statusIcon = item.isPurchased ? '✅' : '⬜';
      const priceText = item.actualPrice !== undefined
        ? `৳${item.actualPrice}`
        : `~৳${item.estimatedPrice}`;
      return `${idx + 1}. ${statusIcon} ${item.nameBn || item.name} (${item.quantity}) - ${priceText}`;
    });

    const shareText = `📋 কাঁচাবাজারের ফর্দ (Khoroch Tracker)\nতারিখ: ${new Date().toLocaleDateString('bn-BD')}\nমোট আইটেম: ${bazarTotalCount}টি | আনুমানিক বাজেট: ৳${estimatedBazarTotal}\n---------------------------\n${listLines.join('\n')}\n---------------------------\nহিসাব ট্র্যাকড বাই 'Khoroch' অ্যাপ`;

    navigator.clipboard.writeText(shareText);
    setCopiedToast(true);
    setTimeout(() => setCopiedToast(false), 3000);
  };

  // Checkout and convert to Expense Transaction
  const handleConfirmCheckout = () => {
    const res = checkoutBazarList(selectedCheckoutAccountId, checkoutNote);
    if (res.success) {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#059669', '#34d399', '#f59e0b'],
      });
      setIsCheckoutModalOpen(false);
    }
  };

  // Log new market price for a commodity
  const handleOpenLogPrice = (commodity: BazarMarketCommodity) => {
    setSelectedCommodityForLog(commodity);
    setLogPriceInput(commodity.currentPrice.toString());
    setLogMarketNameInput('কারওয়ান বাজার');
    setIsLogPriceModalOpen(true);
  };

  const handleSavePriceLog = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedCommodityForLog) return;
    const priceNum = parseFloat(logPriceInput);
    if (isNaN(priceNum) || priceNum <= 0) return;

    addPriceHistoryLog(
      selectedCommodityForLog.id,
      priceNum,
      new Date().toISOString().split('T')[0],
      logMarketNameInput.trim() || 'কাঁচাবাজার'
    );

    setIsLogPriceModalOpen(false);
  };

  const selectedCommodityChartData = bazarMarketCommodities.find(
    c => c.id === selectedCommodityForChart
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Header Card */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-br from-emerald-700 via-emerald-600 to-teal-800 text-white p-6 sm:p-8 shadow-sm">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/30 text-emerald-100 text-xs font-semibold backdrop-blur-xs border border-emerald-400/30">
              <ShoppingBag className="w-3.5 h-3.5" />
              <span>{isBn ? 'স্মার্ট কাঁচাবাজার মডিউল' : 'Smart Bazar Module'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
              {isBn ? 'কাঁচাবাজারের ফর্দ ও বাজার দর' : 'Bazar Checklist & Price Trends'}
            </h1>
            <p className="text-emerald-100/90 text-sm max-w-xl">
              {isBn
                ? 'বাজারে যাওয়ার আগে প্রয়োজনীয় পণ্যের তালিকা তৈরি করুন, বাজার দর ও টিসিবি ট্রেন্ড পর্যবেক্ষণ করুন এবং এক ক্লিকে মূল খরচে যুক্ত করুন।'
                : 'Plan grocery lists with live Bangladesh market trends, TCB benchmarks, and convert purchases to real expenses in one click.'}
            </p>
          </div>

          {/* Quick Stat Pill in Hero */}
          <div className="flex flex-wrap sm:flex-nowrap gap-3">
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl px-4 py-3 min-w-[130px]">
              <span className="text-xs text-emerald-200 block font-medium">
                {isBn ? 'আনুমানিক বাজেট' : 'Estimated Budget'}
              </span>
              <span className="text-xl sm:text-2xl font-bold tracking-tight">
                {formatMoney(estimatedBazarTotal)}
              </span>
            </div>
            <div className="bg-white/10 backdrop-blur-md border border-white/20 rounded-xl px-4 py-3 min-w-[130px]">
              <span className="text-xs text-emerald-200 block font-medium">
                {isBn ? 'প্রকৃত খরচ (কেনা)' : 'Purchased Spent'}
              </span>
              <span className="text-xl sm:text-2xl font-bold tracking-tight text-emerald-200">
                {formatMoney(actualBazarSpent)}
              </span>
            </div>
          </div>
        </div>

        {/* Decorative background circle */}
        <div className="absolute -right-16 -bottom-16 w-64 h-64 bg-emerald-500/20 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Navigation Sub-tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveSubTab('checklist')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
              activeSubTab === 'checklist'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <ShoppingCart className="w-4 h-4" />
            <span>{isBn ? 'বাজারের ফর্দ ও চেকলিস্ট' : 'Bazar Checklist'}</span>
            <span
              className={`text-xs px-2 py-0.5 rounded-full font-semibold ${
                activeSubTab === 'checklist' ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-100 text-slate-700'
              }`}
            >
              {bazarCompletedCount}/{bazarTotalCount}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('trends')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
              activeSubTab === 'trends'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <LineChartIcon className="w-4 h-4" />
            <span>{isBn ? 'বাজার দর ও মূল্য ট্রেন্ড' : 'Price Tracker & Trends'}</span>
          </button>

          <button
            onClick={() => setActiveSubTab('tips')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-sm font-bold transition-all ${
              activeSubTab === 'tips'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Lightbulb className="w-4 h-4" />
            <span>{isBn ? 'সাশ্রয়ী বাজার টিপস' : 'Savings Tips & Insights'}</span>
          </button>
        </div>

        {/* Clear List Button */}
        {bazarItems.length > 0 && (
          <button
            onClick={clearAllBazarItems}
            title={isBn ? 'সম্পূর্ণ ফর্দ খালি করুন' : 'Clear Entire List'}
            className="text-xs text-slate-500 hover:text-rose-600 flex items-center gap-1 px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-rose-50 transition-colors shrink-0 cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{isBn ? 'ফর্দ খালি করুন' : 'Clear List'}</span>
          </button>
        )}
      </div>

      {/* ========================================================================= */}
      {/* SUB-TAB 1: BAZAR CHECKLIST (ফর্দ) */}
      {/* ========================================================================= */}
      {activeSubTab === 'checklist' && (
        <div className="space-y-6">
          {/* Progress & Quick Checkout Action Bar */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-base font-bold text-slate-800">
                    {isBn ? 'বাজারের অগ্রগতি' : 'Shopping Progress'}
                  </h2>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    {progressPercent}% {isBn ? 'সম্পন্ন' : 'Completed'}
                  </span>
                  {bazarSavingsSoFar > 0 && (
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full bg-teal-100 text-teal-800 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-teal-600" />
                      {isBn ? `${formatMoney(bazarSavingsSoFar)} সাশ্রয়!` : `Saved ${formatMoney(bazarSavingsSoFar)}!`}
                    </span>
                  )}
                </div>
                <p className="text-xs text-slate-500">
                  {isBn
                    ? `${bazarTotalCount}টি আইটেমের মধ্যে ${bazarCompletedCount}টি সদাই কেনা হয়েছে`
                    : `${bazarCompletedCount} of ${bazarTotalCount} items purchased so far`}
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                <button
                  onClick={handleCopyBazarList}
                  className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-700 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors active:scale-95"
                  title={isBn ? 'WhatsApp বা SMS এ পাঠানোর জন্য ফর্দ কপি করুন' : 'Copy List for WhatsApp/SMS'}
                >
                  {copiedToast ? <CheckCheck className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedToast ? (isBn ? 'কপি হয়েছে!' : 'Copied!') : (isBn ? 'ফর্দ কপি' : 'Share List')}</span>
                </button>

                {bazarCompletedCount > 0 && (
                  <button
                    onClick={clearPurchasedBazarItems}
                    className="inline-flex items-center gap-1 px-3 py-2 text-xs font-semibold text-slate-600 hover:text-rose-700 bg-slate-50 hover:bg-rose-50 border border-slate-200 rounded-xl transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{isBn ? 'কেনা তালিকা ক্লিয়ার' : 'Clear Purchased'}</span>
                  </button>
                )}

                <button
                  onClick={() => setIsCheckoutModalOpen(true)}
                  disabled={bazarCompletedCount === 0}
                  className={`inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-bold rounded-xl transition-all shadow-xs ${
                    bazarCompletedCount > 0
                      ? 'bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white cursor-pointer shadow-emerald-200'
                      : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                  }`}
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>{isBn ? 'কেনা শেষ - মূল খরচে যোগ' : 'Finish & Add to Expenses'}</span>
                </button>

                <button
                  onClick={handleOpenAddModal}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-bold bg-slate-900 hover:bg-slate-800 text-white rounded-xl shadow-xs active:scale-95 transition-transform"
                >
                  <Plus className="w-4 h-4 stroke-[2.5]" />
                  <span>{isBn ? 'নতুন আইটেম' : 'Add Item'}</span>
                </button>
              </div>
            </div>

            {/* Progress bar line */}
            <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
              <div
                className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full transition-all duration-300 rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Quick 1-Tap Presets */}
          <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                {isBn ? '১-ট্যাপে ফর্দে যোগ করুন (জনপ্রিয় আইটেম)' : 'Quick 1-Tap Presets'}
              </span>
              <span className="text-[11px] text-slate-400">
                {isBn ? 'ক্লিক করলেই ফর্দে যোগ হবে' : 'Click to add immediately'}
              </span>
            </div>

            <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
              {quickPresets.map((preset, idx) => (
                <button
                  key={idx}
                  onClick={() => handleAddQuickPreset(preset)}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl border border-slate-200 hover:border-emerald-300 bg-slate-50 hover:bg-emerald-50 text-xs font-semibold text-slate-700 hover:text-emerald-800 transition-colors whitespace-nowrap shrink-0 active:scale-95"
                >
                  <span>{preset.icon}</span>
                  <span>{isBn ? preset.nameBn : preset.nameEn}</span>
                  <span className="text-[10px] text-slate-500">({preset.quantity})</span>
                  <span className="text-emerald-600 font-bold ml-0.5">৳{preset.est}</span>
                  <Plus className="w-3 h-3 text-slate-400 group-hover:text-emerald-600" />
                </button>
              ))}
            </div>
          </div>

          {/* Category Filter Chips */}
          <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
                selectedCategory === 'all'
                  ? 'bg-emerald-700 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {isBn ? 'সব পণ্য' : 'All'} ({bazarTotalCount})
            </button>
            <button
              onClick={() => setSelectedCategory('pending')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
                selectedCategory === 'pending'
                  ? 'bg-amber-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {isBn ? 'বাকি আছে' : 'Pending'} ({bazarTotalCount - bazarCompletedCount})
            </button>
            <button
              onClick={() => setSelectedCategory('purchased')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors shrink-0 ${
                selectedCategory === 'purchased'
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {isBn ? 'কেনা সম্পন্ন' : 'Purchased'} ({bazarCompletedCount})
            </button>

            {/* Individual categories */}
            {Object.entries(categoryLabels).map(([catKey, catMeta]) => {
              const count = bazarItems.filter(i => i.category === catKey).length;
              if (count === 0 && selectedCategory !== catKey) return null;
              return (
                <button
                  key={catKey}
                  onClick={() => setSelectedCategory(catKey)}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors shrink-0 ${
                    selectedCategory === catKey
                      ? 'bg-slate-800 text-white'
                      : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
                  }`}
                >
                  <span>{catMeta.icon}</span>
                  <span>{isBn ? catMeta.bn : catMeta.en}</span>
                  <span className="text-[10px] opacity-75">({count})</span>
                </button>
              );
            })}
          </div>

          {/* Checklist Items Grid / List */}
          {filteredItems.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShoppingBag className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-800 mb-1">
                {isBn ? 'কাঁচাবাজারের ফর্দ সম্পূর্ণ খালি' : 'Bazar Checklist is Empty'}
              </h3>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mb-5">
                {isBn
                  ? 'কোনো ডেমো ডেটা নেই। নিজের প্রয়োজনীয় সদাই যোগ করতে উপরের ১-ট্যাপ বোতামে ক্লিক করুন অথবা সরাসরি নতুন পণ্য লিখুন।'
                  : 'Clean and ready. Add your personal grocery items using the 1-tap presets above or write a custom item.'}
              </p>
              <button
                onClick={handleOpenAddModal}
                className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs"
              >
                <Plus className="w-4 h-4" />
                <span>{isBn ? 'নতুন আইটেম যোগ করুন' : 'Add First Item'}</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
              {filteredItems.map(item => {
                const catMeta = categoryLabels[item.category] || categoryLabels.other;
                const isPaidLower = item.actualPrice !== undefined && item.actualPrice < item.estimatedPrice;
                const isPaidHigher = item.actualPrice !== undefined && item.actualPrice > item.estimatedPrice;

                return (
                  <div
                    key={item.id}
                    className={`relative rounded-2xl p-4 border transition-all duration-200 flex flex-col justify-between ${
                      item.isPurchased
                        ? 'bg-emerald-50/40 border-emerald-200/80 text-slate-600'
                        : 'bg-white border-slate-200 hover:border-emerald-300 shadow-2xs'
                    }`}
                  >
                    <div>
                      {/* Top Row: Checkbox, Name, Category Badge */}
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex items-start gap-3 flex-1 min-w-0">
                          <button
                            onClick={() => toggleBazarItemPurchased(item.id)}
                            className="mt-0.5 text-slate-400 hover:text-emerald-600 transition-colors shrink-0"
                            title={isBn ? 'কেনা হিসেবে মার্ক করুন' : 'Mark as purchased'}
                          >
                            {item.isPurchased ? (
                              <CheckCircle2 className="w-5 h-5 text-emerald-600 fill-emerald-100" />
                            ) : (
                              <Circle className="w-5 h-5 text-slate-300 hover:text-emerald-500" />
                            )}
                          </button>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h4
                                className={`text-sm font-bold text-slate-900 truncate ${
                                  item.isPurchased ? 'line-through text-slate-500' : ''
                                }`}
                              >
                                {isBn ? item.nameBn || item.name : item.name}
                              </h4>
                              <span className="text-xs font-semibold px-2 py-0.5 rounded-md bg-slate-100 text-slate-700">
                                {item.quantity}
                              </span>
                              {item.priority === 'essential' && (
                                <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-rose-50 text-rose-700 border border-rose-200">
                                  {isBn ? 'জরুরি' : 'Essential'}
                                </span>
                              )}
                            </div>

                            {item.notes && (
                              <p className="text-xs text-slate-500 mt-1 italic">
                                {item.notes}
                              </p>
                            )}
                          </div>
                        </div>

                        {/* Category Tag */}
                        <span
                          className={`text-[11px] font-semibold px-2 py-0.5 rounded-full border shrink-0 ${catMeta.color}`}
                        >
                          {catMeta.icon} {isBn ? catMeta.bn : catMeta.en}
                        </span>
                      </div>
                    </div>

                    {/* Bottom Row: Price Info & Actions */}
                    <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div>
                          <span className="text-[10px] text-slate-400 block font-medium">
                            {isBn ? 'আনুমানিক দর' : 'Estimated'}
                          </span>
                          <span className="text-xs font-bold text-slate-600">
                            {formatMoney(item.estimatedPrice)}
                          </span>
                        </div>

                        {/* Actual Price Input / Display */}
                        <div className="pl-3 border-l border-slate-200">
                          <span className="text-[10px] text-slate-500 block font-medium">
                            {isBn ? 'প্রকৃত কেনা দর' : 'Actual Paid'}
                          </span>
                          <div className="flex items-center gap-1">
                            <span className="text-xs text-slate-400">{currency.symbol}</span>
                            <input
                              type="number"
                              value={item.actualPrice !== undefined ? item.actualPrice : ''}
                              placeholder={item.estimatedPrice.toString()}
                              onChange={e => {
                                const val = parseFloat(e.target.value);
                                updateBazarItemActualPrice(item.id, isNaN(val) ? 0 : val);
                              }}
                              className={`w-16 px-1.5 py-0.5 text-xs font-bold rounded-md border text-slate-800 transition-colors ${
                                item.isPurchased
                                  ? 'bg-emerald-50/80 border-emerald-300 text-emerald-900 font-extrabold'
                                  : 'bg-slate-50 border-slate-200 hover:border-slate-300'
                              }`}
                            />
                            {isPaidLower && (
                              <span className="text-[10px] font-bold text-emerald-600 bg-emerald-100 px-1 rounded-sm">
                                🔻 {isBn ? 'সাশ্রয়' : 'Saved'}
                              </span>
                            )}
                            {isPaidHigher && (
                              <span className="text-[10px] font-bold text-rose-600 bg-rose-100 px-1 rounded-sm">
                                🔺 {isBn ? 'বেশি' : 'Over'}
                              </span>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Edit & Delete Buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleOpenEditModal(item)}
                          className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                          title="Edit"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => deleteBazarItem(item.id)}
                          className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                          title="Delete"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 2: PRICE TRACKER & TRENDS (বাজার দর ও মূল্য ট্রেন্ড) */}
      {/* ========================================================================= */}
      {activeSubTab === 'trends' && (
        <div className="space-y-6">
          {/* Header Info Banner */}
          <div className="bg-amber-50/80 border border-amber-200 rounded-2xl p-4 flex items-start gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
            <div className="text-xs text-amber-900 space-y-1">
              <span className="font-bold block text-sm">
                {isBn ? 'বাংলাদেশি বাজার দর ও টিসিবি বেঞ্চমার্ক ট্র্যাকার' : 'Bangladesh Commodity Tracker & TCB Benchmarks'}
              </span>
              <p>
                {isBn
                  ? 'এখানে নিত্যপ্রয়োজনীয় পণ্যের সাম্প্রতিক খুচরা বাজার দর এবং সরকারি ট্রেডিং করপোরেশন অব বাংলাদেশ (TCB) নির্ধারিত দর দেখানো হচ্ছে। স্থানীয় বাজারে কেনা দর মিলিয়ে আপডেট করতে পারেন।'
                  : 'Track retail commodity price movements with TCB guidelines and historical fluctuation graphs for essential groceries.'}
              </p>
            </div>
          </div>

          {/* Commodity Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {bazarMarketCommodities.map(comm => {
              const diff = comm.currentPrice - comm.previousPrice;
              const isUp = diff > 0;
              const isDown = diff < 0;
              const isStable = diff === 0;

              return (
                <div
                  key={comm.id}
                  className={`bg-white rounded-2xl p-5 border transition-all hover:shadow-xs flex flex-col justify-between ${
                    selectedCommodityForChart === comm.id
                      ? 'border-emerald-500 ring-2 ring-emerald-500/10'
                      : 'border-slate-200'
                  }`}
                >
                  <div>
                    {/* Top Row: Icon, Name, Trend Pill */}
                    <div className="flex items-start justify-between gap-2 mb-3">
                      <div className="flex items-center gap-2.5">
                        <span className="text-2xl p-2 rounded-xl bg-slate-50 border border-slate-100">
                          {comm.icon}
                        </span>
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">
                            {isBn ? comm.nameBn : comm.name}
                          </h4>
                          <span className="text-xs text-slate-400">
                            {isBn ? comm.unitBn : comm.unit}
                          </span>
                        </div>
                      </div>

                      {/* Trend Pill */}
                      <span
                        className={`inline-flex items-center gap-1 px-2 py-1 rounded-lg text-xs font-bold ${
                          isDown
                            ? 'bg-emerald-100 text-emerald-800'
                            : isUp
                            ? 'bg-rose-100 text-rose-800'
                            : 'bg-slate-100 text-slate-700'
                        }`}
                      >
                        {isDown && <TrendingDown className="w-3.5 h-3.5 text-emerald-600" />}
                        {isUp && <TrendingUp className="w-3.5 h-3.5 text-rose-600" />}
                        {isStable && <Minus className="w-3.5 h-3.5 text-slate-500" />}
                        <span>
                          {isStable
                            ? (isBn ? 'অপরিবর্তিত' : 'Stable')
                            : `${isUp ? '+' : ''}${diff}৳`}
                        </span>
                      </span>
                    </div>

                    {/* Price Comparison */}
                    <div className="bg-slate-50 rounded-xl p-3 mb-3 border border-slate-100 flex items-center justify-between">
                      <div>
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {isBn ? 'বর্তমান দর' : 'Current Rate'}
                        </span>
                        <span className="text-lg font-black text-slate-900">
                          {currency.symbol}{comm.currentPrice}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-[10px] text-slate-400 block font-medium">
                          {isBn ? 'আগের দর' : 'Previous'}
                        </span>
                        <span className="text-xs font-semibold text-slate-500 line-through">
                          {currency.symbol}{comm.previousPrice}
                        </span>
                      </div>
                    </div>

                    {/* TCB Benchmark Range */}
                    {comm.benchmarkTcbMin && comm.benchmarkTcbMax && (
                      <div className="text-[11px] text-slate-500 mb-2 flex items-center justify-between">
                        <span className="font-medium text-slate-400">
                          {isBn ? 'টিসিবি সরকারি রেঞ্জ:' : 'TCB Range:'}
                        </span>
                        <span className="font-bold text-slate-700">
                          ৳{comm.benchmarkTcbMin} - ৳{comm.benchmarkTcbMax}
                        </span>
                      </div>
                    )}

                    {/* Market Advice */}
                    {comm.adviceBn && (
                      <p className="text-xs text-slate-600 bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100/60 leading-relaxed mb-4">
                        💡 {isBn ? comm.adviceBn : comm.adviceEn}
                      </p>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 pt-2 border-t border-slate-100">
                    <button
                      onClick={() => setSelectedCommodityForChart(comm.id)}
                      className={`flex-1 py-1.5 px-3 rounded-lg text-xs font-bold transition-colors ${
                        selectedCommodityForChart === comm.id
                          ? 'bg-emerald-600 text-white'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700'
                      }`}
                    >
                      {isBn ? 'গ্রাফ দেখুন' : 'View Trend'}
                    </button>
                    <button
                      onClick={() => handleOpenLogPrice(comm)}
                      className="py-1.5 px-3 rounded-lg text-xs font-semibold bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200/70 transition-colors"
                      title={isBn ? 'আজকের বাজার দর লগ করুন' : 'Log price'}
                    >
                      {isBn ? 'দর আপডেট' : 'Update'}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Price Fluctuation Trend Chart Card */}
          {selectedCommodityChartData && (
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div className="flex items-center gap-2">
                  <span className="text-2xl">{selectedCommodityChartData.icon}</span>
                  <div>
                    <h3 className="text-base font-bold text-slate-900">
                      {isBn ? selectedCommodityChartData.nameBn : selectedCommodityChartData.name} - {isBn ? 'মূল্য পরিবর্তনের গতিধারা' : 'Price History Trend'}
                    </h3>
                    <p className="text-xs text-slate-500">
                      {isBn
                        ? `প্রতি ${selectedCommodityChartData.unitBn} এর সাম্প্রতিক বাজার দর পর্যালোচনা`
                        : `Recent historical price fluctuation per ${selectedCommodityChartData.unit}`}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-xs text-slate-500 font-medium">
                    {isBn ? 'বর্তমান রেট:' : 'Latest:'}
                  </span>
                  <span className="text-base font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-lg border border-emerald-200">
                    {currency.symbol}{selectedCommodityChartData.currentPrice}
                  </span>
                </div>
              </div>

              {/* Chart container */}
              <div className="h-64 w-full pt-4">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart
                    data={selectedCommodityChartData.history}
                    margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                  >
                    <defs>
                      <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#10b981" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                    <XAxis dataKey="date" tick={{ fontSize: 11, fill: '#64748b' }} />
                    <YAxis tick={{ fontSize: 11, fill: '#64748b' }} domain={['auto', 'auto']} />
                    <Tooltip
                      formatter={(val: any) => [`${currency.symbol}${val}`, isBn ? 'দর' : 'Price']}
                      labelFormatter={(label) => `${isBn ? 'তারিখ' : 'Date'}: ${label}`}
                      contentStyle={{
                        backgroundColor: '#ffffff',
                        borderRadius: '12px',
                        border: '1px solid #e2e8f0',
                        fontSize: '12px',
                        boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="price"
                      stroke="#059669"
                      strokeWidth={3}
                      fillOpacity={1}
                      fill="url(#colorPrice)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* SUB-TAB 3: SAVINGS TIPS & GROCERY INSIGHTS (সাশ্রয় টিপস) */}
      {/* ========================================================================= */}
      {activeSubTab === 'tips' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Practical Bangladesh Grocery Shopping Advice */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-2xs space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                <div className="p-2 bg-emerald-50 text-emerald-700 rounded-xl">
                  <Lightbulb className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">
                    {isBn ? 'কাঁচাবাজারে টাকা বাঁচানোর পরীক্ষিত কৌশল' : 'Smart Bazar Savings Strategies'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isBn ? 'মাসিক বাজেটে ২০-২৫% সাশ্রয় করার টিপস' : 'Actionable tips to cut grocery bills'}
                  </p>
                </div>
              </div>

              <div className="space-y-3.5">
                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-lg">📦</span>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-800 block font-bold">
                      {isBn ? '১. পাইকারি ও বস্তায় চাল-ডাল কেনা' : '1. Bulk Buying for Staples'}
                    </strong>
                    <p className="text-slate-600 leading-relaxed">
                      {isBn
                        ? 'মিনিকেট চাল বা মসুর ডাল খুচরা ১-২ কেজি না কিনে ২৫ বা ৫০ কেজির বস্তা নিলে কেজিপ্রতি ৩ থেকে ৫ টাকা এবং যাতায়াত খরচ সাশ্রয় হয়।'
                        : 'Purchasing 25kg or 50kg sacks of rice or lentils saves ৳3-5 per kg compared to small loose buys.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-lg">🥚</span>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-800 block font-bold">
                      {isBn ? '২. ডিম খাঁচিতে (৩০টি) কেনা' : '2. Buy Eggs in Crates'}
                    </strong>
                    <p className="text-slate-600 leading-relaxed">
                      {isBn
                        ? 'হালি হিসেবে না কিনে পুরো খাঁচি কিনলে ডজনপ্রতি ১০-১৫ টাকা কমে পাওয়া যায় এবং ঘন ঘন দোকানে যাওয়া লাগে না।'
                        : 'Buying full 30-egg crates saves ৳10-15 per dozen compared to individual 4-egg purchases.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-lg">🥬</span>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-800 block font-bold">
                      {isBn ? '৩. সিজনাল শাকসবজি প্রাধান্য দেওয়া' : '3. Prioritize Seasonal Vegetables'}
                    </strong>
                    <p className="text-slate-600 leading-relaxed">
                      {isBn
                        ? 'অসময়ের দামি সবজি এড়িয়ে মৌসুমি টাটকা শাকসবজি কিনলে পুষ্টিও বেশি পাওয়া যায় এবং খরচ অর্ধেকের নিচে নামে।'
                        : 'Off-season items command huge premiums; seasonal greens and veggies cost nearly half with better freshness.'}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 border border-slate-100">
                  <span className="text-lg">🚛</span>
                  <div className="text-xs space-y-1">
                    <strong className="text-slate-800 block font-bold">
                      {isBn ? '৪. টিসিবি ট্রাকসেল ও সুপারশপ অফার' : '4. TCB Trucksale & Offers'}
                    </strong>
                    <p className="text-slate-600 leading-relaxed">
                      {isBn
                        ? 'তেল, চিনি ও ডালের ক্ষেত্রে টিসিবির নির্ধারিত পয়েন্ট থেকে নিলে বাজার দরের চেয়ে বড় অঙ্কের সাশ্রয় সম্ভব।'
                        : 'Government TCB subsidies for oil, sugar, and lentils provide significant relief against open market price hikes.'}
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Price Stability & Budget Rule Card */}
            <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-2xs space-y-4">
              <div className="flex items-center gap-2.5 pb-3 border-b border-slate-100">
                <div className="p-2 bg-teal-50 text-teal-700 rounded-xl">
                  <Sparkles className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-800">
                    {isBn ? 'বাজেট নিয়ম ও খরচের ভারসাম্য' : 'Bazar Ratio & Allocation'}
                  </h3>
                  <p className="text-xs text-slate-500">
                    {isBn ? 'একটি আদর্শ পরিবারের বাজার খরচের অনুপাত' : 'Healthy expenditure ratio breakdown'}
                  </p>
                </div>
              </div>

              {/* Breakdown Bars */}
              <div className="space-y-4 pt-1">
                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-slate-700">{isBn ? 'মাছ ও মাংস (Fish & Meat)' : 'Fish & Meat'}</span>
                    <span className="text-rose-700 font-bold">৪০% - ৪৫%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-rose-500 h-full w-[45%]" />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    {isBn ? 'সবচেয়ে বড় খরচের অংশ, সপ্তাহে ১-২ দিন বড় বাজার করা ভালো।' : 'Largest expense portion.'}
                  </span>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-slate-700">{isBn ? 'চাল, তেল ও মুদিখানা (Groceries & Staples)' : 'Staples & Groceries'}</span>
                    <span className="text-amber-700 font-bold">৩০% - ৩৫%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-amber-500 h-full w-[35%]" />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    {isBn ? 'মাসের শুরুতে একবারে কেনা সবচেয়ে সাশ্রয়ী।' : 'Best bought monthly in bulk.'}
                  </span>
                </div>

                <div>
                  <div className="flex justify-between text-xs font-semibold mb-1">
                    <span className="text-slate-700">{isBn ? 'টাটকা শাকসবজি ও ফল (Fresh Veg & Fruits)' : 'Vegetables & Fruits'}</span>
                    <span className="text-emerald-700 font-bold">২০% - ২৫%</span>
                  </div>
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden">
                    <div className="bg-emerald-500 h-full w-[20%]" />
                  </div>
                  <span className="text-[11px] text-slate-400 mt-0.5 block">
                    {isBn ? 'সপ্তাহে ২-৩ দিন স্থানীয় কাঁচাবাজার থেকে টাটকা কেনা উত্তম।' : 'Buy fresh 2-3 times weekly.'}
                  </span>
                </div>
              </div>

              {/* Motivational Quote */}
              <div className="bg-emerald-50 rounded-xl p-3.5 border border-emerald-100 text-xs text-emerald-900 mt-4 leading-relaxed">
                📌 <strong>{isBn ? 'পরামর্শ:' : 'Pro-tip:'}</strong>{' '}
                {isBn
                  ? 'বাজারে যাওয়ার আগে ফর্দ লিখে নিলে অতিরিক্ত কেনাকাটা বা ইমপালস বাই প্রায় ৩০% কমে যায়!'
                  : 'Sticking to a pre-written bazar checklist curbs impulsive superstore/bazar purchases by over 30%!'}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: ADD / EDIT ITEM MODAL */}
      {/* ========================================================================= */}
      {isAddItemModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddItemModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4 animate-in fade-in zoom-in-95 duration-150 max-h-[90dvh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-base font-bold text-slate-900">
                {editingItem
                  ? (isBn ? 'বাজার আইটেম এডিট করুন' : 'Edit Bazar Item')
                  : (isBn ? 'নতুন বাজার আইটেম যোগ করুন' : 'Add Bazar Item')}
              </h3>
              <button
                onClick={() => setIsAddItemModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveItem} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? 'পণ্যের নাম' : 'Item Name'} *
                </label>
                <input
                  type="text"
                  required
                  placeholder={isBn ? 'যেমন: দেশি পেঁয়াজ, ইলিশ মাছ, আলু' : 'e.g. Red Onion, Rui Fish'}
                  value={itemNameInput}
                  onChange={e => setItemNameInput(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isBn ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={itemCategoryInput}
                    onChange={e => setItemCategoryInput(e.target.value as BazarCategory)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 bg-white"
                  >
                    <option value="vegetables">{isBn ? '🥬 শাকসবজি' : 'Vegetables'}</option>
                    <option value="fish_meat">{isBn ? '🥩 মাছ ও মাংস' : 'Fish & Meat'}</option>
                    <option value="grocery">{isBn ? '🛢️ মুদি ও তেল' : 'Grocery'}</option>
                    <option value="spices">{isBn ? '🌶️ মসলা' : 'Spices'}</option>
                    <option value="dairy_eggs">{isBn ? '🥚 ডিম ও দুধ' : 'Dairy & Eggs'}</option>
                    <option value="fruits">{isBn ? '🍎 ফলমূল' : 'Fruits'}</option>
                    <option value="other">{isBn ? '🛒 অন্যান্য' : 'Other'}</option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isBn ? 'পরিমাণ' : 'Quantity'}
                  </label>
                  <input
                    type="text"
                    placeholder="১ কেজি / ২ লিটার"
                    value={itemQuantityInput}
                    onChange={e => setItemQuantityInput(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isBn ? 'আনুমানিক বাজেট (টাকা)' : 'Estimated Price'}
                  </label>
                  <input
                    type="number"
                    placeholder="১১০"
                    value={itemEstimatedPriceInput}
                    onChange={e => setItemEstimatedPriceInput(e.target.value)}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">
                    {isBn ? 'গুরুত্ব' : 'Priority'}
                  </label>
                  <select
                    value={itemPriorityInput}
                    onChange={e => setItemPriorityInput(e.target.value as 'essential' | 'optional')}
                    className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 bg-white"
                  >
                    <option value="essential">{isBn ? 'জরুরি (অপরিহার্য)' : 'Essential'}</option>
                    <option value="optional">{isBn ? 'ঐচ্ছিক (বাজেট থাকলে)' : 'Optional'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? 'নোট বা বিবরণ (ঐচ্ছিক)' : 'Notes (Optional)'}
                </label>
                <input
                  type="text"
                  placeholder={isBn ? 'যেমন: মাঝারি সাইজ, টাটকা' : 'e.g. Medium size, fresh'}
                  value={itemNotesInput}
                  onChange={e => setItemNotesInput(e.target.value)}
                  className="w-full px-3 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsAddItemModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs"
                >
                  {editingItem ? (isBn ? 'আপডেট করুন' : 'Update Item') : (isBn ? 'ফর্দে যোগ করুন' : 'Add to List')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: CHECKOUT & CONVERT TO REAL EXPENSE MODAL */}
      {/* ========================================================================= */}
      {isCheckoutModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsCheckoutModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-2xl max-w-md w-full p-6 shadow-xl space-y-4 animate-in fade-in zoom-in-95 duration-150 max-h-[90dvh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-2 bg-emerald-100 text-emerald-800 rounded-xl">
                  <CheckCircle2 className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {isBn ? 'কেনাকাটা শেষ - খরচে যোগ করুন' : 'Checkout & Add to Expenses'}
                  </h3>
                  <span className="text-xs text-slate-500">
                    {isBn ? `${bazarCompletedCount}টি কেনা পণ্যের হিসাব যুক্ত হবে` : `${bazarCompletedCount} purchased items`}
                  </span>
                </div>
              </div>
              <button
                onClick={() => setIsCheckoutModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-emerald-50 rounded-xl p-4 border border-emerald-100 flex items-center justify-between">
              <div>
                <span className="text-xs text-emerald-800 font-semibold block">
                  {isBn ? 'মোট খরচ পরিশোধ হবে' : 'Total Checkout Amount'}
                </span>
                <span className="text-2xl font-black text-emerald-900">
                  {formatMoney(actualBazarSpent)}
                </span>
              </div>
              <span className="text-xs font-bold px-2.5 py-1 rounded-lg bg-emerald-200 text-emerald-900">
                {bazarCompletedCount} {isBn ? 'টি আইটেম' : 'items'}
              </span>
            </div>

            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? 'কোন ওয়ালেট থেকে টাকা পরিশোধ করেছেন?' : 'Paid From Account'} *
                </label>
                <select
                  value={selectedCheckoutAccountId}
                  onChange={e => setSelectedCheckoutAccountId(e.target.value)}
                  className="w-full px-3.5 py-2.5 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 bg-white"
                >
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {isBn ? acc.nameBn : acc.name} ({formatMoney(acc.balance)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? 'বাজারের নাম বা নোট (ঐচ্ছিক)' : 'Market Name / Note (Optional)'}
                </label>
                <input
                  type="text"
                  placeholder={isBn ? 'যেমন: কারওয়ান বাজার সকালের সদাই' : 'e.g. Karwan Bazar Morning Shopping'}
                  value={checkoutNote}
                  onChange={e => setCheckoutNote(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div className="p-3 bg-slate-50 rounded-xl text-xs text-slate-600 space-y-1 border border-slate-100">
                <p>
                  ✅ {isBn ? 'এটি স্বয়ংক্রিয়ভাবে "বাজার ও মুদিখানা" ক্যাটাগরিতে একটি ব্যয় তৈরি করবে।' : 'Will record an expense under "Groceries".'}
                </p>
                <p>
                  ✅ {isBn ? 'নির্বাচিত ওয়ালেটের ব্যালেন্স থেকে টাকা সমন্বয় হবে।' : 'Wallet balance will be deducted automatically.'}
                </p>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setIsCheckoutModalOpen(false)}
                className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={handleConfirmCheckout}
                className="px-5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs cursor-pointer active:scale-95 transition-transform"
              >
                {isBn ? 'নিশ্চিত করুন ও ট্রানজ্যাকশন যোগ করুন' : 'Confirm & Log Expense'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: LOG NEW COMMODITY PRICE MODAL */}
      {/* ========================================================================= */}
      {isLogPriceModalOpen && selectedCommodityForLog && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsLogPriceModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-xl space-y-4 animate-in fade-in zoom-in-95 duration-150 max-h-[90dvh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <span className="text-xl">{selectedCommodityForLog.icon}</span>
                <h3 className="text-base font-bold text-slate-900">
                  {isBn ? selectedCommodityForLog.nameBn : selectedCommodityForLog.name} - {isBn ? 'দর আপডেট' : 'Update Price'}
                </h3>
              </div>
              <button
                onClick={() => setIsLogPriceModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-slate-700"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSavePriceLog} className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? `আজকের বাজার দর (${currency.symbol} প্রতি ${selectedCommodityForLog.unitBn})` : `Today's Rate (${currency.symbol}/${selectedCommodityForLog.unit})`} *
                </label>
                <input
                  type="number"
                  required
                  value={logPriceInput}
                  onChange={e => setLogPriceInput(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 font-bold"
                />
              </div>

              <div>
                <label className="text-xs font-bold text-slate-700 block mb-1">
                  {isBn ? 'বাজারের নাম বা উৎস' : 'Market Location / Source'}
                </label>
                <input
                  type="text"
                  placeholder="যেমন: কারওয়ান বাজার, মিরপুর ১"
                  value={logMarketNameInput}
                  onChange={e => setLogMarketNameInput(e.target.value)}
                  className="w-full px-3.5 py-2 text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsLogPriceModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {isBn ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl shadow-xs"
                >
                  {isBn ? 'সংরক্ষণ করুন' : 'Save Price'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
