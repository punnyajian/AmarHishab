import React, { useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import {
  AIActionProposal,
  AIActivityEvent,
  AIChatMessage,
  AIReportSummary,
} from '../../types';
import {
  Sparkles,
  ShieldCheck,
  ShieldAlert,
  AlertTriangle,
  TrendingUp,
  TrendingDown,
  CheckCircle2,
  Clock,
  ArrowRight,
  BrainCircuit,
  Bot,
  Send,
  RefreshCw,
  Sliders,
  FileText,
  CreditCard,
  Target,
  Wallet,
  Calendar,
  Layers,
  Activity,
  History,
  Check,
  X,
  Printer,
  Copy,
  CheckCheck,
  ChevronRight,
  HelpCircle,
  Lightbulb,
} from 'lucide-react';
import { AIActionConfirmationModal } from '../AIActionConfirmationModal';

export const AIControlCenterView: React.FC = () => {
  const {
    aiHealthScore,
    aiAnomalies,
    aiActionProposals,
    aiActivityLogs,
    aiMemory,
    aiNetWorth,
    aiCashFlowForecast,
    aiChatMessages,
    executeAIAction,
    dismissAIAction,
    updateAIMemoryPreferences,
    sendAICommand,
    generateAIReport,
    activeActionConfirmationModal,
    setActiveActionConfirmationModal,
    accounts,
    transactions,
    categories,
    budgets,
    subscriptions,
    debts,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const isBn = language === 'bn';

  // Sub-tabs
  type ControlTab = 'overview' | 'actions' | 'anomalies' | 'assistant' | 'reports' | 'memory';
  const [activeTab, setActiveTab] = useState<ControlTab>('overview');

  // Assistant query input
  const [chatInput, setChatInput] = useState('');
  const [isProcessingChat, setIsProcessingChat] = useState(false);

  // Active generated report state
  const [reportPeriod, setReportPeriod] = useState<'daily' | 'weekly' | 'monthly'>('monthly');
  const [activeReport, setActiveReport] = useState<AIReportSummary | null>(null);
  const [copiedReport, setCopiedReport] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);

  // Filter logs by module
  const [logFilterModule, setLogFilterModule] = useState<string>('all');

  const handleRefreshAudit = () => {
    setIsRefreshing(true);
    setTimeout(() => {
      setIsRefreshing(false);
    }, 600);
  };

  const handleSendChat = async (textToSend?: string) => {
    const text = textToSend || chatInput;
    if (!text.trim() || isProcessingChat) return;

    setChatInput('');
    setIsProcessingChat(true);
    try {
      await sendAICommand(text.trim());
    } finally {
      setIsProcessingChat(false);
    }
  };

  const handleGenerateReport = (period: 'daily' | 'weekly' | 'monthly') => {
    setReportPeriod(period);
    const report = generateAIReport(period);
    setActiveReport(report);
  };

  const handleCopyReport = () => {
    if (!activeReport) return;
    const txt = `📊 ${activeReport.headlineBn || activeReport.headlineEn}\nতারিখ: ${new Date().toLocaleDateString('bn-BD')}\n\nমূল তথ্যাদি:\n• আয়: ${formatMoney(activeReport.keyMetrics.income)}\n• ব্যয়: ${formatMoney(activeReport.keyMetrics.expense)}\n• নিট সঞ্চয়: ${formatMoney(activeReport.keyMetrics.netSavings)} (${activeReport.keyMetrics.savingsRate}%)\n• প্রধান খরচের খাত: ${activeReport.keyMetrics.topCategory}\n\nগুরুত্বপূর্ণ বিষয়সমূহ:\n${activeReport.highlightsBn.map(h => `• ${h}`).join('\n')}\n\nকরণীয় পদক্ষেপ:\n${activeReport.actionableStepsBn.map(s => `• ${s}`).join('\n')}\n\n- Khoroch Central AI Control System`;
    navigator.clipboard.writeText(txt);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2500);
  };

  const pendingProposals = aiActionProposals.filter(p => p.status === 'pending');

  const filteredLogs = aiActivityLogs.filter(log => {
    if (logFilterModule === 'all') return true;
    return log.module.toLowerCase() === logFilterModule.toLowerCase();
  });

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      
      {/* Hero Header: AI Guardian Online */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-slate-900 via-emerald-950 to-teal-900 text-white p-6 sm:p-8 shadow-sm border border-emerald-900/50">
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 text-xs font-bold border border-emerald-400/30 backdrop-blur-xs">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
              <BrainCircuit className="w-3.5 h-3.5 text-emerald-400" />
              <span>{isBn ? 'সেন্ট্রাল এআই অভিভাবক সক্রিয় · ১২টি মডিউল সিঙ্কড' : 'AI Guardian Online · 12 Modules Connected'}</span>
            </div>
            
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2.5">
              <span>{isBn ? 'কেন্দ্রীয় এআই অর্থনৈতিক কন্ট্রোল সিস্টেম' : 'Central AI Financial Control System'}</span>
              <Sparkles className="w-6 h-6 text-emerald-400 animate-pulse hidden sm:inline" />
            </h1>
            
            <p className="text-emerald-100/80 text-xs sm:text-sm max-w-2xl leading-relaxed">
              {isBn
                ? 'আপনার আয়, ব্যয়, বাজেট, দেনা-পাওনা, ডিজিটাল কার্ড, সাবস্ক্রিপশন এবং সঞ্চয় লক্ষ্যের সার্বক্ষণিক এআই অডিট ও নিরাপত্তা নিয়ন্ত্রণ হাব।'
                : 'Centralized intelligence layer continuously analyzing transactions, category patterns, budget boundaries, obligations, and liquidity risks.'}
            </p>
          </div>

          {/* Health Score Pill Card in Hero */}
          <div className="flex items-center gap-4 bg-white/10 backdrop-blur-md border border-white/20 rounded-2xl p-4 sm:p-5 shrink-0">
            <div className="relative w-16 h-16 sm:w-20 sm:h-20 flex items-center justify-center">
              <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                <path
                  className="text-white/20"
                  strokeWidth="3.8"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
                <path
                  className={
                    aiHealthScore.overallScore >= 80
                      ? 'text-emerald-400'
                      : aiHealthScore.overallScore >= 60
                      ? 'text-teal-300'
                      : aiHealthScore.overallScore >= 40
                      ? 'text-amber-400'
                      : 'text-rose-400'
                  }
                  strokeDasharray={`${aiHealthScore.overallScore}, 100`}
                  strokeWidth="3.8"
                  strokeLinecap="round"
                  stroke="currentColor"
                  fill="none"
                  d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                />
              </svg>
              <div className="absolute flex flex-col items-center">
                <span className="text-lg sm:text-2xl font-black text-white">{aiHealthScore.overallScore}</span>
                <span className="text-[9px] uppercase tracking-wider text-emerald-200 font-bold">/১০০</span>
              </div>
            </div>

            <div className="space-y-1">
              <span className="text-xs text-emerald-200 block font-medium">
                {isBn ? 'আর্থিক স্বাস্থ্য স্কোর' : 'Health Score'}
              </span>
              <span
                className={`inline-block px-2.5 py-0.5 rounded-full text-xs font-bold ${
                  aiHealthScore.status === 'excellent'
                    ? 'bg-emerald-400/30 text-emerald-200 border border-emerald-400/40'
                    : aiHealthScore.status === 'good'
                    ? 'bg-teal-400/30 text-teal-200 border border-teal-400/40'
                    : aiHealthScore.status === 'moderate'
                    ? 'bg-amber-400/30 text-amber-200 border border-amber-400/40'
                    : 'bg-rose-400/30 text-rose-200 border border-rose-400/40'
                }`}
              >
                {aiHealthScore.status === 'excellent'
                  ? (isBn ? 'চমৎকার' : 'Excellent')
                  : aiHealthScore.status === 'good'
                  ? (isBn ? 'সন্তোষজনক' : 'Good')
                  : aiHealthScore.status === 'moderate'
                  ? (isBn ? 'সতর্কতা' : 'Moderate')
                  : (isBn ? 'জরুরি দৃষ্টি' : 'Critical')}
              </span>
              <div className="pt-1">
                <button
                  onClick={handleRefreshAudit}
                  disabled={isRefreshing}
                  className="text-[11px] text-emerald-300 hover:text-white flex items-center gap-1 transition-colors"
                >
                  <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
                  <span>{isBn ? 'অডিট রিফ্রেশ' : 'Refresh Audit'}</span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative background glow */}
        <div className="absolute -right-20 -top-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2 overflow-x-auto no-scrollbar gap-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('overview')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'overview'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Activity className="w-4 h-4" />
            <span>{isBn ? 'সার্বিক বিশ্লেষণ' : 'Overview & Health'}</span>
          </button>

          <button
            onClick={() => setActiveTab('actions')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'actions'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <BrainCircuit className="w-4 h-4" />
            <span>{isBn ? 'এআই অ্যাকশন ও সুপারিশ' : 'AI Actions'}</span>
            {pendingProposals.length > 0 && (
              <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-full bg-rose-500 text-white">
                {pendingProposals.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('anomalies')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'anomalies'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <AlertTriangle className="w-4 h-4" />
            <span>{isBn ? 'রিস্ক ও অ্যানোমালি' : 'Risk & Anomalies'}</span>
            {aiAnomalies.length > 0 && (
              <span className="text-[10px] font-extrabold px-1.5 py-0.5 rounded-full bg-amber-500 text-white">
                {aiAnomalies.length}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveTab('assistant')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'assistant'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Bot className="w-4 h-4" />
            <span>{isBn ? 'এআই অ্যাসিস্ট্যান্ট' : 'AI Assistant'}</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('reports');
              if (!activeReport) handleGenerateReport('monthly');
            }}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'reports'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <FileText className="w-4 h-4" />
            <span>{isBn ? 'অডিট রিপোর্ট' : 'AI Reports'}</span>
          </button>

          <button
            onClick={() => setActiveTab('memory')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-all shrink-0 ${
              activeTab === 'memory'
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>{isBn ? 'অ্যাক্টিভিটি লগ ও মেমোরি' : 'Logs & Memory'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. OVERVIEW & HEALTH SCORE TAB */}
      {/* ========================================================================= */}
      {activeTab === 'overview' && (
        <div className="space-y-6">
          
          {/* Health Score Summary Banner */}
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-emerald-600" />
                <span>{isBn ? 'এআই আর্থিক মূল্যায়ন সারাংশ' : 'Executive AI Financial Evaluation'}</span>
              </h3>
              <span className="text-xs text-slate-400 font-medium">
                {new Date().toLocaleDateString(isBn ? 'bn-BD' : 'en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
              </span>
            </div>
            
            <p className="text-xs sm:text-sm text-slate-700 leading-relaxed bg-slate-50 p-3.5 rounded-xl border border-slate-200/60 font-medium">
              💡 {isBn ? aiHealthScore.summaryBn : aiHealthScore.summaryEn}
            </p>

            {/* 5 Health Pillars Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 pt-2">
              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1">
                <span className="text-[11px] font-semibold text-slate-500 block truncate">
                  {isBn ? 'সঞ্চয় শৃঙ্খলা' : 'Savings Rate'}
                </span>
                <span className="text-base font-black text-slate-900">{aiHealthScore.savingsScore}%</span>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-500 h-full rounded-full" style={{ width: `${aiHealthScore.savingsScore}%` }} />
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1">
                <span className="text-[11px] font-semibold text-slate-500 block truncate">
                  {isBn ? 'বাজেট নিয়ন্ত্রণ' : 'Budget Control'}
                </span>
                <span className="text-base font-black text-slate-900">{aiHealthScore.budgetDisciplineScore}%</span>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-teal-500 h-full rounded-full" style={{ width: `${aiHealthScore.budgetDisciplineScore}%` }} />
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1">
                <span className="text-[11px] font-semibold text-slate-500 block truncate">
                  {isBn ? 'ঋণ ও দায়ভার' : 'Debt Burden'}
                </span>
                <span className="text-base font-black text-slate-900">{aiHealthScore.debtToIncomeScore}%</span>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-indigo-500 h-full rounded-full" style={{ width: `${aiHealthScore.debtToIncomeScore}%` }} />
                </div>
              </div>

              <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1">
                <span className="text-[11px] font-semibold text-slate-500 block truncate">
                  {isBn ? 'ক্যাশ রানওয়ে' : 'Cash Runway'}
                </span>
                <span className="text-base font-black text-slate-900">{aiHealthScore.liquidityScore}%</span>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-cyan-500 h-full rounded-full" style={{ width: `${aiHealthScore.liquidityScore}%` }} />
                </div>
              </div>

              <div className="col-span-2 sm:col-span-1 bg-slate-50 rounded-xl p-3 border border-slate-100 space-y-1">
                <span className="text-[11px] font-semibold text-slate-500 block truncate">
                  {isBn ? 'বিলের নিয়মানুবর্তিতা' : 'Bill Punctuality'}
                </span>
                <span className="text-base font-black text-slate-900">{aiHealthScore.billPunctualityScore}%</span>
                <div className="w-full bg-slate-200 h-1.5 rounded-full overflow-hidden">
                  <div className="bg-emerald-600 h-full rounded-full" style={{ width: `${aiHealthScore.billPunctualityScore}%` }} />
                </div>
              </div>
            </div>
          </div>

          {/* Dual Intelligence Cards: Net Worth & Cash-Flow Runway */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* 1. Net Worth Intelligence */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-emerald-50 text-emerald-800 rounded-xl">
                      <Wallet className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">
                        {isBn ? 'নিট সম্পদ বিশ্লেষণ (Net Worth)' : 'Net Worth Intelligence'}
                      </h4>
                      <span className="text-[11px] text-slate-400">{isBn ? 'সম্পদ বনাম দায়ভারের বাস্তব চিত্র' : 'Assets vs. Liabilities balance'}</span>
                    </div>
                  </div>
                  <span className="text-lg font-black text-emerald-700">
                    {formatMoney(aiNetWorth.netWorth)}
                  </span>
                </div>

                <div className="space-y-2.5 pt-3 text-xs">
                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                    <span className="text-slate-600 font-medium">{isBn ? 'মোট সম্পদ (Assets):' : 'Total Assets:'}</span>
                    <span className="font-bold text-emerald-800">{formatMoney(aiNetWorth.totalAssets)}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                    <span className="text-slate-600 font-medium">{isBn ? 'মোট দায়ভার (Liabilities):' : 'Total Liabilities:'}</span>
                    <span className="font-bold text-rose-700">{formatMoney(aiNetWorth.totalLiabilities)}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed bg-emerald-50/50 p-2.5 rounded-xl border border-emerald-100">
                    ℹ️ {isBn ? aiNetWorth.insightBn : aiNetWorth.insightEn}
                  </p>
                </div>
              </div>

              <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-100">
                <span>{isBn ? 'লিকুইড ক্যাশ:' : 'Liquid Cash:'} {formatMoney(aiNetWorth.liquidCashAndBank)}</span>
                <span>{isBn ? 'বিনিয়োগ ও স্বর্ণ:' : 'Investments:'} {formatMoney(aiNetWorth.investmentsAndGold)}</span>
              </div>
            </div>

            {/* 2. Cash Flow & Runway Forecast */}
            <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-4 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <div className="p-2 bg-teal-50 text-teal-800 rounded-xl">
                      <Clock className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-slate-900">
                        {isBn ? 'ক্যাশ-ফ্লো পূর্বাভাস ও রানওয়ে' : 'Cash Flow & Runway Forecast'}
                      </h4>
                      <span className="text-[11px] text-slate-400">{isBn ? 'মাস শেষের সম্ভাব্য ব্যালেন্স' : 'Projected month-end buffer'}</span>
                    </div>
                  </div>

                  <span
                    className={`text-xs font-bold px-2 py-0.5 rounded-md ${
                      aiCashFlowForecast.riskLevel === 'safe'
                        ? 'bg-emerald-100 text-emerald-800'
                        : aiCashFlowForecast.riskLevel === 'caution'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-rose-100 text-rose-800'
                    }`}
                  >
                    {isBn ? `রানওয়ে: ${aiCashFlowForecast.runwayDays} দিন` : `${aiCashFlowForecast.runwayDays} Days Runway`}
                  </span>
                </div>

                <div className="space-y-2.5 pt-3 text-xs">
                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                    <span className="text-slate-600 font-medium">{isBn ? 'বর্তমান নগদ তহবিল:' : 'Current Liquid Funds:'}</span>
                    <span className="font-bold text-slate-800">{formatMoney(aiCashFlowForecast.currentLiquidBalance)}</span>
                  </div>
                  <div className="flex items-center justify-between p-2 rounded-xl bg-slate-50">
                    <span className="text-slate-600 font-medium">{isBn ? 'মাস শেষে সম্ভাব্য ব্যালেন্স:' : 'Projected Month-End Balance:'}</span>
                    <span className="font-bold text-teal-700">{formatMoney(aiCashFlowForecast.estimatedEndOfMonthBalance)}</span>
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed bg-teal-50/50 p-2.5 rounded-xl border border-teal-100">
                    🔮 {isBn ? aiCashFlowForecast.adviceBn : aiCashFlowForecast.adviceEn}
                  </p>
                </div>
              </div>

              <div className="pt-2 text-[11px] text-slate-400 flex items-center justify-between border-t border-slate-100">
                <span>{isBn ? 'আসন্ন বিলের দায়:' : 'Upcoming Bills:'} {formatMoney(aiCashFlowForecast.upcomingObligations)}</span>
                <span>{isBn ? 'দৈনিক খরচ অনুমান:' : 'Est. Burn:'} {formatMoney(Math.round(aiCashFlowForecast.projectedExpensesRemainder / 20))}</span>
              </div>
            </div>
          </div>

          {/* Quick Assistant Callout Bar */}
          <div className="bg-gradient-to-r from-emerald-600 to-teal-700 rounded-2xl p-4.5 text-white flex flex-col sm:flex-row sm:items-center justify-between gap-4 shadow-xs">
            <div className="space-y-1">
              <div className="flex items-center gap-2">
                <Bot className="w-5 h-5 text-emerald-200" />
                <span className="text-sm font-bold">{isBn ? 'এআই কমান্ড কনসোল প্রস্তুত' : 'AI Assistant Ready for Commands'}</span>
              </div>
              <p className="text-xs text-emerald-100/90">
                {isBn
                  ? 'মুখে বা লিখে বলুন: "এই মাসে কত খরচ হলো?", "বাজেট সুপারিশ করো", অথবা "আজকে ৫০০ টাকা বাজার খরচ যোগ করো"'
                  : 'Ask natural questions or request actions like "Add 500 taka grocery expense today" or "Can I afford a new phone?"'}
              </p>
            </div>
            <button
              onClick={() => setActiveTab('assistant')}
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-white text-emerald-800 font-bold text-xs rounded-xl shadow-xs hover:bg-emerald-50 active:scale-95 transition-all shrink-0 cursor-pointer"
            >
              <span>{isBn ? 'অ্যাসিস্ট্যান্ট খুলুন' : 'Open Assistant'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. AI ACTIONS & RECOMMENDATIONS TAB */}
      {/* ========================================================================= */}
      {activeTab === 'actions' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <BrainCircuit className="w-5 h-5 text-emerald-600" />
                <span>{isBn ? 'এআই অ্যাকশন ও অনুমোদনাধীন প্রস্তাবসমূহ' : 'AI Action Proposals & Recommendations'}</span>
              </h3>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                {pendingProposals.length} {isBn ? 'টি বিবেচনাধীন' : 'Pending'}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {isBn
                ? 'সংবেদনশীল কোনো পরিবর্তন (বাজেট পরিবর্তন, নতুন ট্রানজ্যাকশন, সেভিংস গোল) আপনার সুস্পষ্ট অনুমোদন ছাড়া কার্যকর হবে না।'
                : 'AI follows strict safety protocols: actions require your explicit confirmation before applying.'}
            </p>
          </div>

          {/* Proposals List */}
          {pendingProposals.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle2 className="w-8 h-8" />
              </div>
              <h4 className="text-base font-bold text-slate-800 mb-1">
                {isBn ? 'কোনো অমীমাংসিত অ্যাকশন প্রস্তাব নেই' : 'No Pending Action Proposals'}
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
                {isBn
                  ? 'আপনার সকল বাজেট ও ট্রানজ্যাকশন সামঞ্জস্যপূর্ণ। অ্যাসিস্ট্যান্টে গিয়ে নতুন কমান্ড দিতে পারেন।'
                  : 'All modules are synchronized and optimal. Use the Assistant tab to request new actions.'}
              </p>
              <button
                onClick={() => setActiveTab('assistant')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs inline-flex items-center gap-1.5"
              >
                <Bot className="w-4 h-4" />
                <span>{isBn ? 'অ্যাসিস্ট্যান্টকে নির্দেশ দিন' : 'Instruct Assistant'}</span>
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              {pendingProposals.map(proposal => (
                <div
                  key={proposal.id}
                  className="bg-white rounded-2xl p-5 border border-slate-200 hover:border-emerald-300 shadow-2xs transition-all space-y-4"
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                          {proposal.type.replace('_', ' ')}
                        </span>
                        <h4 className="text-sm sm:text-base font-bold text-slate-900">
                          {isBn ? proposal.titleBn || proposal.title : proposal.title}
                        </h4>
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {isBn ? proposal.descriptionBn || proposal.description : proposal.description}
                      </p>
                    </div>

                    {/* Action buttons */}
                    <div className="flex items-center gap-2 shrink-0">
                      <button
                        onClick={() => dismissAIAction(proposal.id)}
                        className="px-3 py-1.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-500 hover:bg-slate-100 transition-colors"
                      >
                        {isBn ? 'বাতিল' : 'Dismiss'}
                      </button>
                      <button
                        onClick={() => setActiveActionConfirmationModal(proposal)}
                        className="px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs active:scale-95 transition-transform inline-flex items-center gap-1.5 cursor-pointer"
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>{isBn ? 'পর্যালোচনা ও নিশ্চিতকরণ' : 'Review & Confirm'}</span>
                      </button>
                    </div>
                  </div>

                  {/* Spec Row */}
                  <div className="bg-slate-50 rounded-xl p-3 border border-slate-100 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    {proposal.currentValue && (
                      <div>
                        <span className="text-slate-400 block font-medium">{isBn ? 'বর্তমান মান:' : 'Current:'}</span>
                        <span className="font-bold text-slate-700">{proposal.currentValue}</span>
                      </div>
                    )}
                    <div>
                      <span className="text-slate-400 block font-medium">{isBn ? 'প্রস্তাবিত নতুন মান:' : 'Proposed Value:'}</span>
                      <span className="font-extrabold text-emerald-700">{proposal.newValue}</span>
                    </div>
                    <div className="sm:col-span-1">
                      <span className="text-slate-400 block font-medium">{isBn ? 'যুক্তি ও বিশ্লেষণ:' : 'Reasoning:'}</span>
                      <span className="font-medium text-slate-600 truncate block" title={proposal.reason}>
                        {isBn ? proposal.reasonBn || proposal.reason : proposal.reason}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. RISKS & ANOMALIES TAB */}
      {/* ========================================================================= */}
      {activeTab === 'anomalies' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                <AlertTriangle className="w-5 h-5 text-amber-500" />
                <span>{isBn ? 'রিস্ক ও অ্যানোমালি ডিটেকশন মনিটর' : 'Risk & Anomaly Monitor'}</span>
              </h3>
              <span className="text-xs font-bold px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-900">
                {aiAnomalies.length} {isBn ? 'টি সতর্কতা' : 'Alerts'}
              </span>
            </div>
            <p className="text-xs text-slate-500">
              {isBn
                ? 'স্বয়ংক্রিয়ভাবে অস্বাভাবিক ব্যয়, ডুপ্লিকেট লেনদেন, বাজেট বিপর্যয় ও নগদ অর্থের ঘাটতি শনাক্ত করা হয়।'
                : 'Real-time surveillance scanning for abnormal spending spikes, duplicates, budget breaches, and liquidity gaps.'}
            </p>
          </div>

          {aiAnomalies.length === 0 ? (
            <div className="bg-white rounded-2xl p-12 text-center border border-slate-200">
              <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <ShieldCheck className="w-8 h-8" />
              </div>
              <h4 className="text-base font-bold text-slate-800 mb-1">
                {isBn ? 'কোনো অ্যানোমালি বা ঝুঁকি পাওয়া যায়নি!' : 'No Anomalies or Risks Detected'}
              </h4>
              <p className="text-xs text-slate-500 max-w-sm mx-auto">
                {isBn
                  ? 'আপনার সকল ট্রানজ্যাকশন ও বাজেট স্বাভাবিক প্যারামিটারে রয়েছে। এআই সার্বক্ষণিক নজর রাখছে।'
                  : 'All transactions, category behaviors, and obligations are within safe operational thresholds.'}
              </p>
            </div>
          ) : (
            <div className="space-y-3.5">
              {aiAnomalies.map(risk => (
                <div
                  key={risk.id}
                  className={`rounded-2xl p-4.5 border transition-all ${
                    risk.severity === 'critical'
                      ? 'bg-rose-50/70 border-rose-200 text-rose-950'
                      : risk.severity === 'high'
                      ? 'bg-amber-50/70 border-amber-200 text-amber-950'
                      : 'bg-slate-50 border-slate-200 text-slate-800'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-sm ${
                            risk.severity === 'critical'
                              ? 'bg-rose-200 text-rose-900'
                              : risk.severity === 'high'
                              ? 'bg-amber-200 text-amber-900'
                              : 'bg-slate-200 text-slate-800'
                          }`}
                        >
                          {risk.severity}
                        </span>
                        <h4 className="text-sm font-bold">
                          {isBn ? risk.titleBn || risk.title : risk.title}
                        </h4>
                      </div>
                      <p className="text-xs opacity-90 leading-relaxed">
                        {isBn ? risk.messageBn || risk.message : risk.message}
                      </p>
                    </div>

                    {risk.actionProposal && (
                      <button
                        onClick={() => setActiveActionConfirmationModal(risk.actionProposal!)}
                        className="px-3.5 py-1.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-bold shadow-xs shrink-0 self-start cursor-pointer"
                      >
                        {isBn ? 'প্রতিকার নিন' : 'Apply Mitigation'}
                      </button>
                    )}
                  </div>

                  <div className="mt-3 pt-2.5 border-t border-slate-200/60 flex items-center justify-between text-[11px] opacity-80">
                    <span>💡 {isBn ? `সুপারিশ: ${risk.suggestedActionBn}` : `Action: ${risk.suggestedAction}`}</span>
                    <span className="font-mono text-[10px]">{new Date(risk.detectedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 4. NATURAL LANGUAGE FINANCIAL ASSISTANT TAB */}
      {/* ========================================================================= */}
      {activeTab === 'assistant' && (
        <div className="bg-white rounded-3xl border border-slate-200 shadow-2xs overflow-hidden flex flex-col min-h-[580px]">
          {/* Header */}
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                <Bot className="w-4 h-4" />
              </div>
              <div>
                <h3 className="text-sm font-bold text-slate-900">
                  {isBn ? 'স্মার্ট এআই ফাইন্যান্সিয়াল কমান্ড অ্যাসিস্ট্যান্ট' : 'AI Financial Command Console'}
                </h3>
                <span className="text-[11px] text-emerald-700 font-semibold flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                  {isBn ? 'সকল মডিউলের ডেটায় সরাসরি প্রবেশাধিকার সক্রিয়' : 'Grounded in real financial data'}
                </span>
              </div>
            </div>

            <button
              onClick={() => handleSendChat(isBn ? 'মাসিক খরচের সামারি বিশ্লেষণ করো' : 'Audit my monthly spending')}
              className="text-xs text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 px-3 py-1.5 rounded-xl font-bold transition-colors cursor-pointer"
            >
              {isBn ? 'অডিট সামারি' : 'Quick Audit'}
            </button>
          </div>

          {/* Chat Message Scroll */}
          <div className="flex-1 p-4 sm:p-6 overflow-y-auto space-y-4 max-h-[460px]">
            {aiChatMessages.length === 0 ? (
              <div className="py-12 sm:py-16 text-center text-slate-400 space-y-3">
                <div className="w-14 h-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto shadow-2xs">
                  <Bot className="w-7 h-7" />
                </div>
                <div className="space-y-1">
                  <h4 className="text-sm font-bold text-slate-800">
                    {isBn ? 'সেন্ট্রাল এআই ফাইন্যান্সিয়াল অ্যাসিস্ট্যান্ট প্রস্তুত' : 'Central AI Financial Assistant Ready'}
                  </h4>
                  <p className="text-xs text-slate-500 max-w-sm mx-auto">
                    {isBn
                      ? 'অ্যাপের খরচ, আয়, বাজেট, ঋণ বা সেভিংস সম্পর্কে যেকোনো প্রশ্ন করুন অথবা নিচের সাজেস্টেড বাটনে ট্যাপ করুন।'
                      : 'Ask anything about your expenses, budgets, debts or savings, or tap any quick suggestion below.'}
                  </p>
                </div>
              </div>
            ) : (
              aiChatMessages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.sender === 'ai' && (
                    <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5 shadow-2xs">
                      <Sparkles className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] sm:max-w-[75%] rounded-2xl p-4 text-xs sm:text-sm leading-relaxed space-y-2 ${
                      msg.sender === 'user'
                        ? 'bg-slate-900 text-white font-medium rounded-br-xs'
                        : 'bg-slate-50 border border-slate-200 text-slate-800 rounded-bl-xs'
                    }`}
                  >
                    <p className="whitespace-pre-line">{msg.text}</p>

                    {/* Attached Action Proposal Card inside Chat */}
                    {msg.actionProposal && (
                      <div className="mt-3 p-3 bg-white rounded-xl border border-emerald-200 shadow-2xs space-y-2">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-bold text-emerald-800">{msg.actionProposal.titleBn || msg.actionProposal.title}</span>
                          <span className="font-extrabold text-slate-900">{msg.actionProposal.newValue}</span>
                        </div>
                        <p className="text-[11px] text-slate-500">{msg.actionProposal.reasonBn || msg.actionProposal.reason}</p>
                        
                        {msg.actionProposal.status === 'pending' ? (
                          <button
                            onClick={() => setActiveActionConfirmationModal(msg.actionProposal!)}
                            className="w-full py-1.5 bg-emerald-600 hover:bg-emerald-700 active:scale-[0.99] text-white text-xs font-bold rounded-lg shadow-xs transition-all cursor-pointer"
                          >
                            {isBn ? 'নিশ্চিত করুন ও কার্যকর করুন' : 'Confirm Action'}
                          </button>
                        ) : (
                          <span className="text-[11px] font-bold text-emerald-700 block text-center bg-emerald-50 py-1 rounded-md">
                            ✓ {msg.actionProposal.status === 'confirmed' ? (isBn ? 'কার্যকর সম্পন্ন' : 'Executed') : (isBn ? 'বাতিলকৃত' : 'Dismissed')}
                          </span>
                        )}
                      </div>
                    )}

                    <span className="text-[10px] opacity-40 block text-right font-mono">
                      {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              ))
            )}

            {isProcessingChat && (
              <div className="flex items-center gap-2 text-xs text-slate-500 font-medium p-2">
                <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-600" />
                <span>{isBn ? 'এআই আর্থিক ডেটা বিশ্লেষণ করছে...' : 'Analyzing financial data...'}</span>
              </div>
            )}
          </div>

          {/* Quick Preset Prompt Chips (As explicitly listed in User Brief) */}
          <div className="px-4 py-2 bg-slate-50/70 border-t border-slate-200/70 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
            <span className="text-[10px] font-bold text-slate-400 uppercase shrink-0">
              {isBn ? 'দ্রুত জিজ্ঞাসা:' : 'Suggestions:'}
            </span>
            {[
              isBn ? 'এই মাসে কত খরচ হলো?' : 'How much did I spend this month?',
              isBn ? 'সবচেয়ে বেশি খরচ কোন খাতে?' : 'Where am I spending the most?',
              isBn ? 'নতুন ফোন কেনার সামর্থ্য আছে?' : 'Can I afford a new phone?',
              isBn ? 'সামনে কী কী বিল দিতে হবে?' : 'Show my upcoming payments',
              isBn ? 'আমার মোট দেনা-পাওনা কত?' : 'How much debt do I have?',
              isBn ? 'আজকে ৫০০ টাকা বাজার খরচ যোগ করো' : 'Add 500 taka grocery expense today',
            ].map((prompt, idx) => (
              <button
                key={idx}
                onClick={() => handleSendChat(prompt)}
                className="px-2.5 py-1 rounded-lg border border-slate-200 bg-white hover:bg-emerald-50 hover:border-emerald-200 text-slate-700 text-[11px] font-semibold whitespace-nowrap shrink-0 transition-colors cursor-pointer"
              >
                {prompt}
              </button>
            ))}
          </div>

          {/* Message Input Box */}
          <div className="p-3 sm:p-4 bg-white border-t border-slate-200 flex items-center gap-2">
            <input
              type="text"
              value={chatInput}
              onChange={e => setChatInput(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && handleSendChat()}
              placeholder={isBn ? 'কমান্ড বা প্রশ্ন লিখুন (যেমন: এই মাসে মোট কত খরচ হয়েছে?)...' : 'Type a command or financial question...'}
              className="flex-1 px-4 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-200 focus:outline-hidden focus:border-emerald-500 transition-colors"
            />
            <button
              onClick={() => handleSendChat()}
              disabled={!chatInput.trim() || isProcessingChat}
              className={`p-2.5 rounded-xl text-white font-bold transition-all shrink-0 ${
                chatInput.trim() && !isProcessingChat
                  ? 'bg-emerald-600 hover:bg-emerald-700 shadow-xs cursor-pointer active:scale-95'
                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
              }`}
            >
              <Send className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* 5. AI REPORTS TAB */}
      {/* ========================================================================= */}
      {activeTab === 'reports' && (
        <div className="space-y-6">
          <div className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                  <FileText className="w-5 h-5 text-emerald-600" />
                  <span>{isBn ? 'স্বয়ংক্রিয় এআই আর্থিক অডিট ও রিপোর্ট' : 'Automated AI Financial Reports'}</span>
                </h3>
                <p className="text-xs text-slate-500">
                  {isBn
                    ? 'আয়, ব্যয়, বাজেট কার্যকারিতা, সঞ্চয় হার ও নেট-ওয়ার্থের সুনির্দিষ্ট বিশ্লেষণ প্রতিবেদন।'
                    : 'Formal executive summary outlining income, burn-rate, budget adherence, debt and net worth.'}
                </p>
              </div>

              {/* Period Selectors */}
              <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
                <button
                  onClick={() => handleGenerateReport('daily')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    reportPeriod === 'daily' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {isBn ? 'দৈনিক' : 'Daily'}
                </button>
                <button
                  onClick={() => handleGenerateReport('weekly')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    reportPeriod === 'weekly' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {isBn ? 'সাপ্তাহিক' : 'Weekly'}
                </button>
                <button
                  onClick={() => handleGenerateReport('monthly')}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    reportPeriod === 'monthly' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {isBn ? 'মাসিক অডিট' : 'Monthly'}
                </button>
              </div>
            </div>
          </div>

          {activeReport && (
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
              
              {/* Header and Print/Copy Actions */}
              <div className="flex items-start justify-between pb-4 border-b border-slate-100 gap-4">
                <div>
                  <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                    {reportPeriod.toUpperCase()} AI AUDIT
                  </span>
                  <h2 className="text-lg sm:text-xl font-black text-slate-900 mt-1">
                    {isBn ? activeReport.headlineBn : activeReport.headlineEn}
                  </h2>
                  <span className="text-xs text-slate-400">
                    {new Date(activeReport.generatedAt).toLocaleDateString(isBn ? 'bn-BD' : 'en-GB', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric',
                    })}
                  </span>
                </div>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    onClick={handleCopyReport}
                    className="p-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors"
                    title="Copy Report Text"
                  >
                    {copiedReport ? <CheckCheck className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => window.print()}
                    className="p-2 border border-slate-200 rounded-xl text-slate-600 hover:bg-slate-50 transition-colors"
                    title="Print Statement"
                  >
                    <Printer className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Key Metrics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                  <span className="text-xs text-slate-500 font-medium block">{isBn ? 'মোট আয়' : 'Total Inflow'}</span>
                  <span className="text-base sm:text-lg font-black text-emerald-700">
                    {formatMoney(activeReport.keyMetrics.income)}
                  </span>
                </div>
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                  <span className="text-xs text-slate-500 font-medium block">{isBn ? 'মোট ব্যয়' : 'Total Outflow'}</span>
                  <span className="text-base sm:text-lg font-black text-rose-700">
                    {formatMoney(activeReport.keyMetrics.expense)}
                  </span>
                </div>
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                  <span className="text-xs text-slate-500 font-medium block">{isBn ? 'নিট সঞ্চয়' : 'Net Savings'}</span>
                  <span className="text-base sm:text-lg font-black text-slate-900">
                    {formatMoney(activeReport.keyMetrics.netSavings)}
                  </span>
                </div>
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-100">
                  <span className="text-xs text-slate-500 font-medium block">{isBn ? 'সঞ্চয়ের হার' : 'Savings Rate'}</span>
                  <span className="text-base sm:text-lg font-black text-teal-700">
                    {activeReport.keyMetrics.savingsRate}%
                  </span>
                </div>
              </div>

              {/* Highlights List */}
              <div className="space-y-3">
                <h4 className="text-sm font-bold text-slate-900">{isBn ? 'প্রধান পর্যবেক্ষণ ও হাইলাইটস' : 'Key Highlights'}</h4>
                <div className="space-y-2">
                  {(isBn ? activeReport.highlightsBn : activeReport.highlightsEn).map((h, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-100 font-medium">
                      <span className="text-emerald-600 font-bold">•</span>
                      <span>{h}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Actionable Steps */}
              <div className="space-y-3 pt-2">
                <h4 className="text-sm font-bold text-slate-900">{isBn ? 'এআই নির্দেশিত করণীয় পদক্ষেপ' : 'Actionable Strategic Steps'}</h4>
                <div className="space-y-2">
                  {(isBn ? activeReport.actionableStepsBn : activeReport.actionableStepsEn).map((step, i) => (
                    <div key={i} className="flex items-start gap-2.5 text-xs text-emerald-900 bg-emerald-50/80 p-3 rounded-xl border border-emerald-100 font-medium">
                      <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                      <span>{step}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ========================================================================= */}
      {/* 6. LOGS & MEMORY PREFERENCES TAB */}
      {/* ========================================================================= */}
      {activeTab === 'memory' && (
        <div className="space-y-6">
          
          {/* AI Memory & Preferences Settings Card */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-2xs space-y-5">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Sliders className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">
                  {isBn ? 'এআই মেমোরি ও কনফিগারেশন' : 'AI Memory & Preferences Layer'}
                </h3>
              </div>
              <span className="text-xs text-slate-400">
                {isBn ? `${aiMemory.userCorrectionsCount}টি সংশোধনী সংরক্ষিত` : `${aiMemory.userCorrectionsCount} Corrections Learned`}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              
              {/* Toggle 1: Auto Budget Assistance */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-slate-800">
                    {isBn ? 'স্বয়ংক্রিয় বাজেট সহায়তা' : 'Auto Budget Assistance'}
                  </span>
                  <input
                    type="checkbox"
                    checked={aiMemory.autoBudgetAssistance}
                    onChange={e => updateAIMemoryPreferences({ autoBudgetAssistance: e.target.checked })}
                    className="w-4 h-4 rounded-sm text-emerald-600 accent-emerald-600 cursor-pointer"
                  />
                </div>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {isBn
                    ? 'অনুমোদন ছাড়া কখনোই স্বয়ংক্রিয়ভাবে বাজেট পরিবর্তন হবে না।'
                    : 'AI prepares recommendations without auto-applying without consent.'}
                </p>
              </div>

              {/* Selector 2: Anomaly Sensitivity */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <span className="text-xs font-bold text-slate-800 block">
                  {isBn ? 'অ্যানোমালি সেনসিটিভিটি' : 'Anomaly Sensitivity'}
                </span>
                <select
                  value={aiMemory.anomalySensitivity}
                  onChange={e => updateAIMemoryPreferences({ anomalySensitivity: e.target.value as any })}
                  className="w-full text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white"
                >
                  <option value="low">{isBn ? 'কম (Low)' : 'Low'}</option>
                  <option value="medium">{isBn ? 'মাঝারি (Medium)' : 'Medium'}</option>
                  <option value="high">{isBn ? 'উচ্চ (High)' : 'High'}</option>
                </select>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {isBn ? 'খরচের অস্বাভাবিক বৃদ্ধি সতর্কতার মাত্রা' : 'Threshold for unusual spending triggers.'}
                </p>
              </div>

              {/* Selector 3: Risk Tolerance */}
              <div className="p-4 rounded-xl bg-slate-50 border border-slate-200/80 space-y-2">
                <span className="text-xs font-bold text-slate-800 block">
                  {isBn ? 'আর্থিক ঝুঁকি সহনশীলতা' : 'Risk Profile'}
                </span>
                <select
                  value={aiMemory.preferredRiskTolerance}
                  onChange={e => updateAIMemoryPreferences({ preferredRiskTolerance: e.target.value as any })}
                  className="w-full text-xs font-semibold px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white"
                >
                  <option value="conservative">{isBn ? 'রক্ষণশীল (Conservative)' : 'Conservative'}</option>
                  <option value="balanced">{isBn ? 'ভারসাম্যপূর্ণ (Balanced)' : 'Balanced'}</option>
                  <option value="aggressive">{isBn ? 'উচ্চাকাঙ্ক্ষী (Aggressive)' : 'Aggressive'}</option>
                </select>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {isBn ? 'সঞ্চয় ও বিনিয়োগ পরিকল্পনার দৃষ্টিভঙ্গি' : 'Affects buffer recommendations.'}
                </p>
              </div>
            </div>

            {/* Learned Merchant Rules List */}
            <div className="space-y-2 pt-2">
              <span className="text-xs font-bold text-slate-700 block">
                {isBn ? 'পরিচিত মার্চেন্ট ও ক্যাটাগরি ম্যাপিং' : 'Learned Merchant Recognition Rules'}
              </span>
              {Object.keys(aiMemory.learnedMerchantCategories).length === 0 ? (
                <div className="p-4 rounded-xl bg-slate-50 border border-slate-100 text-center text-xs text-slate-500">
                  {isBn
                    ? 'এখনও কোনো কাস্টম মার্চেন্ট রুল সংরক্ষিত নেই। আপনি যখন লেনদেন যোগ করবেন, এআই স্বয়ংক্রিয়ভাবে শিখে নেবে।'
                    : 'No custom merchant rules learned yet. As you add transactions, AI will automatically learn and show rules here.'}
                </div>
              ) : (
                <div className="flex flex-wrap gap-2 max-h-36 overflow-y-auto p-1">
                  {Object.entries(aiMemory.learnedMerchantCategories).map(([merchant, catId]) => {
                    const cat = categories.find(c => c.id === catId);
                    return (
                      <span
                        key={merchant}
                        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-100 text-[11px] font-semibold text-slate-700 border border-slate-200"
                      >
                        <span className="font-bold">{merchant}</span>
                        <ArrowRight className="w-3 h-3 text-slate-400" />
                        <span className="text-emerald-700">{isBn ? cat?.nameBn || cat?.name : cat?.name}</span>
                      </span>
                    );
                  })}
                </div>
              )}
            </div>
          </div>

          {/* AI Activity Log Timeline (As requested in User Prompt) */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-2xs space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <History className="w-5 h-5 text-emerald-600" />
                <h3 className="text-base font-bold text-slate-900">
                  {isBn ? 'এআই অ্যাক্টিভিটি অডিট লগ' : 'AI Activity Log'}
                </h3>
              </div>

              {/* Module Filter Chips */}
              <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
                {['all', 'transactions', 'action engine', 'reports', 'bills', 'analytics'].map(mod => (
                  <button
                    key={mod}
                    onClick={() => setLogFilterModule(mod)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-semibold capitalize transition-colors ${
                      logFilterModule === mod
                        ? 'bg-slate-900 text-white'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                  >
                    {mod}
                  </button>
                ))}
              </div>
            </div>

            {filteredLogs.length === 0 ? (
              <div className="py-8 text-center text-slate-400 space-y-1 bg-slate-50 rounded-xl border border-slate-100">
                <p className="text-xs font-semibold text-slate-600">
                  {isBn ? 'কোনো অ্যাক্টিভিটি লগ নেই' : 'No activity logs found'}
                </p>
                <p className="text-[11px] text-slate-400">
                  {isBn ? 'নতুন লেনদেন বা এআই কমান্ড কার্যকর হলে এখানে রিয়েল-টাইম লগ প্রদর্শিত হবে।' : 'New actions, categorization, and audits will be logged here in real-time.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredLogs.map(log => (
                  <div
                    key={log.id}
                    className="p-3.5 rounded-xl bg-slate-50 border border-slate-100 flex items-start justify-between gap-3 text-xs"
                  >
                    <div className="space-y-0.5">
                      <div className="flex items-center gap-2">
                        <span
                          className={`text-xs ${
                            log.status === 'completed'
                              ? 'text-emerald-600'
                              : log.status === 'alert'
                              ? 'text-amber-500'
                              : 'text-slate-400'
                          }`}
                        >
                          {log.status === 'completed' ? '✓' : log.status === 'alert' ? '⚠️' : '•'}
                        </span>
                        <strong className="text-slate-900 font-bold">
                          {isBn ? log.titleBn || log.title : log.title}
                        </strong>
                        <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded-sm bg-slate-200 text-slate-700">
                          {log.module}
                        </span>
                      </div>
                      <p className="text-slate-600 pl-4">{isBn ? log.detailsBn || log.details : log.details}</p>
                    </div>

                    <span className="text-[10px] text-slate-400 shrink-0 font-mono">
                      {new Date(log.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Global AI Action Confirmation Modal */}
      <AIActionConfirmationModal
        proposal={activeActionConfirmationModal}
        isOpen={Boolean(activeActionConfirmationModal)}
        onClose={() => setActiveActionConfirmationModal(null)}
        onConfirm={prop => {
          executeAIAction(prop.id);
          setActiveActionConfirmationModal(null);
        }}
      />
    </div>
  );
};
