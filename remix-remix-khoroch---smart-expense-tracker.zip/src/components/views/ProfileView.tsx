import React, { useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { PRESET_SECURITY_QUESTIONS, SecurityQuestionItem } from '../../types/auth';
import {
  User,
  Cloud,
  CloudOff,
  CheckCircle2,
  AlertCircle,
  LogOut,
  RefreshCw,
  ArrowLeft,
  Smartphone,
  Laptop,
  Tablet,
  Database,
  Lock,
  ShieldCheck,
  Receipt,
  Landmark,
  Target,
  CreditCard,
  Bell,
  Sparkles,
  Download,
  Settings,
  X,
  KeyRound,
  HelpCircle,
  Copy,
  Check,
  Plus,
  Trash2,
} from 'lucide-react';

interface ProfileViewProps {
  onBack?: () => void;
}

export const ProfileView: React.FC<ProfileViewProps> = ({ onBack }) => {
  const {
    currentUser,
    authSession,
    isCloudSyncing,
    syncStatus,
    lastSyncedTime,
    handleSignOut,
    syncAllToCloudNow,
    changePassword,
    updateSecurityQuestions,
    setIsAuthModalOpen,
    language,
    transactions,
    accounts,
    budgets,
    goals,
    subscriptions,
    setActiveTab,
    exportJSON,
    exportCSV,
  } = useExpense();

  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  // Change Password state
  const [isChangingPassword, setIsChangingPassword] = useState(false);
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');

  // Manage Security Questions state
  const [isUpdatingQuestions, setIsUpdatingQuestions] = useState(false);
  const [authPasswordForQuestions, setAuthPasswordForQuestions] = useState('');
  const [questionsList, setQuestionsList] = useState<SecurityQuestionItem[]>([
    { id: 'q1', question: PRESET_SECURITY_QUESTIONS[0], answer: '' },
    { id: 'q2', question: PRESET_SECURITY_QUESTIONS[1], answer: '' },
  ]);

  // Sign out confirmation modal
  const [showSignOutConfirm, setShowSignOutConfirm] = useState(false);

  const isBn = language === 'bn';

  const onManualSync = async () => {
    try {
      setLoading(true);
      setErrorMessage(null);
      await syncAllToCloudNow();
      setSuccessMessage(isBn ? 'সব তথ্য ক্লাউডে সফলভাবে সংরক্ষিত হয়েছে!' : 'All data successfully saved to cloud!');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'সিঙ্ক ব্যর্থ হয়েছে।' : 'Sync failed.'));
    } finally {
      setLoading(false);
    }
  };

  const handleCopyId = () => {
    if (currentUser?.id) {
      navigator.clipboard.writeText(currentUser.id);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPassword || !newPassword) {
      setErrorMessage(isBn ? 'সব ঘর পূরণ করুন' : 'Fill all fields');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setErrorMessage(isBn ? 'নতুন পাসওয়ার্ড দুটি মিলছে না' : 'New passwords do not match');
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    try {
      await changePassword(currentPassword, newPassword, confirmNewPassword);
      setSuccessMessage(isBn ? 'পাসওয়ার্ড সফলভাবে পরিবর্তন করা হয়েছে!' : 'Password changed successfully!');
      setCurrentPassword('');
      setNewPassword('');
      setConfirmNewPassword('');
      setIsChangingPassword(false);
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'পাসওয়ার্ড পরিবর্তন ব্যর্থ' : 'Failed to change password'));
    } finally {
      setLoading(false);
    }
  };

  const handleQuestionsSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!authPasswordForQuestions) {
      setErrorMessage(isBn ? 'আপনার বর্তমান পাসওয়ার্ড দিন' : 'Enter your current password');
      return;
    }

    const filledQuestions = questionsList.filter((q) => q.question.trim() && q.answer.trim());
    if (filledQuestions.length < 2) {
      setErrorMessage(
        isBn
          ? 'কমপক্ষে ২টি নিরাপত্তা প্রশ্ন ও উত্তর দিতে হবে'
          : 'At least 2 questions with answers are required'
      );
      return;
    }

    setLoading(true);
    setErrorMessage(null);
    try {
      await updateSecurityQuestions(authPasswordForQuestions, filledQuestions);
      setSuccessMessage(
        isBn
          ? 'রিকভারি নিরাপত্তা প্রশ্নসমূহ সফলভাবে আপডেট হয়েছে!'
          : 'Security questions updated successfully!'
      );
      setAuthPasswordForQuestions('');
      setIsUpdatingQuestions(false);
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'প্রশ্ন আপডেট ব্যর্থ' : 'Failed to update questions'));
    } finally {
      setLoading(false);
    }
  };

  const confirmSignOut = async () => {
    try {
      setLoading(true);
      await handleSignOut();
      setShowSignOutConfirm(false);
      setSuccessMessage(isBn ? 'লগআউট সম্পন্ন হয়েছে।' : 'Signed out successfully.');
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || 'Error signing out');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6 pb-16 animate-in fade-in duration-200 max-w-5xl mx-auto">
      {/* Top Header Navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2 border-b border-slate-200/80">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack || (() => setActiveTab('dashboard'))}
            className="p-2.5 rounded-2xl bg-white border border-slate-200/90 hover:bg-slate-50 text-slate-700 shadow-2xs transition-all hover:scale-105 active:scale-95 cursor-pointer"
            title={isBn ? 'ড্যাশবোর্ডে ফিরে যান' : 'Back to Dashboard'}
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {isBn ? 'প্রোফাইল ও ক্লাউড সিঙ্ক' : 'Profile & Cloud Sync'}
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 font-medium">
              {isBn
                ? 'ইউজারনেম ভিত্তিক ক্রস-ডিভাইস ক্লাউড ব্যাকআপ ও পূর্ণাঙ্গ ডাটা বিচ্ছিন্নতা'
                : 'Username-based cross-device sync and complete data isolation'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          {currentUser && (
            <button
              onClick={onManualSync}
              disabled={loading || isCloudSyncing}
              className="inline-flex items-center gap-2 px-4 py-2 text-xs font-bold text-emerald-800 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/80 rounded-xl transition-all shadow-2xs cursor-pointer disabled:opacity-60"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isCloudSyncing || loading ? 'animate-spin' : ''}`} />
              <span>{isBn ? 'এখনই ক্লাউডে সেভ করুন' : 'Sync All Now'}</span>
            </button>
          )}

          <button
            onClick={() => setActiveTab('settings')}
            className="inline-flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl transition-colors shadow-2xs cursor-pointer"
          >
            <Settings className="w-3.5 h-3.5 text-slate-500" />
            <span>{isBn ? 'সেটিংস' : 'Settings'}</span>
          </button>

          <button
            onClick={onBack || (() => setActiveTab('dashboard'))}
            className="p-2 rounded-xl bg-white hover:bg-slate-100 text-slate-500 hover:text-slate-800 border border-slate-200 transition-colors shadow-2xs cursor-pointer"
            title={isBn ? 'বন্ধ করুন' : 'Close Profile'}
            aria-label="Close"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Alert Banners */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-800 text-xs sm:text-sm flex items-center gap-3 animate-shake">
          <AlertCircle className="w-5 h-5 shrink-0 text-rose-600" />
          <p className="font-semibold">{errorMessage}</p>
        </div>
      )}

      {successMessage && (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs sm:text-sm flex items-center gap-3 animate-fade-in">
          <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600" />
          <p className="font-semibold">{successMessage}</p>
        </div>
      )}

      {/* Main Profile Account Card */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 pb-6 border-b border-slate-100">
          <div className="flex items-center gap-4 sm:gap-5">
            <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-bold text-2xl sm:text-3xl shadow-sm shrink-0">
              {currentUser?.username ? currentUser.username[0].toUpperCase() : 'U'}
            </div>

            <div className="space-y-1">
              <div className="flex flex-wrap items-center gap-2">
                <h2 className="text-lg sm:text-2xl font-black text-slate-900 tracking-tight">
                  {currentUser ? `@${currentUser.username}` : isBn ? 'অতিথি ইউজার (লগইন করা নেই)' : 'Guest Mode (Not Logged In)'}
                </h2>
                {currentUser ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-800 border border-emerald-200">
                    <Sparkles className="w-3 h-3 text-emerald-600" />
                    <span>Cloud Synced</span>
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200">
                    <span>Local Only</span>
                  </span>
                )}
              </div>

              <p className="text-xs sm:text-sm text-slate-500 font-medium">
                {currentUser
                  ? isBn
                    ? 'আপনার ডেটা নিজস্ব সুরক্ষিত একাউন্টে সংরক্ষিত হচ্ছে'
                    : 'Your financial data is backed up to your private cloud storage'
                  : isBn
                  ? 'যেকোনো মোবাইল বা পিসি থেকে অ্যাক্সেস পেতে ইউজারনেম দিয়ে সাইন ইন করুন'
                  : 'Sign in with username & password to access your expenses anywhere'}
              </p>

              {currentUser && (
                <div className="flex items-center gap-2 text-[11px] text-slate-500 font-mono pt-1">
                  <span>User ID: <strong className="text-slate-700">{currentUser.id}</strong></span>
                  <button
                    onClick={handleCopyId}
                    className="p-1 hover:text-emerald-700 text-slate-400 transition-colors cursor-pointer"
                    title={isBn ? 'ইউজার আইডি কপি করুন' : 'Copy User ID'}
                  >
                    {copiedId ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Action button */}
          <div className="shrink-0 flex items-center gap-2.5">
            {currentUser ? (
              <button
                onClick={() => setShowSignOutConfirm(true)}
                disabled={loading}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-rose-200 bg-rose-50/80 hover:bg-rose-100 text-rose-700 text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-2xs"
              >
                <LogOut className="w-4 h-4" />
                <span>{isBn ? 'লগআউট' : 'Log Out'}</span>
              </button>
            ) : (
              <button
                onClick={() => setIsAuthModalOpen(true)}
                disabled={loading}
                className="w-full sm:w-auto px-6 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 shadow-sm hover:shadow-md active:scale-95 cursor-pointer"
              >
                <User className="w-4 h-4" />
                <span>{isBn ? 'সাইন ইন / রেজিস্টার' : 'Sign In / Register'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Sync Status Banner */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {isBn ? 'সিঙ্ক স্ট্যাটাস' : 'Sync Status'}
            </span>
            <div className="flex items-center gap-2">
              <span
                className={`w-2.5 h-2.5 rounded-full ${
                  syncStatus === 'syncing'
                    ? 'bg-amber-500 animate-ping'
                    : syncStatus === 'offline'
                    ? 'bg-amber-400'
                    : syncStatus === 'error'
                    ? 'bg-rose-500'
                    : currentUser
                    ? 'bg-emerald-500 animate-pulse'
                    : 'bg-slate-300'
                }`}
              />
              <span className="text-sm font-bold text-slate-900 capitalize">
                {syncStatus === 'syncing'
                  ? isBn ? 'সিঙ্ক হচ্ছে...' : 'Syncing...'
                  : syncStatus === 'offline'
                  ? isBn ? 'অফলাইন' : 'Offline'
                  : syncStatus === 'error'
                  ? isBn ? 'সিঙ্ক ত্রুটি' : 'Sync Error'
                  : currentUser
                  ? isBn ? 'ক্লাউড সিঙ্ক সক্রিয়' : 'Active & Synced'
                  : isBn ? 'লোকাল মোড' : 'Local Storage Only'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              {currentUser
                ? lastSyncedTime
                  ? `${isBn ? 'সর্বশেষ সিঙ্ক:' : 'Last synced:'} ${new Date(lastSyncedTime).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`
                  : isBn ? 'স্বয়ংক্রিয় সিঙ্ক কার্যকর' : 'Auto sync enabled'
                : isBn ? 'লগইন করলে ডেটা ক্লাউডে সেভ হবে' : 'Login to sync across devices'}
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {isBn ? 'ক্লাউড ডাটাবেজ' : 'Cloud Database'}
            </span>
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-600" />
              <span className="text-sm font-bold text-slate-900">
                {isBn ? 'সুরক্ষিত ক্লাউড স্টোর' : 'Private Cloud Vault'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              {isBn ? 'এনক্রিপ্টেড ও সম্পূর্ণ ইউজার-আইসোলেটেড স্টোরেজ' : 'Encrypted with strict User-ID authorization'}
            </p>
          </div>

          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {isBn ? 'অ্যাকাউন্ট রিকভারি' : 'Account Recovery'}
            </span>
            <div className="flex items-center gap-2">
              <HelpCircle className="w-4 h-4 text-emerald-600" />
              <span className="text-sm font-bold text-slate-900">
                {currentUser?.hasSecurityQuestions
                  ? isBn ? 'প্রশ্নাবলী সেট করা আছে' : 'Security Questions Active'
                  : isBn ? 'প্রশ্ন কনফিগার করুন' : 'Setup Security Questions'}
              </span>
            </div>
            <p className="text-[11px] text-slate-500">
              {isBn ? 'পাসওয়ার্ড ভুলে গেলে রিকভারির সুযোগ' : 'Recover your account if password is forgotten'}
            </p>
          </div>
        </div>

        {/* Security & Password Management Buttons for Authenticated User */}
        {currentUser && (
          <div className="pt-4 border-t border-slate-100 flex flex-wrap gap-3">
            <button
              onClick={() => setIsChangingPassword(!isChangingPassword)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-bold text-slate-700 flex items-center gap-2 transition-colors cursor-pointer"
            >
              <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isBn ? 'পাসওয়ার্ড পরিবর্তন' : 'Change Password'}</span>
            </button>

            <button
              onClick={() => setIsUpdatingQuestions(!isUpdatingQuestions)}
              className="px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-xs font-bold text-slate-700 flex items-center gap-2 transition-colors cursor-pointer"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>{isBn ? 'রিকভারি প্রশ্ন পরিবর্তন' : 'Update Security Questions'}</span>
            </button>
          </div>
        )}

        {/* Inline Change Password Form */}
        {isChangingPassword && currentUser && (
          <form onSubmit={handleChangePasswordSubmit} className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200 space-y-3">
            <h4 className="text-xs font-bold text-emerald-950 flex items-center gap-2">
              <KeyRound className="w-4 h-4 text-emerald-600" />
              {isBn ? 'পাসওয়ার্ড পরিবর্তন করুন' : 'Change Password'}
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isBn ? 'বর্তমান পাসওয়ার্ড' : 'Current Password'}
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isBn ? 'নতুন পাসওয়ার্ড' : 'New Password'}
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="e.g. 1234 or hello"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                  {isBn ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm New Password'}
                </label>
                <input
                  type="password"
                  value={confirmNewPassword}
                  onChange={(e) => setConfirmNewPassword(e.target.value)}
                  placeholder="e.g. 1234 or hello"
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsChangingPassword(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm transition-all disabled:opacity-50 cursor-pointer"
              >
                {loading ? (isBn ? 'আপডেট হচ্ছে...' : 'Updating...') : (isBn ? 'সংরক্ষণ করুন' : 'Save New Password')}
              </button>
            </div>
          </form>
        )}

        {/* Inline Manage Security Questions Form */}
        {isUpdatingQuestions && currentUser && (
          <form onSubmit={handleQuestionsSubmit} className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200 space-y-3">
            <h4 className="text-xs font-bold text-emerald-950 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-emerald-600" />
              {isBn ? 'অ্যাকাউন্ট রিকভারি প্রশ্নসমূহ আপডেট করুন' : 'Update Security Questions'}
            </h4>

            <div>
              <label className="block text-[11px] font-semibold text-slate-700 mb-1">
                {isBn ? 'নিরাপত্তা যাচাইয়ের জন্য বর্তমান পাসওয়ার্ড লিখুন' : 'Enter your current password to authorize change'}
              </label>
              <input
                type="password"
                value={authPasswordForQuestions}
                onChange={(e) => setAuthPasswordForQuestions(e.target.value)}
                placeholder="••••••••"
                className="w-full sm:w-1/2 px-3 py-2 text-xs rounded-xl border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div className="space-y-3 pt-1">
              {questionsList.map((q, idx) => (
                <div key={q.id} className="p-3 bg-white rounded-xl border border-slate-200 space-y-2">
                  <span className="text-[11px] font-bold text-slate-700 block">
                    {isBn ? `প্রশ্ন ${idx + 1}` : `Question ${idx + 1}`}
                  </span>
                  <select
                    value={q.question}
                    onChange={(e) =>
                      setQuestionsList(
                        questionsList.map((item) =>
                          item.id === q.id ? { ...item, question: e.target.value } : item
                        )
                      )
                    }
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
                  >
                    {PRESET_SECURITY_QUESTIONS.map((pq) => (
                      <option key={pq} value={pq}>
                        {pq}
                      </option>
                    ))}
                  </select>
                  <input
                    type="text"
                    value={q.answer}
                    onChange={(e) =>
                      setQuestionsList(
                        questionsList.map((item) =>
                          item.id === q.id ? { ...item, answer: e.target.value } : item
                        )
                      )
                    }
                    placeholder={isBn ? 'উত্তর লিখুন' : 'Enter answer'}
                    className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
                  />
                </div>
              ))}
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                type="button"
                onClick={() => setIsUpdatingQuestions(false)}
                className="px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold shadow-sm transition-all disabled:opacity-50 cursor-pointer"
              >
                {loading ? (isBn ? 'আপডেট হচ্ছে...' : 'Updating...') : (isBn ? 'প্রশ্ন আপডেট করুন' : 'Save Questions')}
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Synced Data Summary */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200/90 shadow-2xs space-y-5">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-slate-900">
              {isBn ? 'সংরক্ষিত তথ্যাদি (Cloud Synced Items)' : 'Your Synced Records in Cloud'}
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              {isBn ? 'আপনার প্রোফাইলে এই হিসাবগুলো নিরাপদ রয়েছে' : 'All these records stay protected under your account'}
            </p>
          </div>
          <span className="text-xs font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-3 py-1 rounded-full">
            {transactions.length + accounts.length + budgets.length + goals.length} {isBn ? 'টি আইটেম' : 'Total Items'}
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
          <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-100 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-black text-slate-900 leading-none">{transactions.length}</span>
              <p className="text-[11px] font-semibold text-slate-500 mt-1">{isBn ? 'লেনদেন' : 'Transactions'}</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-100 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center shrink-0">
              <Landmark className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-black text-slate-900 leading-none">{accounts.length}</span>
              <p className="text-[11px] font-semibold text-slate-500 mt-1">{isBn ? 'অ্যাকাউন্ট' : 'Accounts'}</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-100 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center shrink-0">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-black text-slate-900 leading-none">{budgets.length}</span>
              <p className="text-[11px] font-semibold text-slate-500 mt-1">{isBn ? 'বাজেট' : 'Budgets'}</p>
            </div>
          </div>

          <div className="p-4 rounded-2xl bg-slate-50/80 border border-slate-100 flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center shrink-0">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <span className="text-lg font-black text-slate-900 leading-none">{subscriptions.length}</span>
              <p className="text-[11px] font-semibold text-slate-500 mt-1">{isBn ? 'বিল ও সাবস্ক্রিপশন' : 'Bills & Subs'}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Multi-Device Architecture Section */}
      <div className="bg-gradient-to-br from-emerald-800 to-teal-900 text-white rounded-3xl p-6 sm:p-8 shadow-sm space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center text-emerald-300">
            <Cloud className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold tracking-tight">
              {isBn ? 'যেকোনো ডিভাইস থেকে কীভাবে সিঙ্ক করবেন?' : 'Cross-Device Cloud Sync Architecture'}
            </h3>
            <p className="text-xs text-emerald-200/90">
              {isBn
                ? 'শুধু আপনার ইউজারনেম ও পাসওয়ার্ড দিয়ে যেকোনো ব্রাউজারে লগইন করলেই সব ডেটা পাওয়া যাবে'
                : 'Sign in with your username and password on any browser or device to access all your records'}
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-1">
          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-xs space-y-2 border border-white/10">
            <Smartphone className="w-6 h-6 text-emerald-300" />
            <h4 className="font-bold text-sm">{isBn ? '১. স্মার্টফোন' : '1. Smartphone'}</h4>
            <p className="text-xs text-emerald-100/80 leading-relaxed">
              {isBn ? 'দৈনন্দিন কেনাকাটার খরচ মোবাইল থেকে সাথে সাথে ইনপুট দিন।' : 'Record purchases instantly on the go from your phone browser.'}
            </p>
          </div>

          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-xs space-y-2 border border-white/10">
            <Laptop className="w-6 h-6 text-emerald-300" />
            <h4 className="font-bold text-sm">{isBn ? '২. ল্যাপটপ বা কম্পিউটার' : '2. Laptop / Desktop'}</h4>
            <p className="text-xs text-emerald-100/80 leading-relaxed">
              {isBn ? 'বাসা বা অফিসে বসে বড় পর্দায় বাজেট ও স্মার্ট পেমেন্ট অগ্রাধিকার পর্যবেক্ষণ করুন।' : 'Analyze charts, print reports, and prioritize bills on a big screen.'}
            </p>
          </div>

          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-xs space-y-2 border border-white/10">
            <Tablet className="w-6 h-6 text-emerald-300" />
            <h4 className="font-bold text-sm">{isBn ? '৩. পূর্ণাঙ্গ ইউজার আইসোলেশন' : '3. Strict User Isolation'}</h4>
            <p className="text-xs text-emerald-100/80 leading-relaxed">
              {isBn ? 'শেয়ার্ড ডিভাইসে লগআউট করলেই সব লোকাল ক্যাশ মুছে যাবে, অন্য কেউ দেখতে পারবে না।' : 'Logging out completely clears device storage, protecting your records on shared PCs.'}
            </p>
          </div>
        </div>
      </div>

      {/* Data Export & Backup Actions */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200/90 shadow-2xs flex flex-col sm:flex-row items-center justify-between gap-4">
        <div>
          <h4 className="text-sm font-bold text-slate-800">
            {isBn ? 'অফলাইন ব্যাকআপ ডাউনলোড' : 'Offline Backup & Export'}
          </h4>
          <p className="text-xs text-slate-400 mt-0.5">
            {isBn ? 'চাইলে আপনার সমস্ত ডেটা এক্সেল (CSV) বা JSON ফাইলে ডাউনলোড করে রাখতে পারেন' : 'Export your complete dataset to CSV or JSON for local records'}
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportCSV}
            className="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-bold text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>CSV (Excel)</span>
          </button>
          <button
            onClick={exportJSON}
            className="px-4 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-xs font-bold text-slate-700 flex items-center gap-1.5 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>JSON Backup</span>
          </button>
        </div>
      </div>

      {/* Sign Out Confirmation Modal */}
      {showSignOutConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-2xl max-w-sm w-full p-6 shadow-2xl border border-rose-100 space-y-4 animate-scale-up">
            <div className="w-12 h-12 rounded-2xl bg-rose-50 border border-rose-200 text-rose-600 flex items-center justify-center mx-auto">
              <LogOut className="w-6 h-6" />
            </div>

            <div className="text-center space-y-1">
              <h3 className="font-bold text-base text-slate-900">
                {isBn ? 'লগআউট নিশ্চিত করুন' : 'Confirm Sign Out'}
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                {isBn
                  ? 'লগআউট করলে এই ব্রাউজারের লোকাল ক্যাশ সাফ হয়ে যাবে। অন্য কেউ আপনার হিসাব দেখতে পারবে না। ক্লাউডে আপনার সব ডেটা নিরাপদ থাকবে।'
                  : 'Signing out clears local device cache for security and multi-user isolation. Your data remains safely backed up in the cloud.'}
              </p>
            </div>

            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowSignOutConfirm(false)}
                className="flex-1 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-50 cursor-pointer"
              >
                {isBn ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={confirmSignOut}
                disabled={loading}
                className="flex-1 py-2 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold shadow-sm transition-all disabled:opacity-50 cursor-pointer"
              >
                {loading ? (isBn ? 'অপেক্ষা করুন...' : 'Processing...') : (isBn ? 'লগআউট করুন' : 'Yes, Sign Out')}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
