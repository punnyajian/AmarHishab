import React, { useState, useMemo } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { SubscriptionBill, BillCategory } from '../../types';
import { AddSubscriptionModal } from '../AddSubscriptionModal';
import { PayBillModal } from '../PayBillModal';
import {
  CalendarClock,
  Plus,
  Receipt,
  Search,
  Filter,
  CheckCircle2,
  AlertTriangle,
  Clock,
  Zap,
  Droplets,
  Flame,
  Wifi,
  Tv,
  Headphones,
  Home,
  Dumbbell,
  Bot,
  Smartphone,
  CreditCard,
  Building2,
  Banknote,
  DollarSign,
  TrendingDown,
  Sparkles,
  ArrowUpRight,
  PauseCircle,
  PlayCircle,
  Trash2,
  Edit2,
  ShieldCheck,
  ChevronDown,
  Info,
} from 'lucide-react';

export const SubscriptionsView: React.FC = () => {
  const {
    subscriptions,
    deleteSubscription,
    togglePauseSubscription,
    accounts,
    digitalCards,
    formatMoney,
    currency,
    language,
    totalMonthlyRecurring,
    totalYearlyRecurring,
    paidThisMonthRecurring,
    pendingThisMonthRecurring,
    overdueBillsCount,
    dueSoonBillsCount,
    subscriptionFilterTab,
    setSubscriptionFilterTab,
  } = useExpense();

  // State
  const filterTab = subscriptionFilterTab;
  const setFilterTab = setSubscriptionFilterTab;
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'dueDate' | 'amountDesc' | 'name'>('dueDate');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingBill, setEditingBill] = useState<SubscriptionBill | null>(null);
  const [payingBill, setPayingBill] = useState<SubscriptionBill | null>(null);

  const todayStr = new Date().toISOString().split('T')[0];
  const currentMonthStr = todayStr.slice(0, 7);

  // Helper for category icon
  const getBillIcon = (category: BillCategory, iconName?: string) => {
    switch (category) {
      case 'utility':
        if (iconName === 'Flame') return Flame;
        if (iconName === 'Droplets') return Droplets;
        return Zap;
      case 'internet':
        return Wifi;
      case 'rent':
        return Home;
      case 'streaming':
        if (iconName === 'Headphones') return Headphones;
        return Tv;
      case 'software':
        return Bot;
      case 'fitness':
        return Dumbbell;
      case 'mobile':
        return Smartphone;
      default:
        return Receipt;
    }
  };

  // Status calculation for each bill
  const getDueStatus = (bill: SubscriptionBill) => {
    if (bill.status === 'paused') {
      return {
        label: language === 'bn' ? 'স্থগিত (Paused)' : 'Paused',
        type: 'paused',
        badgeColor: 'bg-slate-100 text-slate-600 border-slate-200',
      };
    }

    const isPaidThisMonth = bill.lastPaidDate && bill.lastPaidDate.startsWith(currentMonthStr);
    const dueTime = new Date(bill.dueDate).getTime();
    const nowTime = new Date(todayStr).getTime();
    const diffDays = Math.ceil((dueTime - nowTime) / (1000 * 60 * 60 * 24));

    if (isPaidThisMonth) {
      return {
        label: language === 'bn' ? 'চলতি মাসে পরিশোধিত' : 'Paid This Month',
        type: 'paid',
        badgeColor: 'bg-emerald-50 text-emerald-800 border-emerald-200',
      };
    }

    if (diffDays < 0) {
      const lateDays = Math.abs(diffDays);
      return {
        label: language === 'bn' ? `মেয়াদ পার (${lateDays} দিন আগে)` : `Overdue by ${lateDays}d`,
        type: 'overdue',
        badgeColor: 'bg-rose-50 text-rose-700 border-rose-200 font-black animate-pulse',
      };
    }

    if (diffDays === 0) {
      return {
        label: language === 'bn' ? 'আজই শেষ দিন' : 'Due Today',
        type: 'today',
        badgeColor: 'bg-amber-500 text-white border-amber-600 font-extrabold',
      };
    }

    if (diffDays <= 3) {
      return {
        label: language === 'bn' ? `${diffDays} দিনের মধ্যে প্রদেয়` : `Due in ${diffDays} days`,
        type: 'soon',
        badgeColor: 'bg-amber-50 text-amber-800 border-amber-300 font-bold',
      };
    }

    return {
      label: language === 'bn' ? `${diffDays} দিন বাকি` : `Due in ${diffDays} days`,
      type: 'upcoming',
      badgeColor: 'bg-slate-50 text-slate-700 border-slate-200',
    };
  };

  // Filtered & Sorted Bills
  const filteredBills = useMemo(() => {
    return subscriptions
      .filter(b => {
        // Tab filtering
        if (filterTab === 'due') {
          const isPaidThisMonth = b.lastPaidDate && b.lastPaidDate.startsWith(currentMonthStr);
          const diffDays = Math.ceil((new Date(b.dueDate).getTime() - new Date(todayStr).getTime()) / (1000 * 60 * 60 * 24));
          return b.status === 'active' && !isPaidThisMonth && diffDays <= 7;
        }
        if (filterTab === 'utility') {
          return b.category === 'utility' || b.category === 'rent';
        }
        if (filterTab === 'telecom') {
          return b.category === 'internet' || b.category === 'mobile';
        }
        if (filterTab === 'digital') {
          return b.category === 'streaming' || b.category === 'software';
        }
        if (filterTab === 'paid') {
          return b.lastPaidDate && b.lastPaidDate.startsWith(currentMonthStr);
        }
        return true;
      })
      .filter(b => {
        // Search query
        if (!searchQuery.trim()) return true;
        const q = searchQuery.toLowerCase();
        return (
          b.name.toLowerCase().includes(q) ||
          (b.providerName && b.providerName.toLowerCase().includes(q)) ||
          (b.subscriberIdOrMeterNo && b.subscriberIdOrMeterNo.toLowerCase().includes(q))
        );
      })
      .sort((a, b) => {
        if (sortBy === 'amountDesc') return b.amount - a.amount;
        if (sortBy === 'name') return a.name.localeCompare(b.name);
        // Default: due date
        return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
      });
  }, [subscriptions, filterTab, searchQuery, sortBy, currentMonthStr, todayStr]);

  // Urgent overdue / due today bills
  const urgentBills = useMemo(() => {
    return subscriptions.filter(b => {
      if (b.status !== 'active') return false;
      const isPaid = b.lastPaidDate && b.lastPaidDate.startsWith(currentMonthStr);
      if (isPaid) return false;
      const diffDays = Math.ceil((new Date(b.dueDate).getTime() - new Date(todayStr).getTime()) / (1000 * 60 * 60 * 24));
      return diffDays <= 0;
    });
  }, [subscriptions, currentMonthStr, todayStr]);

  // Annual Digital Subscriptions total (entertainment/software)
  const digitalAnnualCost = useMemo(() => {
    return subscriptions
      .filter(s => s.status === 'active' && (s.category === 'streaming' || s.category === 'software'))
      .reduce((sum, s) => {
        const monthly = s.billingCycle === 'yearly' ? s.amount / 12 : s.amount;
        return sum + monthly * 12;
      }, 0);
  }, [subscriptions]);

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Top Header */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-emerald-800 font-bold text-xs uppercase tracking-wider mb-1">
            <CalendarClock className="w-4 h-4 text-emerald-600" />
            <span>{language === 'bn' ? 'বিল ও সাবস্ক্রিপশন ট্র্যাকার' : 'Recurring Bills & Subscriptions'}</span>
          </div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {language === 'bn' ? 'ইউটিলিটি ও সাবস্ক্রিপশন হিসাব' : 'Bills & Subscriptions Manager'}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
            {language === 'bn'
              ? 'বিদ্যুৎ, পানি, গ্যাস, ইন্টারনেট, বাসা ভাড়া ও ডিজিটাল সাবস্ক্রিপশনের মেয়াদ ট্র্যাক করুন এবং ১-ক্লিকে পরিশোধ করে লেনদেনে যুক্ত করুন।'
              : 'Track utilities, rent, broadband, and digital services with due date reminders and 1-tap instant payment logging.'}
          </p>
        </div>

        <div className="flex items-center gap-2.5 self-start md:self-auto">
          <button
            onClick={() => {
              setEditingBill(null);
              setIsAddModalOpen(true);
            }}
            className="px-4 sm:px-5 py-2.5 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-extrabold text-xs sm:text-sm flex items-center gap-2 shadow-sm active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4 stroke-[3]" />
            <span>{language === 'bn' ? 'নতুন বিল যোগ করুন' : 'Add New Bill'}</span>
          </button>
        </div>
      </div>

      {/* Urgent Attention Alert (if any bills overdue or due today) */}
      {urgentBills.length > 0 && (
        <div className="bg-gradient-to-r from-rose-500/10 via-amber-500/10 to-rose-500/10 border-2 border-rose-400/30 rounded-3xl p-4 sm:p-5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 animate-in fade-in">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500 text-white flex items-center justify-center shrink-0 shadow-sm animate-pulse">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-rose-900">
                {language === 'bn'
                  ? `জরুরি সতর্কবার্তা! ${urgentBills.length}টি বিলের মেয়াদ পার হয়েছে বা আজই শেষ দিন`
                  : `Attention Required! ${urgentBills.length} bills are due today or overdue`}
              </h3>
              <p className="text-xs text-rose-700 mt-0.5">
                {language === 'bn'
                  ? 'বিলম্ব ফি এড়াতে সময়মতো বিল পরিশোধ করুন।'
                  : 'Avoid late payment penalties and service disruption.'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto">
            {urgentBills.slice(0, 2).map(bill => (
              <button
                key={bill.id}
                onClick={() => setPayingBill(bill)}
                className="px-3 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-extrabold flex items-center gap-1 shadow-xs transition-colors cursor-pointer"
              >
                <span>{bill.name}</span>
                <span className="opacity-90 font-mono">({formatMoney(bill.amount)})</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Top 4 Stats Overview Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        {/* Monthly Commitment */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'মোট মাসিক বিলের চাপ' : 'Monthly Recurring'}
            </span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-slate-900">
              {formatMoney(totalMonthlyRecurring)}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn' ? 'প্রতি মাসে নিয়মমাফিক খরচ' : 'Calculated regular outflow'}
            </p>
          </div>
        </div>

        {/* Yearly Commitment */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'বাৎসরিক মোট ভার' : 'Yearly Outflow'}
            </span>
            <div className="w-8 h-8 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center">
              <DollarSign className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-xl sm:text-2xl font-black text-teal-800">
              {formatMoney(totalYearlyRecurring)}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn' ? 'বছরে মোট প্রদেয় হবে' : 'Annual projection'}
            </p>
          </div>
        </div>

        {/* Overdue / Due Soon */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'আসন্ন ও বকেয়া' : 'Overdue / Due Soon'}
            </span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-700 flex items-center justify-center">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="flex items-baseline gap-1.5">
              <span className="text-xl sm:text-2xl font-black text-slate-900">
                {overdueBillsCount + dueSoonBillsCount}
              </span>
              <span className="text-xs font-bold text-slate-400">
                {language === 'bn' ? 'টি বিল' : 'bills'}
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] mt-0.5">
              {overdueBillsCount > 0 ? (
                <span className="text-rose-600 font-bold">
                  {overdueBillsCount} {language === 'bn' ? 'বকেয়া' : 'overdue'}
                </span>
              ) : (
                <span className="text-emerald-700 font-semibold">
                  {language === 'bn' ? 'কোনো বকেয়া নেই' : 'No overdue'}
                </span>
              )}
              <span className="text-slate-300">·</span>
              <span className="text-amber-700 font-semibold">
                {dueSoonBillsCount} {language === 'bn' ? 'শীঘ্রই প্রদেয়' : 'due soon'}
              </span>
            </div>
          </div>
        </div>

        {/* Paid this month vs Pending */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'চলতি মাসের অবস্থা' : 'This Month Status'}
            </span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div>
            <div className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-1.5">
              <span className="text-emerald-700">{formatMoney(paidThisMonthRecurring)}</span>
              <span className="text-xs text-slate-300 font-normal">/</span>
              <span className="text-slate-500 font-bold">{formatMoney(totalMonthlyRecurring)}</span>
            </div>
            <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden mt-2">
              <div
                className="bg-emerald-500 h-1.5 rounded-full transition-all duration-500"
                style={{
                  width: `${
                    totalMonthlyRecurring > 0
                      ? Math.min(100, Math.round((paidThisMonthRecurring / totalMonthlyRecurring) * 100))
                      : 0
                  }%`,
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Filter Tabs & Search & Sort */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-4 shadow-xs space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          {/* Tabs */}
          <div className="flex gap-1.5 overflow-x-auto pb-1 sm:pb-0 scrollbar-none">
            {[
              { id: 'all', label: language === 'bn' ? 'সকল বিল' : 'All Bills' },
              { id: 'due', label: language === 'bn' ? 'শীঘ্রই প্রদেয়' : 'Due Soon / Overdue' },
              { id: 'utility', label: language === 'bn' ? 'বিদ্যুৎ ও ভাড়া' : 'Utilities & Rent' },
              { id: 'telecom', label: language === 'bn' ? 'ইন্টারনেট ও ফোন' : 'Internet & Phone' },
              { id: 'digital', label: language === 'bn' ? 'স্ট্রিমিং ও AI' : 'Digital & AI' },
              { id: 'paid', label: language === 'bn' ? 'পরিশোধিত' : 'Paid This Month' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => setFilterTab(tab.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all shrink-0 cursor-pointer ${
                  filterTab === tab.id
                    ? 'bg-emerald-600 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Search & Sort */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:w-60">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder={language === 'bn' ? 'বিল বা মিটার খুঁজুন...' : 'Search bills...'}
                className="w-full pl-8 pr-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              />
            </div>

            <select
              value={sortBy}
              onChange={e => setSortBy(e.target.value as any)}
              className="px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-none"
            >
              <option value="dueDate">{language === 'bn' ? 'তারিখ অনুযায়ী' : 'By Due Date'}</option>
              <option value="amountDesc">{language === 'bn' ? 'টাকার পরিমাণ (বেশি)' : 'Highest Amount'}</option>
              <option value="name">{language === 'bn' ? 'নাম অনুযায়ী' : 'By Name'}</option>
            </select>
          </div>
        </div>
      </div>

      {/* Bill Cards Grid */}
      {filteredBills.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 mx-auto flex items-center justify-center">
            <Receipt className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">
            {language === 'bn' ? 'কোনো বিল পাওয়া যায়নি' : 'No bills found'}
          </h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto">
            {language === 'bn'
              ? 'নতুন কোনো ইউটিলিটি বিল বা সাবস্ক্রিপশন যোগ করতে উপরের বোতামে ক্লিক করুন।'
              : 'Add your regular expenses to get automatic reminders and 1-click settlements.'}
          </p>
          <button
            onClick={() => {
              setEditingBill(null);
              setIsAddModalOpen(true);
            }}
            className="px-4 py-2 rounded-xl bg-emerald-600 text-white text-xs font-bold inline-flex items-center gap-1.5 shadow-xs"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'bn' ? 'নতুন বিল যোগ করুন' : 'Add Bill'}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredBills.map(bill => {
            const Icon = getBillIcon(bill.category, bill.iconName);
            const statusInfo = getDueStatus(bill);
            const linkedAcc = accounts.find(a => a.id === bill.accountId);
            const linkedCard = digitalCards.find(c => c.id === bill.cardId);

            return (
              <div
                key={bill.id}
                className="bg-white border border-slate-200/90 hover:border-emerald-300 rounded-3xl p-5 shadow-xs transition-all hover:shadow-md flex flex-col justify-between space-y-4 relative group"
              >
                {/* Top Row: Icon + Name + Status */}
                <div className="space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex items-center gap-3">
                      <div
                        className="w-11 h-11 rounded-2xl flex items-center justify-center text-white shrink-0 shadow-xs"
                        style={{ backgroundColor: bill.color || '#10b981' }}
                      >
                        <Icon className="w-5 h-5 stroke-[2.2]" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="text-sm font-extrabold text-slate-900 truncate" title={bill.name}>
                          {bill.name}
                        </h3>
                        {bill.providerName && (
                          <p className="text-xs text-slate-400 truncate">
                            {bill.providerName}
                          </p>
                        )}
                      </div>
                    </div>

                    {/* Due Status Chip */}
                    <span
                      className={`text-[10px] px-2.5 py-1 rounded-full border shrink-0 text-center font-bold ${statusInfo.badgeColor}`}
                    >
                      {statusInfo.label}
                    </span>
                  </div>

                  {/* Meter / Subscriber / Account No Chip */}
                  {bill.subscriberIdOrMeterNo && (
                    <div className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-slate-50 border border-slate-100 text-[11px] font-mono text-slate-600">
                      <span className="text-slate-400">{language === 'bn' ? 'মিটার/আইডি:' : 'ID:'}</span>
                      <span className="font-bold">{bill.subscriberIdOrMeterNo}</span>
                    </div>
                  )}

                  {/* Notes / Description */}
                  {bill.notes && (
                    <p className="text-xs text-slate-500 line-clamp-2 italic">
                      "{bill.notes}"
                    </p>
                  )}
                </div>

                {/* Amount & Due Date Box */}
                <div className="pt-2 border-t border-slate-100 space-y-3">
                  <div className="flex items-baseline justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        {language === 'bn' ? 'বিল পরিমাণ' : 'Amount'}
                      </span>
                      <span className="text-xl font-black text-slate-900">
                        {formatMoney(bill.amount)}
                      </span>
                      <span className="text-[11px] text-slate-400 ml-1 font-semibold">
                        / {bill.billingCycle === 'yearly' ? (language === 'bn' ? 'বছর' : 'yr') : (language === 'bn' ? 'মাস' : 'mo')}
                      </span>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
                        {language === 'bn' ? 'পরবর্তী তারিখ' : 'Due Date'}
                      </span>
                      <span className="text-xs font-black text-slate-800 flex items-center justify-end gap-1">
                        <CalendarClock className="w-3 h-3 text-slate-400" />
                        <span>{bill.dueDate}</span>
                      </span>
                      {bill.lastPaidDate && (
                        <span className="text-[10px] text-emerald-700 block mt-0.5">
                          {language === 'bn' ? 'গত পরিশোধ:' : 'Paid:'} {bill.lastPaidDate}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Linked Payment Account or Card */}
                  {(linkedAcc || linkedCard) && (
                    <div className="flex items-center gap-1.5 text-[11px] text-slate-500 bg-slate-50/80 p-2 rounded-xl border border-slate-100">
                      {linkedCard ? (
                        <>
                          <CreditCard className="w-3.5 h-3.5 text-slate-700" />
                          <span className="font-semibold text-slate-700 truncate">
                            {linkedCard.issuerName} (•••• {linkedCard.last4})
                          </span>
                        </>
                      ) : linkedAcc ? (
                        <>
                          <Building2 className="w-3.5 h-3.5 text-slate-700" />
                          <span className="font-semibold text-slate-700 truncate">
                            {language === 'bn' ? linkedAcc.nameBn || linkedAcc.name : linkedAcc.name}
                          </span>
                        </>
                      ) : null}
                    </div>
                  )}

                  {/* Actions Bar */}
                  <div className="flex items-center justify-between gap-1.5 pt-1">
                    <button
                      onClick={() => setPayingBill(bill)}
                      className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white text-xs font-black shadow-xs flex items-center justify-center gap-1.5 active:scale-95 transition-all cursor-pointer"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{language === 'bn' ? 'পরিশোধ করুন' : 'Pay Bill'}</span>
                    </button>

                    <button
                      onClick={() => togglePauseSubscription(bill.id)}
                      className="p-2 rounded-xl border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
                      title={bill.status === 'active' ? 'Pause' : 'Resume'}
                    >
                      {bill.status === 'active' ? (
                        <PauseCircle className="w-4 h-4" />
                      ) : (
                        <PlayCircle className="w-4 h-4 text-emerald-600" />
                      )}
                    </button>

                    <button
                      onClick={() => {
                        setEditingBill(bill);
                        setIsAddModalOpen(true);
                      }}
                      className="p-2 rounded-xl border border-slate-200 text-slate-500 hover:text-slate-800 hover:bg-slate-50 transition-colors cursor-pointer"
                      title="Edit"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => {
                        if (confirm(language === 'bn' ? 'বিলটি মুছে ফেলতে চান?' : 'Delete this bill?')) {
                          deleteSubscription(bill.id);
                        }
                      }}
                      className="p-2 rounded-xl border border-slate-200 text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition-colors cursor-pointer"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Smart Cost-Cutting & Subscription Audit Card */}
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-emerald-950 text-white rounded-3xl p-5 sm:p-6 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 flex items-center justify-center">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-black tracking-tight flex items-center gap-2">
                <span>{language === 'bn' ? 'স্মার্ট সাবস্ক্রিপশন অডিট ও সাশ্রয় টিপস' : 'Subscription Health & Audit'}</span>
              </h3>
              <p className="text-xs text-slate-300">
                {language === 'bn'
                  ? 'আপনার বিনোদন ও সফটওয়্যার সাবস্ক্রিপশনে বছরে কত খরচ হচ্ছে তা জানুন'
                  : 'Analyze unseen recurring drains on your annual cashflow'}
              </p>
            </div>
          </div>

          <div className="bg-white/10 backdrop-blur-md px-3.5 py-1.5 rounded-2xl border border-white/15 text-right self-start sm:self-auto">
            <span className="text-[10px] text-emerald-300 font-bold block uppercase tracking-wider">
              {language === 'bn' ? 'ডিজিটাল সেবায় বাৎসরিক ব্যয়' : 'Annual Digital Drain'}
            </span>
            <span className="text-base sm:text-lg font-black text-white">
              {formatMoney(digitalAnnualCost)}
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 text-xs">
          <div className="bg-white/5 rounded-2xl p-3.5 border border-white/10 space-y-1">
            <span className="font-extrabold text-emerald-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4" />
              {language === 'bn' ? 'ফ্যামিলি প্ল্যানিং' : 'Family Plan Sharing'}
            </span>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {language === 'bn'
                ? 'Spotify Duo বা Family এবং Netflix শেয়ার করলে মাসিক খরচ ৬০% পর্যন্ত কমে যেতে পারে।'
                : 'Sharing duo/family tiers with roommates cuts individual streaming costs by up to 60%.'}
            </p>
          </div>

          <div className="bg-white/5 rounded-2xl p-3.5 border border-white/10 space-y-1">
            <span className="font-extrabold text-amber-400 flex items-center gap-1.5">
              <TrendingDown className="w-4 h-4" />
              {language === 'bn' ? 'ঘোস্ট সাবস্ক্রিপশন অডিট' : 'Ghost Subscription Check'}
            </span>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {language === 'bn'
                ? 'যে সেবাগুলো মাসে ২-৩ বারের কম ব্যবহার করেন, সেগুলোর সাবস্ক্রিপশন পজ (Pause) করে রাখুন।'
                : 'Services opened less than twice a month should be paused to preserve capital.'}
            </p>
          </div>

          <div className="bg-white/5 rounded-2xl p-3.5 border border-white/10 space-y-1">
            <span className="font-extrabold text-sky-400 flex items-center gap-1.5">
              <Zap className="w-4 h-4" />
              {language === 'bn' ? 'দেরি না করে বিল পরিশোধ' : 'Avoid Surcharges'}
            </span>
            <p className="text-slate-300 text-[11px] leading-relaxed">
              {language === 'bn'
                ? 'DESCO ও তিতাস গ্যাসে বিলম্ব ফি এড়াতে আমাদের দেওয়া কাউন্টডাউন নোটিফিকেশন দেখে বিল পরিশোধ করুন।'
                : 'Paying utility bills 3 days before cutoff avoids late fee surcharges.'}
            </p>
          </div>
        </div>
      </div>

      {/* Modals */}
      <AddSubscriptionModal
        isOpen={isAddModalOpen}
        onClose={() => {
          setIsAddModalOpen(false);
          setEditingBill(null);
        }}
        editBill={editingBill}
      />

      <PayBillModal
        isOpen={!!payingBill}
        onClose={() => setPayingBill(null)}
        bill={payingBill}
      />
    </div>
  );
};
