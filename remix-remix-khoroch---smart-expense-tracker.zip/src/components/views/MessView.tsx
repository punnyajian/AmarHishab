import React, { useState, useMemo, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import {
  MessMember,
  MessBazarEntry,
  MessDepositEntry,
  MessFixedCostItem,
  MessBazarScheduleItem,
} from '../../types';
import {
  CookingPot,
  Plus,
  Trash2,
  Edit2,
  Calendar,
  DollarSign,
  Utensils,
  ShoppingBag,
  Home,
  Users,
  Copy,
  Check,
  Printer,
  Share2,
  ArrowUpRight,
  ArrowDownLeft,
  ChevronRight,
  Phone,
  Bed,
  CheckCircle2,
  AlertCircle,
  X,
  Wallet,
  CalendarDays,
  Sparkles,
  Info,
  Clock,
  UserCheck,
  UserX,
} from 'lucide-react';
import confetti from 'canvas-confetti';

type MessSubTab = 'overview' | 'meals' | 'bazar' | 'deposits' | 'fixed' | 'routine';

export const MessView: React.FC = () => {
  const {
    messData,
    updateMessConfig,
    addMessMember,
    editMessMember,
    deleteMessMember,
    setMemberDailyMeal,
    quickIncrementMeal,
    addBazarEntry,
    deleteBazarEntry,
    addDepositEntry,
    deleteDepositEntry,
    addFixedCost,
    editFixedCost,
    deleteFixedCost,
    addBazarSchedule,
    deleteBazarSchedule,
    resetMessMonth,
    totalMessMeals,
    totalMessBazarCost,
    messMealRate,
    totalMessFixedCost,
    fixedCostPerMember,
    totalMessDeposits,
    messCashInHand,
    memberSummaries,
    accounts,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const [activeSubTab, setActiveSubTab] = useState<MessSubTab>('overview');
  const [selectedDate, setSelectedDate] = useState<string>(() => new Date().toISOString().split('T')[0]);
  const [copySuccess, setCopySuccess] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals state
  const [isMemberModalOpen, setIsMemberModalOpen] = useState(false);
  const [editingMember, setEditingMember] = useState<MessMember | null>(null);

  const [isBazarModalOpen, setIsBazarModalOpen] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [isFixedCostModalOpen, setIsFixedCostModalOpen] = useState(false);
  const [editingFixedCost, setEditingFixedCost] = useState<MessFixedCostItem | null>(null);

  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isConfigModalOpen, setIsConfigModalOpen] = useState(false);

  const isAnyMessModalOpen =
    isMemberModalOpen ||
    isBazarModalOpen ||
    isDepositModalOpen ||
    isFixedCostModalOpen ||
    isScheduleModalOpen ||
    isShareModalOpen ||
    isConfigModalOpen;

  useLockBodyScroll(isAnyMessModalOpen);

  useEffect(() => {
    if (!isAnyMessModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setIsMemberModalOpen(false);
        setIsBazarModalOpen(false);
        setIsDepositModalOpen(false);
        setIsFixedCostModalOpen(false);
        setIsScheduleModalOpen(false);
        setIsShareModalOpen(false);
        setIsConfigModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAnyMessModalOpen]);

  // Quick Toast Helper
  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Filter daily meals for the currently selected date
  const selectedDateMeals = useMemo(() => {
    const map = new Map<string, typeof messData.dailyMeals[0]>();
    messData.dailyMeals
      .filter(dm => dm.date === selectedDate)
      .forEach(dm => map.set(dm.memberId, dm));
    return map;
  }, [messData.dailyMeals, selectedDate]);

  // Day total meals for selected date
  const selectedDayTotalMeals = useMemo(() => {
    let sum = 0;
    selectedDateMeals.forEach(dm => {
      sum += dm.totalMeals || 0;
    });
    return Math.round(sum * 10) / 10;
  }, [selectedDateMeals]);

  // Generate shareable WhatsApp/Messenger formatted Bengali text summary
  const shareableText = useMemo(() => {
    const month = messData.config?.activeMonth || new Date().toISOString().slice(0, 7);
    const lines: string[] = [];

    lines.push(`🏠 *${messData.config?.name || 'ব্যাচেলর মেস'}*`);
    lines.push(`📅 *মাসের হিসাব:* ${month}`);
    if (messData.config?.managerName) {
      lines.push(`👤 *ম্যানেজার:* ${messData.config.managerName}`);
    }
    lines.push(`----------------------------------`);
    lines.push(`🍚 *মোট মিল:* ${totalMessMeals} টি`);
    lines.push(`🛒 *মোট বাজার খরচ:* ${formatMoney(totalMessBazarCost)}`);
    lines.push(`🔥 *মিল রেট:* ${formatMoney(messMealRate)} / মিল`);
    lines.push(`🏠 *মোট স্থায়ী খরচ:* ${formatMoney(totalMessFixedCost)} (জনপ্রতি ${formatMoney(fixedCostPerMember)})`);
    lines.push(`💰 *মোট ফান্ড জমা:* ${formatMoney(totalMessDeposits)}`);
    lines.push(`💵 *হাতে ক্যাশ ব্যালেন্স:* ${formatMoney(messCashInHand)}`);
    lines.push(`----------------------------------`);
    lines.push(`📋 *সদস্যদের হিসাব বিবরণী:*`);

    memberSummaries.forEach((summary, idx) => {
      const { member, totalMeals, totalCost, totalDeposit, balance, status } = summary;
      let statusStr = '';
      if (status === 'refund') {
        statusStr = `✅ পাবে: ${formatMoney(balance)}`;
      } else if (status === 'due') {
        statusStr = `⚠️ দিবে: ${formatMoney(Math.abs(balance))}`;
      } else {
        statusStr = `✨ পরিশোধিত (ব্যালেন্স 0)`;
      }

      lines.push(
        `${idx + 1}. *${member.name}* (রুম: ${member.roomNo || 'N/A'})\n` +
        `   • মিল: ${totalMeals} টি | মোট খরচ: ${formatMoney(totalCost)} | জমা: ${formatMoney(totalDeposit)}\n` +
        `   • *হিসাব:* ${statusStr}`
      );
    });

    lines.push(`----------------------------------`);
    lines.push(`Generated by Khoroch Smart Expense & Mess Tracker 💚`);
    return lines.join('\n');
  }, [
    messData,
    totalMessMeals,
    totalMessBazarCost,
    messMealRate,
    totalMessFixedCost,
    fixedCostPerMember,
    totalMessDeposits,
    messCashInHand,
    memberSummaries,
    formatMoney,
  ]);

  const handleCopyShare = () => {
    navigator.clipboard.writeText(shareableText);
    setCopySuccess(true);
    confetti({
      particleCount: 50,
      spread: 60,
      origin: { y: 0.8 },
    });
    showToast(language === 'bn' ? 'মেসের হিসাব কপি হয়েছে! মেসেঞ্জারে বা হোয়াটসঅ্যাপে শেয়ার করুন।' : 'Mess summary copied!');
    setTimeout(() => setCopySuccess(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-16 animate-in fade-in duration-200">
      
      {/* Toast banner */}
      {toastMessage && (
        <div className="bg-emerald-600 text-white px-4 py-3 rounded-2xl shadow-lg flex items-center justify-between text-xs sm:text-sm font-semibold animate-in slide-in-from-top duration-200 no-print">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-200" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-white/80 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Header Card */}
      <div className="bg-gradient-to-br from-emerald-700 via-emerald-600 to-teal-700 rounded-3xl p-5 sm:p-7 text-white shadow-lg relative overflow-hidden">
        {/* Subtle decorative circles */}
        <div className="absolute -top-12 -right-12 w-48 h-48 bg-white/10 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-8 -left-8 w-40 h-40 bg-teal-400/20 rounded-full blur-xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/20 backdrop-blur-md rounded-full text-xs font-semibold text-emerald-100">
              <CookingPot className="w-3.5 h-3.5 text-emerald-200" />
              <span>{language === 'bn' ? 'মেস ও মিল ক্যালকুলেটর' : 'Mess & Bachelor Meal Manager'}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-300" />
              <span>{messData.config?.activeMonth || 'Current Month'}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
              <span>{messData.config?.name || 'গ্রিন ভিউ ব্যাচেলর মেস'}</span>
              <button
                onClick={() => setIsConfigModalOpen(true)}
                className="p-1.5 rounded-xl bg-white/10 hover:bg-white/25 text-white/90 hover:text-white transition-colors"
                title="মেসের তথ্য এডিট করুন"
              >
                <Edit2 className="w-4 h-4" />
              </button>
            </h1>

            <p className="text-xs sm:text-sm text-emerald-100 flex flex-wrap items-center gap-x-3 gap-y-1">
              <span>{language === 'bn' ? 'ম্যানেজার:' : 'Manager:'} <strong>{messData.config?.managerName || 'ফয়সাল রানা'}</strong></span>
              {messData.config?.managerPhone && (
                <span>• 📞 {messData.config.managerPhone}</span>
              )}
              <span>• 👥 {messData.members.length} {language === 'bn' ? 'জন সদস্য' : 'members'}</span>
            </p>
          </div>

          {/* Quick Actions Buttons */}
          <div className="flex flex-wrap items-center gap-2 no-print">
            <button
              onClick={() => setIsBazarModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white text-emerald-800 font-bold text-xs hover:bg-emerald-50 active:scale-95 shadow-xs transition-all"
            >
              <ShoppingBag className="w-4 h-4 text-emerald-600" />
              <span>{language === 'bn' ? 'বাজার খরচ' : 'Add Bazar'}</span>
            </button>

            <button
              onClick={() => setIsDepositModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-500/80 hover:bg-emerald-500 text-white font-bold text-xs active:scale-95 border border-white/20 transition-all"
            >
              <DollarSign className="w-4 h-4" />
              <span>{language === 'bn' ? 'টাকা জমা' : 'Add Deposit'}</span>
            </button>

            <button
              onClick={() => setIsShareModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs backdrop-blur-md active:scale-95 transition-all"
              title="হোয়াটসঅ্যাপে শেয়ার করুন"
            >
              <Share2 className="w-4 h-4" />
              <span className="hidden sm:inline">{language === 'bn' ? 'শেয়ার' : 'Share'}</span>
            </button>

            <button
              onClick={handlePrint}
              className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-white/15 hover:bg-white/25 text-white font-bold text-xs backdrop-blur-md active:scale-95 transition-all"
              title="প্রিন্ট করুন"
            >
              <Printer className="w-4 h-4" />
              <span className="hidden sm:inline">{language === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
            </button>
          </div>
        </div>

        {/* Live Key Metrics Banner */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3 mt-6 pt-6 border-t border-white/15 text-white">
          
          {/* Meal Rate Card */}
          <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-emerald-100 flex items-center gap-1">
              <Utensils className="w-3.5 h-3.5" />
              {language === 'bn' ? 'লাইভ মিল রেট' : 'Live Meal Rate'}
            </span>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-black tracking-tight">
                {formatMoney(messMealRate)}
                <span className="text-xs font-normal text-emerald-200 ml-1">
                  {language === 'bn' ? '/মিল' : '/meal'}
                </span>
              </div>
              <p className="text-[10px] text-emerald-200 mt-0.5 truncate">
                {totalMessMeals > 0 
                  ? `${totalMessBazarCost} ÷ ${totalMessMeals}` 
                  : (language === 'bn' ? 'মিল শুরু হয়নি' : 'No meals')}
              </p>
            </div>
          </div>

          {/* Total Meals Card */}
          <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-emerald-100 flex items-center gap-1">
              <CookingPot className="w-3.5 h-3.5" />
              {language === 'bn' ? 'মোট মিল' : 'Total Meals'}
            </span>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-black tracking-tight">
                {totalMessMeals}
                <span className="text-xs font-normal text-emerald-200 ml-1">
                  {language === 'bn' ? 'টি' : 'meals'}
                </span>
              </div>
              <p className="text-[10px] text-emerald-200 mt-0.5">
                {language === 'bn' ? 'সকল সদস্য ও গেস্ট' : 'All members'}
              </p>
            </div>
          </div>

          {/* Total Bazar Card */}
          <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-emerald-100 flex items-center gap-1">
              <ShoppingBag className="w-3.5 h-3.5" />
              {language === 'bn' ? 'মোট বাজার খরচ' : 'Total Bazar'}
            </span>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-black tracking-tight">
                {formatMoney(totalMessBazarCost)}
              </div>
              <p className="text-[10px] text-emerald-200 mt-0.5">
                {messData.bazarEntries.length} {language === 'bn' ? 'টি বাজার এন্ট্রি' : 'bazar entries'}
              </p>
            </div>
          </div>

          {/* Fixed Costs Card */}
          <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-emerald-100 flex items-center gap-1">
              <Home className="w-3.5 h-3.5" />
              {language === 'bn' ? 'স্থায়ী বিল (জনপ্রতি)' : 'Fixed Share'}
            </span>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-black tracking-tight">
                {formatMoney(fixedCostPerMember)}
              </div>
              <p className="text-[10px] text-emerald-200 mt-0.5 truncate">
                {language === 'bn' ? `মোট: ${formatMoney(totalMessFixedCost)}` : `Total: ${formatMoney(totalMessFixedCost)}`}
              </p>
            </div>
          </div>

          {/* Cash in Hand Card */}
          <div className="bg-white/15 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between col-span-2 sm:col-span-1">
            <span className="text-[11px] font-semibold text-emerald-100 flex items-center gap-1">
              <Wallet className="w-3.5 h-3.5" />
              {language === 'bn' ? 'হাতে নগদ ক্যাশ' : 'Cash in Hand'}
            </span>
            <div className="mt-1">
              <div className={`text-xl sm:text-2xl font-black tracking-tight ${messCashInHand < 0 ? 'text-rose-200' : 'text-white'}`}>
                {formatMoney(messCashInHand)}
              </div>
              <p className="text-[10px] text-emerald-200 mt-0.5">
                {language === 'bn' ? `মোট জমা: ${formatMoney(totalMessDeposits)}` : `Deposits: ${formatMoney(totalMessDeposits)}`}
              </p>
            </div>
          </div>

        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar border-b border-slate-200/80 no-print">
        {[
          { id: 'overview', label: language === 'bn' ? 'সদস্যদের হিসাব ও মিল রেট' : 'Overview & Accounts', icon: Users },
          { id: 'meals', label: language === 'bn' ? 'দৈনিক মিল শিট' : 'Daily Meal Sheet', icon: Utensils },
          { id: 'bazar', label: language === 'bn' ? 'বাজারের খাতা' : 'Bazar Log', icon: ShoppingBag },
          { id: 'deposits', label: language === 'bn' ? 'টাকা জমা ও ফান্ড' : 'Deposits', icon: DollarSign },
          { id: 'fixed', label: language === 'bn' ? 'স্থায়ী খরচ ও বিল' : 'Fixed Utilities', icon: Home },
          { id: 'routine', label: language === 'bn' ? 'বাজারের রুটিন' : 'Bazar Routine', icon: CalendarDays },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as MessSubTab)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-150 ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200/60'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ========================================================= */}
      {/* 1. OVERVIEW & MEMBERS SUMMARY TAB */}
      {/* ========================================================= */}
      {activeSubTab === 'overview' && (
        <div className="space-y-6">
          
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight flex items-center gap-2">
                <span>{language === 'bn' ? 'সদস্যদের চূড়ান্ত হিসাব (কে পাবে / কে দিবে)' : 'Member Balances & Settlement'}</span>
              </h2>
              <p className="text-xs text-slate-500">
                {language === 'bn'
                  ? 'মিল রেট ও স্থায়ী খরচ ভাগ হয়ে স্বয়ংক্রিয়ভাবে ব্যালেন্স নির্ধারিত হচ্ছে'
                  : 'Automatic calculation based on meals, meal rate, and shared utilities'}
              </p>
            </div>

            <div className="flex items-center gap-2 no-print">
              <button
                onClick={() => {
                  setEditingMember(null);
                  setIsMemberModalOpen(true);
                }}
                className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors"
              >
                <Plus className="w-4 h-4 stroke-[2.5]" />
                <span>{language === 'bn' ? 'নতুন মেম্বার' : 'Add Member'}</span>
              </button>
            </div>
          </div>

          {/* Members Table */}
          <div className="bg-white border border-slate-200/80 rounded-3xl shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs sm:text-sm">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-[11px] tracking-wider border-b border-slate-100">
                  <tr>
                    <th className="py-3.5 px-4">{language === 'bn' ? 'সদস্য / রুম' : 'Member / Room'}</th>
                    <th className="py-3.5 px-3 text-center">{language === 'bn' ? 'মোট মিল' : 'Meals'}</th>
                    <th className="py-3.5 px-3 text-right">{language === 'bn' ? 'মিল বাবদ খরচ' : 'Meal Cost'}</th>
                    <th className="py-3.5 px-3 text-right">{language === 'bn' ? 'স্থায়ী বিল' : 'Fixed Share'}</th>
                    <th className="py-3.5 px-3 text-right">{language === 'bn' ? 'মোট খরচ' : 'Total Cost'}</th>
                    <th className="py-3.5 px-3 text-right">{language === 'bn' ? 'জমা টাকা' : 'Deposited'}</th>
                    <th className="py-3.5 px-4 text-right font-black">{language === 'bn' ? 'পাবে / দিবে' : 'Status / Balance'}</th>
                    <th className="py-3.5 px-3 text-center no-print">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100 font-medium">
                  {memberSummaries.map((summary) => {
                    const { member, totalMeals, mealCost, fixedCostShare, extraCost, totalCost, totalDeposit, balance, status } = summary;
                    const isRefund = status === 'refund';
                    const isDue = status === 'due';

                    return (
                      <tr key={member.id} className="hover:bg-slate-50/80 transition-colors">
                        
                        {/* Member Name and details */}
                        <td className="py-3.5 px-4">
                          <div className="flex items-center gap-2.5">
                            <div
                              className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-black shrink-0"
                              style={{ backgroundColor: member.avatarColor || '#10b981' }}
                            >
                              {member.name.charAt(0)}
                            </div>
                            <div className="min-w-0">
                              <div className="font-bold text-slate-900 truncate flex items-center gap-1.5">
                                <span>{member.name}</span>
                                {!member.active && (
                                  <span className="text-[10px] px-1.5 py-0.5 rounded-sm bg-slate-100 text-slate-500 font-semibold">
                                    {language === 'bn' ? 'নিষ্ক্রিয়' : 'Inactive'}
                                  </span>
                                )}
                              </div>
                              <div className="text-[11px] text-slate-400 flex items-center gap-2">
                                {member.roomNo && (
                                  <span className="flex items-center gap-0.5">
                                    <Bed className="w-3 h-3" />
                                    {member.roomNo}
                                  </span>
                                )}
                                {member.phone && (
                                  <span className="flex items-center gap-0.5">
                                    <Phone className="w-3 h-3" />
                                    {member.phone}
                                  </span>
                                )}
                              </div>
                            </div>
                          </div>
                        </td>

                        {/* Meals */}
                        <td className="py-3.5 px-3 text-center font-bold text-slate-800">
                          {totalMeals}
                        </td>

                        {/* Meal Cost */}
                        <td className="py-3.5 px-3 text-right text-slate-600">
                          {formatMoney(mealCost)}
                        </td>

                        {/* Fixed Cost Share */}
                        <td className="py-3.5 px-3 text-right text-slate-600">
                          {formatMoney(fixedCostShare)}
                          {extraCost > 0 && (
                            <div className="text-[10px] text-amber-600 font-bold" title="ব্যক্তিগত অতিরিক্ত খরচ">
                              +{formatMoney(extraCost)}
                            </div>
                          )}
                        </td>

                        {/* Total Cost */}
                        <td className="py-3.5 px-3 text-right font-bold text-slate-900">
                          {formatMoney(totalCost)}
                        </td>

                        {/* Deposit Paid */}
                        <td className="py-3.5 px-3 text-right text-emerald-700 font-bold">
                          {formatMoney(totalDeposit)}
                        </td>

                        {/* Final Balance (পাবে / দিবে) */}
                        <td className="py-3.5 px-4 text-right">
                          {isRefund ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-emerald-100 text-emerald-800 font-black text-xs">
                              <ArrowDownLeft className="w-3.5 h-3.5 stroke-[2.5]" />
                              <span>{formatMoney(balance)} {language === 'bn' ? 'পাবে' : 'Refund'}</span>
                            </span>
                          ) : isDue ? (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-rose-100 text-rose-800 font-black text-xs">
                              <ArrowUpRight className="w-3.5 h-3.5 stroke-[2.5]" />
                              <span>{formatMoney(Math.abs(balance))} {language === 'bn' ? 'দিবে' : 'Due'}</span>
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-xl bg-slate-100 text-slate-700 font-bold text-xs">
                              <Check className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'পরিশোধিত' : 'Settled'}</span>
                            </span>
                          )}
                        </td>

                        {/* Action buttons */}
                        <td className="py-3.5 px-3 text-center no-print">
                          <div className="flex items-center justify-center gap-1">
                            <button
                              onClick={() => {
                                setEditingMember(member);
                                setIsMemberModalOpen(true);
                              }}
                              className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
                              title="এডিট মেম্বার"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => {
                                if (window.confirm(language === 'bn' ? `${member.name}-কে মেস থেকে ডিলিট করতে চান?` : 'Delete member?')) {
                                  deleteMessMember(member.id);
                                  showToast(language === 'bn' ? 'মেম্বার ডিলিট হয়েছে' : 'Member deleted');
                                }
                              }}
                              className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                              title="মুছুন"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>

                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Quick Explanation Banner */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 flex items-start gap-3 text-xs text-slate-600">
            <Info className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
            <div>
              <strong className="text-slate-800 font-bold">
                {language === 'bn' ? 'মেস হিসাব কীভাবে কাজ করে?' : 'How is this calculated?'}
              </strong>
              <p className="mt-0.5 leading-relaxed">
                {language === 'bn'
                  ? `মিল রেট = (মোট বাজার খরচ ÷ মোট মিল সংখ্যা)। প্রতিটি মেম্বারের মোট খরচ = (তার খাওয়া মিল × মিল রেট) + (জনপ্রতি স্থায়ী বিল)। মেম্বারের জমা টাকা থেকে মোট খরচ বিয়োগ করলে 'পাবে' বা 'দিবে' হিসাব স্বয়ংক্রিয়ভাবে বের হয়ে আসে।`
                  : `Meal Rate = (Total Bazar Expense ÷ Total Meals). Member Total Cost = (Member Meals × Meal Rate) + Member Fixed Cost Share. Net Balance = Deposit - Total Cost.`}
              </p>
            </div>
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* 2. DAILY MEAL SHEET TAB */}
      {/* ========================================================= */}
      {activeSubTab === 'meals' && (
        <div className="space-y-6">
          
          {/* Date Selector Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center shrink-0">
                <Calendar className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-black text-slate-900 text-base">
                  {language === 'bn' ? 'তারিখ অনুযায়ী দৈনিক মিল রেজিস্টার' : 'Daily Meal Entry Sheet'}
                </h3>
                <p className="text-xs text-slate-400">
                  {language === 'bn' ? 'প্রতিদিনের সকাল, দুপুর ও রাতের মিল সহজে এন্ট্রি করুন' : 'Record breakfast, lunch, and dinner counts'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="date"
                value={selectedDate}
                onChange={e => setSelectedDate(e.target.value)}
                className="px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              <button
                onClick={() => setSelectedDate(new Date().toISOString().split('T')[0])}
                className="px-3 py-2 bg-emerald-50 text-emerald-800 text-xs font-bold rounded-xl hover:bg-emerald-100 transition-colors"
              >
                {language === 'bn' ? 'আজ' : 'Today'}
              </button>
            </div>
          </div>

          {/* Selected Date Summary Badge */}
          <div className="flex items-center justify-between px-2">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider">
              📅 {selectedDate} • {language === 'bn' ? 'আজকের মোট মিল:' : 'Day Total Meals:'}{' '}
              <strong className="text-emerald-700 text-sm">{selectedDayTotalMeals} টি</strong>
            </span>
          </div>

          {/* Member Daily Meal Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {messData.members.map(member => {
              const entry = selectedDateMeals.get(member.id);
              const b = entry?.breakfast ?? 0.5;
              const l = entry?.lunch ?? 1;
              const d = entry?.dinner ?? 1;
              const g = entry?.guestMeals ?? 0;
              const isOff = entry?.isOff ?? false;
              const total = isOff ? 0 : (entry?.totalMeals ?? (b * 0.5 + l + d + g));

              return (
                <div
                  key={member.id}
                  className={`bg-white border rounded-3xl p-4 sm:p-5 shadow-xs transition-all space-y-3.5 ${
                    isOff
                      ? 'border-slate-200 bg-slate-50/50 opacity-75'
                      : 'border-slate-200/80 hover:border-emerald-300'
                  }`}
                >
                  {/* Member info & total */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      <div
                        className="w-8 h-8 rounded-full flex items-center justify-center text-white text-xs font-black shrink-0"
                        style={{ backgroundColor: member.avatarColor || '#10b981' }}
                      >
                        {member.name.charAt(0)}
                      </div>
                      <div>
                        <h4 className="font-bold text-slate-900 text-sm">{member.name}</h4>
                        <span className="text-[11px] text-slate-400">
                          {member.roomNo ? `রুম: ${member.roomNo}` : (language === 'bn' ? 'সদস্য' : 'Member')}
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className={`px-2.5 py-1 rounded-xl text-xs font-black ${isOff ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-800'}`}>
                        {isOff ? (language === 'bn' ? 'মিল বন্ধ' : 'Meal Off') : `${total} মিল`}
                      </div>
                    </div>
                  </div>

                  {/* Meal Counters (Breakfast, Lunch, Dinner, Guest) */}
                  <div className="grid grid-cols-4 gap-2 pt-1">
                    
                    {/* Breakfast */}
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2 text-center">
                      <span className="text-[10px] font-bold text-slate-400 block mb-1">
                        {language === 'bn' ? 'সকাল' : 'Breakfast'}
                      </span>
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => {
                            const newB = Math.max(0, b - 0.5);
                            setMemberDailyMeal(selectedDate, member.id, newB, l, d, g);
                          }}
                          className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-600 flex items-center justify-center font-bold text-xs hover:bg-slate-100 active:scale-95"
                        >
                          -
                        </button>
                        <span className="text-xs font-black text-slate-800 min-w-[20px]">{b}</span>
                        <button
                          onClick={() => {
                            const newB = b + 0.5;
                            setMemberDailyMeal(selectedDate, member.id, newB, l, d, g);
                          }}
                          className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs hover:bg-emerald-700 active:scale-95"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Lunch */}
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2 text-center">
                      <span className="text-[10px] font-bold text-slate-400 block mb-1">
                        {language === 'bn' ? 'দুপুর' : 'Lunch'}
                      </span>
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => {
                            const newL = Math.max(0, l - 1);
                            setMemberDailyMeal(selectedDate, member.id, b, newL, d, g);
                          }}
                          className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-600 flex items-center justify-center font-bold text-xs hover:bg-slate-100 active:scale-95"
                        >
                          -
                        </button>
                        <span className="text-xs font-black text-slate-800 min-w-[20px]">{l}</span>
                        <button
                          onClick={() => {
                            const newL = l + 1;
                            setMemberDailyMeal(selectedDate, member.id, b, newL, d, g);
                          }}
                          className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs hover:bg-emerald-700 active:scale-95"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Dinner */}
                    <div className="bg-slate-50 border border-slate-100 rounded-2xl p-2 text-center">
                      <span className="text-[10px] font-bold text-slate-400 block mb-1">
                        {language === 'bn' ? 'রাত' : 'Dinner'}
                      </span>
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => {
                            const newD = Math.max(0, d - 1);
                            setMemberDailyMeal(selectedDate, member.id, b, l, newD, g);
                          }}
                          className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-600 flex items-center justify-center font-bold text-xs hover:bg-slate-100 active:scale-95"
                        >
                          -
                        </button>
                        <span className="text-xs font-black text-slate-800 min-w-[20px]">{d}</span>
                        <button
                          onClick={() => {
                            const newD = d + 1;
                            setMemberDailyMeal(selectedDate, member.id, b, l, newD, g);
                          }}
                          className="w-6 h-6 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-bold text-xs hover:bg-emerald-700 active:scale-95"
                        >
                          +
                        </button>
                      </div>
                    </div>

                    {/* Guest */}
                    <div className="bg-amber-50/60 border border-amber-100 rounded-2xl p-2 text-center">
                      <span className="text-[10px] font-bold text-amber-700 block mb-1">
                        {language === 'bn' ? 'গেস্ট' : 'Guest'}
                      </span>
                      <div className="flex items-center justify-center gap-1">
                        <button
                          onClick={() => {
                            const newG = Math.max(0, g - 1);
                            setMemberDailyMeal(selectedDate, member.id, b, l, d, newG);
                          }}
                          className="w-6 h-6 rounded-lg bg-white border border-slate-200 text-slate-600 flex items-center justify-center font-bold text-xs hover:bg-slate-100 active:scale-95"
                        >
                          -
                        </button>
                        <span className="text-xs font-black text-amber-900 min-w-[20px]">{g}</span>
                        <button
                          onClick={() => {
                            const newG = g + 1;
                            setMemberDailyMeal(selectedDate, member.id, b, l, d, newG);
                          }}
                          className="w-6 h-6 rounded-lg bg-amber-600 text-white flex items-center justify-center font-bold text-xs hover:bg-amber-700 active:scale-95"
                        >
                          +
                        </button>
                      </div>
                    </div>

                  </div>

                  {/* Quick Toggle Meal Off / Reset to Normal */}
                  <div className="flex items-center justify-between pt-1 border-t border-slate-100 text-xs">
                    <span className="text-[11px] text-slate-400">
                      {entry?.note ? `নোট: ${entry.note}` : (language === 'bn' ? 'স্ট্যান্ডার্ড মিল' : 'Standard count')}
                    </span>

                    <button
                      onClick={() => {
                        if (isOff) {
                          // Turn back on to default 2.5
                          setMemberDailyMeal(selectedDate, member.id, 0.5, 1, 1, 0);
                        } else {
                          // Turn meal off
                          setMemberDailyMeal(selectedDate, member.id, 0, 0, 0, 0);
                        }
                      }}
                      className={`text-[11px] font-bold px-2 py-1 rounded-lg transition-colors ${
                        isOff
                          ? 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200'
                          : 'bg-slate-100 text-slate-600 hover:bg-rose-50 hover:text-rose-600'
                      }`}
                    >
                      {isOff ? (language === 'bn' ? '✓ মিল চালু করুন' : 'Turn On') : (language === 'bn' ? '❌ মিল অফ' : 'Turn Off')}
                    </button>
                  </div>

                </div>
              );
            })}
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* 3. BAZAR EXPENSE LOG TAB */}
      {/* ========================================================= */}
      {activeSubTab === 'bazar' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                {language === 'bn' ? 'বাজার খরচের তালিকা' : 'Mess Daily Bazar Log'}
              </h2>
              <p className="text-xs text-slate-500">
                {language === 'bn'
                  ? `মোট বাজার খরচ: ${formatMoney(totalMessBazarCost)} • মিল রেট নির্ধারণে এই খরচের যোগফল ব্যবহৃত হয়`
                  : `Total bazar expenses used in live meal rate formula`}
              </p>
            </div>

            <button
              onClick={() => setIsBazarModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{language === 'bn' ? 'নতুন বাজার যোগ' : 'Add Bazar'}</span>
            </button>
          </div>

          {messData.bazarEntries.length === 0 ? (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs">
              <ShoppingBag className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-700">
                {language === 'bn' ? 'কোনো বাজার খরচের রেকর্ড নেই।' : 'No bazar records yet.'}
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {messData.bazarEntries.map(entry => (
                <div
                  key={entry.id}
                  className="bg-white border border-slate-200/80 hover:border-emerald-300 rounded-3xl p-5 shadow-xs transition-all flex flex-col justify-between space-y-3"
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-900 bg-slate-100 px-2 py-0.5 rounded-lg">
                            📅 {entry.date}
                          </span>
                          <span className="text-xs font-bold text-emerald-800 bg-emerald-50 border border-emerald-200/60 px-2 py-0.5 rounded-lg">
                            👤 {entry.shopperName}
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <span className="text-base font-black text-slate-900">
                          {formatMoney(entry.amount)}
                        </span>
                        <button
                          onClick={() => {
                            if (window.confirm(language === 'bn' ? 'বাজার খরচ মুছতে চান?' : 'Delete bazar?')) {
                              deleteBazarEntry(entry.id);
                              showToast(language === 'bn' ? 'বাজার খরচ মুছে ফেলা হয়েছে' : 'Bazar entry deleted');
                            }
                          }}
                          className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="mt-3">
                      <p className="text-xs font-semibold text-slate-800 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                        🛒 {entry.itemsDescription}
                      </p>
                    </div>
                  </div>

                  {entry.note && (
                    <div className="text-[11px] text-slate-400 italic">
                      নোট: {entry.note}
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}

        </div>
      )}

      {/* ========================================================= */}
      {/* 4. DEPOSITS & FUND TAB */}
      {/* ========================================================= */}
      {activeSubTab === 'deposits' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                {language === 'bn' ? 'সদস্যদের টাকা জমার হিসাব' : 'Member Deposits & Fund'}
              </h2>
              <p className="text-xs text-slate-500">
                {language === 'bn'
                  ? `মোট সংগৃহীত মেস ফান্ড: ${formatMoney(totalMessDeposits)} • ম্যানেজারের হাতে ক্যাশ: ${formatMoney(messCashInHand)}`
                  : `Total mess fund collected & cash balance`}
              </p>
            </div>

            <button
              onClick={() => setIsDepositModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{language === 'bn' ? 'টাকা জমা এন্ট্রি' : 'Record Deposit'}</span>
            </button>
          </div>

          {messData.deposits.length === 0 ? (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs">
              <DollarSign className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-700">
                {language === 'bn' ? 'কোনো টাকা জমার রেকর্ড নেই।' : 'No deposit records yet.'}
              </p>
            </div>
          ) : (
            <div className="bg-white border border-slate-200/80 rounded-3xl shadow-xs overflow-hidden">
              <div className="divide-y divide-slate-100">
                {messData.deposits.map(dep => (
                  <div key={dep.id} className="p-4 flex items-center justify-between hover:bg-slate-50/80 transition-colors">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-2xl bg-emerald-50 text-emerald-700 border border-emerald-200/80 flex items-center justify-center font-bold text-xs shrink-0">
                        {dep.paymentMethod === 'bkash' ? 'bK' : dep.paymentMethod === 'nagad' ? 'NG' : '৳'}
                      </div>
                      <div>
                        <div className="font-bold text-sm text-slate-900 flex items-center gap-2">
                          <span>{dep.memberName}</span>
                          <span className="text-[10px] uppercase font-bold px-1.5 py-0.5 rounded bg-slate-100 text-slate-600">
                            {dep.paymentMethod}
                          </span>
                        </div>
                        <div className="text-xs text-slate-400">
                          📅 {dep.date} {dep.note && `• ${dep.note}`}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-3">
                      <span className="text-sm font-black text-emerald-700">
                        +{formatMoney(dep.amount)}
                      </span>
                      <button
                        onClick={() => {
                          if (window.confirm(language === 'bn' ? 'জমা রেকর্ড মুছতে চান?' : 'Delete deposit?')) {
                            deleteDepositEntry(dep.id);
                            showToast(language === 'bn' ? 'জমা রেকর্ড মুছে ফেলা হয়েছে' : 'Deposit deleted');
                          }
                        }}
                        className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

        </div>
      )}

      {/* ========================================================= */}
      {/* 5. FIXED UTILITY COSTS TAB */}
      {/* ========================================================= */}
      {activeSubTab === 'fixed' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                {language === 'bn' ? 'স্থায়ী খরচ ও ইউটিলিটি বিল' : 'Fixed Utility Costs'}
              </h2>
              <p className="text-xs text-slate-500">
                {language === 'bn'
                  ? `মোট স্থায়ী খরচ: ${formatMoney(totalMessFixedCost)} • সকল সক্রিয় সদস্যদের মাঝে সমভাগে ভাগ হবে (জনপ্রতি ${formatMoney(fixedCostPerMember)})`
                  : `Divided equally among active members`}
              </p>
            </div>

            <button
              onClick={() => {
                setEditingFixedCost(null);
                setIsFixedCostModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{language === 'bn' ? 'বিল যোগ করুন' : 'Add Bill'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {messData.fixedCosts.map(cost => (
              <div
                key={cost.id}
                className="bg-white border border-slate-200/80 hover:border-emerald-300 rounded-3xl p-5 shadow-xs transition-all flex flex-col justify-between space-y-3"
              >
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-2xl bg-teal-50 text-teal-700 border border-teal-200/80 flex items-center justify-center shrink-0">
                      <Home className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="font-bold text-slate-900 text-sm">{cost.title}</h4>
                      <span className="text-[10px] text-slate-400 capitalize">{cost.category}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => {
                        setEditingFixedCost(cost);
                        setIsFixedCostModalOpen(true);
                      }}
                      className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => {
                        if (window.confirm(language === 'bn' ? 'বিলটি মুছে ফেলতে চান?' : 'Delete fixed cost?')) {
                          deleteFixedCost(cost.id);
                        }
                      }}
                      className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 flex items-baseline justify-between">
                  <span className="text-xs text-slate-400">
                    {language === 'bn' ? 'জনপ্রতি অংশ:' : 'Per member:'}{' '}
                    <strong>{formatMoney(Math.round(cost.amount / (messData.members.filter(m => m.active).length || 1)))}</strong>
                  </span>
                  <span className="text-base font-black text-slate-900">
                    {formatMoney(cost.amount)}
                  </span>
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* 6. BAZAR ROUTINE / SCHEDULE TAB */}
      {/* ========================================================= */}
      {activeSubTab === 'routine' && (
        <div className="space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <div>
              <h2 className="text-lg font-black text-slate-900 tracking-tight">
                {language === 'bn' ? 'বাজারের রুটিন ও পালা' : 'Bazar Routine & Duty'}
              </h2>
              <p className="text-xs text-slate-500">
                {language === 'bn'
                  ? 'কে কোন দিন বাজার করবে তার সাপ্তাহিক তালিকা'
                  : 'Weekly duty turns for bachelor grocery shopping'}
              </p>
            </div>

            <button
              onClick={() => setIsScheduleModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-colors self-start sm:self-auto"
            >
              <Plus className="w-4 h-4 stroke-[2.5]" />
              <span>{language === 'bn' ? 'রুটিন এন্ট্রি' : 'Add Duty Turn'}</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {messData.bazarSchedule.map(item => (
              <div
                key={item.id}
                className="bg-white border border-slate-200/80 rounded-3xl p-4 shadow-xs hover:border-emerald-300 transition-all flex flex-col justify-between space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-black px-2.5 py-1 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200/80">
                    {item.dayName}
                  </span>
                  <button
                    onClick={() => deleteBazarSchedule(item.id)}
                    className="p-1 text-slate-300 hover:text-rose-600 rounded-md"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div>
                  <h4 className="font-bold text-slate-900 text-sm flex items-center gap-1.5">
                    <CookingPot className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{item.memberName}</span>
                  </h4>
                  {item.notes && (
                    <p className="text-xs text-slate-500 mt-1">{item.notes}</p>
                  )}
                </div>
              </div>
            ))}
          </div>

        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD / EDIT MEMBER */}
      {/* ========================================================= */}
      {isMemberModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsMemberModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {editingMember ? (language === 'bn' ? 'সদস্যের তথ্য এডিট' : 'Edit Member') : (language === 'bn' ? 'নতুন মেস সদস্য যোগ' : 'Add New Member')}
              </h3>
              <button onClick={() => setIsMemberModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const name = (form.elements.namedItem('memberName') as HTMLInputElement).value.trim();
                const roomNo = (form.elements.namedItem('roomNo') as HTMLInputElement).value.trim();
                const phone = (form.elements.namedItem('phone') as HTMLInputElement).value.trim();
                const deposit = parseFloat((form.elements.namedItem('deposit') as HTMLInputElement).value) || 0;
                const extra = parseFloat((form.elements.namedItem('extra') as HTMLInputElement).value) || 0;
                const active = (form.elements.namedItem('active') as HTMLInputElement).checked;

                if (!name) return;

                if (editingMember) {
                  editMessMember({
                    ...editingMember,
                    name,
                    roomNo,
                    phone,
                    initialDeposit: deposit,
                    individualExtraCost: extra,
                    active,
                  });
                  showToast(language === 'bn' ? 'সদস্য আপডেট হয়েছে' : 'Member updated');
                } else {
                  addMessMember({
                    name,
                    roomNo,
                    phone,
                    initialDeposit: deposit,
                    individualExtraCost: extra,
                    active,
                    avatarColor: ['#10b981', '#06b6d4', '#f59e0b', '#8b5cf6', '#ec4899', '#3b82f6'][Math.floor(Math.random() * 6)],
                  });
                  showToast(language === 'bn' ? 'নতুন সদস্য যুক্ত হয়েছে' : 'Member added');
                }

                setIsMemberModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'সদস্যের পুরো নাম' : 'Member Name'} *
                </label>
                <input
                  type="text"
                  name="memberName"
                  required
                  defaultValue={editingMember?.name || ''}
                  placeholder="যেমন: তানভীর আহমেদ"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'রুম / সিট নং' : 'Room / Bed'}
                  </label>
                  <input
                    type="text"
                    name="roomNo"
                    defaultValue={editingMember?.roomNo || ''}
                    placeholder="যেমন: ২০২-বি"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'মোবাইল / বিকাশ' : 'Phone / bKash'}
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    defaultValue={editingMember?.phone || ''}
                    placeholder="01712-XXXXXX"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'শুরুর জমা টাকা' : 'Starting Deposit'} ({currency.symbol})
                  </label>
                  <input
                    type="number"
                    name="deposit"
                    min="0"
                    defaultValue={editingMember?.initialDeposit ?? 4000}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ব্যক্তিগত অতিরিক্ত খরচ' : 'Individual Extra'} ({currency.symbol})
                  </label>
                  <input
                    type="number"
                    name="extra"
                    min="0"
                    defaultValue={editingMember?.individualExtraCost ?? 0}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="activeCheck"
                  name="active"
                  defaultChecked={editingMember?.active ?? true}
                  className="rounded text-emerald-600 focus:ring-emerald-500"
                />
                <label htmlFor="activeCheck" className="text-xs font-semibold text-slate-700">
                  {language === 'bn' ? 'সক্রিয় সদস্য (স্থায়ী বিল প্রযোজ্য)' : 'Active Member'}
                </label>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsMemberModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'সংরক্ষণ' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD BAZAR ENTRY */}
      {/* ========================================================= */}
      {isBazarModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsBazarModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'বাজার খরচের এন্ট্রি' : 'Add Bazar Expense'}
              </h3>
              <button onClick={() => setIsBazarModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const shopperId = (form.elements.namedItem('shopperId') as HTMLSelectElement).value;
                const member = messData.members.find(m => m.id === shopperId);
                const shopperName = member ? member.name : 'Unknown';
                const date = (form.elements.namedItem('bazarDate') as HTMLInputElement).value;
                const amount = parseFloat((form.elements.namedItem('amount') as HTMLInputElement).value);
                const itemsDescription = (form.elements.namedItem('items') as HTMLTextAreaElement).value.trim();
                const note = (form.elements.namedItem('bazarNote') as HTMLInputElement).value.trim();
                const syncTx = (form.elements.namedItem('syncTx') as HTMLInputElement).checked;
                const accountId = (form.elements.namedItem('accountId') as HTMLSelectElement)?.value;

                if (isNaN(amount) || amount <= 0 || !itemsDescription) return;

                addBazarEntry({
                  date,
                  shopperMemberId: shopperId,
                  shopperName,
                  amount,
                  itemsDescription,
                  paidFromFund: true,
                  note,
                }, syncTx, accountId);

                showToast(language === 'bn' ? `${formatMoney(amount)} বাজার খরচ যোগ হয়েছে` : 'Bazar expense added');
                setIsBazarModalOpen(false);
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'কে বাজার করেছে?' : 'Shopper'} *
                  </label>
                  <select
                    name="shopperId"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                    defaultValue={messData.members[0]?.id}
                  >
                    {messData.members.map(m => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'তারিখ' : 'Date'}
                  </label>
                  <input
                    type="date"
                    name="bazarDate"
                    defaultValue={selectedDate}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'বাজারের মোট খরচ' : 'Total Amount'} ({currency.symbol}) *
                </label>
                <input
                  type="number"
                  name="amount"
                  required
                  min="1"
                  step="any"
                  placeholder="যেমন: ১৫৫০"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'বাজারের দ্রব্যাদি / ফর্দ' : 'Items Description'} *
                </label>
                <textarea
                  name="items"
                  required
                  rows={2}
                  placeholder={language === 'bn' ? 'যেমন: চাল ১০ কেজি, রুই মাছ, আলু, তেল, কাঁচামরিচ...' : 'e.g. Rice 10kg, fish, potato, cooking oil...'}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'নোট বা দোকান' : 'Store / Note'}
                </label>
                <input
                  type="text"
                  name="bazarNote"
                  placeholder="যেমন: কারওয়ান বাজার থেকে কেনা"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              {/* Sync with personal Khoroch expense wallet */}
              <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="syncBazarTx"
                    name="syncTx"
                    defaultChecked={false}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <label htmlFor="syncBazarTx" className="text-xs font-bold text-emerald-900 cursor-pointer">
                    {language === 'bn' ? 'আমার ব্যক্তিগত ওয়ালেট খরচেও যুক্ত করুন' : 'Also log to my personal Khoroch expenses'}
                  </label>
                </div>
                <div className="pl-5">
                  <select
                    name="accountId"
                    className="w-full px-2.5 py-1.5 bg-white border border-emerald-200 rounded-lg text-xs font-semibold text-emerald-900"
                  >
                    {accounts.map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {acc.name} ({formatMoney(acc.balance)})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsBazarModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'যোগ করুন' : 'Add Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD MEMBER DEPOSIT */}
      {/* ========================================================= */}
      {isDepositModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsDepositModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'মেস ফান্ডে টাকা জমা' : 'Record Member Deposit'}
              </h3>
              <button onClick={() => setIsDepositModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const memberId = (form.elements.namedItem('memberId') as HTMLSelectElement).value;
                const member = messData.members.find(m => m.id === memberId);
                const memberName = member ? member.name : 'Unknown';
                const date = (form.elements.namedItem('depDate') as HTMLInputElement).value;
                const amount = parseFloat((form.elements.namedItem('amount') as HTMLInputElement).value);
                const paymentMethod = (form.elements.namedItem('method') as HTMLSelectElement).value as any;
                const note = (form.elements.namedItem('depNote') as HTMLInputElement).value.trim();
                const syncTx = (form.elements.namedItem('syncDepTx') as HTMLInputElement).checked;
                const accountId = (form.elements.namedItem('depAccountId') as HTMLSelectElement)?.value;

                if (isNaN(amount) || amount <= 0) return;

                addDepositEntry({
                  date,
                  memberId,
                  memberName,
                  amount,
                  paymentMethod,
                  note,
                }, syncTx, accountId);

                showToast(language === 'bn' ? `${memberName}-এর ${formatMoney(amount)} জমা হয়েছে` : 'Deposit recorded');
                setIsDepositModalOpen(false);
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'সদস্য' : 'Member'} *
                  </label>
                  <select
                    name="memberId"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                    defaultValue={messData.members[0]?.id}
                  >
                    {messData.members.map(m => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'তারিখ' : 'Date'}
                  </label>
                  <input
                    type="date"
                    name="depDate"
                    defaultValue={new Date().toISOString().split('T')[0]}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'জমার পরিমাণ' : 'Amount'} ({currency.symbol}) *
                  </label>
                  <input
                    type="number"
                    name="amount"
                    required
                    min="1"
                    step="any"
                    placeholder="যেমন: ৪০০০"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                    autoFocus
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'মাধ্যম' : 'Method'}
                  </label>
                  <select
                    name="method"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                    defaultValue="bkash"
                  >
                    <option value="bkash">bKash (বিকাশ)</option>
                    <option value="nagad">Nagad (নগদ)</option>
                    <option value="cash">Cash (নগদ টাকা)</option>
                    <option value="bank">Bank Transfer (ব্যাংক)</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'নোট বা রেফারেন্স' : 'Note / Reference'}
                </label>
                <input
                  type="text"
                  name="depNote"
                  placeholder="যেমন: অক্টোবর মাসের মেস জমা"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              {/* Sync with personal Khoroch expense wallet */}
              <div className="bg-emerald-50/70 border border-emerald-200/80 rounded-2xl p-3 space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="syncDepositTx"
                    name="syncDepTx"
                    defaultChecked={false}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <label htmlFor="syncDepositTx" className="text-xs font-bold text-emerald-900 cursor-pointer">
                    {language === 'bn' ? 'আমার ওয়ালেট থেকেও টাকা কর্তন করুন' : 'Deduct from my Khoroch wallet balance'}
                  </label>
                </div>
                <div className="pl-5">
                  <select
                    name="depAccountId"
                    className="w-full px-2.5 py-1.5 bg-white border border-emerald-200 rounded-lg text-xs font-semibold text-emerald-900"
                  >
                    {accounts.map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {acc.name} ({formatMoney(acc.balance)})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsDepositModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'জমা সম্পন্ন' : 'Save Deposit'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD / EDIT FIXED COST */}
      {/* ========================================================= */}
      {isFixedCostModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsFixedCostModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {editingFixedCost ? (language === 'bn' ? 'স্থায়ী বিল এডিট' : 'Edit Bill') : (language === 'bn' ? 'নতুন স্থায়ী বিল যোগ' : 'Add Fixed Bill')}
              </h3>
              <button onClick={() => setIsFixedCostModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const title = (form.elements.namedItem('billTitle') as HTMLInputElement).value.trim();
                const amount = parseFloat((form.elements.namedItem('billAmount') as HTMLInputElement).value);
                const category = (form.elements.namedItem('category') as HTMLSelectElement).value as any;
                const note = (form.elements.namedItem('billNote') as HTMLInputElement).value.trim();

                if (!title || isNaN(amount) || amount <= 0) return;

                if (editingFixedCost) {
                  editFixedCost({
                    ...editingFixedCost,
                    title,
                    amount,
                    category,
                    note,
                  });
                  showToast(language === 'bn' ? 'বিল আপডেট হয়েছে' : 'Bill updated');
                } else {
                  addFixedCost({
                    title,
                    amount,
                    category,
                    note,
                  });
                  showToast(language === 'bn' ? 'নতুন বিল যোগ হয়েছে' : 'Bill added');
                }

                setIsFixedCostModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'বিলের নাম' : 'Bill Title'} *
                </label>
                <input
                  type="text"
                  name="billTitle"
                  required
                  defaultValue={editingFixedCost?.title || ''}
                  placeholder="যেমন: খালা/বুয়ার বেতন বা গ্যাস বিল"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'বিলের অঙ্ক' : 'Amount'} ({currency.symbol}) *
                  </label>
                  <input
                    type="number"
                    name="billAmount"
                    required
                    min="1"
                    defaultValue={editingFixedCost?.amount || ''}
                    placeholder="0"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    name="category"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                    defaultValue={editingFixedCost?.category || 'cook'}
                  >
                    <option value="rent">{language === 'bn' ? 'বাসা ভাড়া (Rent)' : 'Rent'}</option>
                    <option value="cook">{language === 'bn' ? 'খালা/বুয়া (Cook)' : 'Cook'}</option>
                    <option value="electricity">{language === 'bn' ? 'বিদ্যুৎ (Electricity)' : 'Electricity'}</option>
                    <option value="gas">{language === 'bn' ? 'গ্যাস (Gas)' : 'Gas'}</option>
                    <option value="wifi">{language === 'bn' ? 'ওয়াইফাই (WiFi)' : 'WiFi'}</option>
                    <option value="waste">{language === 'bn' ? 'পানি ও ময়লা (Waste)' : 'Waste'}</option>
                    <option value="other">{language === 'bn' ? 'অন্যান্য (Other)' : 'Other'}</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'নোট' : 'Notes'}
                </label>
                <input
                  type="text"
                  name="billNote"
                  defaultValue={editingFixedCost?.note || ''}
                  placeholder="যেমন: প্রতি মাসের ৫ তারিখ প্রদেয়"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsFixedCostModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'সংরক্ষণ' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD BAZAR SCHEDULE */}
      {/* ========================================================= */}
      {isScheduleModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsScheduleModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'বাজারের নতুন রুটিন' : 'Add Duty Turn'}
              </h3>
              <button onClick={() => setIsScheduleModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const dayName = (form.elements.namedItem('day') as HTMLInputElement).value.trim();
                const memberId = (form.elements.namedItem('schMemberId') as HTMLSelectElement).value;
                const member = messData.members.find(m => m.id === memberId);
                const memberName = member ? member.name : 'Unknown';
                const notes = (form.elements.namedItem('schNotes') as HTMLInputElement).value.trim();

                if (!dayName) return;

                addBazarSchedule({
                  dayName,
                  memberId,
                  memberName,
                  notes,
                });

                showToast(language === 'bn' ? 'রুটিন আপডেট হয়েছে' : 'Schedule added');
                setIsScheduleModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'বারের নাম / দিন' : 'Day'} *
                </label>
                <input
                  type="text"
                  name="day"
                  required
                  placeholder="যেমন: শনিবার বা শুক্রবার"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'কে বাজার করবে?' : 'Assigned Member'} *
                </label>
                <select
                  name="schMemberId"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                >
                  {messData.members.map(m => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'কাজের বিবরণ বা স্পেশাল নোট' : 'Duty note'}
                </label>
                <input
                  type="text"
                  name="schNotes"
                  placeholder="যেমন: সকালের তাজা মাছ ও সবজি"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsScheduleModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'যোগ করুন' : 'Add Turn'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: SHARE TO WHATSAPP / MESSENGER */}
      {/* ========================================================= */}
      {isShareModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsShareModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                  <Share2 className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-800">
                    {language === 'bn' ? 'মেসের মাসিক হিসাব শেয়ার' : 'Share Mess Report'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {language === 'bn' ? 'মেস গ্রুপে এক ক্লিকে পাঠিয়ে দিন' : 'Copy and send to WhatsApp/Messenger group'}
                  </p>
                </div>
              </div>

              <button onClick={() => setIsShareModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 font-mono text-xs text-slate-800 whitespace-pre-wrap leading-relaxed max-h-64 overflow-y-auto select-all">
              {shareableText}
            </div>

            <div className="flex flex-col sm:flex-row items-center gap-2 pt-2">
              <button
                onClick={handleCopyShare}
                className="w-full sm:flex-1 py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs active:scale-95 transition-all"
              >
                {copySuccess ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                <span>{copySuccess ? (language === 'bn' ? 'কপি সম্পন্ন!' : 'Copied!') : (language === 'bn' ? 'টেক্সট কপি করুন' : 'Copy Text')}</span>
              </button>

              <button
                onClick={() => {
                  const url = `https://wa.me/?text=${encodeURIComponent(shareableText)}`;
                  window.open(url, '_blank');
                }}
                className="w-full sm:w-auto py-2.5 px-4 bg-[#25D366] hover:bg-[#20ba59] text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 shadow-xs transition-all"
              >
                <span>WhatsApp-এ পাঠান</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: EDIT MESS CONFIG & ACTIVE MONTH */}
      {/* ========================================================= */}
      {isConfigModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsConfigModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'মেস সেটিংস ও মাস পরিবর্তন' : 'Mess Profile & Month'}
              </h3>
              <button onClick={() => setIsConfigModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const name = (form.elements.namedItem('messName') as HTMLInputElement).value.trim();
                const managerName = (form.elements.namedItem('manager') as HTMLInputElement).value.trim();
                const managerPhone = (form.elements.namedItem('managerPhone') as HTMLInputElement).value.trim();
                const activeMonth = (form.elements.namedItem('activeMonth') as HTMLInputElement).value.trim();

                if (!name) return;

                updateMessConfig({
                  name,
                  managerName,
                  managerPhone,
                  activeMonth,
                });

                showToast(language === 'bn' ? 'মেসের তথ্য আপডেট হয়েছে' : 'Config saved');
                setIsConfigModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'মেসের নাম' : 'Mess Name'} *
                </label>
                <input
                  type="text"
                  name="messName"
                  required
                  defaultValue={messData.config?.name || 'গ্রিন ভিউ ব্যাচেলর মেস'}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ম্যানেজারের নাম' : 'Manager Name'}
                  </label>
                  <input
                    type="text"
                    name="manager"
                    defaultValue={messData.config?.managerName || ''}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'হিসাবের মাস (YYYY-MM)' : 'Active Month'}
                  </label>
                  <input
                    type="month"
                    name="activeMonth"
                    defaultValue={messData.config?.activeMonth || new Date().toISOString().slice(0, 7)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'ম্যানেজারের মোবাইল' : 'Manager Phone'}
                </label>
                <input
                  type="tel"
                  name="managerPhone"
                  defaultValue={messData.config?.managerPhone || ''}
                  placeholder="01712-XXXXXX"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              {/* Start new clean month button */}
              <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => {
                    const nextMonth = prompt(language === 'bn' ? 'নতুন মাসের কোড লিখুন (যেমন: 2026-11):' : 'Enter new month (YYYY-MM):', new Date().toISOString().slice(0, 7));
                    if (nextMonth && window.confirm(language === 'bn' ? `নতুন মাস ${nextMonth}-এর ফ্রেশ মিল ও বাজার শিট শুরু করতে চান? বর্তমান সদস্যরা বহাল থাকবে।` : 'Start fresh month?')) {
                      resetMessMonth(nextMonth);
                      showToast(language === 'bn' ? `নতুন মাস ${nextMonth} শুরু হয়েছে` : 'New month started');
                      setIsConfigModalOpen(false);
                    }
                  }}
                  className="text-xs text-rose-600 font-bold hover:underline"
                >
                  {language === 'bn' ? '🔄 নতুন মাসের হিসাব শুরু করুন' : 'Start Fresh Month'}
                </button>

                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setIsConfigModalOpen(false)}
                    className="px-3.5 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                  >
                    {language === 'bn' ? 'বাতিল' : 'Cancel'}
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                  >
                    {language === 'bn' ? 'সংরক্ষণ' : 'Save'}
                  </button>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
