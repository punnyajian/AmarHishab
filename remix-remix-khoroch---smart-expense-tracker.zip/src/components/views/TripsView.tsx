import React, { useState, useMemo, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import {
  TripItem,
  TripExpense,
  TripMember,
  TripExpenseCategory,
  TripType,
  TripPackingItem,
  TripItineraryDay,
} from '../../types';
import {
  Compass,
  MapPin,
  Calendar,
  Plus,
  Trash2,
  Edit2,
  CheckCircle2,
  Circle,
  DollarSign,
  Luggage,
  Users,
  ReceiptText,
  Printer,
  Clock,
  Sparkles,
  Car,
  Hotel,
  Utensils,
  Ticket,
  ShoppingBag,
  Package,
  AlertTriangle,
  X,
  ChevronRight,
  PartyPopper,
  Trees,
  Waves,
  Heart,
  Briefcase,
  Layers,
  ArrowRightLeft,
  CheckSquare,
  Square,
  TrendingUp,
  CreditCard,
  FileSpreadsheet,
} from 'lucide-react';
import confetti from 'canvas-confetti';

type TripTab = 'overview' | 'expenses' | 'members' | 'packing' | 'itinerary' | 'settlement';

export const TripsView: React.FC = () => {
  const {
    trips,
    activeTrip,
    addTrip,
    editTrip,
    deleteTrip,
    setActiveTripStatus,
    addTripExpense,
    deleteTripExpense,
    addTripMember,
    deleteTripMember,
    recordTripMemberDeposit,
    toggleTripPackingItem,
    addTripPackingItem,
    deleteTripPackingItem,
    addTripItineraryDay,
    deleteTripItineraryDay,
    accounts,
    formatMoney,
    language,
    currency,
  } = useExpense();

  // Active selected trip for detailed inspection
  const [selectedTripId, setSelectedTripId] = useState<string>(() => {
    return activeTrip?.id || trips[0]?.id || '';
  });

  const selectedTrip = useMemo(() => {
    return trips.find(t => t.id === selectedTripId) || activeTrip || trips[0] || null;
  }, [trips, selectedTripId, activeTrip]);

  const [tripSubTab, setTripSubTab] = useState<TripTab>('overview');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals state
  const [isAddTripModalOpen, setIsAddTripModalOpen] = useState(false);
  const [editingTrip, setEditingTrip] = useState<TripItem | null>(null);
  const [isAddExpenseModalOpen, setIsAddExpenseModalOpen] = useState(false);
  const [isAddMemberModalOpen, setIsAddMemberModalOpen] = useState(false);
  const [isDepositModalOpen, setIsDepositModalOpen] = useState(false);
  const [selectedMemberForDeposit, setSelectedMemberForDeposit] = useState<TripMember | null>(null);
  const [isAddPackingModalOpen, setIsAddPackingModalOpen] = useState(false);
  const [isAddItineraryModalOpen, setIsAddItineraryModalOpen] = useState(false);

  const isAnyTripModalOpen =
    isAddTripModalOpen ||
    isAddExpenseModalOpen ||
    isAddMemberModalOpen ||
    isDepositModalOpen ||
    isAddPackingModalOpen ||
    isAddItineraryModalOpen;

  useLockBodyScroll(isAnyTripModalOpen);

  useEffect(() => {
    if (!isAnyTripModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setIsAddTripModalOpen(false);
        setIsAddExpenseModalOpen(false);
        setIsAddMemberModalOpen(false);
        setIsDepositModalOpen(false);
        setIsAddPackingModalOpen(false);
        setIsAddItineraryModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAnyTripModalOpen]);

  // Filter for packing checklist
  const [packingCategoryFilter, setPackingCategoryFilter] = useState<string>('all');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Calculations for selected trip
  const tripStats = useMemo(() => {
    if (!selectedTrip) {
      return {
        totalSpent: 0,
        totalBudget: 0,
        remainingBudget: 0,
        budgetUsedPercent: 0,
        totalPoolDeposits: 0,
        poolCashBalance: 0,
        costPerPerson: 0,
        categoryBreakdown: [],
        memberBalances: [],
      };
    }

    const totalSpent = selectedTrip.expenses.reduce((sum, e) => sum + e.amount, 0);
    const totalBudget = selectedTrip.totalBudget || 0;
    const remainingBudget = totalBudget - totalSpent;
    const budgetUsedPercent = totalBudget > 0 ? Math.min(100, Math.round((totalSpent / totalBudget) * 100)) : 0;

    const totalPoolDeposits = selectedTrip.members.reduce((sum, m) => sum + (m.depositAmount || 0), 0);
    
    // Expenses paid directly from pool fund
    const fundSpent = selectedTrip.expenses
      .filter(e => e.paidByMemberId === 'fund')
      .reduce((sum, e) => sum + e.amount, 0);
    
    const poolCashBalance = totalPoolDeposits - fundSpent;

    const memberCount = Math.max(1, selectedTrip.members.length);
    const costPerPerson = Math.round(totalSpent / memberCount);

    // Category breakdown
    const catMap: { [key: string]: number } = {};
    selectedTrip.expenses.forEach(e => {
      catMap[e.category] = (catMap[e.category] || 0) + e.amount;
    });

    const categoryBreakdown = Object.entries(catMap).map(([category, amount]) => ({
      category: category as TripExpenseCategory,
      amount,
      percent: totalSpent > 0 ? Math.round((amount / totalSpent) * 100) : 0,
    })).sort((a, b) => b.amount - a.amount);

    // Individual member balances (Fair share vs deposits + out-of-pocket expenses)
    const memberBalances = selectedTrip.members.map(member => {
      const personalExpensesPaid = selectedTrip.expenses
        .filter(e => e.paidByMemberId === member.id)
        .reduce((sum, e) => sum + e.amount, 0);

      const totalContributed = member.depositAmount + personalExpensesPaid;
      const fairShare = costPerPerson;
      const balance = totalContributed - fairShare;

      return {
        member,
        depositAmount: member.depositAmount,
        personalExpensesPaid,
        totalContributed,
        fairShare,
        balance, // positive = will get refund, negative = owes money
        status: balance > 0 ? 'refund' : balance < 0 ? 'due' : 'settled',
      };
    });

    return {
      totalSpent,
      totalBudget,
      remainingBudget,
      budgetUsedPercent,
      totalPoolDeposits,
      poolCashBalance,
      costPerPerson,
      categoryBreakdown,
      memberBalances,
    };
  }, [selectedTrip]);

  const getCategoryMeta = (cat: TripExpenseCategory) => {
    switch (cat) {
      case 'transport':
        return { label: language === 'bn' ? 'যাতায়াত ও ভাড়া' : 'Transport', icon: Car, color: 'text-sky-600 bg-sky-50 border-sky-200' };
      case 'hotel':
        return { label: language === 'bn' ? 'হোটেল ও রিসোর্ট' : 'Hotel / Stay', icon: Hotel, color: 'text-indigo-600 bg-indigo-50 border-indigo-200' };
      case 'food':
        return { label: language === 'bn' ? 'খাবার ও রেস্তোরাঁ' : 'Food & Dining', icon: Utensils, color: 'text-amber-600 bg-amber-50 border-amber-200' };
      case 'activity':
        return { label: language === 'bn' ? 'টিকিট ও সাইটসিয়িং' : 'Sightseeing & Entry', icon: Ticket, color: 'text-emerald-600 bg-emerald-50 border-emerald-200' };
      case 'shopping':
        return { label: language === 'bn' ? 'কেনাকাটা ও উপহার' : 'Shopping', icon: ShoppingBag, color: 'text-pink-600 bg-pink-50 border-pink-200' };
      case 'logistics':
        return { label: language === 'bn' ? 'ডেকোরেশন ও সাউন্ড' : 'Logistics / Decor', icon: Package, color: 'text-purple-600 bg-purple-50 border-purple-200' };
      case 'emergency':
        return { label: language === 'bn' ? 'জরুরি ও চিকিৎসা' : 'Emergency & First Aid', icon: AlertTriangle, color: 'text-rose-600 bg-rose-50 border-rose-200' };
      default:
        return { label: language === 'bn' ? 'অন্যান্য খরচ' : 'Miscellaneous', icon: DollarSign, color: 'text-slate-600 bg-slate-50 border-slate-200' };
    }
  };

  const getTypeMeta = (type: TripType) => {
    switch (type) {
      case 'tour':
        return { label: language === 'bn' ? 'ভ্রমণ ও ট্যুর' : 'Travel Tour', icon: Trees, color: 'bg-emerald-100 text-emerald-800' };
      case 'picnic':
        return { label: language === 'bn' ? 'পিকনিক ও ডে-আউট' : 'Picnic', icon: Waves, color: 'bg-teal-100 text-teal-800' };
      case 'wedding':
        return { label: language === 'bn' ? 'বিয়ে ও রিসেপশন' : 'Wedding Event', icon: Heart, color: 'bg-rose-100 text-rose-800' };
      case 'party':
        return { label: language === 'bn' ? 'পার্টি ও অনুষ্ঠান' : 'Party / Celebration', icon: PartyPopper, color: 'bg-amber-100 text-amber-800' };
      case 'official':
        return { label: language === 'bn' ? 'অফিসিয়াল ট্যুর' : 'Official / Business', icon: Briefcase, color: 'bg-blue-100 text-blue-800' };
      default:
        return { label: language === 'bn' ? 'ইভেন্ট' : 'Event', icon: Compass, color: 'bg-slate-100 text-slate-800' };
    }
  };

  // Filtered packing list
  const filteredPackingList = useMemo(() => {
    if (!selectedTrip) return [];
    if (packingCategoryFilter === 'all') return selectedTrip.packingList;
    return selectedTrip.packingList.filter(item => item.category === packingCategoryFilter);
  }, [selectedTrip, packingCategoryFilter]);

  const packedCount = selectedTrip?.packingList.filter(p => p.isPacked).length || 0;
  const totalPackingCount = selectedTrip?.packingList.length || 0;

  return (
    <div className="space-y-6 pb-20 animate-in fade-in duration-200">
      
      {/* Toast banner */}
      {toastMessage && (
        <div className="bg-emerald-600 text-white px-4 py-3 rounded-2xl shadow-lg flex items-center justify-between text-xs sm:text-sm font-semibold animate-in slide-in-from-top duration-200 no-print">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-200" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-white/80 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Hero Header & Active Trip Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-teal-950 to-emerald-950 rounded-3xl p-5 sm:p-7 text-white shadow-xl relative overflow-hidden">
        {/* Soft background light */}
        <div className="absolute -top-16 -right-16 w-56 h-56 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-56 h-56 bg-teal-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-semibold text-emerald-200 border border-white/10">
              <Compass className="w-3.5 h-3.5 text-emerald-300" />
              <span>{language === 'bn' ? 'ট্যুর, ভ্রমণ ও ইভেন্ট বাজেট ট্র্যাকার' : 'Trip & Event Budget Mode'}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>{trips.length} {language === 'bn' ? 'টি ট্রিপ' : 'Trips'}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
              <span>{selectedTrip ? (selectedTrip.titleBn || selectedTrip.title) : (language === 'bn' ? 'কোনো ট্রিপ নেই' : 'No Trip Selected')}</span>
            </h1>

            {selectedTrip && (
              <p className="text-xs sm:text-sm text-slate-300 flex flex-wrap items-center gap-x-3 gap-y-1">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-emerald-400" />
                  <strong>{selectedTrip.destination}</strong>
                </span>
                <span>• 📅 {selectedTrip.startDate} - {selectedTrip.endDate}</span>
                <span>• {selectedTrip.members.length} {language === 'bn' ? 'জন সদস্য' : 'Members'}</span>
              </p>
            )}
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-wrap items-center gap-2 no-print">
            {selectedTrip && (
              <button
                onClick={() => setIsAddExpenseModalOpen(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-bold text-xs active:scale-95 shadow-lg shadow-emerald-950/30 transition-all cursor-pointer"
              >
                <Plus className="w-4 h-4 stroke-[3]" />
                <span>{language === 'bn' ? 'ট্যুর খরচ যোগ' : 'Add Expense'}</span>
              </button>
            )}

            <button
              onClick={() => {
                setEditingTrip(null);
                setIsAddTripModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-3.5 py-2.5 rounded-xl bg-white/10 hover:bg-white/20 text-white border border-white/15 font-bold text-xs active:scale-95 transition-all cursor-pointer"
            >
              <Compass className="w-4 h-4 text-emerald-300" />
              <span>{language === 'bn' ? 'নতুন ট্রিপ খুলুন' : 'New Trip'}</span>
            </button>
          </div>
        </div>

        {/* Selected Trip Key Metric Cards */}
        {selectedTrip && (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10 text-white">
            
            {/* Total Budget vs Spent */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
                {language === 'bn' ? 'মোট বাজেট' : 'Trip Budget'}
              </span>
              <div className="mt-1">
                <div className="text-xl sm:text-2xl font-black text-white">
                  {formatMoney(selectedTrip.totalBudget)}
                </div>
                <p className="text-[10px] text-emerald-300 mt-0.5 truncate">
                  {language === 'bn' ? `ব্যয়: ${formatMoney(tripStats.totalSpent)} (${tripStats.budgetUsedPercent}%)` : `Spent: ${formatMoney(tripStats.totalSpent)} (${tripStats.budgetUsedPercent}%)`}
                </p>
              </div>
            </div>

            {/* Remaining Budget */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-teal-400" />
                {language === 'bn' ? 'অবশিষ্ট বাজেট' : 'Remaining'}
              </span>
              <div className="mt-1">
                <div className={`text-xl sm:text-2xl font-black ${tripStats.remainingBudget >= 0 ? 'text-teal-300' : 'text-rose-400'}`}>
                  {formatMoney(tripStats.remainingBudget)}
                </div>
                <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                  {tripStats.remainingBudget >= 0 ? (language === 'bn' ? 'বাজেট নিয়ন্ত্রণে আছে' : 'On Track') : (language === 'bn' ? 'বাজেট পার হয়ে গেছে!' : 'Over Budget!')}
                </p>
              </div>
            </div>

            {/* Per Person Fair Share */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                <Users className="w-3.5 h-3.5 text-amber-400" />
                {language === 'bn' ? 'জনপ্রতি খরচ' : 'Per Person Share'}
              </span>
              <div className="mt-1">
                <div className="text-xl sm:text-2xl font-black text-amber-300">
                  {formatMoney(tripStats.costPerPerson)}
                </div>
                <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                  {selectedTrip.members.length} {language === 'bn' ? 'জনের মধ্যে সমান ভাগ' : 'equal split'}
                </p>
              </div>
            </div>

            {/* Common Pool Fund Cash Balance */}
            <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
              <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
                <CreditCard className="w-3.5 h-3.5 text-sky-400" />
                {language === 'bn' ? 'কমন ফান্ড ক্যাশ' : 'Pool Cash Fund'}
              </span>
              <div className="mt-1">
                <div className="text-xl sm:text-2xl font-black text-sky-300">
                  {formatMoney(tripStats.poolCashBalance)}
                </div>
                <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                  {language === 'bn' ? `মোট জমা: ${formatMoney(tripStats.totalPoolDeposits)}` : `Deposited: ${formatMoney(tripStats.totalPoolDeposits)}`}
                </p>
              </div>
            </div>

          </div>
        )}
      </div>

      {/* Trips Switcher & Selector Chips */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-3 sm:p-4 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
            {language === 'bn' ? 'আমার সংরক্ষিত ট্যুর ও ইভেন্ট' : 'My Trips & Events'}
          </span>
          <button
            onClick={() => {
              setEditingTrip(null);
              setIsAddTripModalOpen(true);
            }}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{language === 'bn' ? 'নতুন ট্রিপ' : 'New Trip'}</span>
          </button>
        </div>

        {/* Horizontal Trip Cards Selector */}
        <div className="flex items-center gap-3 overflow-x-auto pb-1 no-scrollbar">
          {trips.map(trip => {
            const isSelected = selectedTrip?.id === trip.id;
            const typeMeta = getTypeMeta(trip.type);
            const totalExp = trip.expenses.reduce((s, e) => s + e.amount, 0);
            const progress = trip.totalBudget > 0 ? Math.min(100, Math.round((totalExp / trip.totalBudget) * 100)) : 0;

            return (
              <button
                key={trip.id}
                onClick={() => setSelectedTripId(trip.id)}
                className={`flex-shrink-0 text-left p-3.5 rounded-2xl border transition-all min-w-[240px] sm:min-w-[270px] cursor-pointer ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/60 ring-2 ring-emerald-500/20 shadow-xs'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:bg-slate-50/50'
                }`}
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md ${typeMeta.color}`}>
                    {typeMeta.label}
                  </span>

                  <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                    trip.status === 'active'
                      ? 'bg-emerald-600 text-white animate-pulse'
                      : trip.status === 'completed'
                      ? 'bg-slate-200 text-slate-700'
                      : 'bg-amber-100 text-amber-800'
                  }`}>
                    {trip.status === 'active' 
                      ? (language === 'bn' ? 'সক্রিয়' : 'Active') 
                      : trip.status === 'completed' 
                      ? (language === 'bn' ? 'সম্পন্ন' : 'Completed') 
                      : (language === 'bn' ? 'আসন্ন' : 'Upcoming')}
                  </span>
                </div>

                <h4 className="font-extrabold text-xs sm:text-sm text-slate-900 truncate">
                  {trip.titleBn || trip.title}
                </h4>

                <p className="text-[11px] text-slate-500 truncate mt-0.5 flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-slate-400" />
                  <span>{trip.destination}</span>
                </p>

                {/* Mini Progress */}
                <div className="mt-2 pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                  <span className="font-bold text-slate-800">{formatMoney(totalExp)}</span>
                  <span className="text-slate-400">/ {formatMoney(trip.totalBudget)} ({progress}%)</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Trip Details Workspace */}
      {selectedTrip && (
        <div className="space-y-5">
          
          {/* Sub-tabs within Selected Trip */}
          <div className="flex items-center gap-1 overflow-x-auto pb-1 no-scrollbar border-b border-slate-200/80 no-print">
            {[
              { id: 'overview', label: language === 'bn' ? 'সারসংক্ষেপ ও অ্যানালিটিক্স' : 'Overview & Stats', icon: TrendingUp },
              { id: 'expenses', label: language === 'bn' ? `খরচের খাতা (${selectedTrip.expenses.length})` : `Expenses (${selectedTrip.expenses.length})`, icon: ReceiptText },
              { id: 'members', label: language === 'bn' ? `সদস্য ও পাওনা-দেনা (${selectedTrip.members.length})` : `Members & Balances (${selectedTrip.members.length})`, icon: Users },
              { id: 'packing', label: language === 'bn' ? `প্যাকিং লিস্ট (${packedCount}/${totalPackingCount})` : `Packing List (${packedCount}/${totalPackingCount})`, icon: Luggage },
              { id: 'itinerary', label: language === 'bn' ? `ভ্রমণ রুটিন (${selectedTrip.itinerary.length} দিন)` : `Itinerary (${selectedTrip.itinerary.length} Days)`, icon: Calendar },
              { id: 'settlement', label: language === 'bn' ? 'হিসাব নিষ্পত্তি ও ইনভয়েস' : 'Settlement Invoice', icon: FileSpreadsheet },
            ].map(tab => {
              const Icon = tab.icon;
              const isActive = tripSubTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setTripSubTab(tab.id as TripTab)}
                  className={`flex items-center gap-2 px-3.5 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-150 cursor-pointer ${
                    isActive
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200/60'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
                  <span>{tab.label}</span>
                </button>
              );
            })}
          </div>

          {/* 1. OVERVIEW TAB */}
          {tripSubTab === 'overview' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-150">
              
              {/* Category Breakdown & Progress */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 lg:col-span-2">
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <div>
                    <h3 className="text-base font-bold text-slate-800">
                      {language === 'bn' ? 'খাতভিত্তিক ট্যুর খরচের বণ্টন' : 'Expense Breakdown by Category'}
                    </h3>
                    <p className="text-xs text-slate-400">
                      {language === 'bn' ? 'যাতায়াত, হোটেল, খাবার ও অন্যান্য খরচ' : 'Transport, Hotel, Food & Sightseeing'}
                    </p>
                  </div>
                  <button
                    onClick={() => setIsAddExpenseModalOpen(true)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-50 text-emerald-800 hover:bg-emerald-100 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'খরচ লিখুন' : 'Add Cost'}</span>
                  </button>
                </div>

                {/* Overall Budget Progress Bar */}
                <div className="space-y-1.5">
                  <div className="flex justify-between text-xs font-semibold text-slate-600">
                    <span>{language === 'bn' ? 'বাজেট ব্যবহার:' : 'Budget Used:'}</span>
                    <strong className={tripStats.budgetUsedPercent > 90 ? 'text-rose-600' : 'text-emerald-700'}>
                      {formatMoney(tripStats.totalSpent)} / {formatMoney(selectedTrip.totalBudget)} ({tripStats.budgetUsedPercent}%)
                    </strong>
                  </div>
                  <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
                    <div
                      className={`h-full transition-all duration-500 rounded-full ${
                        tripStats.budgetUsedPercent > 100
                          ? 'bg-rose-500'
                          : tripStats.budgetUsedPercent > 80
                          ? 'bg-amber-500'
                          : 'bg-emerald-600'
                      }`}
                      style={{ width: `${Math.min(100, tripStats.budgetUsedPercent)}%` }}
                    />
                  </div>
                </div>

                {/* Category Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
                  {tripStats.categoryBreakdown.length === 0 ? (
                    <div className="col-span-2 py-8 text-center text-xs text-slate-400">
                      {language === 'bn' ? 'এখনও কোনো খরচ যোগ করা হয়নি।' : 'No expenses recorded yet.'}
                    </div>
                  ) : (
                    tripStats.categoryBreakdown.map(item => {
                      const meta = getCategoryMeta(item.category);
                      const Icon = meta.icon;
                      return (
                        <div key={item.category} className="p-3 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                          <div className="flex items-center gap-2.5">
                            <div className={`w-8 h-8 rounded-xl flex items-center justify-center border ${meta.color}`}>
                              <Icon className="w-4 h-4" />
                            </div>
                            <div>
                              <span className="text-xs font-bold text-slate-800 block">{meta.label}</span>
                              <span className="text-[10px] text-slate-400">{item.percent}% {language === 'bn' ? 'খরচ' : 'of total'}</span>
                            </div>
                          </div>
                          <span className="text-xs sm:text-sm font-extrabold text-slate-900">
                            {formatMoney(item.amount)}
                          </span>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>

              {/* Trip Control & Actions Card */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                    <h3 className="text-base font-bold text-slate-800">
                      {language === 'bn' ? 'ট্রিপ নিয়ন্ত্রণ ও সেটিংস' : 'Trip Control'}
                    </h3>
                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => {
                          setEditingTrip(selectedTrip);
                          setIsAddTripModalOpen(true);
                        }}
                        className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100 cursor-pointer"
                        title="এডিট করুন"
                      >
                        <Edit2 className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(language === 'bn' ? 'এই ট্রিপটি মুছে ফেলতে চান?' : 'Delete this trip?')) {
                            deleteTrip(selectedTrip.id);
                            showToast(language === 'bn' ? 'ট্রিপ মুছে ফেলা হয়েছে' : 'Trip deleted');
                          }
                        }}
                        className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg hover:bg-rose-50 cursor-pointer"
                        title="মুছুন"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  <div className="space-y-3 mt-3 text-xs">
                    <div>
                      <span className="text-[11px] font-bold text-slate-400 block mb-1">
                        {language === 'bn' ? 'ট্রিপ স্ট্যাটাস পরিবর্তন' : 'Trip Status'}
                      </span>
                      <div className="grid grid-cols-3 gap-1.5">
                        {(['upcoming', 'active', 'completed'] as const).map(st => (
                          <button
                            key={st}
                            onClick={() => {
                              setActiveTripStatus(selectedTrip.id, st);
                              showToast(language === 'bn' ? `স্ট্যাটাস: ${st === 'active' ? 'সক্রিয়' : st === 'completed' ? 'সম্পন্ন' : 'আসন্ন'}` : `Status: ${st}`);
                            }}
                            className={`py-1.5 text-[11px] font-bold rounded-xl border text-center transition-all cursor-pointer ${
                              selectedTrip.status === st
                                ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                                : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                            }`}
                          >
                            {st === 'active' 
                              ? (language === 'bn' ? 'সক্রিয়' : 'Active') 
                              : st === 'completed' 
                              ? (language === 'bn' ? 'সম্পন্ন' : 'Completed') 
                              : (language === 'bn' ? 'আসন্ন' : 'Upcoming')}
                          </button>
                        ))}
                      </div>
                    </div>

                    <div className="p-3 rounded-2xl bg-emerald-50/60 border border-emerald-200/60 space-y-1">
                      <span className="text-[11px] font-bold text-emerald-900 block">
                        💡 {language === 'bn' ? 'ট্যুর টিপস ও অটোমেটিক ব্যালেন্স' : 'Smart Tip'}
                      </span>
                      <p className="text-[11px] text-emerald-800/80 leading-relaxed">
                        {language === 'bn'
                          ? 'কমন ফান্ড থেকে খরচ হলে "ফান্ড হতে" নির্বাচন করুন। ব্যক্তিগতভাবে কেউ খরচ পরিশোধ করলে তার নাম নির্বাচন করুন; হিসাব স্বয়ংক্রিয়ভাবে ব্যালেন্স শিটে অ্যাডজাস্ট হবে।'
                          : 'Select "From Fund" for pooled costs, or choose the specific member. Balances will auto-adjust.'}
                      </p>
                    </div>
                  </div>
                </div>

                <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                  <button
                    onClick={() => setTripSubTab('settlement')}
                    className="w-full py-2 bg-slate-900 hover:bg-black text-white text-xs font-bold rounded-xl text-center shadow-xs cursor-pointer flex items-center justify-center gap-1.5"
                  >
                    <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-300" />
                    <span>{language === 'bn' ? 'পূর্ণাঙ্গ হিসাব বিবরণী দেখুন' : 'View Settlement Statement'}</span>
                  </button>
                </div>
              </div>

            </div>
          )}

          {/* 2. EXPENSES TAB */}
          {tripSubTab === 'expenses' && (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 animate-in fade-in duration-150">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-bold text-slate-800">
                    {language === 'bn' ? 'ট্যুরের আইটেমভিত্তিক খরচের খাতা' : 'Trip Expense Log'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? `মোট ${selectedTrip.expenses.length}টি খরচ লিপিবদ্ধ করা হয়েছে` : `${selectedTrip.expenses.length} expenses recorded`}
                  </p>
                </div>

                <button
                  onClick={() => setIsAddExpenseModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{language === 'bn' ? 'নতুন খরচ যোগ' : 'Add Expense'}</span>
                </button>
              </div>

              {/* Expenses List */}
              {selectedTrip.expenses.length === 0 ? (
                <div className="py-12 text-center text-slate-400 text-xs">
                  <ReceiptText className="w-10 h-10 mx-auto text-slate-300 mb-2" />
                  <p className="font-semibold">{language === 'bn' ? 'এখনও কোনো খরচ যুক্ত করা হয়নি।' : 'No expenses logged yet.'}</p>
                </div>
              ) : (
                <div className="divide-y divide-slate-100">
                  {selectedTrip.expenses.map(exp => {
                    const meta = getCategoryMeta(exp.category);
                    const Icon = meta.icon;
                    const paidByMember = selectedTrip.members.find(m => m.id === exp.paidByMemberId);
                    const paidByText = exp.paidByMemberId === 'fund' 
                      ? (language === 'bn' ? 'কমন ফান্ড হতে' : 'From Fund') 
                      : (paidByMember?.name || exp.paidByMemberId);

                    return (
                      <div key={exp.id} className="py-3 flex items-center justify-between gap-3 group">
                        <div className="flex items-center gap-3 min-w-0">
                          <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 border ${meta.color}`}>
                            <Icon className="w-4 h-4" />
                          </div>

                          <div className="min-w-0">
                            <h4 className="text-xs sm:text-sm font-bold text-slate-800 truncate">
                              {exp.title}
                            </h4>
                            <p className="text-[11px] text-slate-400 truncate flex items-center gap-1.5 mt-0.5">
                              <span>📅 {exp.date}</span>
                              <span>•</span>
                              <span className="font-semibold text-emerald-700 bg-emerald-50 px-1.5 py-0.2 rounded-md">
                                {paidByText}
                              </span>
                              {exp.note && <span>• {exp.note}</span>}
                            </p>
                          </div>
                        </div>

                        <div className="flex items-center gap-3 shrink-0">
                          <span className="text-xs sm:text-sm font-black text-slate-900">
                            {formatMoney(exp.amount)}
                          </span>

                          <button
                            onClick={() => {
                              if (window.confirm(language === 'bn' ? 'খরচটি মুছতে চান?' : 'Delete expense?')) {
                                deleteTripExpense(selectedTrip.id, exp.id);
                                showToast(language === 'bn' ? 'খরচ মুছে ফেলা হয়েছে' : 'Expense deleted');
                              }
                            }}
                            className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* 3. MEMBERS TAB */}
          {tripSubTab === 'members' && (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 animate-in fade-in duration-150">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-bold text-slate-800">
                    {language === 'bn' ? 'ট্যুর সদস্য, জমা ও পাওনা-দেনা' : 'Members & Pool Deposits'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? `জনপ্রতি নির্ধারিত খরচ: ${formatMoney(tripStats.costPerPerson)}` : `Per person fair cost: ${formatMoney(tripStats.costPerPerson)}`}
                  </p>
                </div>

                <button
                  onClick={() => setIsAddMemberModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{language === 'bn' ? 'সদস্য যোগ করুন' : 'Add Member'}</span>
                </button>
              </div>

              {/* Members Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead>
                    <tr className="border-b border-slate-200 text-slate-400 font-bold uppercase text-[10px]">
                      <th className="py-2.5 px-3">{language === 'bn' ? 'সদস্যের নাম' : 'Member'}</th>
                      <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'ফান্ডে জমা' : 'Pool Deposit'}</th>
                      <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'নিজস্ব খরচ' : 'Out-of-Pocket'}</th>
                      <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'মোট দেওয়া' : 'Total Contributed'}</th>
                      <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'ব্যালেন্স / অবস্থা' : 'Net Balance'}</th>
                      <th className="py-2.5 px-3 text-center">{language === 'bn' ? 'অ্যাকশন' : 'Action'}</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 font-semibold text-slate-700">
                    {tripStats.memberBalances.map(({ member, depositAmount, personalExpensesPaid, totalContributed, balance, status }) => (
                      <tr key={member.id} className="hover:bg-slate-50/50">
                        <td className="py-3 px-3">
                          <div className="flex items-center gap-2">
                            <span
                              className="w-7 h-7 rounded-full text-white flex items-center justify-center font-bold text-xs shrink-0"
                              style={{ backgroundColor: member.avatarColor || '#10b981' }}
                            >
                              {member.name.charAt(0)}
                            </span>
                            <div>
                              <span className="font-bold text-slate-900 block">{member.name}</span>
                              {member.phone && <span className="text-[10px] text-slate-400">{member.phone}</span>}
                            </div>
                          </div>
                        </td>

                        <td className="py-3 px-3 text-right font-bold text-slate-800">
                          {formatMoney(depositAmount)}
                        </td>

                        <td className="py-3 px-3 text-right text-slate-600">
                          {formatMoney(personalExpensesPaid)}
                        </td>

                        <td className="py-3 px-3 text-right font-black text-slate-900">
                          {formatMoney(totalContributed)}
                        </td>

                        <td className="py-3 px-3 text-right">
                          {status === 'refund' ? (
                            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded-md inline-block">
                              +{formatMoney(balance)} ({language === 'bn' ? 'পাবে' : 'Refund'})
                            </span>
                          ) : status === 'due' ? (
                            <span className="text-rose-700 font-bold bg-rose-50 px-2 py-0.5 rounded-md inline-block">
                              {formatMoney(Math.abs(balance))} ({language === 'bn' ? 'দিবে' : 'Due'})
                            </span>
                          ) : (
                            <span className="text-slate-500 font-bold bg-slate-100 px-2 py-0.5 rounded-md inline-block">
                              {language === 'bn' ? 'সমান' : 'Settled'}
                            </span>
                          )}
                        </td>

                        <td className="py-3 px-3 text-center">
                          <div className="flex items-center justify-center gap-1.5">
                            <button
                              onClick={() => {
                                setSelectedMemberForDeposit(member);
                                setIsDepositModalOpen(true);
                              }}
                              className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg text-[11px] font-bold cursor-pointer"
                              title="টাকা জমা নিন"
                            >
                              + {language === 'bn' ? 'জমা' : 'Deposit'}
                            </button>

                            <button
                              onClick={() => {
                                if (window.confirm(language === 'bn' ? 'সদস্যকে সরাতে চান?' : 'Remove member?')) {
                                  deleteTripMember(selectedTrip.id, member.id);
                                  showToast(language === 'bn' ? 'সদস্য সরানো হয়েছে' : 'Member removed');
                                }
                              }}
                              className="p-1 text-slate-300 hover:text-rose-600 rounded-md cursor-pointer"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* 4. PACKING LIST TAB */}
          {tripSubTab === 'packing' && (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 animate-in fade-in duration-150">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                    <Luggage className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? 'ট্যুর প্যাকিং চেকলিস্ট' : 'Tour Packing Checklist'}</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? `${packedCount} / ${totalPackingCount} টি জিনিস প্যাক করা হয়েছে` : `${packedCount} of ${totalPackingCount} packed`}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  <select
                    value={packingCategoryFilter}
                    onChange={e => setPackingCategoryFilter(e.target.value)}
                    className="px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700"
                  >
                    <option value="all">{language === 'bn' ? 'সকল ক্যাটাগরি' : 'All Categories'}</option>
                    <option value="documents">{language === 'bn' ? 'জরুরি ডকুমেন্টস' : 'Documents'}</option>
                    <option value="electronics">{language === 'bn' ? 'ইলেকট্রনিক্স ও গ্যাজেট' : 'Electronics'}</option>
                    <option value="medicine">{language === 'bn' ? 'ওষুধ ও ফার্স্ট এইড' : 'Medicine'}</option>
                    <option value="gear">{language === 'bn' ? 'ট্র্যাকিং গিয়ার' : 'Gear'}</option>
                    <option value="clothes">{language === 'bn' ? 'পোশাক ও এক্সেসরিজ' : 'Clothes'}</option>
                    <option value="toiletries">{language === 'bn' ? 'প্রসাধন ও টয়লেট্রিজ' : 'Toiletries'}</option>
                  </select>

                  <button
                    onClick={() => setIsAddPackingModalOpen(true)}
                    className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'আইটেম যোগ' : 'Add Item'}</span>
                  </button>
                </div>
              </div>

              {/* Progress bar */}
              <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-2 rounded-full transition-all duration-300"
                  style={{ width: `${totalPackingCount > 0 ? (packedCount / totalPackingCount) * 100 : 0}%` }}
                />
              </div>

              {/* Checklist items */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2.5 pt-2">
                {filteredPackingList.map(item => (
                  <div
                    key={item.id}
                    onClick={() => toggleTripPackingItem(selectedTrip.id, item.id)}
                    className={`p-3 rounded-2xl border transition-all flex items-center justify-between cursor-pointer select-none ${
                      item.isPacked
                        ? 'bg-emerald-50/50 border-emerald-200 text-slate-500'
                        : 'bg-white border-slate-200 text-slate-800 hover:border-emerald-300'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      {item.isPacked ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <Square className="w-4 h-4 text-slate-400 shrink-0" />
                      )}

                      <div className="min-w-0">
                        <span className={`text-xs font-bold block truncate ${item.isPacked ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                          {item.title}
                        </span>
                        {item.assignedMemberName && (
                          <span className="text-[10px] text-emerald-700 font-semibold">
                            👤 {item.assignedMemberName}
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={e => {
                        e.stopPropagation();
                        deleteTripPackingItem(selectedTrip.id, item.id);
                      }}
                      className="p-1 text-slate-300 hover:text-rose-600 rounded-md shrink-0 cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 5. ITINERARY TAB */}
          {tripSubTab === 'itinerary' && (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4 animate-in fade-in duration-150">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div>
                  <h3 className="text-base font-bold text-slate-800 flex items-center gap-2">
                    <Calendar className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? 'দিনভিত্তিক ভ্রমণসূচি ও রুটিন' : 'Day-by-Day Itinerary'}</span>
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? 'প্রতিদিনের দর্শনীয় স্থান, সময়সূচি ও সম্ভাব্য বাজেট' : 'Activities, timeline and estimated day cost'}
                  </p>
                </div>

                <button
                  onClick={() => setIsAddItineraryModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>{language === 'bn' ? 'নতুন দিন যোগ' : 'Add Day'}</span>
                </button>
              </div>

              {/* Timeline Cards */}
              <div className="space-y-4 pt-2">
                {selectedTrip.itinerary.map(day => (
                  <div key={day.id} className="relative pl-6 sm:pl-8 pb-4 border-l-2 border-emerald-500 last:border-l-0">
                    {/* Circle marker */}
                    <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-emerald-600 ring-4 ring-emerald-100 flex items-center justify-center" />

                    <div className="bg-slate-50/80 hover:bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-2">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span className="px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[11px] font-black uppercase">
                            {language === 'bn' ? `দিন ${day.dayNumber}` : `Day ${day.dayNumber}`}
                          </span>
                          <h4 className="font-extrabold text-sm text-slate-900">
                            {day.title}
                          </h4>
                        </div>

                        <div className="flex items-center gap-2">
                          {day.estimatedCost !== undefined && day.estimatedCost > 0 && (
                            <span className="text-xs font-bold text-emerald-800 bg-emerald-100/70 px-2 py-0.5 rounded-lg">
                              ≈ {formatMoney(day.estimatedCost)}
                            </span>
                          )}
                          <button
                            onClick={() => deleteTripItineraryDay(selectedTrip.id, day.id)}
                            className="p-1 text-slate-300 hover:text-rose-600 rounded-md cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      <p className="text-xs text-slate-600 leading-relaxed">
                        {day.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 6. SETTLEMENT INVOICE TAB */}
          {tripSubTab === 'settlement' && (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-6 sm:p-8 shadow-xs space-y-6 animate-in fade-in duration-150">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-200">
                <div>
                  <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800">
                    {language === 'bn' ? 'চূড়ান্ত হিসাব নিষ্পত্তি' : 'Final Settlement Statement'}
                  </span>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-1">
                    {selectedTrip.titleBn || selectedTrip.title}
                  </h2>
                  <p className="text-xs text-slate-400">
                    📍 {selectedTrip.destination} • 📅 {selectedTrip.startDate} - {selectedTrip.endDate}
                  </p>
                </div>

                <button
                  onClick={() => window.print()}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-slate-900 hover:bg-black text-white rounded-xl text-xs font-bold shadow-xs cursor-pointer no-print"
                >
                  <Printer className="w-4 h-4 text-emerald-400" />
                  <span>{language === 'bn' ? 'ইনভয়েস প্রিন্ট / ডাউনলোড' : 'Print Invoice'}</span>
                </button>
              </div>

              {/* Summary Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-2xl bg-slate-50 border border-slate-100 text-xs">
                <div>
                  <span className="text-slate-400 block font-semibold">{language === 'bn' ? 'মোট ভ্রমণ ব্যয়' : 'Total Spent'}</span>
                  <span className="text-lg font-black text-slate-900">{formatMoney(tripStats.totalSpent)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">{language === 'bn' ? 'মোট সদস্য' : 'Travelers'}</span>
                  <span className="text-lg font-black text-slate-900">{selectedTrip.members.length} {language === 'bn' ? 'জন' : 'Persons'}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">{language === 'bn' ? 'জনপ্রতি শেয়ার' : 'Per Person Share'}</span>
                  <span className="text-lg font-black text-emerald-700">{formatMoney(tripStats.costPerPerson)}</span>
                </div>
                <div>
                  <span className="text-slate-400 block font-semibold">{language === 'bn' ? 'কমন ফান্ড অবশিষ্ট' : 'Fund Remaining'}</span>
                  <span className="text-lg font-black text-sky-700">{formatMoney(tripStats.poolCashBalance)}</span>
                </div>
              </div>

              {/* Settlement Table: Who owes whom */}
              <div className="space-y-3">
                <h4 className="font-extrabold text-sm text-slate-900">
                  {language === 'bn' ? 'সদস্যদের হিসাব বিবরণী ও লেনদেন নিষ্পত্তি তালিকা' : 'Individual Member Settlement Breakdown'}
                </h4>

                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs border border-slate-200 rounded-xl overflow-hidden">
                    <thead className="bg-slate-100 text-slate-600 font-bold uppercase text-[10px]">
                      <tr>
                        <th className="py-2.5 px-3">{language === 'bn' ? 'নাম' : 'Name'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'ফান্ড জমা' : 'Pool Deposit'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'ব্যক্তিগত প্রদান' : 'Out-of-Pocket'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'মোট অবদান' : 'Total Paid'}</th>
                        <th className="py-2.5 px-3 text-right">{language === 'bn' ? 'প্রদেয় অংশ' : 'Fair Share'}</th>
                        <th className="py-2.5 px-3 text-right font-black">{language === 'bn' ? 'চূড়ান্ত স্থিতি' : 'Final Status'}</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 font-semibold">
                      {tripStats.memberBalances.map(({ member, depositAmount, personalExpensesPaid, totalContributed, fairShare, balance, status }) => (
                        <tr key={member.id} className="hover:bg-slate-50">
                          <td className="py-2.5 px-3 font-bold text-slate-900">{member.name}</td>
                          <td className="py-2.5 px-3 text-right">{formatMoney(depositAmount)}</td>
                          <td className="py-2.5 px-3 text-right">{formatMoney(personalExpensesPaid)}</td>
                          <td className="py-2.5 px-3 text-right font-bold text-slate-900">{formatMoney(totalContributed)}</td>
                          <td className="py-2.5 px-3 text-right text-slate-500">{formatMoney(fairShare)}</td>
                          <td className="py-2.5 px-3 text-right font-black">
                            {status === 'refund' ? (
                              <span className="text-emerald-700">
                                +{formatMoney(balance)} ({language === 'bn' ? 'ফেরত পাবে' : 'Gets Refund'})
                              </span>
                            ) : status === 'due' ? (
                              <span className="text-rose-600">
                                -{formatMoney(Math.abs(balance))} ({language === 'bn' ? 'বকেয়া দিবে' : 'Must Pay'})
                              </span>
                            ) : (
                              <span className="text-slate-500">{language === 'bn' ? 'পরিশোধিত' : 'Settled'}</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Footer Note */}
              <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-400">
                <span>{language === 'bn' ? 'Khoroch - স্মার্ট ট্রিপ ও ইভেন্ট ম্যানেজার দ্বারা প্রস্তুতকৃত' : 'Generated by Khoroch Smart Trip Manager'}</span>
                <span>{new Date().toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', { year: 'numeric', month: 'long', day: 'numeric' })}</span>
              </div>

            </div>
          )}

        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD / EDIT TRIP */}
      {/* ========================================================= */}
      {isAddTripModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddTripModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {editingTrip ? (language === 'bn' ? 'ট্রিপ তথ্য এডিট করুন' : 'Edit Trip') : (language === 'bn' ? 'নতুন ট্যুর / ইভেন্ট প্ল্যান করুন' : 'Create New Trip / Event')}
              </h3>
              <button onClick={() => setIsAddTripModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const title = (form.elements.namedItem('tripTitle') as HTMLInputElement).value.trim();
                const destination = (form.elements.namedItem('destination') as HTMLInputElement).value.trim();
                const type = (form.elements.namedItem('tripType') as HTMLSelectElement).value as TripType;
                const totalBudget = parseFloat((form.elements.namedItem('totalBudget') as HTMLInputElement).value) || 0;
                const startDate = (form.elements.namedItem('startDate') as HTMLInputElement).value;
                const endDate = (form.elements.namedItem('endDate') as HTMLInputElement).value || startDate;
                const status = (form.elements.namedItem('status') as HTMLSelectElement).value as any;
                const notes = (form.elements.namedItem('notes') as HTMLInputElement).value.trim();

                if (!title || !destination) return;

                if (editingTrip) {
                  editTrip({
                    ...editingTrip,
                    title,
                    destination,
                    type,
                    totalBudget,
                    startDate,
                    endDate,
                    status,
                    notes,
                  });
                  showToast(language === 'bn' ? 'ট্রিপ আপডেট হয়েছে' : 'Trip updated');
                } else {
                  addTrip({
                    title,
                    destination,
                    type,
                    totalBudget,
                    startDate,
                    endDate,
                    status,
                    notes,
                    members: [
                      { id: 'tm-' + Date.now(), name: 'আমি (ফয়সাল)', depositAmount: Math.round(totalBudget / 4), isLead: true },
                    ],
                    expenses: [],
                    packingList: [
                      { id: 'tp-1', title: 'এনআইডি কার্ড / পাসপোর্ট কপি', isPacked: false },
                      { id: 'tp-2', title: 'পাওয়ার ব্যাংক ও চার্জার', isPacked: false },
                      { id: 'tp-3', title: 'ফার্স্ট এইড ওষুধ ও ওআরএস', isPacked: false },
                    ],
                    itinerary: [
                      { id: 'ti-1', dayNumber: 1, title: 'গন্তব্যে পৌঁছানো ও চেক-ইন', description: 'যাত্রা শুরু ও হোটেলে পৌঁছানো' },
                    ],
                  });
                  confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
                  showToast(language === 'bn' ? 'নতুন ট্রিপ সফলভাবে তৈরি হয়েছে!' : 'Trip created successfully!');
                }

                setIsAddTripModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'ট্যুর বা ইভেন্টের নাম' : 'Trip / Event Title'} *
                </label>
                <input
                  type="text"
                  name="tripTitle"
                  required
                  defaultValue={editingTrip?.title || ''}
                  placeholder={language === 'bn' ? 'যেমন: সাজেক ভ্যালি ৪ দিনের অ্যাডভেঞ্চার ট্যুর' : 'e.g. Sajek Valley 4-Day Trip'}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'গন্তব্য / ভেন্যু' : 'Destination / Venue'} *
                  </label>
                  <input
                    type="text"
                    name="destination"
                    required
                    defaultValue={editingTrip?.destination || ''}
                    placeholder={language === 'bn' ? 'যেমন: সাজেক, রাঙ্গামাটি' : 'e.g. Cox\'s Bazar'}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ধরন' : 'Category / Type'}
                  </label>
                  <select
                    name="tripType"
                    defaultValue={editingTrip?.type || 'tour'}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  >
                    <option value="tour">{language === 'bn' ? 'ভ্রমণ ও ট্যুর (Tour)' : 'Travel Tour'}</option>
                    <option value="picnic">{language === 'bn' ? 'পিকনিক ও ডে-আউট (Picnic)' : 'Picnic'}</option>
                    <option value="wedding">{language === 'bn' ? 'বিয়ে ও অনুষ্ঠান (Wedding)' : 'Wedding'}</option>
                    <option value="party">{language === 'bn' ? 'পার্টি ও জন্মদিন (Party)' : 'Party'}</option>
                    <option value="official">{language === 'bn' ? 'অফিসিয়াল ট্যুর (Official)' : 'Official'}</option>
                    <option value="other">{language === 'bn' ? 'অন্যান্য (Other)' : 'Other'}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'মোট লক্ষ্য বাজেট' : 'Total Budget'} ({currency.symbol}) *
                  </label>
                  <input
                    type="number"
                    name="totalBudget"
                    required
                    min="1000"
                    step="500"
                    defaultValue={editingTrip?.totalBudget || 30000}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-black text-emerald-800"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'স্ট্যাটাস' : 'Status'}
                  </label>
                  <select
                    name="status"
                    defaultValue={editingTrip?.status || 'active'}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  >
                    <option value="active">{language === 'bn' ? 'সক্রিয় ট্যুর (Active)' : 'Active'}</option>
                    <option value="upcoming">{language === 'bn' ? 'আসন্ন ট্যুর (Upcoming)' : 'Upcoming'}</option>
                    <option value="completed">{language === 'bn' ? 'সম্পন্ন (Completed)' : 'Completed'}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'শুরুর তারিখ' : 'Start Date'}
                  </label>
                  <input
                    type="date"
                    name="startDate"
                    defaultValue={editingTrip?.startDate || new Date().toISOString().split('T')[0]}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'শেষের তারিখ' : 'End Date'}
                  </label>
                  <input
                    type="date"
                    name="endDate"
                    defaultValue={editingTrip?.endDate || new Date().toISOString().split('T')[0]}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'নোট বা বিবরণ' : 'Notes'}
                </label>
                <input
                  type="text"
                  name="notes"
                  defaultValue={editingTrip?.notes || ''}
                  placeholder={language === 'bn' ? 'যেমন: চাঁদের গাড়ি ও হেলিপ্যাড সূর্যাস্ত' : 'e.g. Hotel booked, tickets confirmed'}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddTripModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? 'সংরক্ষণ' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD TRIP EXPENSE */}
      {/* ========================================================= */}
      {isAddExpenseModalOpen && selectedTrip && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddExpenseModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'ট্যুর খরচ লিপিবদ্ধ করুন' : 'Add Trip Expense'}
              </h3>
              <button onClick={() => setIsAddExpenseModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const title = (form.elements.namedItem('expenseTitle') as HTMLInputElement).value.trim();
                const amount = parseFloat((form.elements.namedItem('expenseAmount') as HTMLInputElement).value) || 0;
                const category = (form.elements.namedItem('expenseCategory') as HTMLSelectElement).value as TripExpenseCategory;
                const paidByMemberId = (form.elements.namedItem('paidBy') as HTMLSelectElement).value;
                const date = (form.elements.namedItem('expenseDate') as HTMLInputElement).value;
                const syncWithKhoroch = (form.elements.namedItem('syncWallet') as HTMLInputElement)?.checked || false;
                const accountId = (form.elements.namedItem('syncAccountId') as HTMLSelectElement)?.value;
                const note = (form.elements.namedItem('expenseNote') as HTMLInputElement).value.trim();

                if (!title || amount <= 0) return;

                addTripExpense(
                  selectedTrip.id,
                  {
                    tripId: selectedTrip.id,
                    title,
                    amount,
                    category,
                    paidByMemberId,
                    date,
                    note,
                  },
                  syncWithKhoroch,
                  accountId
                );

                showToast(language === 'bn' ? `৳${amount.toLocaleString()} খরচ লিপিবদ্ধ হয়েছে` : `Recorded expense of ৳${amount.toLocaleString()}`);
                setIsAddExpenseModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'খরচের বিবরণ' : 'Description'} *
                </label>
                <input
                  type="text"
                  name="expenseTitle"
                  required
                  placeholder={language === 'bn' ? 'যেমন: চাঁদের গাড়ি ভাড়া / ব্যাম্বো চিকেন ডিনার' : 'e.g. Bus Ticket / Dinner'}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'টাকার পরিমাণ' : 'Amount'} ({currency.symbol}) *
                  </label>
                  <input
                    type="number"
                    name="expenseAmount"
                    required
                    min="1"
                    placeholder="1200"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black text-slate-900"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    name="expenseCategory"
                    defaultValue="food"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  >
                    <option value="transport">{language === 'bn' ? 'যাতায়াত (Transport)' : 'Transport'}</option>
                    <option value="hotel">{language === 'bn' ? 'হোটেল ও রিসোর্ট (Hotel)' : 'Hotel'}</option>
                    <option value="food">{language === 'bn' ? 'খাবার (Food)' : 'Food'}</option>
                    <option value="activity">{language === 'bn' ? 'টিকিট ও সাইটসিয়িং' : 'Sightseeing'}</option>
                    <option value="shopping">{language === 'bn' ? 'কেনাকাটা (Shopping)' : 'Shopping'}</option>
                    <option value="logistics">{language === 'bn' ? 'লজিস্টিক ও ডেকোর' : 'Logistics'}</option>
                    <option value="emergency">{language === 'bn' ? 'জরুরি (Emergency)' : 'Emergency'}</option>
                    <option value="other">{language === 'bn' ? 'অন্যান্য (Other)' : 'Other'}</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'কে পরিশোধ করেছে?' : 'Paid By'}
                  </label>
                  <select
                    name="paidBy"
                    defaultValue="fund"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-emerald-800"
                  >
                    <option value="fund">💰 {language === 'bn' ? 'কমন ফান্ড হতে' : 'From Common Fund'}</option>
                    {selectedTrip.members.map(m => (
                      <option key={m.id} value={m.id}>
                        👤 {m.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'তারিখ' : 'Date'}
                  </label>
                  <input
                    type="date"
                    name="expenseDate"
                    defaultValue={new Date().toISOString().split('T')[0]}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              {/* Khoroch Wallet Sync Option */}
              <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-2 text-xs">
                <label className="flex items-center gap-2 font-bold text-slate-700 cursor-pointer">
                  <input type="checkbox" name="syncWallet" className="rounded text-emerald-600 focus:ring-emerald-500" />
                  <span>{language === 'bn' ? 'আমার মূল খরচ ওয়ালেট থেকেও কর্তন করুন' : 'Deduct from my personal Khoroch wallet'}</span>
                </label>
                <div className="pl-5">
                  <select
                    name="syncAccountId"
                    defaultValue={accounts[0]?.id}
                    className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                  >
                    {accounts.map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {acc.name} ({formatMoney(acc.balance)})
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'অতিরিক্ত নোট' : 'Note'}
                </label>
                <input
                  type="text"
                  name="expenseNote"
                  placeholder={language === 'bn' ? 'যেমন: ৪ জনের শেয়ার' : 'e.g. Receipt saved'}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddExpenseModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? 'খরচ নিশ্চিত করুন' : 'Log Expense'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD TRIP MEMBER */}
      {/* ========================================================= */}
      {isAddMemberModalOpen && selectedTrip && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddMemberModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'ট্যুরে নতুন সদস্য যুক্ত করুন' : 'Add Trip Member'}
              </h3>
              <button onClick={() => setIsAddMemberModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const name = (form.elements.namedItem('memberName') as HTMLInputElement).value.trim();
                const phone = (form.elements.namedItem('memberPhone') as HTMLInputElement).value.trim();
                const deposit = parseFloat((form.elements.namedItem('memberDeposit') as HTMLInputElement).value) || 0;

                if (!name) return;

                const colors = ['#10b981', '#06b6d4', '#f59e0b', '#8b5cf6', '#ec4899', '#3b82f6'];
                const randomColor = colors[Math.floor(Math.random() * colors.length)];

                addTripMember(selectedTrip.id, {
                  name,
                  phone,
                  depositAmount: deposit,
                  avatarColor: randomColor,
                });

                showToast(language === 'bn' ? `${name} যুক্ত হয়েছে` : `${name} added`);
                setIsAddMemberModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'সদস্যের নাম' : 'Name'} *
                </label>
                <input
                  type="text"
                  name="memberName"
                  required
                  placeholder="যেমন: সাকিব হাসান"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'মোবাইল নম্বর' : 'Phone'}
                </label>
                <input
                  type="text"
                  name="memberPhone"
                  placeholder="01712-345678"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'প্রাথমিক ফান্ড জমা' : 'Initial Pool Deposit'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  name="memberDeposit"
                  min="0"
                  defaultValue="5000"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddMemberModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? 'যোগ করুন' : 'Add'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: MEMBER DEPOSIT TO POOL */}
      {/* ========================================================= */}
      {isDepositModalOpen && selectedTrip && selectedMemberForDeposit && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsDepositModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-base text-slate-800">
                  {language === 'bn' ? 'ট্যুর ফান্ডে টাকা জমা নিন' : 'Record Deposit'}
                </h3>
                <p className="text-xs text-slate-400">
                  {selectedMemberForDeposit.name}
                </p>
              </div>
              <button onClick={() => setIsDepositModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const amount = parseFloat((form.elements.namedItem('depositAmount') as HTMLInputElement).value) || 0;

                if (amount <= 0) return;

                recordTripMemberDeposit(selectedTrip.id, selectedMemberForDeposit.id, amount);
                showToast(language === 'bn' ? `৳${amount.toLocaleString()} জমা গ্রহণ করা হয়েছে` : `Recorded ৳${amount.toLocaleString()} deposit`);
                setIsDepositModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'জমার পরিমাণ' : 'Deposit Amount'} ({currency.symbol}) *
                </label>
                <input
                  type="number"
                  name="depositAmount"
                  required
                  min="1"
                  defaultValue="2000"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base font-black text-emerald-800"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsDepositModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? 'জমা নিশ্চিত করুন' : 'Confirm'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD PACKING ITEM */}
      {/* ========================================================= */}
      {isAddPackingModalOpen && selectedTrip && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddPackingModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'প্যাকিং লিস্টে জিনিস যোগ করুন' : 'Add Packing Item'}
              </h3>
              <button onClick={() => setIsAddPackingModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const title = (form.elements.namedItem('packTitle') as HTMLInputElement).value.trim();
                const category = (form.elements.namedItem('packCategory') as HTMLSelectElement).value as any;
                const assigned = (form.elements.namedItem('assigned') as HTMLInputElement).value.trim();

                if (!title) return;

                addTripPackingItem(selectedTrip.id, {
                  title,
                  category,
                  isPacked: false,
                  assignedMemberName: assigned || undefined,
                });

                showToast(language === 'bn' ? 'প্যাকিং আইটেম যোগ হয়েছে' : 'Added to packing list');
                setIsAddPackingModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'জিনিসের নাম' : 'Item Name'} *
                </label>
                <input
                  type="text"
                  name="packTitle"
                  required
                  placeholder={language === 'bn' ? 'যেমন: পাওয়ার ব্যাংক ২০০০০ mAh' : 'e.g. Power bank'}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
                </label>
                <select
                  name="packCategory"
                  defaultValue="electronics"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                >
                  <option value="documents">{language === 'bn' ? 'জরুরি ডকুমেন্টস' : 'Documents'}</option>
                  <option value="electronics">{language === 'bn' ? 'ইলেকট্রনিক্স ও গ্যাজেট' : 'Electronics'}</option>
                  <option value="medicine">{language === 'bn' ? 'ওষুধ ও ফার্স্ট এইড' : 'Medicine'}</option>
                  <option value="gear">{language === 'bn' ? 'ট্র্যাকিং গিয়ার' : 'Gear'}</option>
                  <option value="clothes">{language === 'bn' ? 'পোশাক ও এক্সেসরিজ' : 'Clothes'}</option>
                  <option value="toiletries">{language === 'bn' ? 'প্রসাধন ও টয়লেট্রিজ' : 'Toiletries'}</option>
                  <option value="other">{language === 'bn' ? 'অন্যান্য' : 'Other'}</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'কে নিয়ে যাবে? (ঐচ্ছিক)' : 'Assigned Member (Optional)'}
                </label>
                <input
                  type="text"
                  name="assigned"
                  placeholder={language === 'bn' ? 'যেমন: তানভীর' : 'e.g. Faysal'}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddPackingModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? 'যোগ করুন' : 'Add'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD ITINERARY DAY */}
      {/* ========================================================= */}
      {isAddItineraryModalOpen && selectedTrip && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddItineraryModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'ভ্রমণসূচিতে নতুন দিন যোগ করুন' : 'Add Day to Itinerary'}
              </h3>
              <button onClick={() => setIsAddItineraryModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600 cursor-pointer">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const dayNumber = parseInt((form.elements.namedItem('dayNo') as HTMLInputElement).value) || (selectedTrip.itinerary.length + 1);
                const title = (form.elements.namedItem('dayTitle') as HTMLInputElement).value.trim();
                const description = (form.elements.namedItem('dayDesc') as HTMLTextAreaElement).value.trim();
                const estimatedCost = parseFloat((form.elements.namedItem('dayEstCost') as HTMLInputElement).value) || undefined;

                if (!title) return;

                addTripItineraryDay(selectedTrip.id, {
                  dayNumber,
                  title,
                  description,
                  estimatedCost,
                });

                showToast(language === 'bn' ? `দিন ${dayNumber} যুক্ত হয়েছে` : `Day ${dayNumber} added`);
                setIsAddItineraryModalOpen(false);
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-3 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'কততম দিন' : 'Day #'} *
                  </label>
                  <input
                    type="number"
                    name="dayNo"
                    min="1"
                    defaultValue={selectedTrip.itinerary.length + 1}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>

                <div className="col-span-2">
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'দিনের প্রধান পরিকল্পনা' : 'Day Title'} *
                  </label>
                  <input
                    type="text"
                    name="dayTitle"
                    required
                    placeholder={language === 'bn' ? 'যেমন: কংলাক পাহাড় ট্র্যাকিং' : 'e.g. Konglak Peak Trekking'}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'বিস্তারিত কর্মসূচি' : 'Description'}
                </label>
                <textarea
                  name="dayDesc"
                  rows={3}
                  placeholder={language === 'bn' ? 'যেমন: ভোর ৫টায় সূর্যোদয় দেখা, নাশতা ও কংলাকে ট্র্যাকিং...' : 'Schedule details'}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'সম্ভাব্য দিন বাজেট' : 'Estimated Day Cost'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  name="dayEstCost"
                  min="0"
                  placeholder="3000"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddItineraryModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl cursor-pointer"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {language === 'bn' ? 'যোগ করুন' : 'Add'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
