import React, { useState, useMemo, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import { WishlistItem, WishlistStatus } from '../../types';
import { WishlistModal } from '../WishlistModal';
import { getBengaliDate } from '../../utils/bengaliCalendar';
import {
  Hourglass,
  Plus,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Clock,
  Sparkles,
  ExternalLink,
  Edit2,
  Trash2,
  Search,
  ArrowUpDown,
  ShoppingBag,
  HelpCircle,
  ChevronRight,
  TrendingDown,
  Info,
  Scale,
} from 'lucide-react';
import { CanIAffordThisModal } from '../CanIAffordThisModal';

export const WishlistView: React.FC = () => {
  const {
    wishlistItems,
    deleteWishlistItem,
    markWishlistPurchased,
    dropWishlistItem,
    totalMoneySavedFromImpulse,
    formatMoney,
    categories,
    accounts,
    language,
    currency,
  } = useExpense();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAffordModalOpen, setIsAffordModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<WishlistItem | null>(null);
  const [activeFilter, setActiveFilter] = useState<'all' | 'cooling' | 'ready' | 'dropped' | 'purchased'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'days' | 'price_desc' | 'price_asc' | 'date_desc'>('days');
  const [purchaseConfirmItem, setPurchaseConfirmItem] = useState<WishlistItem | null>(null);
  const [selectedWalletId, setSelectedWalletId] = useState<string>('');
  const [showCelebrationNote, setShowCelebrationNote] = useState<string | null>(null);

  useLockBodyScroll(!!purchaseConfirmItem);

  useEffect(() => {
    if (!purchaseConfirmItem) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setPurchaseConfirmItem(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [purchaseConfirmItem]);

  const getCategory = (catId?: string) => categories.find(c => c.id === catId);
  const getAccount = (accId?: string) => accounts.find(a => a.id === accId);

  // Helper to compute elapsed days and remaining days
  const now = new Date();
  const getItemDaysInfo = (item: WishlistItem) => {
    const added = new Date(item.addedDate);
    const diffTime = Math.max(0, now.getTime() - added.getTime());
    const elapsedDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const totalDays = item.coolingPeriodDays || 30;
    const remainingDays = Math.max(0, totalDays - elapsedDays);
    const progressPercent = Math.min(100, Math.round((elapsedDays / totalDays) * 100));
    const isReady = item.status === 'ready' || (item.status === 'cooling' && remainingDays === 0);

    return {
      elapsedDays,
      totalDays,
      remainingDays,
      progressPercent,
      isReady,
    };
  };

  // Filtered & sorted items
  const processedItems = useMemo(() => {
    let list = [...wishlistItems];

    // Filter by tab
    if (activeFilter === 'cooling') {
      list = list.filter(w => {
        const info = getItemDaysInfo(w);
        return w.status === 'cooling' && !info.isReady;
      });
    } else if (activeFilter === 'ready') {
      list = list.filter(w => {
        const info = getItemDaysInfo(w);
        return (w.status === 'ready' || (w.status === 'cooling' && info.isReady));
      });
    } else if (activeFilter === 'dropped') {
      list = list.filter(w => w.status === 'dropped');
    } else if (activeFilter === 'purchased') {
      list = list.filter(w => w.status === 'purchased');
    }

    // Search
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase();
      list = list.filter(
        w => w.title.toLowerCase().includes(q) || (w.notes && w.notes.toLowerCase().includes(q))
      );
    }

    // Sorting
    list.sort((a, b) => {
      const infoA = getItemDaysInfo(a);
      const infoB = getItemDaysInfo(b);

      if (sortBy === 'days') {
        return infoA.remainingDays - infoB.remainingDays;
      }
      if (sortBy === 'price_desc') {
        return b.estimatedPrice - a.estimatedPrice;
      }
      if (sortBy === 'price_asc') {
        return a.estimatedPrice - b.estimatedPrice;
      }
      return new Date(b.addedDate).getTime() - new Date(a.addedDate).getTime();
    });

    return list;
  }, [wishlistItems, activeFilter, searchQuery, sortBy]);

  // Overall counts
  const coolingCount = wishlistItems.filter(w => {
    const info = getItemDaysInfo(w);
    return w.status === 'cooling' && !info.isReady;
  }).length;

  const readyCount = wishlistItems.filter(w => {
    const info = getItemDaysInfo(w);
    return (w.status === 'ready' || (w.status === 'cooling' && info.isReady));
  }).length;

  const droppedCount = wishlistItems.filter(w => w.status === 'dropped').length;
  const purchasedCount = wishlistItems.filter(w => w.status === 'purchased').length;

  const handleOpenAdd = () => {
    setEditingItem(null);
    setIsModalOpen(true);
  };

  const handleEdit = (item: WishlistItem) => {
    setEditingItem(item);
    setIsModalOpen(true);
  };

  const handleDrop = (item: WishlistItem) => {
    dropWishlistItem(item.id);
    setShowCelebrationNote(
      language === 'bn'
        ? `দারুণ সিদ্ধান্ত! "${item.title}" বাদ দিয়ে আপনি ${formatMoney(item.estimatedPrice)} টাকা বাঁচালেন!`
        : `Smart move! Dropping "${item.title}" saved you ${formatMoney(item.estimatedPrice)}!`
    );
    setTimeout(() => {
      setShowCelebrationNote(null);
    }, 4500);
  };

  const handleConfirmPurchase = () => {
    if (!purchaseConfirmItem) return;
    markWishlistPurchased(purchaseConfirmItem.id, selectedWalletId || purchaseConfirmItem.accountId, true);
    setPurchaseConfirmItem(null);
  };

  return (
    <div className="space-y-6">
      {/* Top Banner Alert / Toast for celebration */}
      {showCelebrationNote && (
        <div className="bg-emerald-50 border border-emerald-200 text-emerald-900 px-4 py-3 rounded-2xl flex items-center justify-between shadow-xs animate-in slide-in-from-top-2 duration-200">
          <div className="flex items-center gap-2.5">
            <ShieldCheck className="w-5 h-5 text-emerald-600 shrink-0" />
            <span className="text-xs sm:text-sm font-semibold">{showCelebrationNote}</span>
          </div>
          <button
            onClick={() => setShowCelebrationNote(null)}
            className="text-xs text-emerald-700 font-bold hover:underline ml-3"
          >
            {language === 'bn' ? 'ঠিক আছে' : 'OK'}
          </button>
        </div>
      )}

      {/* Header with Title and Add Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
              {language === 'bn' ? 'উইশলিস্ট ও ৩০ দিনের কুলিং রুল' : 'Wishlist & 30-Day Delay Rule'}
            </h1>
            <span className="text-[11px] font-bold px-2 py-0.5 rounded-md bg-indigo-50 text-indigo-700 border border-indigo-100">
              {language === 'bn' ? 'ইমপালস বাই কন্ট্রোলার' : 'Impulse Controller'}
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl leading-relaxed">
            {language === 'bn'
              ? 'হুটহাট কেনাকাটার আবেগ প্রশমিত করতে ৩০ দিন অপেক্ষা করুন। অধিকাংশ ক্ষেত্রে দেখা যায় ৩০ দিন পর কেনার তীব্র ইচ্ছা এমনিতেই মিলিয়ে যায় এবং প্রচুর টাকা বেঁচে যায়!'
              : 'Cool down impulse spending by waiting 30 days. Research proves most temporary urges fade, saving you significant money!'}
          </p>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            type="button"
            onClick={() => setIsAffordModalOpen(true)}
            className="inline-flex items-center justify-center gap-1.5 px-3.5 py-2.5 bg-teal-50 hover:bg-teal-100 border border-teal-200 text-teal-800 rounded-xl text-xs sm:text-sm font-bold shadow-2xs transition-all active:scale-95 shrink-0 cursor-pointer"
            title={language === 'bn' ? 'ক্রয় সামর্থ্য যাচাই করুন' : 'Can I Afford This?'}
          >
            <Scale className="w-4 h-4 text-teal-600" />
            <span>{language === 'bn' ? 'কিনতে পারবো?' : 'Can I Afford This?'}</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs hover:shadow-md transition-all active:scale-95 shrink-0"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>{language === 'bn' ? 'নতুন ইচ্ছা যোগ করুন' : 'Add Desire / Wish'}</span>
          </button>
        </div>
      </div>

      {/* 4 Stat Overview Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
        
        {/* Total Money Saved Card */}
        <div className="bg-gradient-to-br from-emerald-50/90 to-teal-50/50 border border-emerald-200/80 rounded-2xl p-4 space-y-1 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-emerald-800">
              {language === 'bn' ? 'অপচয় রোধ বা মোট সঞ্চয়' : 'Money Saved (Impulse Avoided)'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-emerald-100/80 flex items-center justify-center text-emerald-700">
              <ShieldCheck className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-2xl font-extrabold font-mono tabular-nums text-emerald-700">
            {formatMoney(totalMoneySavedFromImpulse)}
          </div>
          <p className="text-[11px] text-emerald-600 font-medium">
            {language === 'bn'
              ? `${droppedCount}টি ইচ্ছা বাদ দিয়ে টাকা বাঁচিয়েছেন`
              : `Saved by dropping ${droppedCount} impulse wants`}
          </p>
        </div>

        {/* In Cooling Card */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 space-y-1 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              {language === 'bn' ? 'অপেক্ষমাণ ইচ্ছা' : 'In Cooling Period'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-indigo-50 flex items-center justify-center text-indigo-600">
              <Hourglass className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-2xl font-extrabold font-mono tabular-nums text-slate-800">
            {coolingCount}
          </div>
          <p className="text-[11px] text-slate-400">
            {language === 'bn' ? 'কাউন্টডাউন চলছে' : 'Timer counting down'}
          </p>
        </div>

        {/* Ready for Decision Card */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 space-y-1 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-amber-800">
              {language === 'bn' ? 'সিদ্ধান্ত নেওয়ার সময়' : 'Ready to Decide'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-amber-50 flex items-center justify-center text-amber-600">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-2xl font-extrabold font-mono tabular-nums text-amber-700">
            {readyCount}
          </div>
          <p className="text-[11px] text-amber-600 font-medium">
            {language === 'bn' ? '৩০ দিন শেষ, ভাবুন কিনবেন কিনা' : 'Delay complete! Time to decide'}
          </p>
        </div>

        {/* Purchased Card */}
        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 space-y-1 shadow-xs">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-slate-600">
              {language === 'bn' ? 'সুচিন্তিত কেনাকাটা' : 'Mindfully Bought'}
            </span>
            <div className="w-7 h-7 rounded-lg bg-slate-100 flex items-center justify-center text-slate-600">
              <ShoppingBag className="w-4 h-4" />
            </div>
          </div>
          <div className="text-lg sm:text-2xl font-extrabold font-mono tabular-nums text-slate-800">
            {purchasedCount}
          </div>
          <p className="text-[11px] text-slate-400">
            {language === 'bn' ? 'কুলিং শেষে কেনা হয়েছে' : 'Bought after deliberation'}
          </p>
        </div>

      </div>

      {/* Filter Tabs, Search & Sort Bar */}
      <div className="bg-white border border-slate-200/80 rounded-2xl p-3 sm:p-4 space-y-3 shadow-xs">
        <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
          
          {/* Segmented Filter Buttons */}
          <div className="flex items-center gap-1 overflow-x-auto p-1 bg-slate-100/80 rounded-xl no-scrollbar">
            <button
              onClick={() => setActiveFilter('all')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeFilter === 'all'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'সবগুলো' : 'All'} ({wishlistItems.length})
            </button>
            <button
              onClick={() => setActiveFilter('cooling')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeFilter === 'cooling'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'অপেক্ষমাণ' : 'Cooling'} ({coolingCount})
            </button>
            <button
              onClick={() => setActiveFilter('ready')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeFilter === 'ready'
                  ? 'bg-white text-amber-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'সিদ্ধান্ত নিন' : 'Ready'} ({readyCount})
            </button>
            <button
              onClick={() => setActiveFilter('dropped')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeFilter === 'dropped'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'টাকা বাঁচলো' : 'Saved'} ({droppedCount})
            </button>
            <button
              onClick={() => setActiveFilter('purchased')}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg transition-all whitespace-nowrap ${
                activeFilter === 'purchased'
                  ? 'bg-white text-slate-900 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'কেনা হয়েছে' : 'Bought'} ({purchasedCount})
            </button>
          </div>

          {/* Search & Sort */}
          <div className="flex items-center gap-2">
            <div className="relative flex-1 sm:w-56">
              <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                placeholder={language === 'bn' ? 'খুঁজুন...' : 'Search items...'}
                className="w-full pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="relative shrink-0">
              <select
                value={sortBy}
                onChange={e => setSortBy(e.target.value as any)}
                className="px-2.5 py-1.5 text-xs font-semibold bg-slate-50 border border-slate-200 rounded-xl text-slate-700 focus:outline-hidden"
              >
                <option value="days">{language === 'bn' ? 'বাকি দিন অনুযায়ী' : 'Days Remaining'}</option>
                <option value="price_desc">{language === 'bn' ? 'বেশি দাম আগে' : 'Price: High to Low'}</option>
                <option value="price_asc">{language === 'bn' ? 'কম দাম আগে' : 'Price: Low to High'}</option>
                <option value="date_desc">{language === 'bn' ? 'যুক্ত করার তারিখ' : 'Recently Added'}</option>
              </select>
            </div>
          </div>

        </div>
      </div>

      {/* Items List */}
      {processedItems.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-2xl p-10 text-center space-y-3">
          <div className="w-12 h-12 rounded-full bg-slate-100 flex items-center justify-center text-slate-400 mx-auto">
            <Hourglass className="w-6 h-6" />
          </div>
          <h3 className="text-base font-bold text-slate-800">
            {language === 'bn' ? 'কোনো উইশলিস্ট আইটেম পাওয়া যায়নি' : 'No wishlist items found'}
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            {language === 'bn'
              ? 'নতুন কোনো পণ্য কেনার ইচ্ছা হলে ৩০ দিনের নিয়ম দিয়ে এখানে যোগ করুন।'
              : 'Add an item you desire with a 30-day delay to prevent impulse spending.'}
          </p>
          <button
            onClick={handleOpenAdd}
            className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'bn' ? 'প্রথম ইচ্ছা যোগ করুন' : 'Add First Item'}</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {processedItems.map(item => {
            const daysInfo = getItemDaysInfo(item);
            const cat = getCategory(item.categoryId);
            const acc = getAccount(item.accountId);

            const isCooling = item.status === 'cooling' && !daysInfo.isReady;
            const isReady = item.status === 'ready' || (item.status === 'cooling' && daysInfo.isReady);
            const isDropped = item.status === 'dropped';
            const isPurchased = item.status === 'purchased';

            return (
              <div
                key={item.id}
                className={`bg-white border rounded-2xl p-4 sm:p-5 flex flex-col justify-between space-y-4 shadow-xs transition-all ${
                  isReady
                    ? 'border-amber-300 ring-2 ring-amber-400/20'
                    : isDropped
                    ? 'border-emerald-200 bg-emerald-50/20'
                    : isPurchased
                    ? 'border-slate-200 opacity-90'
                    : 'border-slate-200/90 hover:border-slate-300'
                }`}
              >
                {/* Top Row: Title, Price, Status Tag */}
                <div>
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="text-base font-bold text-slate-900 leading-snug">
                          {item.title}
                        </h3>
                        {item.productUrl && (
                          <a
                            href={item.productUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="text-slate-400 hover:text-emerald-600 transition-colors p-0.5"
                            title="Open product link"
                          >
                            <ExternalLink className="w-3.5 h-3.5" />
                          </a>
                        )}
                      </div>

                      {/* Clean Unboxed Metadata with · separator */}
                      <div className="flex items-center gap-2 text-xs text-slate-500 mt-1 flex-wrap">
                        {cat && <span>{language === 'bn' ? cat.nameBn : cat.name}</span>}
                        {cat && <span aria-hidden="true">·</span>}
                        {acc && <span>{language === 'bn' ? acc.nameBn : acc.name}</span>}
                        {acc && <span aria-hidden="true">·</span>}
                        <span>
                          {language === 'bn' ? 'যুক্ত:' : 'Added:'} {item.addedDate} <span className="text-emerald-700 font-semibold">({getBengaliDate(item.addedDate).shortDateBn})</span>
                        </span>
                      </div>
                    </div>

                    {/* Price */}
                    <div className="text-right shrink-0">
                      <div className="text-base sm:text-lg font-extrabold font-mono tabular-nums text-slate-900">
                        {formatMoney(item.estimatedPrice)}
                      </div>
                      <div className="text-[10px] text-slate-400">
                        {language === 'bn' ? 'আনুমানিক বাজেট' : 'Estimated Budget'}
                      </div>
                    </div>
                  </div>

                  {/* Reflection Notes */}
                  {item.notes && (
                    <div className="mt-3 p-2.5 rounded-xl bg-slate-50 text-xs text-slate-600 italic border border-slate-100 leading-relaxed">
                      "{item.notes}"
                    </div>
                  )}

                  {/* Status Banner / Progress */}
                  <div className="mt-3.5">
                    {isCooling && (
                      <div className="space-y-1.5">
                        <div className="flex items-center justify-between text-xs">
                          <span className="font-semibold text-indigo-900 flex items-center gap-1.5">
                            <Hourglass className="w-3.5 h-3.5 text-indigo-600 animate-pulse" />
                            {language === 'bn' ? 'কুলিং পিরিয়ড চলছে:' : 'Cooling Delay:'} {daysInfo.elapsedDays} / {daysInfo.totalDays} {language === 'bn' ? 'দিন' : 'days'}
                          </span>
                          <span className="font-bold font-mono text-indigo-700 tabular-nums">
                            {daysInfo.remainingDays} {language === 'bn' ? 'দিন বাকি' : 'days left'}
                          </span>
                        </div>
                        {/* Progress bar */}
                        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div
                            className="bg-indigo-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${daysInfo.progressPercent}%` }}
                          />
                        </div>
                      </div>
                    )}

                    {isReady && (
                      <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl space-y-1">
                        <div className="flex items-center gap-2 text-amber-900 text-xs font-bold">
                          <Clock className="w-4 h-4 text-amber-600 shrink-0" />
                          <span>
                            {language === 'bn'
                              ? '🎉 ৩০ দিনের বিরতি সমাপ্ত! সিদ্ধান্ত নেওয়ার সময় এসেছে:'
                              : '🎉 30-Day Cooling Complete! Time for conscious decision:'}
                          </span>
                        </div>
                        <p className="text-[11px] text-amber-800 leading-normal">
                          {language === 'bn'
                            ? 'আপনি কি এখনও এটি সমানভাবে কিনতে চাচ্ছেন? যদি উত্তর না হয়, তবে বাদ দিন এবং টাকা সঞ্চয় করুন!'
                            : 'Do you still genuinely need it? If not, drop it and celebrate money saved!'}
                        </p>
                      </div>
                    )}

                    {isDropped && (
                      <div className="p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between text-xs font-semibold text-emerald-900">
                        <span className="flex items-center gap-1.5">
                          <ShieldCheck className="w-4 h-4 text-emerald-600" />
                          {language === 'bn' ? 'অপচয় রোধ হয়েছে!' : 'Impulse avoided!'}
                        </span>
                        <span className="font-mono font-bold text-emerald-700 tabular-nums">
                          +{formatMoney(item.estimatedPrice)} {language === 'bn' ? 'সঞ্চয়' : 'Saved'}
                        </span>
                      </div>
                    )}

                    {isPurchased && (
                      <div className="p-2.5 bg-slate-100 rounded-xl flex items-center justify-between text-xs font-medium text-slate-700">
                        <span className="flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                          {language === 'bn' ? 'সুচিন্তিত সিদ্ধান্ত নিয়ে কেনা হয়েছে' : 'Purchased with conscious intent'}
                        </span>
                        <span className="text-[11px] text-slate-500">
                          {item.decisionDate || item.addedDate}
                        </span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Bottom Row: Score + Interactive Actions */}
                <div className="pt-2 border-t border-slate-100 flex items-center justify-between gap-2 flex-wrap">
                  
                  {/* Necessity Score indicator */}
                  <div className="flex items-center gap-1 text-[11px] text-slate-500">
                    <span className="font-semibold">{language === 'bn' ? 'প্রয়োজন:' : 'Need:'}</span>
                    <div className="flex gap-0.5">
                      {[1, 2, 3, 4, 5].map(star => (
                        <div
                          key={star}
                          className={`w-2 h-2 rounded-full ${
                            star <= (item.necessityScore || 3)
                              ? 'bg-amber-400'
                              : 'bg-slate-200'
                          }`}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex items-center gap-1.5">
                    {/* If cooling or ready, show Drop and Purchase actions */}
                    {(isCooling || isReady) && (
                      <>
                        <button
                          onClick={() => handleDrop(item)}
                          className="px-2.5 py-1.5 rounded-lg border border-slate-200 hover:bg-rose-50 hover:text-rose-700 text-slate-600 text-xs font-semibold transition-colors flex items-center gap-1"
                          title={language === 'bn' ? 'বাদ দিন ও টাকা বাঁচান' : 'Drop & Save Money'}
                        >
                          <XCircle className="w-3.5 h-3.5 text-rose-500" />
                          <span className="hidden sm:inline">{language === 'bn' ? 'বাদ দিন' : 'Drop'}</span>
                        </button>

                        <button
                          onClick={() => {
                            setPurchaseConfirmItem(item);
                            setSelectedWalletId(item.accountId || accounts[0]?.id || '');
                          }}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all flex items-center gap-1 shadow-xs active:scale-95 ${
                            isReady
                              ? 'bg-emerald-600 hover:bg-emerald-700 text-white'
                              : 'bg-slate-800 hover:bg-slate-900 text-white'
                          }`}
                        >
                          <CheckCircle2 className="w-3.5 h-3.5" />
                          <span>{language === 'bn' ? 'কিনে ফেলেছি' : 'Bought'}</span>
                        </button>
                      </>
                    )}

                    {/* Edit & Delete */}
                    <button
                      onClick={() => handleEdit(item)}
                      className="p-1.5 text-slate-400 hover:text-slate-700 hover:bg-slate-100 rounded-lg transition-colors"
                      title={language === 'bn' ? 'এডিট' : 'Edit'}
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    <button
                      onClick={() => deleteWishlistItem(item.id)}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                      title={language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Educational Behavioral Guide: 30-Day Rule */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 text-white rounded-2xl p-5 sm:p-6 shadow-md space-y-4">
        <div className="flex items-start justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400">
              {language === 'bn' ? 'আর্থিক পরামর্শ ও বৈজ্ঞানিক কৌশল' : 'Behavioral Finance Principle'}
            </span>
            <h2 className="text-base sm:text-lg font-bold">
              {language === 'bn'
                ? 'কীভাবে ৩০ দিনের নিয়ম (30-Day Delay Rule) লাখ টাকা বাঁচায়?'
                : 'How the 30-Day Rule Prevents Impulse Spending?'}
            </h2>
          </div>
          <div className="w-10 h-10 rounded-xl bg-white/10 flex items-center justify-center shrink-0">
            <Sparkles className="w-5 h-5 text-emerald-400" />
          </div>
        </div>

        <p className="text-xs sm:text-sm text-slate-300 leading-relaxed max-w-3xl">
          {language === 'bn'
            ? 'যখন আমরা কোনো আকর্ষণীয় জিনিস দেখি, মস্তিষ্কে ডোপামিন হরমোন ক্ষরণের কারণে তাৎক্ষণিক কেনার তীব্র তাড়না তৈরি হয়। কিন্তু ৩০ দিন বিরতি দিলে ওই সাময়িক আবেগ কেটে যায় এবং যৌক্তিক মন সক্রিয় হয়। বিশ্বজুড়ে মানুষ ৩০ দিনের নিয়মের মাধ্যমে তাদের শখের খরচের প্রায় ৬০% অর্থ অপচয় হওয়া থেকে রক্ষা করেন।'
            : 'Immediate buying triggers an impulsive dopamine surge. Delaying non-essential desires for 30 days lets the emotional urge dissipate and rational thinking take over. Most people end up skipping 60% of impulse wants, preserving significant savings.'}
        </p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2 border-t border-slate-700/80">
          <div className="bg-white/5 border border-white/10 rounded-xl p-3 space-y-1">
            <div className="text-xs font-bold text-emerald-400">১. চাহিদা নাকি শখ?</div>
            <p className="text-[11px] text-slate-300">
              {language === 'bn'
                ? 'এটা ছাড়া কি আমার বর্তমান কাজ ঠিকঠাক চলছে?'
                : 'Is my life functioning perfectly fine without it right now?'}
            </p>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-3 space-y-1">
            <div className="text-xs font-bold text-emerald-400">২. বিকল্প কি আছে?</div>
            <p className="text-[11px] text-slate-300">
              {language === 'bn'
                ? 'এই টাকা দিয়ে কি ভবিষ্যৎ জরুরি তহবিল বা সঞ্চয় বাড়ানো বেশি জরুরি?'
                : 'Could this capital be better deployed into emergency funds or investments?'}
            </p>
          </div>
          <div className="bg-white/5 border border-white/10 rounded-xl p-3 space-y-1">
            <div className="text-xs font-bold text-emerald-400">৩. দীর্ঘমেয়াদী মূল্য?</div>
            <p className="text-[11px] text-slate-300">
              {language === 'bn'
                ? '৩ মাস পরেও কি এটা সমান দরকারী থাকবে, নাকি আলমারিতে পড়ে থাকবে?'
                : 'Will this item still retain utility 3 months from now, or collect dust?'}
            </p>
          </div>
        </div>
      </div>

      {/* Confirmation Modal for Marking as Purchased */}
      {purchaseConfirmItem && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setPurchaseConfirmItem(null);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div
            className="bg-white rounded-2xl max-w-md w-full p-5 sm:p-6 shadow-2xl space-y-4 animate-in zoom-in-95 duration-150 max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  {language === 'bn' ? 'কেনার হিসাব সংরক্ষণ করুন' : 'Confirm Mindful Purchase'}
                </h3>
                <p className="text-xs text-slate-500">
                  {language === 'bn' ? 'এটি স্বয়ংক্রিয়ভাবে ট্রানজেকশনে যোগ হবে' : 'This will be added as an expense'}
                </p>
              </div>
            </div>

            <div className="p-3 bg-slate-50 rounded-xl space-y-1 text-xs">
              <div className="flex justify-between text-slate-600">
                <span>{language === 'bn' ? 'পণ্য:' : 'Item:'}</span>
                <span className="font-bold text-slate-800">{purchaseConfirmItem.title}</span>
              </div>
              <div className="flex justify-between text-slate-600">
                <span>{language === 'bn' ? 'টাকার পরিমাণ:' : 'Amount:'}</span>
                <span className="font-mono font-bold text-emerald-700">{formatMoney(purchaseConfirmItem.estimatedPrice)}</span>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'কোন অ্যাকাউন্ট থেকে টাকা পরিশোধ করেছেন?' : 'Paid from which account?'}
              </label>
              <select
                value={selectedWalletId}
                onChange={e => setSelectedWalletId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20"
              >
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>
                    {language === 'bn' ? acc.nameBn : acc.name} ({formatMoney(acc.balance)})
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setPurchaseConfirmItem(null)}
                className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-600 hover:bg-slate-100"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleConfirmPurchase}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{language === 'bn' ? 'নিশ্চিত ও খরচ যোগ করুন' : 'Confirm & Log Expense'}</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Add / Edit Modal */}
      <WishlistModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingItem(null);
        }}
        editItem={editingItem}
      />

      {/* "Can I Afford This?" Readiness Modal */}
      <CanIAffordThisModal
        isOpen={isAffordModalOpen}
        onClose={() => setIsAffordModalOpen(false)}
      />
    </div>
  );
};
