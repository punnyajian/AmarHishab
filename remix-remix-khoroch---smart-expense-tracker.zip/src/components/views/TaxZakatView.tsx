import React, { useState, useMemo } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import {
  Scale,
  Calculator,
  Receipt,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Coins,
  Landmark,
  Sparkles,
  Info,
  Copy,
  Printer,
  RefreshCw,
  Building2,
  HelpCircle,
  Check,
  Wallet,
  ArrowRight,
  HandCoins,
  BadgePercent,
  FileText,
} from 'lucide-react';
import confetti from 'canvas-confetti';

type CalculatorTab = 'tax' | 'zakat';

// Taxpayer categories under Bangladesh Finance Act
type TaxpayerCategory = 'general' | 'female_senior' | 'disabled_third' | 'freedom_fighter';

// Location for minimum tax
type MinimumTaxLocation = 'dhaka_ctg_cc' | 'other_cc' | 'non_cc';

export const TaxZakatView: React.FC = () => {
  const {
    accounts,
    investments,
    debts,
    goldMarketRates,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const [activeTab, setActiveTab] = useState<CalculatorTab>('tax');
  const [copyFeedback, setCopyFeedback] = useState<string | null>(null);

  // =========================================================================
  // BANGLADESH INCOME TAX ESTIMATOR STATE (FY 2024-2025 / 2025-2026)
  // =========================================================================
  const [taxpayerCategory, setTaxpayerCategory] = useState<TaxpayerCategory>('general');
  const [disabledChildrenCount, setDisabledChildrenCount] = useState<number>(0);
  const [minimumTaxLocation, setMinimumTaxLocation] = useState<MinimumTaxLocation>('dhaka_ctg_cc');

  // Income Sources
  const [basicSalary, setBasicSalary] = useState<number>(600000); // 50,000/mo
  const [houseRentAllowance, setHouseRentAllowance] = useState<number>(240000); // 20,000/mo
  const [medicalAllowance, setMedicalAllowance] = useState<number>(60000); // 5,000/mo
  const [conveyanceAllowance, setConveyanceAllowance] = useState<number>(36000); // 3,000/mo
  const [festivalBonus, setFestivalBonus] = useState<number>(100000); // 2 bonuses
  const [houseRentIncome, setHouseRentIncome] = useState<number>(0); // Rental income
  const [businessIncome, setBusinessIncome] = useState<number>(0); // Business/Profession
  const [bankInterestSanchay, setBankInterestSanchay] = useState<number>(25000); // Interest/Dividends
  const [otherIncome, setOtherIncome] = useState<number>(0);

  // Investments for Tax Rebate (Section 78)
  const [dpsInvestment, setDpsInvestment] = useState<number>(120000); // Max 1,20,000 allowed
  const [sanchayapatraInvestment, setSanchayapatraInvestment] = useState<number>(100000);
  const [lifeInsurancePremium, setLifeInsurancePremium] = useState<number>(20000);
  const [providentFund, setProvidentFund] = useState<number>(60000);
  const [stockInvestment, setStockInvestment] = useState<number>(50000);
  const [benevolentFund, setBenevolentFund] = useState<number>(5000);

  // Advance Tax / AIT Deducted
  const [advanceTaxDeducted, setAdvanceTaxDeducted] = useState<number>(10000);

  // =========================================================================
  // ISLAMIC ZAKAT CALCULATOR STATE
  // =========================================================================
  const [nisabStandard, setNisabStandard] = useState<'silver' | 'gold'>('silver');
  const [customGoldBhoriRate, setCustomGoldBhoriRate] = useState<number>(() => {
    return goldMarketRates.price22k || 140000;
  });
  const [customSilverBhoriRate, setCustomSilverBhoriRate] = useState<number>(() => {
    return 2200;
  });

  // Zakatable Assets
  const [zakatCashAndBank, setZakatCashAndBank] = useState<number>(180000);
  const [zakatGoldValue, setZakatGoldValue] = useState<number>(250000);
  const [zakatSilverValue, setZakatSilverValue] = useState<number>(15000);
  const [zakatBusinessInventory, setZakatBusinessInventory] = useState<number>(0);
  const [zakatSharesInvestments, setZakatSharesInvestments] = useState<number>(120000);
  const [zakatReceivables, setZakatReceivables] = useState<number>(25000);
  const [zakatOtherAssets, setZakatOtherAssets] = useState<number>(0);

  // Liabilities
  const [zakatImmediateDebts, setZakatImmediateDebts] = useState<number>(30000);
  const [zakatUnpaidBills, setZakatUnpaidBills] = useState<number>(12000);

  // =========================================================================
  // AUTO-FILL HELPERS FROM KHOROCH REAL DATA
  // =========================================================================
  const handleAutoFillZakatFromKhoroch = () => {
    // 1. Total cash and bank balances
    const totalCashBank = accounts.reduce((sum, acc) => sum + (acc.balance > 0 ? acc.balance : 0), 0);
    setZakatCashAndBank(totalCashBank);

    // 2. Gold assets
    const goldItems = investments.filter(i => i.type === 'gold');
    const goldVal = goldItems.reduce((sum, g) => sum + (g.currentValue || 0), 0);
    setZakatGoldValue(goldVal);

    // 3. Investments (DPS & Sanchayapatra & Shares)
    const financialInvestments = investments.filter(i => i.type !== 'gold');
    const invVal = financialInvestments.reduce((sum, i) => sum + (i.currentValue || i.investedAmount || 0), 0);
    setZakatSharesInvestments(invVal);

    // 4. Receivables (Money I Lent - পাবো)
    const lentDebts = debts.filter(d => d.type === 'lent' && !d.settled);
    const totalLent = lentDebts.reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);
    setZakatReceivables(totalLent);

    // 5. Immediate Debts (Money I Borrowed - দিতে হবে)
    const borrowedDebts = debts.filter(d => d.type === 'borrowed' && !d.settled);
    const totalBorrowed = borrowedDebts.reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);
    setZakatImmediateDebts(totalBorrowed);

    confetti({ particleCount: 30, spread: 60, origin: { y: 0.7 } });
    showCopyFeedback(language === 'bn' ? 'খরচ অ্যাপের ডাটা থেকে পূরণ করা হয়েছে!' : 'Auto-filled from your Khoroch records!');
  };

  const handleAutoFillTaxInvestmentsFromKhoroch = () => {
    // Check DPS
    const dpsItems = investments.filter(i => i.type === 'dps');
    const annualDPSDeposit = dpsItems.reduce((sum, d) => sum + ((d.monthlyInstallment || 0) * 12), 0);
    // Cap at 1,20,000 for tax rebate
    setDpsInvestment(Math.min(120000, annualDPSDeposit || 120000));

    // Check Sanchayapatra
    const sanchayItems = investments.filter(i => i.type === 'sanchayapatra');
    const sanchayTotal = sanchayItems.reduce((sum, s) => sum + s.investedAmount, 0);
    setSanchayapatraInvestment(sanchayTotal || 100000);

    confetti({ particleCount: 25, spread: 50, origin: { y: 0.7 } });
    showCopyFeedback(language === 'bn' ? 'আপনার ইনভেস্টমেন্ট থেকে বিনিয়োগের তথ্য আপডেট হয়েছে!' : 'Investments loaded from your portfolio!');
  };

  const showCopyFeedback = (msg: string) => {
    setCopyFeedback(msg);
    setTimeout(() => setCopyFeedback(null), 3500);
  };

  // =========================================================================
  // BANGLADESH INCOME TAX CALCULATION ENGINE (NBR Rules)
  // =========================================================================
  const taxCalculations = useMemo(() => {
    // 1. Base Tax-Free Threshold
    let threshold = 350000; // General Male
    if (taxpayerCategory === 'female_senior') {
      threshold = 400000;
    } else if (taxpayerCategory === 'disabled_third') {
      threshold = 475000;
    } else if (taxpayerCategory === 'freedom_fighter') {
      threshold = 500000;
    }

    // Additional allowance for parents of disabled children: 50,000 per child
    if (disabledChildrenCount > 0) {
      threshold += disabledChildrenCount * 50000;
    }

    // 2. Minimum Tax according to location
    let minimumTaxAmount = 5000; // Dhaka/Ctg City Corp
    if (minimumTaxLocation === 'other_cc') {
      minimumTaxAmount = 4000;
    } else if (minimumTaxLocation === 'non_cc') {
      minimumTaxAmount = 3000;
    }

    // 3. Gross Salary and Standard Deduction
    // Under new Income Tax Act 2023, standard deduction for salary:
    // Lower of 1/3 of total salary or 4,50,000
    const grossSalary = basicSalary + houseRentAllowance + medicalAllowance + conveyanceAllowance + festivalBonus;
    const salaryDeduction = Math.min(grossSalary / 3, 450000);
    const taxableSalary = Math.max(0, grossSalary - salaryDeduction);

    // 4. House Property Rental Taxable
    // 25% repair and maintenance allowance on gross rent
    const netHousePropertyTaxable = Math.max(0, houseRentIncome * 0.75);

    // 5. Total Taxable Income
    const totalTaxableIncome = Math.round(
      taxableSalary +
      netHousePropertyTaxable +
      businessIncome +
      bankInterestSanchay +
      otherIncome
    );

    // 6. Tax Slabs Computation
    // Slabs:
    // First: threshold @ 0%
    // Next 1,00,000 @ 5%
    // Next 4,00,000 @ 10%
    // Next 5,00,000 @ 15%
    // Next 5,00,000 @ 20%
    // Balance @ 25%

    let remainingIncome = totalTaxableIncome;
    const slabBreakdown: { slabName: string; slabRate: number; taxableInSlab: number; taxAmount: number }[] = [];

    // Slab 1: Tax-free limit
    const slab1Taxable = Math.min(remainingIncome, threshold);
    slabBreakdown.push({
      slabName: language === 'bn' ? `১ম ৳${threshold.toLocaleString('bn-BD')} পর্যন্ত (করমুক্ত সীমা)` : `First ৳${threshold.toLocaleString()} (Exempt)`,
      slabRate: 0,
      taxableInSlab: slab1Taxable,
      taxAmount: 0,
    });
    remainingIncome -= slab1Taxable;

    // Slab 2: Next 1,00,000 @ 5%
    let slab2Taxable = 0;
    let slab2Tax = 0;
    if (remainingIncome > 0) {
      slab2Taxable = Math.min(remainingIncome, 100000);
      slab2Tax = Math.round(slab2Taxable * 0.05);
      slabBreakdown.push({
        slabName: language === 'bn' ? 'পরবর্তী ৳১,০০,০০০ পর্যন্ত' : 'Next ৳1,00,000',
        slabRate: 5,
        taxableInSlab: slab2Taxable,
        taxAmount: slab2Tax,
      });
      remainingIncome -= slab2Taxable;
    }

    // Slab 3: Next 4,00,000 @ 10%
    let slab3Taxable = 0;
    let slab3Tax = 0;
    if (remainingIncome > 0) {
      slab3Taxable = Math.min(remainingIncome, 400000);
      slab3Tax = Math.round(slab3Taxable * 0.10);
      slabBreakdown.push({
        slabName: language === 'bn' ? 'পরবর্তী ৳৪,০০,০০০ পর্যন্ত' : 'Next ৳4,00,000',
        slabRate: 10,
        taxableInSlab: slab3Taxable,
        taxAmount: slab3Tax,
      });
      remainingIncome -= slab3Taxable;
    }

    // Slab 4: Next 5,00,000 @ 15%
    let slab4Taxable = 0;
    let slab4Tax = 0;
    if (remainingIncome > 0) {
      slab4Taxable = Math.min(remainingIncome, 500000);
      slab4Tax = Math.round(slab4Taxable * 0.15);
      slabBreakdown.push({
        slabName: language === 'bn' ? 'পরবর্তী ৳৫,০০,০০০ পর্যন্ত' : 'Next ৳5,00,000',
        slabRate: 15,
        taxableInSlab: slab4Taxable,
        taxAmount: slab4Tax,
      });
      remainingIncome -= slab4Taxable;
    }

    // Slab 5: Next 5,00,000 @ 20%
    let slab5Taxable = 0;
    let slab5Tax = 0;
    if (remainingIncome > 0) {
      slab5Taxable = Math.min(remainingIncome, 500000);
      slab5Tax = Math.round(slab5Taxable * 0.20);
      slabBreakdown.push({
        slabName: language === 'bn' ? 'পরবর্তী ৳৫,০০,০০০ পর্যন্ত' : 'Next ৳5,00,000',
        slabRate: 20,
        taxableInSlab: slab5Taxable,
        taxAmount: slab5Tax,
      });
      remainingIncome -= slab5Taxable;
    }

    // Slab 6: Balance @ 25%
    let slab6Taxable = 0;
    let slab6Tax = 0;
    if (remainingIncome > 0) {
      slab6Taxable = remainingIncome;
      slab6Tax = Math.round(slab6Taxable * 0.25);
      slabBreakdown.push({
        slabName: language === 'bn' ? 'অবশিষ্ট আয়ের ওপর' : 'Remaining Balance',
        slabRate: 25,
        taxableInSlab: slab6Taxable,
        taxAmount: slab6Tax,
      });
      remainingIncome = 0;
    }

    const grossTax = slabBreakdown.reduce((sum, s) => sum + s.taxAmount, 0);

    // 7. Investment Tax Rebate (Section 78)
    // Eligible investment: DPS (capped at 1,20,000) + Sanchayapatra + Life Insurance + Provident Fund + Stocks + Benevolent
    const eligibleDps = Math.min(dpsInvestment, 120000);
    const totalEligibleInvestment = eligibleDps + sanchayapatraInvestment + lifeInsurancePremium + providentFund + stockInvestment + benevolentFund;

    // Rebate is minimum of:
    // a) 15% of eligible investment
    // b) 3% of total taxable income
    // c) ৳10,00,000 cap
    const rebateByInvestment = totalEligibleInvestment * 0.15;
    const rebateByIncome = totalTaxableIncome * 0.03;
    const maxRebateCap = 1000000;
    const calculatedRebate = totalEligibleInvestment > 0 ? Math.round(Math.min(rebateByInvestment, rebateByIncome, maxRebateCap)) : 0;

    // 8. Net Tax Calculation with Minimum Tax and AIT
    let taxAfterRebate = Math.max(0, grossTax - calculatedRebate);

    // Apply minimum tax if taxable income > threshold
    let taxWithMinimum = taxAfterRebate;
    let minimumTaxApplied = false;
    if (totalTaxableIncome > threshold) {
      if (taxWithMinimum < minimumTaxAmount) {
        taxWithMinimum = minimumTaxAmount;
        minimumTaxApplied = true;
      }
    } else {
      taxWithMinimum = 0;
    }

    // Net Payable after Advance Tax (AIT)
    const netPayableTax = Math.max(0, taxWithMinimum - advanceTaxDeducted);
    const refundAmount = advanceTaxDeducted > taxWithMinimum ? advanceTaxDeducted - taxWithMinimum : 0;

    const effectiveTaxRate = totalTaxableIncome > 0 ? ((taxWithMinimum / totalTaxableIncome) * 100).toFixed(2) : '0.00';

    return {
      threshold,
      minimumTaxAmount,
      grossSalary,
      salaryDeduction,
      taxableSalary,
      totalTaxableIncome,
      slabBreakdown,
      grossTax,
      totalEligibleInvestment,
      calculatedRebate,
      taxAfterRebate,
      minimumTaxApplied,
      taxWithMinimum,
      netPayableTax,
      refundAmount,
      effectiveTaxRate,
    };
  }, [
    taxpayerCategory,
    disabledChildrenCount,
    minimumTaxLocation,
    basicSalary,
    houseRentAllowance,
    medicalAllowance,
    conveyanceAllowance,
    festivalBonus,
    houseRentIncome,
    businessIncome,
    bankInterestSanchay,
    otherIncome,
    dpsInvestment,
    sanchayapatraInvestment,
    lifeInsurancePremium,
    providentFund,
    stockInvestment,
    benevolentFund,
    advanceTaxDeducted,
    language,
  ]);

  // =========================================================================
  // ISLAMIC ZAKAT CALCULATION ENGINE (Shariah Nisab & Net Assets)
  // =========================================================================
  const zakatCalculations = useMemo(() => {
    // 1. Nisab Threshold Calculation:
    // Gold Nisab: 7.5 Bhori (87.48 grams)
    // Silver Nisab: 52.5 Bhori (612.36 grams)
    const goldNisabValue = Math.round(7.5 * customGoldBhoriRate);
    const silverNisabValue = Math.round(52.5 * customSilverBhoriRate);

    const activeNisabThreshold = nisabStandard === 'silver' ? silverNisabValue : goldNisabValue;

    // 2. Total Zakatable Assets
    const totalAssets =
      zakatCashAndBank +
      zakatGoldValue +
      zakatSilverValue +
      zakatBusinessInventory +
      zakatSharesInvestments +
      zakatReceivables +
      zakatOtherAssets;

    // 3. Deductible Liabilities (debts due immediately, urgent bills)
    const totalLiabilities = zakatImmediateDebts + zakatUnpaidBills;

    // 4. Net Zakatable Wealth
    const netZakatableWealth = Math.max(0, totalAssets - totalLiabilities);

    // 5. Is Zakat Obligatory? (Hawlan al-Hawl / 1 Lunar Year over Nisab)
    const isZakatObligatory = netZakatableWealth >= activeNisabThreshold;

    // 6. Zakat Amount: 2.5% (1/40th of net zakatable wealth)
    const zakatAmount = isZakatObligatory ? Math.round(netZakatableWealth * 0.025) : 0;

    return {
      goldNisabValue,
      silverNisabValue,
      activeNisabThreshold,
      totalAssets,
      totalLiabilities,
      netZakatableWealth,
      isZakatObligatory,
      zakatAmount,
    };
  }, [
    nisabStandard,
    customGoldBhoriRate,
    customSilverBhoriRate,
    zakatCashAndBank,
    zakatGoldValue,
    zakatSilverValue,
    zakatBusinessInventory,
    zakatSharesInvestments,
    zakatReceivables,
    zakatOtherAssets,
    zakatImmediateDebts,
    zakatUnpaidBills,
  ]);

  // Copy Summary text for easy sharing or filing
  const handleCopySummary = () => {
    if (activeTab === 'tax') {
      const summary = `
========================================
📋 বাংলাদেশ আয়কর বিবরণী (FY 2024-2025)
========================================
করদাতার শ্রেণি: ${
        taxpayerCategory === 'general'
          ? 'সাধারণ করদাতা'
          : taxpayerCategory === 'female_senior'
          ? 'মহিলা ও ৬৫+ প্রবীণ'
          : 'প্রতিবন্ধী/গেজেটভুক্ত'
      }
করমুক্ত আয়ের সীমা: ${currency.symbol}${taxCalculations.threshold.toLocaleString()}
মোট করযোগ্য বার্ষিক আয়: ${currency.symbol}${taxCalculations.totalTaxableIncome.toLocaleString()}
----------------------------------------
মোট ধার্যকৃত গ্রস ট্যাক্স: ${currency.symbol}${taxCalculations.grossTax.toLocaleString()}
বিনিয়োগ কর রেয়াত (সেকশন ৭৮): -${currency.symbol}${taxCalculations.calculatedRebate.toLocaleString()}
অগ্রিম কেটে রাখা কর (AIT): -${currency.symbol}${advanceTaxDeducted.toLocaleString()}
----------------------------------------
চূড়ান্ত প্রদেয় নিট আয়কর: ${currency.symbol}${taxCalculations.netPayableTax.toLocaleString()}
কার্যকর করের হার: ${taxCalculations.effectiveTaxRate}%
${taxCalculations.refundAmount > 0 ? `(ফেরতযোগ্য বা রিফান্ড দাবী: ${currency.symbol}${taxCalculations.refundAmount.toLocaleString()})` : ''}
========================================
হিসাব প্রস্তুতকারক: খরচ (Khoroch) স্মার্ট অ্যাপ
      `.trim();
      navigator.clipboard.writeText(summary);
      showCopyFeedback(language === 'bn' ? 'আয়কর বিবরণী কপি করা হয়েছে!' : 'Tax summary copied to clipboard!');
    } else {
      const summary = `
========================================
🌙 ইসলামিক যাকাত হিসাব বিবরণী (Zakat Summary)
========================================
নিসাব মানদণ্ড: ${nisabStandard === 'silver' ? 'রূপার নিসাব (৫২.৫ ভরি)' : 'স্বর্ণের নিসাব (৭.৫ ভরি)'}
বর্তমান নিসাব মূল্যমান: ${currency.symbol}${zakatCalculations.activeNisabThreshold.toLocaleString()}
----------------------------------------
মোট যাকাতযোগ্য সম্পদ: ${currency.symbol}${zakatCalculations.totalAssets.toLocaleString()}
বাদযোগ্য জরুরি দেনা ও দায়: -${currency.symbol}${zakatCalculations.totalLiabilities.toLocaleString()}
নিট যাকাতযোগ্য সম্পদ: ${currency.symbol}${zakatCalculations.netZakatableWealth.toLocaleString()}
----------------------------------------
যাকাত প্রযোজ্য কি না: ${zakatCalculations.isZakatObligatory ? '✅ যাকাত ফরজ হয়েছে' : '❌ নিসাব পূর্ণ হয়নি'}
প্রদেয় যাকাতের পরিমাণ (২.৫%): ${currency.symbol}${zakatCalculations.zakatAmount.toLocaleString()}
========================================
হিসাব প্রস্তুতকারক: খরচ (Khoroch) স্মার্ট অ্যাপ
      `.trim();
      navigator.clipboard.writeText(summary);
      showCopyFeedback(language === 'bn' ? 'যাকাত হিসাব বিবরণী কপি করা হয়েছে!' : 'Zakat summary copied to clipboard!');
    }
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12 animate-in fade-in duration-200">
      
      {/* Toast Notification */}
      {copyFeedback && (
        <div className="fixed bottom-6 right-6 z-70 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-semibold animate-in slide-in-from-bottom-3 border border-slate-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{copyFeedback}</span>
        </div>
      )}

      {/* Header Banner */}
      <div className="bg-gradient-to-br from-slate-900 via-teal-950 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-sm border border-emerald-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-radial from-emerald-500/10 to-transparent blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-radial from-teal-500/10 to-transparent blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold uppercase tracking-wider">
              <Scale className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'আর্থিক দায়িত্ব ও কর বিধি' : 'Financial Duties & Compliance'}</span>
            </div>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-white tracking-tight">
              {language === 'bn' ? 'যাকাত ও বাংলাদেশ আয়কর ক্যালকুলেটর' : 'Zakat & Bangladesh Income Tax Estimator'}
            </h1>
            <p className="text-slate-300 text-xs sm:text-sm max-w-2xl leading-relaxed">
              {language === 'bn'
                ? 'জাতীয় রাজস্ব বোর্ডের (NBR) ফাইন্যান্স এক্ট ২০২৪-২৫ অনুযায়ী কর স্ল্যাব, স্ট্যান্ডার্ড বেতন ডিডাকশন, সেকশন ৭৮ বিনিয়োগ রেয়াত এবং সহিহ সুন্নাহ মোতাবেক স্বর্ণ/রূপার নিসাবের যাকাত এক ক্লিকে নির্ভুল হিসাব করুন।'
                : 'Accurate estimation according to National Board of Revenue (NBR) Finance Act tax slabs, standard salary deduction, Section 78 rebate, and Shariah-compliant Nisab calculation.'}
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 shrink-0">
            <button
              onClick={handleCopySummary}
              className="px-4 py-2.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white border border-white/15 text-xs font-bold transition-all flex items-center gap-2 shadow-xs cursor-pointer"
            >
              <Copy className="w-4 h-4 text-emerald-300" />
              <span>{language === 'bn' ? 'বিবরণী কপি করুন' : 'Copy Summary'}</span>
            </button>
            <button
              onClick={() => window.print()}
              className="px-4 py-2.5 rounded-2xl bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-black text-xs transition-all flex items-center gap-2 shadow-sm cursor-pointer"
            >
              <Printer className="w-4 h-4" />
              <span>{language === 'bn' ? 'প্রিন্ট রিপোর্ট' : 'Print Statement'}</span>
            </button>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="mt-8 pt-6 border-t border-white/10 flex items-center gap-3">
          <button
            onClick={() => setActiveTab('tax')}
            className={`flex items-center gap-2.5 px-5 py-3 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'tax'
                ? 'bg-emerald-500 text-slate-950 shadow-md scale-102'
                : 'bg-white/10 text-slate-300 hover:bg-white/15 hover:text-white'
            }`}
          >
            <Calculator className="w-4 h-4" />
            <span>{language === 'bn' ? '🇧🇩 বাংলাদেশ আয়কর ক্যালকুলেটর (NBR)' : '🇧🇩 BD Income Tax (NBR)'}</span>
          </button>

          <button
            onClick={() => setActiveTab('zakat')}
            className={`flex items-center gap-2.5 px-5 py-3 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer ${
              activeTab === 'zakat'
                ? 'bg-emerald-500 text-slate-950 shadow-md scale-102'
                : 'bg-white/10 text-slate-300 hover:bg-white/15 hover:text-white'
            }`}
          >
            <Coins className="w-4 h-4" />
            <span>{language === 'bn' ? '🌙 ইসলামিক যাকাত ক্যালকুলেটর' : '🌙 Islamic Zakat Calculator'}</span>
          </button>
        </div>
      </div>

      {/* ========================================================================= */}
      {/* 1. BANGLADESH INCOME TAX ESTIMATOR VIEW */}
      {/* ========================================================================= */}
      {activeTab === 'tax' && (
        <div className="space-y-6">
          
          {/* KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Total Taxable Income */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {language === 'bn' ? 'মোট করযোগ্য বার্ষিক আয়' : 'Total Taxable Income'}
              </span>
              <p className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {formatMoney(taxCalculations.totalTaxableIncome)}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn' ? `করমুক্ত সীমা: ${formatMoney(taxCalculations.threshold)}` : `Tax-free limit: ${formatMoney(taxCalculations.threshold)}`}
              </p>
            </div>

            {/* Gross Tax Before Rebate */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {language === 'bn' ? 'স্ল্যাব অনুযায়ী মোট কর' : 'Gross Tax Payable'}
              </span>
              <p className="text-xl sm:text-2xl font-black text-amber-600 tracking-tight">
                {formatMoney(taxCalculations.grossTax)}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn' ? 'রেয়াত ও এআইটি বাদ দেওয়ার পূর্বে' : 'Before rebate & advance tax'}
              </p>
            </div>

            {/* Investment Rebate */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {language === 'bn' ? 'বিনিয়োগ কর রেয়াত (ছা়ড়)' : 'Investment Tax Rebate'}
              </span>
              <p className="text-xl sm:text-2xl font-black text-emerald-600 tracking-tight">
                -{formatMoney(taxCalculations.calculatedRebate)}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn' ? `অনুমোদিত বিনিয়োগ: ${formatMoney(taxCalculations.totalEligibleInvestment)}` : `Eligible investment: ${formatMoney(taxCalculations.totalEligibleInvestment)}`}
              </p>
            </div>

            {/* Net Payable Tax */}
            <div className="bg-gradient-to-br from-emerald-600 to-teal-700 text-white p-5 rounded-3xl shadow-sm space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-emerald-100 uppercase tracking-wider block">
                  {language === 'bn' ? 'চূড়ান্ত প্রদেয় নিট আয়কর' : 'Net Tax Payable'}
                </span>
                <span className="px-2 py-0.5 rounded-full bg-white/20 text-white text-[10px] font-black">
                  {taxCalculations.effectiveTaxRate}% Rate
                </span>
              </div>
              <p className="text-2xl sm:text-3xl font-black tracking-tight">
                {formatMoney(taxCalculations.netPayableTax)}
              </p>
              <p className="text-[11px] text-emerald-100">
                {taxCalculations.minimumTaxApplied
                  ? (language === 'bn' ? `ন্যূনতম কর বিধান (${formatMoney(taxCalculations.minimumTaxAmount)}) প্রযোজ্য` : `Minimum tax of ${formatMoney(taxCalculations.minimumTaxAmount)} applied`)
                  : (taxCalculations.refundAmount > 0
                      ? (language === 'bn' ? `রিফান্ড দাবী: ${formatMoney(taxCalculations.refundAmount)}` : `Refund claim: ${formatMoney(taxCalculations.refundAmount)}`)
                      : (language === 'bn' ? 'অগ্রিম কর (AIT) সমন্বয়ের পর' : 'After AIT deduction adjustment'))}
              </p>
            </div>

          </div>

          {/* Configuration & Inputs Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left 2 Cols: Form Inputs */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* 1. Taxpayer Profile & Location */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <ShieldCheck className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? '১. করদাতার শ্রেণি ও অবস্থান' : '1. Taxpayer Category & Area'}</span>
                  </h3>
                  <span className="text-xs text-slate-400 font-semibold">
                    {language === 'bn' ? 'করমুক্ত আয়ের সীমা নির্ধারণ' : 'Exemption Limit Determination'}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Category */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'bn' ? 'করদাতার ধরন (Category)' : 'Taxpayer Category'}
                    </label>
                    <select
                      value={taxpayerCategory}
                      onChange={e => setTaxpayerCategory(e.target.value as TaxpayerCategory)}
                      className="w-full px-3.5 py-2.5 rounded-2xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    >
                      <option value="general">{language === 'bn' ? 'সাধারণ পুরুষ করদাতা (সীমা ৳৩,৫০,০০০)' : 'General Male (Limit ৳3,50,000)'}</option>
                      <option value="female_senior">{language === 'bn' ? 'মহিলা ও ৬৫+ বছর বয়সী প্রবীণ (সীমা ৳৪,০০,০০০)' : 'Female & Senior 65+ (Limit ৳4,00,000)'}</option>
                      <option value="disabled_third">{language === 'bn' ? 'শারীরিক প্রতিবন্ধী ও ৩য় লিঙ্গ (সীমা ৳৪,৭৫,০০০)' : 'Disabled & Third Gender (Limit ৳4,75,000)'}</option>
                      <option value="freedom_fighter">{language === 'bn' ? 'গেজেটভুক্ত যুদ্ধাহত মুক্তিযোদ্ধা (সীমা ৳৫,০০,০০০)' : 'Gazetted Freedom Fighter (Limit ৳5,00,000)'}</option>
                    </select>
                  </div>

                  {/* Location for Minimum Tax */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'bn' ? 'এলাকা (ন্যূনতম কর প্রযোজ্য)' : 'Minimum Tax Location'}
                    </label>
                    <select
                      value={minimumTaxLocation}
                      onChange={e => setMinimumTaxLocation(e.target.value as MinimumTaxLocation)}
                      className="w-full px-3.5 py-2.5 rounded-2xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    >
                      <option value="dhaka_ctg_cc">{language === 'bn' ? 'ঢাকা ও চট্টগ্রাম সিটি কর্পোরেশন (ন্যূনতম ৳৫,০০০)' : 'Dhaka & Ctg City Corp (Min ৳5,000)'}</option>
                      <option value="other_cc">{language === 'bn' ? 'অন্যান্য সিটি কর্পোরেশন এলাকা (ন্যূনতম ৳৪,০০০)' : 'Other City Corporations (Min ৳4,000)'}</option>
                      <option value="non_cc">{language === 'bn' ? 'সিটি কর্পোরেশনের বাইরে/পৌরসভা/উপজেলা (ন্যূনতম ৳৩,০০০)' : 'Non-City / Upazila (Min ৳3,000)'}</option>
                    </select>
                  </div>

                  {/* Disabled Children */}
                  <div className="sm:col-span-2 flex items-center justify-between p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80">
                    <div>
                      <p className="text-xs font-bold text-slate-800">
                        {language === 'bn' ? 'প্রতিবন্ধী সন্তানের পিতা/মাতা?' : 'Parent of Child with Disability?'}
                      </p>
                      <p className="text-[11px] text-slate-500">
                        {language === 'bn' ? 'প্রতি সন্তানের জন্য অতিরিক্ত ৳৫০,০০০ করমুক্ত সীমা যুক্ত হবে।' : '+৳50,000 extra tax-free exemption per child.'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <button
                        type="button"
                        onClick={() => setDisabledChildrenCount(Math.max(0, disabledChildrenCount - 1))}
                        className="w-8 h-8 rounded-xl bg-white border border-slate-300 font-bold text-slate-700 flex items-center justify-center hover:bg-slate-100"
                      >
                        -
                      </button>
                      <span className="text-sm font-black text-slate-900 w-6 text-center">
                        {disabledChildrenCount}
                      </span>
                      <button
                        type="button"
                        onClick={() => setDisabledChildrenCount(disabledChildrenCount + 1)}
                        className="w-8 h-8 rounded-xl bg-white border border-slate-300 font-bold text-slate-700 flex items-center justify-center hover:bg-slate-100"
                      >
                        +
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* 2. Salary & Annual Income Inputs */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Building2 className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? '২. বার্ষিক আয় ও আয়ের খাতসমূহ' : '2. Annual Income Heads'}</span>
                  </h3>
                  <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-xl">
                    {language === 'bn' ? `স্ট্যান্ডার্ড বেতন ছাড়: -${formatMoney(taxCalculations.salaryDeduction)}` : `Salary deduction: -${formatMoney(taxCalculations.salaryDeduction)}`}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Basic Salary */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'মূল বেতন (Basic Salary)' : 'Basic Salary (Annual)'}
                    </label>
                    <input
                      type="number"
                      value={basicSalary || ''}
                      onChange={e => setBasicSalary(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* House Rent Allowance */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'বাড়ি ভাড়া ভাতা (House Rent Allowance)' : 'House Rent Allowance'}
                    </label>
                    <input
                      type="number"
                      value={houseRentAllowance || ''}
                      onChange={e => setHouseRentAllowance(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Medical Allowance */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'চিকিৎসা ভাতা (Medical Allowance)' : 'Medical Allowance'}
                    </label>
                    <input
                      type="number"
                      value={medicalAllowance || ''}
                      onChange={e => setMedicalAllowance(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Conveyance Allowance */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'যাতায়াত ও অন্যান্য ভাতা' : 'Conveyance & Other Allowances'}
                    </label>
                    <input
                      type="number"
                      value={conveyanceAllowance || ''}
                      onChange={e => setConveyanceAllowance(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Festival Bonus */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'উৎসব ভাতা ও বোনাস (Festival Bonuses)' : 'Festival Bonuses'}
                    </label>
                    <input
                      type="number"
                      value={festivalBonus || ''}
                      onChange={e => setFestivalBonus(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* House Rent Income */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'বাড়ি ভাড়া প্রাপ্তি আয় (House Property Rent)' : 'Rental Income'}
                    </label>
                    <input
                      type="number"
                      value={houseRentIncome || ''}
                      onChange={e => setHouseRentIncome(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                      placeholder="0"
                    />
                  </div>

                  {/* Business / Freelance Income */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'ব্যবসা বা প্রফেশনাল আয় (Business / Profession)' : 'Business / Freelance Income'}
                    </label>
                    <input
                      type="number"
                      value={businessIncome || ''}
                      onChange={e => setBusinessIncome(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                      placeholder="0"
                    />
                  </div>

                  {/* Bank Interest & Sanchayapatra Profit */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'ব্যাংক সুদ ও সঞ্চয়পত্র মুনাফা' : 'Bank Interest & Sanchayapatra'}
                    </label>
                    <input
                      type="number"
                      value={bankInterestSanchay || ''}
                      onChange={e => setBankInterestSanchay(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Advance Tax Deducted */}
                  <div className="sm:col-span-2">
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'আগে কেটে রাখা কর / উৎসে কর কর্তন (AIT / Advance Tax Already Deducted)' : 'Advance Tax / AIT Deducted'}
                    </label>
                    <input
                      type="number"
                      value={advanceTaxDeducted || ''}
                      onChange={e => setAdvanceTaxDeducted(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                      placeholder="0"
                    />
                    <p className="text-[11px] text-slate-500 mt-1">
                      {language === 'bn' ? 'সঞ্চয়পত্র, গাড়ি ফিটনেস বা ব্যাংক মুনাফা থেকে যে ট্যাক্স আগে কেটে নিয়েছে তা চূড়ান্ত কর থেকে বাদ যাবে।' : 'Taxes already withheld at source by banks, sanchayapatra or vehicle registration.'}
                    </p>
                  </div>
                </div>
              </div>

              {/* 3. Section 78 Investment Rebate */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <BadgePercent className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? '৩. অনুমোদনযোগ্য বিনিয়োগ (কর রেয়াত - ধারা ৭৮)' : '3. Section 78 Eligible Investments'}</span>
                  </h3>
                  <button
                    onClick={handleAutoFillTaxInvestmentsFromKhoroch}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200/80 transition-all cursor-pointer self-start sm:self-auto"
                  >
                    <RefreshCw className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'bn' ? 'আমার ইনভেস্টমেন্ট থেকে লোড' : 'Auto-fill from Portfolio'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* DPS */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'ডিপিএস কিস্তি জমা (বার্ষিক সর্বোচ্চ ৳১,২০,০০০)' : 'DPS (Max ৳1,20,000/yr eligible)'}
                    </label>
                    <input
                      type="number"
                      value={dpsInvestment || ''}
                      onChange={e => setDpsInvestment(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Sanchayapatra */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'জাতীয় সঞ্চয়পত্র ক্রয় (Sanchayapatra)' : 'Savings Certificates Purchased'}
                    </label>
                    <input
                      type="number"
                      value={sanchayapatraInvestment || ''}
                      onChange={e => setSanchayapatraInvestment(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Life Insurance */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'জীবন বীমা প্রিমিয়াম (Life Insurance)' : 'Life Insurance Premium'}
                    </label>
                    <input
                      type="number"
                      value={lifeInsurancePremium || ''}
                      onChange={e => setLifeInsurancePremium(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Provident Fund */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'প্রভিডেন্ট ফান্ড / জিপিএফ / সিপিএফ' : 'Provident Fund (GPF/CPF)'}
                    </label>
                    <input
                      type="number"
                      value={providentFund || ''}
                      onChange={e => setProvidentFund(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Stock Market */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'শেয়ার বাজার বিনিয়োগ (Stocks / Mutual Funds)' : 'Listed Stocks / Mutual Funds'}
                    </label>
                    <input
                      type="number"
                      value={stockInvestment || ''}
                      onChange={e => setStockInvestment(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Benevolent Fund */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'সরকারি কল্যাণ ও বেনোভোলেন্ট ফান্ড' : 'Govt. Benevolent Fund'}
                    </label>
                    <input
                      type="number"
                      value={benevolentFund || ''}
                      onChange={e => setBenevolentFund(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                </div>

                <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/60 text-xs text-emerald-950 flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold">
                      {language === 'bn' ? 'এনবিআর কর রেয়াতের নিয়মাবলী:' : 'NBR Tax Rebate Calculation Rules:'}
                    </p>
                    <p className="mt-0.5 leading-relaxed text-emerald-800">
                      {language === 'bn'
                        ? 'মোট অনুমোদিত বিনিয়োগের ১৫%, অথবা মোট করযোগ্য আয়ের ৩%, অথবা সর্বোচ্চ ৳১০,০০,০০০—এই তিনটির মধ্যে যেটি কম হবে, সেটি সরাসরি প্রদেয় কর থেকে ছাড় পাবেন।'
                        : 'Rebate is the lowest of: 15% of eligible investments, 3% of total taxable income, or ৳10,00,000 cap.'}
                    </p>
                  </div>
                </div>
              </div>

            </div>

            {/* Right 1 Col: Complete Slab Breakdown & Final Statement */}
            <div className="space-y-6">
              
              {/* Slab Breakdown Card */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'bn' ? 'আয়কর স্ল্যাব বিবরণী' : 'Tax Slab Breakdown'}</span>
                  </h3>
                  <span className="text-[11px] font-bold text-slate-400 uppercase">
                    FY 2024-25
                  </span>
                </div>

                <div className="space-y-2.5">
                  {taxCalculations.slabBreakdown.map((slab, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-2xl bg-slate-50 border border-slate-200/60 flex items-center justify-between text-xs"
                    >
                      <div>
                        <p className="font-bold text-slate-800">{slab.slabName}</p>
                        <p className="text-[11px] text-slate-500">
                          {formatMoney(slab.taxableInSlab)} @ {slab.slabRate}%
                        </p>
                      </div>
                      <span className="font-black text-slate-900 text-sm">
                        {formatMoney(slab.taxAmount)}
                      </span>
                    </div>
                  ))}
                </div>

                {/* Calculation Summary Table */}
                <div className="pt-3 border-t border-slate-100 space-y-2 text-xs">
                  <div className="flex items-center justify-between text-slate-600">
                    <span>{language === 'bn' ? 'মোট গ্রস কর (Gross Tax)' : 'Gross Tax'}</span>
                    <span className="font-bold text-slate-900">{formatMoney(taxCalculations.grossTax)}</span>
                  </div>

                  <div className="flex items-center justify-between text-emerald-700">
                    <span>{language === 'bn' ? 'বিনিয়োগ কর রেয়াত (Rebate)' : 'Investment Rebate'}</span>
                    <span className="font-bold">-{formatMoney(taxCalculations.calculatedRebate)}</span>
                  </div>

                  {taxCalculations.minimumTaxApplied && (
                    <div className="flex items-center justify-between text-amber-700">
                      <span>{language === 'bn' ? 'ন্যূনতম কর সমন্বয়' : 'Min. Tax Adjustment'}</span>
                      <span className="font-bold">+{formatMoney(taxCalculations.minimumTaxAmount - taxCalculations.taxAfterRebate)}</span>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-slate-600">
                    <span>{language === 'bn' ? 'অগ্রিম কর কর্তন (AIT)' : 'Advance Tax Paid'}</span>
                    <span className="font-bold text-rose-600">-{formatMoney(advanceTaxDeducted)}</span>
                  </div>

                  <div className="pt-2 border-t border-slate-200 flex items-baseline justify-between">
                    <span className="font-black text-slate-900 text-sm">
                      {language === 'bn' ? 'চূড়ান্ত প্রদেয় নিট কর' : 'Net Tax Payable'}
                    </span>
                    <span className="text-xl font-black text-emerald-600">
                      {formatMoney(taxCalculations.netPayableTax)}
                    </span>
                  </div>
                </div>

                {taxCalculations.refundAmount > 0 && (
                  <div className="p-3 rounded-2xl bg-teal-50 border border-teal-200 text-xs text-teal-900 font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-4 h-4 text-teal-600 shrink-0" />
                    <span>
                      {language === 'bn'
                        ? `আপনার অগ্রিম কর বেশি কাটা থাকায় ${formatMoney(taxCalculations.refundAmount)} রিফান্ড পাওয়ার যোগ্য!`
                        : `You have an eligible tax refund claim of ${formatMoney(taxCalculations.refundAmount)}!`}
                    </span>
                  </div>
                )}
              </div>

              {/* NBR Return Filing Reminder */}
              <div className="bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-3xl p-5 shadow-xs space-y-3">
                <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold uppercase tracking-wider">
                  <FileText className="w-4 h-4" />
                  <span>{language === 'bn' ? 'এনবিআর ই-রিটার্ন নির্দেশিকা' : 'NBR e-Return Guidance'}</span>
                </div>
                <p className="text-xs text-slate-300 leading-relaxed">
                  {language === 'bn'
                    ? 'আয়কর আইন ২০২৩ অনুযায়ী করমুক্ত আয়ের বেশি আয় থাকলে ৩০ নভেম্বরের মধ্যে জাতীয় রাজস্ব বোর্ডের (www.etaxnbr.gov.bd) পোর্টালে অনলাইন ই-রিটার্ন দাখিল বাধ্যতামূলক।'
                    : 'Annual tax return submission is mandatory if taxable income exceeds the threshold, due by Tax Day (November 30) at etaxnbr.gov.bd.'}
                </p>
                <a
                  href="https://etaxnbr.gov.bd"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-xs font-bold text-emerald-300 hover:text-emerald-200 transition-colors"
                >
                  <span>etaxnbr.gov.bd পোর্টাল ভিজিট করুন</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </a>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. ISLAMIC ZAKAT CALCULATOR VIEW */}
      {/* ========================================================================= */}
      {activeTab === 'zakat' && (
        <div className="space-y-6">
          
          {/* Zakat KPI Summary Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            
            {/* Nisab Threshold Card */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                  {language === 'bn' ? 'বর্তমান নিসাব মানদণ্ড' : 'Current Nisab Value'}
                </span>
                <span className="text-[10px] px-2 py-0.5 rounded-full bg-slate-100 text-slate-700 font-bold uppercase">
                  {nisabStandard === 'silver' ? 'রূপা (৫২.৫ ভরি)' : 'স্বর্ণ (৭.৫ ভরি)'}
                </span>
              </div>
              <p className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
                {formatMoney(zakatCalculations.activeNisabThreshold)}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn'
                  ? `নিসাব স্বর্ণ: ${formatMoney(zakatCalculations.goldNisabValue)}`
                  : `Gold Nisab: ${formatMoney(zakatCalculations.goldNisabValue)}`}
              </p>
            </div>

            {/* Total Zakatable Assets */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {language === 'bn' ? 'মোট যাকাতযোগ্য সম্পদ' : 'Total Zakatable Assets'}
              </span>
              <p className="text-xl sm:text-2xl font-black text-teal-600 tracking-tight">
                {formatMoney(zakatCalculations.totalAssets)}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn' ? 'ক্যাশ, ব্যাংক, স্বর্ণ ও শেয়ার' : 'Cash, gold, business & stocks'}
              </p>
            </div>

            {/* Deductible Liabilities */}
            <div className="bg-white p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
              <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
                {language === 'bn' ? 'বাদযোগ্য জরুরি দেনা ও দায়' : 'Deductible Debts'}
              </span>
              <p className="text-xl sm:text-2xl font-black text-rose-600 tracking-tight">
                -{formatMoney(zakatCalculations.totalLiabilities)}
              </p>
              <p className="text-[11px] text-slate-500">
                {language === 'bn' ? 'জরুরি প্রদেয় দেনা ও বকেয়া' : 'Immediate personal debts & bills'}
              </p>
            </div>

            {/* Zakat Payable */}
            <div className={`p-5 rounded-3xl shadow-sm space-y-1 text-white ${
              zakatCalculations.isZakatObligatory
                ? 'bg-gradient-to-br from-emerald-600 to-teal-700'
                : 'bg-gradient-to-br from-slate-700 to-slate-800'
            }`}>
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold text-emerald-100 uppercase tracking-wider block">
                  {language === 'bn' ? 'প্রদেয় যাকাতের পরিমাণ (২.৫%)' : 'Net Zakat Payable (2.5%)'}
                </span>
                <span className={`px-2 py-0.5 rounded-full text-[10px] font-black ${
                  zakatCalculations.isZakatObligatory ? 'bg-white text-emerald-800' : 'bg-slate-600 text-slate-200'
                }`}>
                  {zakatCalculations.isZakatObligatory
                    ? (language === 'bn' ? 'যাকাত ফরজ' : 'Obligatory')
                    : (language === 'bn' ? 'নিসাব পূর্ণ হয়নি' : 'Below Nisab')}
                </span>
              </div>
              <p className="text-2xl sm:text-3xl font-black tracking-tight">
                {formatMoney(zakatCalculations.zakatAmount)}
              </p>
              <p className="text-[11px] text-emerald-100">
                {language === 'bn'
                  ? `নিট সম্পদ: ${formatMoney(zakatCalculations.netZakatableWealth)}`
                  : `Net wealth: ${formatMoney(zakatCalculations.netZakatableWealth)}`}
              </p>
            </div>

          </div>

          {/* Zakat Input Form & Distribution Guide */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Left 2 Cols: Form Inputs */}
            <div className="lg:col-span-2 space-y-6">
              
              {/* 1. Nisab Selection & Rates */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Scale className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? '১. নিসাব নির্বাচন ও বর্তমান দর' : '1. Nisab Standard & Market Rates'}</span>
                  </h3>
                  <button
                    onClick={handleAutoFillZakatFromKhoroch}
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200/80 transition-all cursor-pointer self-start sm:self-auto"
                  >
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>{language === 'bn' ? 'আমার খরচ ডাটা থেকে অটো-ফিল' : 'Auto-fill from Khoroch'}</span>
                  </button>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  {/* Nisab Selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1.5">
                      {language === 'bn' ? 'নিসাবের মানদণ্ড (Standard)' : 'Nisab Standard'}
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => setNisabStandard('silver')}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                          nisabStandard === 'silver'
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                            : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        {language === 'bn' ? 'রূপা (৫২.৫ ভরি)' : 'Silver (52.5 Bhori)'}
                      </button>
                      <button
                        type="button"
                        onClick={() => setNisabStandard('gold')}
                        className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold border transition-all ${
                          nisabStandard === 'gold'
                            ? 'bg-emerald-50 border-emerald-500 text-emerald-800'
                            : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                        }`}
                      >
                        {language === 'bn' ? 'স্বর্ণ (৭.৫ ভরি)' : 'Gold (7.5 Bhori)'}
                      </button>
                    </div>
                  </div>

                  {/* Gold Price Per Bhori */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'স্বর্ণের দর (প্রতি ভরি ৳)' : 'Gold Rate / Bhori'}
                    </label>
                    <input
                      type="number"
                      value={customGoldBhoriRate || ''}
                      onChange={e => setCustomGoldBhoriRate(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Silver Price Per Bhori */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'রূপার দর (প্রতি ভরি ৳)' : 'Silver Rate / Bhori'}
                    </label>
                    <input
                      type="number"
                      value={customSilverBhoriRate || ''}
                      onChange={e => setCustomSilverBhoriRate(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200/60 text-xs text-slate-600 leading-relaxed">
                  {language === 'bn' ? (
                    <>
                      💡 <strong>উলামায়ে কেরামের অভিমত:</strong> নগদ টাকা ও অন্যান্য সম্পদের ক্ষেত্রে দরিদ্রদের সর্বাধিক কল্যাণে রূপার নিসাব (৫২.৫ ভরি = প্রায় {formatMoney(zakatCalculations.silverNisabValue)}) বিবেচনা করা অধিক সতর্কতামূলক ও প্রশংসনীয়। শুধু স্বর্ণ থাকলে স্বর্ণের নিসাব (৭.৫ ভরি) প্রযোজ্য।
                    </>
                  ) : (
                    <>
                      💡 <strong>Islamic Jurisprudence:</strong> For mixed wealth and cash, adopting the silver standard (~{formatMoney(zakatCalculations.silverNisabValue)}) ensures broader benefit to the poor.
                    </>
                  )}
                </div>
              </div>

              {/* 2. Zakatable Assets */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Coins className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? '২. যাকাতযোগ্য সম্পদসমূহ' : '2. Zakatable Assets'}</span>
                  </h3>
                  <span className="text-xs text-emerald-700 font-bold bg-emerald-50 px-2.5 py-1 rounded-xl">
                    {language === 'bn' ? `মোট সম্পদ: ${formatMoney(zakatCalculations.totalAssets)}` : `Total Assets: ${formatMoney(zakatCalculations.totalAssets)}`}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Cash in Hand & Bank Accounts */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'নগদ ক্যাশ ও ব্যাংক স্থিতি (Cash & Bank/bKash)' : 'Cash in Hand & Bank Balance'}
                    </label>
                    <input
                      type="number"
                      value={zakatCashAndBank || ''}
                      onChange={e => setZakatCashAndBank(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Gold Value */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'স্বর্ণ ও গহনার বর্তমান বাজারদর' : 'Gold & Jewelry Market Value'}
                    </label>
                    <input
                      type="number"
                      value={zakatGoldValue || ''}
                      onChange={e => setZakatGoldValue(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Silver Value */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'রূপা ও রূপার সামগ্রীর মূল্য' : 'Silver & Silverware Value'}
                    </label>
                    <input
                      type="number"
                      value={zakatSilverValue || ''}
                      onChange={e => setZakatSilverValue(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Business Inventory */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'ব্যবসার বিক্রয়যোগ্য পণ্যের স্টক (Inventory)' : 'Business Trade Goods & Stock'}
                    </label>
                    <input
                      type="number"
                      value={zakatBusinessInventory || ''}
                      onChange={e => setZakatBusinessInventory(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Shares & Investments */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'শেয়ার, মিউচুয়াল ফান্ড ও সঞ্চয়পত্র' : 'Shares, Mutual Funds & Bonds'}
                    </label>
                    <input
                      type="number"
                      value={zakatSharesInvestments || ''}
                      onChange={e => setZakatSharesInvestments(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>

                  {/* Receivables (Good debts) */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'অন্যের কাছে পাওনা বা ফেরতযোগ্য ঋণ' : 'Receivables / Loans Given'}
                    </label>
                    <input
                      type="number"
                      value={zakatReceivables || ''}
                      onChange={e => setZakatReceivables(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                    />
                  </div>
                </div>
              </div>

              {/* 3. Deductible Liabilities */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-5">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <HandCoins className="w-5 h-5 text-rose-600" />
                    <span>{language === 'bn' ? '৩. বাদযোগ্য দেনা ও তাৎক্ষণিক দায়' : '3. Deductible Debts & Liabilities'}</span>
                  </h3>
                  <span className="text-xs text-rose-700 font-bold bg-rose-50 px-2.5 py-1 rounded-xl">
                    {language === 'bn' ? `বাদ যাবে: -${formatMoney(zakatCalculations.totalLiabilities)}` : `Deduction: -${formatMoney(zakatCalculations.totalLiabilities)}`}
                  </span>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Immediate personal debts */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'জরুরি ব্যক্তিগত ঋণ বা কিস্তি' : 'Immediate Debts or Installments'}
                    </label>
                    <input
                      type="number"
                      value={zakatImmediateDebts || ''}
                      onChange={e => setZakatImmediateDebts(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                    />
                  </div>

                  {/* Unpaid bills or wages */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 mb-1">
                      {language === 'bn' ? 'চলতি বকেয়া বিল বা কর্মচারীর বেতন' : 'Unpaid Utility Bills / Wages'}
                    </label>
                    <input
                      type="number"
                      value={zakatUnpaidBills || ''}
                      onChange={e => setZakatUnpaidBills(Number(e.target.value) || 0)}
                      className="w-full px-3.5 py-2 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-rose-500/20"
                    />
                  </div>
                </div>

                <p className="text-[11px] text-slate-500">
                  {language === 'bn'
                    ? 'নোট: দীর্ঘমেয়াদী গৃহঋণ বা বড় ঋণের শুধুমাত্র চলতি বছরের তাৎক্ষণিক প্রদেয় কিস্তি বাদ দেওয়া যায়, সম্পূর্ণ ঋণ নয়।'
                    : 'Note: For long-term loans (like home mortgage), only the installment due immediately this period is deductible.'}
                </p>
              </div>

            </div>

            {/* Right 1 Col: Zakat Summary & Distribution Guide */}
            <div className="space-y-6">
              
              {/* Zakat Breakdown Statement */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <h3 className="text-base font-bold text-slate-900 flex items-center gap-2">
                    <Receipt className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'bn' ? 'যাকাত হিসাব বিবরণী' : 'Zakat Summary'}</span>
                  </h3>
                  <span className={`text-[10px] px-2.5 py-1 rounded-full font-bold ${
                    zakatCalculations.isZakatObligatory
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-slate-100 text-slate-700'
                  }`}>
                    {zakatCalculations.isZakatObligatory
                      ? (language === 'bn' ? 'যাকাত ফরজ হয়েছে' : 'Zakat Due')
                      : (language === 'bn' ? 'নিসাব পূর্ণ হয়নি' : 'Below Nisab')}
                  </span>
                </div>

                <div className="space-y-3 text-xs">
                  <div className="flex items-center justify-between text-slate-600">
                    <span>{language === 'bn' ? 'মোট সম্পদ (Assets)' : 'Total Assets'}</span>
                    <span className="font-bold text-slate-900">{formatMoney(zakatCalculations.totalAssets)}</span>
                  </div>

                  <div className="flex items-center justify-between text-rose-600">
                    <span>{language === 'bn' ? 'বাদযোগ্য দায় (Liabilities)' : 'Deductible Debts'}</span>
                    <span className="font-bold">-{formatMoney(zakatCalculations.totalLiabilities)}</span>
                  </div>

                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-slate-800 font-bold">
                    <span>{language === 'bn' ? 'নিট যাকাতযোগ্য সম্পদ' : 'Net Zakatable Wealth'}</span>
                    <span className="text-sm font-black text-slate-900">{formatMoney(zakatCalculations.netZakatableWealth)}</span>
                  </div>

                  <div className="flex items-center justify-between text-slate-500 text-[11px]">
                    <span>{language === 'bn' ? 'নিসাব সীমা (Nisab Cap)' : 'Nisab Threshold'}</span>
                    <span>{formatMoney(zakatCalculations.activeNisabThreshold)}</span>
                  </div>

                  <div className="pt-3 border-t border-slate-200 flex items-baseline justify-between">
                    <div>
                      <span className="font-black text-slate-900 text-sm block">
                        {language === 'bn' ? 'প্রদেয় যাকাত (২.৫%)' : 'Net Zakat Payable'}
                      </span>
                      <span className="text-[11px] text-slate-400">
                        {language === 'bn' ? 'মোট সম্পদের ১/৪০ অংশ' : '1/40th of net wealth'}
                      </span>
                    </div>
                    <span className="text-2xl font-black text-emerald-600">
                      {formatMoney(zakatCalculations.zakatAmount)}
                    </span>
                  </div>
                </div>

                {zakatCalculations.isZakatObligatory ? (
                  <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-950 font-semibold flex items-center gap-2">
                    <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                    <span>
                      {language === 'bn'
                        ? `আলহামদুলিল্লাহ! আপনার নিট সম্পদ নিসাব ছাড়িয়েছে। মোট ${formatMoney(zakatCalculations.zakatAmount)} দরিদ্র ও হকদারদের মাঝে বণ্টন করুন।`
                        : `Alhamdulillah! Your net wealth exceeds Nisab. Total zakat payable is ${formatMoney(zakatCalculations.zakatAmount)}.`}
                    </span>
                  </div>
                ) : (
                  <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-xs text-slate-600 flex items-center gap-2">
                    <Info className="w-5 h-5 text-slate-400 shrink-0" />
                    <span>
                      {language === 'bn'
                        ? 'আপনার বর্তমান সম্পদ নিসাব পরিমাণের নিচে রয়েছে, তাই এই মুহূর্তে আপনার ওপর যাকাত ফরজ নয়।'
                        : 'Your current net wealth is below Nisab, so zakat is not obligatory at this time.'}
                    </span>
                  </div>
                )}
              </div>

              {/* 8 Quranic Categories of Zakat Recipients (সূরা আত-তাওবাহ: ৬০) */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-5 shadow-xs space-y-3">
                <div className="flex items-center gap-2 text-slate-900 text-sm font-bold pb-2 border-b border-slate-100">
                  <Sparkles className="w-4 h-4 text-amber-500" />
                  <span>{language === 'bn' ? 'যাকাত বণ্টনের ৮টি নির্ধারিত খাত' : '8 Quranic Zakat Recipients'}</span>
                </div>
                <p className="text-[11px] text-slate-500">
                  {language === 'bn'
                    ? 'পবিত্র কুরআনের সূরা আত-তাওবাহ-এর ৬০ নম্বর আয়াত অনুযায়ী যাকাতের হকদার ৮টি শ্রেণি:'
                    : 'According to Surah At-Tawbah (9:60), the 8 specified categories of recipients:'}
                </p>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ১. ফকীর (নিঃস্ব)
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ২. মিসকীন (অভাবী)
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ৩. যাকাত আদায়কারী
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ৪. নওমুসলিম (মন জয়)
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ৫. দাসমুক্তি / বন্দী
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ৬. ঋণগ্রস্ত ব্যক্তি
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ৭. আল্লাহর পথে (জিহাদ/দ্বীন)
                  </div>
                  <div className="p-2 rounded-xl bg-slate-50 border border-slate-100 font-semibold text-slate-800">
                    ৮. নিঃস্ব মুসাফির
                  </div>
                </div>
              </div>

            </div>

          </div>

        </div>
      )}

    </div>
  );
};
