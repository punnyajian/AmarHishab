import React, { useState, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import { Debt } from '../../types';
import {
  HandCoins,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  CheckCircle2,
  Calendar,
  Phone,
  Trash2,
  X,
  CreditCard,
  User,
} from 'lucide-react';

export const DebtsView: React.FC = () => {
  const {
    debts,
    addDebt,
    recordDebtPayment,
    toggleDebtSettled,
    deleteDebt,
    formatMoney,
    language,
    t,
    currency,
  } = useExpense();

  const [activeTab, setActiveTab] = useState<'all' | 'lent' | 'borrowed'>('all');
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [paymentDebt, setPaymentDebt] = useState<Debt | null>(null);
  const [paymentAmount, setPaymentAmount] = useState('');

  const isAnyDebtModalOpen = isAddModalOpen || !!paymentDebt;
  useLockBodyScroll(isAnyDebtModalOpen);

  useEffect(() => {
    if (!isAnyDebtModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setIsAddModalOpen(false);
        setPaymentDebt(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAnyDebtModalOpen]);

  // Form states
  const [personName, setPersonName] = useState('');
  const [type, setType] = useState<'lent' | 'borrowed'>('lent');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [phone, setPhone] = useState('');
  const [note, setNote] = useState('');

  const filteredDebts = debts.filter(d => {
    if (activeTab === 'lent') return d.type === 'lent';
    if (activeTab === 'borrowed') return d.type === 'borrowed';
    return true;
  });

  // Calculate totals
  const totalLent = debts
    .filter(d => d.type === 'lent' && !d.settled)
    .reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);

  const totalBorrowed = debts
    .filter(d => d.type === 'borrowed' && !d.settled)
    .reduce((sum, d) => sum + (d.amount - d.paidAmount), 0);

  const handleOpenAdd = () => {
    setPersonName('');
    setType('lent');
    setAmount('');
    setDueDate(new Date(Date.now() + 14 * 86400000).toISOString().split('T')[0]);
    setPhone('');
    setNote('');
    setIsAddModalOpen(true);
  };

  const handleCreateDebt = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0 || !personName.trim()) return;

    addDebt({
      personName: personName.trim(),
      type,
      amount: numAmount,
      paidAmount: 0,
      dueDate,
      phone: phone.trim() || undefined,
      note: note.trim() || undefined,
      settled: false,
    });

    setIsAddModalOpen(false);
  };

  const handlePaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!paymentDebt) return;
    const num = parseFloat(paymentAmount);
    if (isNaN(num) || num <= 0) return;

    recordDebtPayment(paymentDebt.id, num);
    setPaymentDebt(null);
    setPaymentAmount('');
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {t('debtTracker')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {language === 'bn'
              ? 'কাউকে ধার দেওয়া বা ধার নেওয়ার স্পষ্ট হিসাব রাখুন'
              : 'Keep accurate track of money you lent or borrowed'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>{language === 'bn' ? 'নতুন ধার-দেনা' : 'New Entry'}</span>
        </button>
      </div>

      {/* Summary Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* Lent Card (I will receive) */}
        <div className="bg-white border border-emerald-200/80 rounded-3xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <ArrowDownLeft className="w-4 h-4 text-emerald-600" />
              {t('iLent')}
            </span>
            <div className="text-2xl sm:text-3xl font-black text-emerald-700 mt-1">
              +{formatMoney(totalLent)}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn' ? 'মানুষের কাছে আপনার পাওনা টাকা' : 'Money to receive from others'}
            </p>
          </div>
        </div>

        {/* Borrowed Card (I have to pay) */}
        <div className="bg-white border border-rose-200/80 rounded-3xl p-5 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider flex items-center gap-1.5">
              <ArrowUpRight className="w-4 h-4 text-rose-600" />
              {t('iBorrowed')}
            </span>
            <div className="text-2xl sm:text-3xl font-black text-rose-600 mt-1">
              -{formatMoney(totalBorrowed)}
            </div>
            <p className="text-[11px] text-slate-400 mt-0.5">
              {language === 'bn' ? 'অন্যের পাওনা আপনার পরিশোধ করতে হবে' : 'Pending debts you need to pay back'}
            </p>
          </div>
        </div>

      </div>

      {/* Filter Tabs */}
      <div className="flex gap-2 border-b border-slate-200/80 pb-2">
        <button
          onClick={() => setActiveTab('all')}
          className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
            activeTab === 'all' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          {language === 'bn' ? 'সব হিসাব' : 'All Debts'} ({debts.length})
        </button>
        <button
          onClick={() => setActiveTab('lent')}
          className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
            activeTab === 'lent' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          {t('iLent')}
        </button>
        <button
          onClick={() => setActiveTab('borrowed')}
          className={`px-3 py-1.5 text-xs font-bold rounded-xl transition-colors ${
            activeTab === 'borrowed' ? 'bg-emerald-600 text-white shadow-xs' : 'text-slate-600 hover:bg-slate-100'
          }`}
        >
          {t('iBorrowed')}
        </button>
      </div>

      {/* Debts List */}
      {filteredDebts.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs">
          <HandCoins className="w-12 h-12 text-slate-300 mx-auto mb-2" />
          <p className="text-sm font-bold text-slate-700">
            {language === 'bn' ? 'কোনো দেনা বা পাওনার হিসাব নেই।' : 'No debt records found.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredDebts.map(debt => {
            const isLent = debt.type === 'lent';
            const remaining = Math.max(0, debt.amount - debt.paidAmount);
            const progress = Math.min(100, Math.round((debt.paidAmount / debt.amount) * 100));

            return (
              <div
                key={debt.id}
                className={`bg-white border rounded-3xl p-5 shadow-xs transition-all hover:shadow-md flex flex-col justify-between space-y-4 ${
                  debt.settled
                    ? 'border-slate-200 opacity-70 bg-slate-50/50'
                    : isLent
                    ? 'border-emerald-200/90'
                    : 'border-rose-200/90'
                }`}
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-3">
                      <div
                        className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold ${
                          isLent ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                        }`}
                      >
                        {isLent ? <ArrowDownLeft className="w-5 h-5" /> : <ArrowUpRight className="w-5 h-5" />}
                      </div>
                      <div>
                        <h3 className="font-bold text-sm text-slate-800 flex items-center gap-2">
                          <span>{debt.personName}</span>
                          {debt.settled && (
                            <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-sm bg-emerald-100 text-emerald-800">
                              {t('settle')}
                            </span>
                          )}
                        </h3>
                        <p className="text-[11px] text-slate-400">
                          {isLent ? t('iLent') : t('iBorrowed')}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => {
                        if (window.confirm(language === 'bn' ? 'মুছে ফেলতে চান?' : 'Delete entry?')) {
                          deleteDebt(debt.id);
                        }
                      }}
                      className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {debt.note && (
                    <p className="text-xs text-slate-500 mt-2.5">
                      {debt.note}
                    </p>
                  )}

                  {debt.phone && (
                    <div className="flex items-center gap-1.5 text-xs text-slate-600 font-medium mt-1">
                      <Phone className="w-3 h-3 text-slate-400" />
                      <span>{debt.phone}</span>
                    </div>
                  )}
                </div>

                {/* Amount and Due Date */}
                <div className="pt-2 border-t border-slate-100 space-y-2">
                  <div className="flex justify-between items-baseline">
                    <span className="text-xs text-slate-400">
                      {debt.settled ? (language === 'bn' ? 'পরিশোধিত' : 'Paid in full') : (language === 'bn' ? 'বাকি পাওনা' : 'Remaining')}:
                    </span>
                    <span
                      className={`text-lg font-black ${
                        isLent ? 'text-emerald-700' : 'text-rose-600'
                      }`}
                    >
                      {formatMoney(debt.settled ? debt.amount : remaining)}
                    </span>
                  </div>

                  {debt.paidAmount > 0 && !debt.settled && (
                    <div className="space-y-1">
                      <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                        <div
                          className="bg-emerald-600 h-1.5 rounded-full"
                          style={{ width: `${progress}%` }}
                        />
                      </div>
                      <div className="flex justify-between text-[10px] text-slate-400">
                        <span>{language === 'bn' ? 'জমা:' : 'Paid:'} {formatMoney(debt.paidAmount)}</span>
                        <span>{language === 'bn' ? 'মূল:' : 'Total:'} {formatMoney(debt.amount)}</span>
                      </div>
                    </div>
                  )}

                  <div className="flex items-center justify-between text-[11px] text-slate-400 pt-1">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      <span>{language === 'bn' ? 'পরিশোধের তারিখ:' : 'Due:'} {debt.dueDate}</span>
                    </span>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="flex gap-2 pt-1">
                  {!debt.settled && (
                    <button
                      onClick={() => {
                        setPaymentDebt(debt);
                        setPaymentAmount('');
                      }}
                      className="flex-1 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold transition-colors"
                    >
                      {language === 'bn' ? 'টাকা পরিশোধ জমা' : 'Record Payment'}
                    </button>
                  )}

                  <button
                    onClick={() => toggleDebtSettled(debt.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                      debt.settled
                        ? 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    {debt.settled ? (language === 'bn' ? 'পুনরায় সক্রিয়' : 'Unmark') : (language === 'bn' ? 'সম্পন্ন চিহ্নিত' : 'Mark Settled')}
                  </button>
                </div>

              </div>
            );
          })}
        </div>
      )}

      {/* Record Payment Modal */}
      {paymentDebt && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setPaymentDebt(null);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-sm w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'পরিশোধ রেকর্ড করুন' : 'Record Payment'}
              </h3>
              <button
                type="button"
                onClick={() => setPaymentDebt(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-500">
              {paymentDebt.personName} - {language === 'bn' ? 'বাকি আছে' : 'Remaining'}:{' '}
              <strong>{formatMoney(paymentDebt.amount - paymentDebt.paidAmount)}</strong>
            </p>

            <form onSubmit={handlePaymentSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'পরিশোধিত টাকার পরিমাণ' : 'Payment Amount'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  min="1"
                  max={paymentDebt.amount - paymentDebt.paidAmount}
                  placeholder="0.00"
                  value={paymentAmount}
                  onChange={e => setPaymentAmount(e.target.value)}
                  className="w-full px-4 py-3 text-xl font-bold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  autoFocus
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPaymentDebt(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl cursor-pointer hover:bg-slate-200"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs cursor-pointer"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Add Debt Modal */}
      {isAddModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[88vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'নতুন দেনা বা পাওনা হিসাব' : 'Add Debt / Loan'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateDebt} className="space-y-4">
              <div className="grid grid-cols-2 gap-2 p-1 bg-slate-100 rounded-2xl">
                <button
                  type="button"
                  onClick={() => setType('lent')}
                  className={`py-2 text-xs font-bold rounded-xl transition-all ${
                    type === 'lent' ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {t('iLent')}
                </button>
                <button
                  type="button"
                  onClick={() => setType('borrowed')}
                  className={`py-2 text-xs font-bold rounded-xl transition-all ${
                    type === 'borrowed' ? 'bg-white text-rose-700 shadow-xs' : 'text-slate-600'
                  }`}
                >
                  {t('iBorrowed')}
                </button>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'ব্যক্তির নাম' : 'Person Name'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'bn' ? 'যেমন: তানভীর আহমেদ বা হাসান' : 'e.g. John Doe, Alex'}
                  value={personName}
                  onChange={e => setPersonName(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {t('amount')} ({currency.symbol})
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="1"
                    placeholder="0"
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'পরিশোধের শেষ তারিখ' : 'Due Date'}
                  </label>
                  <input
                    type="date"
                    required
                    value={dueDate}
                    onChange={e => setDueDate(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'মোবাইল নম্বর (ঐচ্ছিক)' : 'Phone Number (Optional)'}
                </label>
                <input
                  type="tel"
                  placeholder="01712-XXXXXX"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {t('notes')}
                </label>
                <input
                  type="text"
                  placeholder={language === 'bn' ? 'কারণ বা বিবরণ...' : 'Reason for lending/borrowing...'}
                  value={note}
                  onChange={e => setNote(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
