import React, { useState, useMemo, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import {
  InvestmentItem,
  InvestmentType,
  GoldPurity,
  SanchayapatraCategory,
} from '../../types';
import {
  Landmark,
  Plus,
  Trash2,
  Edit2,
  Calendar,
  DollarSign,
  TrendingUp,
  Percent,
  CheckCircle2,
  AlertCircle,
  X,
  Wallet,
  Sparkles,
  Info,
  Clock,
  Coins,
  ShieldCheck,
  Building2,
  Gem,
  Award,
  ArrowUpRight,
  ArrowDownLeft,
  Calculator,
  RefreshCw,
  Scale,
  BadgePercent,
  ChevronRight,
  FileText,
  PieChart,
} from 'lucide-react';
import confetti from 'canvas-confetti';

type InvestmentSubTab = 'all' | 'dps' | 'sanchayapatra' | 'fdr' | 'gold' | 'calculator';

export const InvestmentsView: React.FC = () => {
  const {
    investments,
    goldMarketRates,
    addInvestment,
    editInvestment,
    deleteInvestment,
    updateGoldRates,
    payDPSInstallment,
    recordInvestmentProfitPayout,
    totalPortfolioValue,
    totalInvestedPrincipal,
    totalUnrealizedGain,
    unrealizedGainPercentage,
    totalMonthlyEstimatedYield,
    totalGoldWeightBhori,
    totalGoldCurrentValue,
    totalGoldZakatPayable,
    upcomingDPSInstallments,
    accounts,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const [activeTab, setActiveTab] = useState<InvestmentSubTab>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<InvestmentItem | null>(null);
  const [isGoldRateModalOpen, setIsGoldRateModalOpen] = useState(false);
  const [isPayDPSModalOpen, setIsPayDPSModalOpen] = useState(false);
  const [selectedDPS, setSelectedDPS] = useState<InvestmentItem | null>(null);
  const [isProfitPayoutModalOpen, setIsProfitPayoutModalOpen] = useState(false);
  const [selectedProfitItem, setSelectedProfitItem] = useState<InvestmentItem | null>(null);

  const isAnyInvestmentModalOpen =
    isAddModalOpen ||
    isGoldRateModalOpen ||
    isPayDPSModalOpen ||
    isProfitPayoutModalOpen;

  useLockBodyScroll(isAnyInvestmentModalOpen);

  useEffect(() => {
    if (!isAnyInvestmentModalOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setIsAddModalOpen(false);
        setIsGoldRateModalOpen(false);
        setIsPayDPSModalOpen(false);
        setIsProfitPayoutModalOpen(false);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isAnyInvestmentModalOpen]);

  // DPS & Compound Calculator State
  const [calcSubTab, setCalcSubTab] = useState<'dps' | 'sanchay' | 'gold'>('dps');
  const [calcMonthlyDeposit, setCalcMonthlyDeposit] = useState<number>(5000);
  const [calcYears, setCalcYears] = useState<number>(5);
  const [calcInterestRate, setCalcInterestRate] = useState<number>(9.0);

  // Sanchayapatra Calculator State
  const [sanchayScheme, setSanchayScheme] = useState<SanchayapatraCategory>('poribar');
  const [sanchayPrincipal, setSanchayPrincipal] = useState<number>(500000);
  const [sanchayTaxTier, setSanchayTaxTier] = useState<number>(5); // 5% or 10% AIT

  // Gold Converter & Zakat State
  const [goldInputMode, setGoldInputMode] = useState<'bhori_ana' | 'grams'>('bhori_ana');
  const [calcGoldBhori, setCalcGoldBhori] = useState<number>(3);
  const [calcGoldAna, setCalcGoldAna] = useState<number>(4);
  const [calcGoldRoti, setCalcGoldRoti] = useState<number>(0);
  const [calcGoldGrams, setCalcGoldGrams] = useState<number>(37.9);
  const [calcGoldPurity, setCalcGoldPurity] = useState<GoldPurity>('22k');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Filtered investments based on tab
  const filteredInvestments = useMemo(() => {
    if (activeTab === 'all') return investments;
    if (activeTab === 'calculator') return [];
    return investments.filter(inv => inv.type === activeTab);
  }, [investments, activeTab]);

  // Asset allocation stats
  const assetAllocation = useMemo(() => {
    const total = totalPortfolioValue || 1;
    const dps = investments.filter(i => i.type === 'dps').reduce((sum, i) => sum + i.currentValue, 0);
    const sanchay = investments.filter(i => i.type === 'sanchayapatra').reduce((sum, i) => sum + i.currentValue, 0);
    const fdr = investments.filter(i => i.type === 'fdr').reduce((sum, i) => sum + i.currentValue, 0);
    const gold = investments.filter(i => i.type === 'gold').reduce((sum, i) => sum + i.currentValue, 0);
    const others = investments.filter(i => !['dps', 'sanchayapatra', 'fdr', 'gold'].includes(i.type)).reduce((sum, i) => sum + i.currentValue, 0);

    return [
      { id: 'dps', label: language === 'bn' ? 'ডিপিএস' : 'DPS', amount: dps, percent: Math.round((dps / total) * 100), color: 'bg-emerald-500' },
      { id: 'sanchay', label: language === 'bn' ? 'সঞ্চয়পত্র' : 'Savings Cert', amount: sanchay, percent: Math.round((sanchay / total) * 100), color: 'bg-teal-500' },
      { id: 'fdr', label: language === 'bn' ? 'এফডিআর' : 'FDR', amount: fdr, percent: Math.round((fdr / total) * 100), color: 'bg-sky-500' },
      { id: 'gold', label: language === 'bn' ? 'স্বর্ণ' : 'Gold', amount: gold, percent: Math.round((gold / total) * 100), color: 'bg-amber-500' },
      { id: 'others', label: language === 'bn' ? 'অন্যান্য' : 'Others', amount: others, percent: Math.round((others / total) * 100), color: 'bg-purple-500' },
    ].filter(item => item.amount > 0);
  }, [investments, totalPortfolioValue, language]);

  // DPS Calculator Result
  const calculatorResult = useMemo(() => {
    const months = calcYears * 12;
    const monthlyRate = (calcInterestRate / 100) / 12;
    const totalPrincipal = calcMonthlyDeposit * months;
    
    // Future Value of monthly recurring deposit (DPS formula)
    let maturityVal = 0;
    if (monthlyRate > 0) {
      maturityVal = calcMonthlyDeposit * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate) * (1 + monthlyRate);
    } else {
      maturityVal = totalPrincipal;
    }

    const totalProfit = maturityVal - totalPrincipal;

    return {
      totalPrincipal: Math.round(totalPrincipal),
      maturityVal: Math.round(maturityVal),
      totalProfit: Math.round(totalProfit),
    };
  }, [calcMonthlyDeposit, calcYears, calcInterestRate]);

  // Sanchayapatra Calculator Result
  const sanchayResult = useMemo(() => {
    let rate = 11.52;
    let frequency: 'monthly' | 'quarterly' | 'maturity' = 'monthly';
    let schemeNameBn = 'পরিবার সঞ্চয়পত্র';
    let schemeNameEn = 'Paribar Sanchayapatra';

    if (sanchayScheme === 'poribar') {
      rate = 11.52;
      frequency = 'monthly';
      schemeNameBn = 'পরিবার সঞ্চয়পত্র (৫ বছর)';
      schemeNameEn = 'Paribar Sanchayapatra (5-Yr)';
    } else if (sanchayScheme === 'three_month') {
      rate = 11.04;
      frequency = 'quarterly';
      schemeNameBn = '৩ মাস অন্তর মুনাফাভিত্তিক সঞ্চয়পত্র (৩ বছর)';
      schemeNameEn = '3-Month Profit Bearing (3-Yr)';
    } else if (sanchayScheme === 'pensioner') {
      rate = 11.76;
      frequency = 'quarterly';
      schemeNameBn = 'পেনশনার সঞ্চয়পত্র (৫ বছর)';
      schemeNameEn = 'Pensioner Sanchayapatra (5-Yr)';
    } else if (sanchayScheme === 'bangladesh_5yr') {
      rate = 11.28;
      frequency = 'maturity';
      schemeNameBn = '৫ বছর মেয়াদী বাংলাদেশ সঞ্চয়পত্র';
      schemeNameEn = '5-Year Bangladesh Sanchayapatra';
    } else if (sanchayScheme === 'post_office') {
      rate = 11.20;
      frequency = 'quarterly';
      schemeNameBn = 'ডাকঘর সঞ্চয় ব্যাংক (মেয়াদী হিসাব - ৩ বছর)';
      schemeNameEn = 'Post Office Fixed Deposit (3-Yr)';
    }

    const grossAnnual = sanchayPrincipal * (rate / 100);
    const grossPayout = frequency === 'monthly' ? grossAnnual / 12 : frequency === 'quarterly' ? grossAnnual / 4 : grossAnnual;
    const taxAmount = grossPayout * (sanchayTaxTier / 100);
    const netPayout = grossPayout - taxAmount;
    const monthlyEquivalent = frequency === 'quarterly' ? netPayout / 3 : frequency === 'monthly' ? netPayout : netPayout / 12;

    return {
      schemeName: language === 'bn' ? schemeNameBn : schemeNameEn,
      rate,
      frequency,
      grossAnnual: Math.round(grossAnnual),
      grossPayout: Math.round(grossPayout),
      taxAmount: Math.round(taxAmount),
      netPayout: Math.round(netPayout),
      monthlyEquivalent: Math.round(monthlyEquivalent),
    };
  }, [sanchayScheme, sanchayPrincipal, sanchayTaxTier, language]);

  // Gold & Zakat Calculator Result
  const goldResult = useMemo(() => {
    let totalBhori = 0;
    if (goldInputMode === 'bhori_ana') {
      totalBhori = (calcGoldBhori || 0) + ((calcGoldAna || 0) / 16) + ((calcGoldRoti || 0) / 96);
    } else {
      totalBhori = (calcGoldGrams || 0) / 11.664;
    }

    const totalGrams = totalBhori * 11.664;

    const ratePerBhori =
      calcGoldPurity === '24k'
        ? goldMarketRates.price24k
        : calcGoldPurity === '21k'
        ? goldMarketRates.price21k
        : calcGoldPurity === '18k'
        ? goldMarketRates.price18k
        : calcGoldPurity === 'traditional'
        ? goldMarketRates.priceTraditional
        : goldMarketRates.price22k;

    const totalMarketValue = Math.round(totalBhori * ratePerBhori);
    const meetsNisab = totalBhori >= 7.5;
    const zakatAmount = meetsNisab ? Math.round(totalMarketValue * 0.025) : 0;

    return {
      totalBhori: Math.round(totalBhori * 1000) / 1000,
      totalGrams: Math.round(totalGrams * 100) / 100,
      ratePerBhori,
      totalMarketValue,
      meetsNisab,
      zakatAmount,
    };
  }, [goldInputMode, calcGoldBhori, calcGoldAna, calcGoldRoti, calcGoldGrams, calcGoldPurity, goldMarketRates]);

  return (
    <div className="space-y-6 pb-16 animate-in fade-in duration-200">
      
      {/* Toast banner */}
      {toastMessage && (
        <div className="bg-emerald-600 text-white px-4 py-3 rounded-2xl shadow-lg flex items-center justify-between text-xs sm:text-sm font-semibold animate-in slide-in-from-top duration-200 no-print">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-200" />
            <span>{toastMessage}</span>
          </div>
          <button onClick={() => setToastMessage(null)} className="text-white/80 hover:text-white p-1">
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Banner & Portfolio Summary */}
      <div className="bg-gradient-to-br from-slate-900 via-teal-950 to-emerald-950 rounded-3xl p-5 sm:p-7 text-white shadow-xl relative overflow-hidden">
        {/* Subtle background glow */}
        <div className="absolute -top-16 -right-16 w-56 h-56 bg-emerald-500/15 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-16 -left-16 w-56 h-56 bg-teal-500/15 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-5">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-xs font-semibold text-emerald-200 border border-white/10">
              <Landmark className="w-3.5 h-3.5 text-emerald-300" />
              <span>{language === 'bn' ? 'ডিপিএস, সঞ্চয়পত্র ও স্বর্ণ পোর্টফোলিও' : 'Wealth & Investment Portfolio'}</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              <span>{investments.length} {language === 'bn' ? 'টি অ্যাসেট' : 'Assets'}</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white flex items-center gap-2">
              <span>{formatMoney(totalPortfolioValue)}</span>
              {totalUnrealizedGain > 0 && (
                <span className="text-xs sm:text-sm px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 font-bold flex items-center gap-1">
                  <TrendingUp className="w-3.5 h-3.5" />
                  +{unrealizedGainPercentage}% {language === 'bn' ? 'লাভ' : 'Profit'}
                </span>
              )}
            </h1>

            <p className="text-xs sm:text-sm text-slate-300 flex flex-wrap items-center gap-x-3 gap-y-1">
              <span>{language === 'bn' ? 'মোট বিনিয়োগকৃত আসল:' : 'Total Invested:'} <strong>{formatMoney(totalInvestedPrincipal)}</strong></span>
              <span>• {language === 'bn' ? 'অর্জিত মুনাফা / প্রবৃদ্ধি:' : 'Net Gain:'} <strong className="text-emerald-300">+{formatMoney(totalUnrealizedGain)}</strong></span>
            </p>
          </div>

          {/* Quick Actions Buttons */}
          <div className="flex flex-wrap items-center gap-2 no-print">
            <button
              onClick={() => {
                setEditingItem(null);
                setIsAddModalOpen(true);
              }}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white font-bold text-xs active:scale-95 shadow-lg shadow-emerald-950/30 transition-all"
            >
              <Plus className="w-4 h-4 stroke-[3]" />
              <span>{language === 'bn' ? 'নতুন বিনিয়োগ যোগ' : 'Add Investment'}</span>
            </button>

            <button
              onClick={() => setIsGoldRateModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-200 border border-amber-400/30 font-bold text-xs active:scale-95 transition-all"
            >
              <Coins className="w-4 h-4 text-amber-300" />
              <span>{language === 'bn' ? 'স্বর্ণের দর (BAJUS)' : 'Gold Rates'}</span>
            </button>
          </div>
        </div>

        {/* Live Key Metrics Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6 pt-6 border-t border-white/10 text-white">
          
          {/* Monthly Passive Yield */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
              <BadgePercent className="w-3.5 h-3.5 text-emerald-400" />
              {language === 'bn' ? 'মাসিক প্যাসিভ প্রফিট' : 'Monthly Yield'}
            </span>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-black text-emerald-300">
                +{formatMoney(totalMonthlyEstimatedYield)}
              </div>
              <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                {language === 'bn' ? 'সঞ্চয়পত্র ও এফডিআর হতে' : 'From Sanchayapatra & FDR'}
              </p>
            </div>
          </div>

          {/* Gold Holdings Card */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-amber-200 flex items-center gap-1">
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              {language === 'bn' ? 'স্বর্ণ ও অলংকার' : 'Gold Holdings'}
            </span>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-black text-amber-300">
                {totalGoldWeightBhori} <span className="text-xs font-semibold text-amber-200">{language === 'bn' ? 'ভরি' : 'bhori'}</span>
              </div>
              <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                {language === 'bn' ? `মূল্য: ${formatMoney(totalGoldCurrentValue)}` : `Value: ${formatMoney(totalGoldCurrentValue)}`}
              </p>
            </div>
          </div>

          {/* Gold Zakat Estimation */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
              <Scale className="w-3.5 h-3.5 text-teal-400" />
              {language === 'bn' ? 'স্বর্ণের সম্ভাব্য যাকাত' : 'Zakat on Gold'}
            </span>
            <div className="mt-1">
              <div className="text-xl sm:text-2xl font-black text-white">
                {totalGoldZakatPayable > 0 ? formatMoney(totalGoldZakatPayable) : (language === 'bn' ? 'প্রযোজ্য নয়' : 'N/A')}
              </div>
              <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                {totalGoldWeightBhori >= 7.5 
                  ? (language === 'bn' ? 'নেসাব (৭.৫ ভরি) পূর্ণ হয়েছে' : 'Nisab reached (2.5%)')
                  : (language === 'bn' ? 'নেসাব (৭.৫ ভরি) এর নিচে' : 'Below 7.5 bhori nisab')}
              </p>
            </div>
          </div>

          {/* Active DPS count & due alert */}
          <div className="bg-white/10 backdrop-blur-md rounded-2xl p-3.5 border border-white/10 flex flex-col justify-between">
            <span className="text-[11px] font-semibold text-slate-300 flex items-center gap-1">
              <Clock className="w-3.5 h-3.5 text-sky-400" />
              {language === 'bn' ? 'ডিপিএস কিস্তি অ্যালার্ট' : 'Next DPS Due'}
            </span>
            <div className="mt-1">
              {upcomingDPSInstallments[0] ? (
                <>
                  <div className="text-sm sm:text-base font-black text-sky-300 truncate">
                    {formatMoney(upcomingDPSInstallments[0].monthlyInstallment || 0)}
                  </div>
                  <p className="text-[10px] text-slate-300 mt-0.5 truncate">
                    📅 {upcomingDPSInstallments[0].nextInstallmentDueDate} • {upcomingDPSInstallments[0].institutionName}
                  </p>
                </>
              ) : (
                <>
                  <div className="text-base font-bold text-slate-300">
                    {language === 'bn' ? 'কোনো বাকি নেই' : 'All Clear'}
                  </div>
                  <p className="text-[10px] text-slate-300 mt-0.5">
                    {language === 'bn' ? 'সব ডিপিএস আপ-টু-ডেট' : 'No pending dues'}
                  </p>
                </>
              )}
            </div>
          </div>

        </div>
      </div>

      {/* Sub-tab Navigation */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar border-b border-slate-200/80 no-print">
        {[
          { id: 'all', label: language === 'bn' ? 'সকল বিনিয়োগ' : 'All Assets', icon: Landmark, count: investments.length },
          { id: 'dps', label: language === 'bn' ? 'ডিপিএস (DPS)' : 'DPS Accounts', icon: Clock, count: investments.filter(i => i.type === 'dps').length },
          { id: 'sanchayapatra', label: language === 'bn' ? 'জাতীয় সঞ্চয়পত্র' : 'Savings Certificates', icon: Award, count: investments.filter(i => i.type === 'sanchayapatra').length },
          { id: 'fdr', label: language === 'bn' ? 'স্থায়ী আমানত (FDR)' : 'Fixed Deposits', icon: Building2, count: investments.filter(i => i.type === 'fdr').length },
          { id: 'gold', label: language === 'bn' ? 'স্বর্ণ ও অলংকার' : 'Gold Portfolio', icon: Coins, count: investments.filter(i => i.type === 'gold').length },
          { id: 'calculator', label: language === 'bn' ? 'ডিপিএস ও মুনাফা ক্যালকুলেটর' : 'Growth Calculator', icon: Calculator },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as InvestmentSubTab)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-150 ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white hover:bg-slate-100 text-slate-600 border border-slate-200/60'
              }`}
            >
              <Icon className={`w-4 h-4 ${isActive ? 'text-white' : 'text-slate-400'}`} />
              <span>{tab.label}</span>
              {tab.count !== undefined && (
                <span className={`text-[10px] px-1.5 py-0.2 rounded-full font-bold ${isActive ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'}`}>
                  {tab.count}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* ========================================================= */}
      {/* INVESTMENTS CARDS / LIST VIEW */}
      {/* ========================================================= */}
      {activeTab !== 'calculator' && (
        <div className="space-y-5">

          {/* Portfolio Allocation Diversity Bar */}
          {activeTab === 'all' && assetAllocation.length > 0 && (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-4 sm:p-5 shadow-xs space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1">
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-slate-800 flex items-center gap-1.5">
                    <PieChart className="w-4 h-4 text-emerald-600" />
                    <span>{language === 'bn' ? 'পোর্টফোলিও বৈচিত্র্য ও অ্যাসেট বণ্টন' : 'Portfolio Diversification'}</span>
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {language === 'bn' ? 'ডিপিএস, সঞ্চয়পত্র, এফডিআর ও স্বর্ণের আনুপাতিক হার' : 'Relative distribution across all your wealth assets'}
                  </p>
                </div>
                <span className="text-xs sm:text-sm font-black text-slate-800">
                  {formatMoney(totalPortfolioValue)}
                </span>
              </div>

              {/* Progress Bar with Multiple Colored Segments */}
              <div className="h-3 w-full bg-slate-100 rounded-full overflow-hidden flex shadow-inner">
                {assetAllocation.map(seg => (
                  <div
                    key={seg.id}
                    style={{ width: `${seg.percent}%` }}
                    className={`${seg.color} h-full transition-all duration-500 first:rounded-l-full last:rounded-r-full`}
                    title={`${seg.label}: ${formatMoney(seg.amount)} (${seg.percent}%)`}
                  />
                ))}
              </div>

              {/* Legend Badges */}
              <div className="flex flex-wrap items-center gap-2 sm:gap-4 pt-1 text-xs">
                {assetAllocation.map(seg => (
                  <div key={seg.id} className="flex items-center gap-1.5 font-semibold text-slate-600">
                    <span className={`w-2.5 h-2.5 rounded-full ${seg.color}`} />
                    <span>{seg.label}:</span>
                    <strong className="text-slate-800">{formatMoney(seg.amount)}</strong>
                    <span className="text-[10px] text-slate-400">({seg.percent}%)</span>
                  </div>
                ))}
              </div>
            </div>
          )}
          
          {filteredInvestments.length === 0 ? (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs">
              <Landmark className="w-12 h-12 text-slate-300 mx-auto mb-2" />
              <p className="text-sm font-bold text-slate-700">
                {language === 'bn' ? 'কোনো বিনিয়োগ পাওয়া যায়নি।' : 'No investments found in this category.'}
              </p>
              <button
                onClick={() => {
                  setEditingItem(null);
                  setIsAddModalOpen(true);
                }}
                className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl shadow-xs hover:bg-emerald-700"
              >
                <Plus className="w-4 h-4" />
                <span>{language === 'bn' ? 'বিনিয়োগ যোগ করুন' : 'Add Investment'}</span>
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
              {filteredInvestments.map(item => {
                const profit = item.currentValue - item.investedAmount;
                const profitPercent = item.investedAmount > 0 ? Math.round((profit / item.investedAmount) * 1000) / 10 : 0;
                const isDPS = item.type === 'dps';
                const isSanchay = item.type === 'sanchayapatra';
                const isGold = item.type === 'gold';
                const isFDR = item.type === 'fdr';

                return (
                  <div
                    key={item.id}
                    className="bg-white border border-slate-200/80 hover:border-emerald-300 rounded-3xl p-5 shadow-xs transition-all flex flex-col justify-between space-y-4"
                  >
                    <div>
                      {/* Header with Type Tag and Actions */}
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-2">
                          <span className={`text-[10px] uppercase tracking-wider font-extrabold px-2.5 py-1 rounded-xl border ${
                            isDPS 
                              ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                              : isSanchay
                              ? 'bg-teal-50 text-teal-800 border-teal-200'
                              : isGold
                              ? 'bg-amber-50 text-amber-800 border-amber-200'
                              : 'bg-sky-50 text-sky-800 border-sky-200'
                          }`}>
                            {isDPS 
                              ? (language === 'bn' ? 'ডিপিএস (DPS)' : 'DPS')
                              : isSanchay 
                              ? (language === 'bn' ? 'সঞ্চয়পত্র' : 'Sanchayapatra')
                              : isGold 
                              ? (language === 'bn' ? 'স্বর্ণ (Gold)' : 'Gold')
                              : (language === 'bn' ? 'এফডিআর (FDR)' : 'FDR')}
                          </span>

                          {item.interestRate && (
                            <span className="text-[11px] font-bold text-slate-500">
                              {item.interestRate}% {language === 'bn' ? 'মুনাফা' : 'Profit'}
                            </span>
                          )}
                        </div>

                        <div className="flex items-center gap-1">
                          <button
                            onClick={() => {
                              setEditingItem(item);
                              setIsAddModalOpen(true);
                            }}
                            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-lg hover:bg-slate-100"
                            title="এডিট করুন"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => {
                              if (window.confirm(language === 'bn' ? 'বিনিয়োগটি মুছে ফেলতে চান?' : 'Delete investment?')) {
                                deleteInvestment(item.id);
                                showToast(language === 'bn' ? 'মুছে ফেলা হয়েছে' : 'Deleted');
                              }
                            }}
                            className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg hover:bg-rose-50"
                            title="মুছুন"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                      {/* Title and Institution */}
                      <div className="mt-3">
                        <h3 className="font-extrabold text-base text-slate-900 leading-snug">
                          {item.titleBn || item.title}
                        </h3>
                        <p className="text-xs text-slate-400 flex items-center gap-1 mt-0.5">
                          <Building2 className="w-3.5 h-3.5 shrink-0" />
                          <span>{item.institutionName}</span>
                          {item.accountOrCertificateNo && (
                            <span>• #{item.accountOrCertificateNo}</span>
                          )}
                        </p>
                      </div>

                      {/* Gold specific highlights */}
                      {isGold && (
                        <div className="mt-3 bg-amber-50/60 border border-amber-200/60 rounded-2xl p-3 space-y-1 text-xs">
                          <div className="flex justify-between text-amber-900 font-bold">
                            <span>{language === 'bn' ? 'ওজন ও ক্যারেট:' : 'Weight & Karat:'}</span>
                            <span>{item.goldWeightBhori} ভরি ({item.goldPurity?.toUpperCase()})</span>
                          </div>
                          <div className="flex justify-between text-slate-600 text-[11px]">
                            <span>{language === 'bn' ? 'বর্তমান দর:' : 'Market Rate:'}</span>
                            <span>{formatMoney(item.currentPricePerBhori || goldMarketRates.price22k)}/ভরি</span>
                          </div>
                          {item.jewelryType && (
                            <p className="text-[10px] text-amber-800/80 italic pt-0.5">
                              {item.jewelryType}
                            </p>
                          )}
                        </div>
                      )}

                      {/* DPS Progress Bar & Next Installment Alert */}
                      {isDPS && item.totalInstallments && (
                        <div className="mt-3 space-y-1.5">
                          <div className="flex justify-between text-xs font-semibold text-slate-500">
                            <span>{language === 'bn' ? 'কিস্তি প্রগতি:' : 'Installment Progress:'}</span>
                            <span className="font-bold text-emerald-800">
                              {item.paidInstallmentsCount || 0} / {item.totalInstallments} {language === 'bn' ? 'টি' : 'paid'}
                            </span>
                          </div>
                          <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                            <div
                              className="bg-emerald-600 h-2 rounded-full transition-all duration-500"
                              style={{ width: `${Math.min(100, Math.round(((item.paidInstallmentsCount || 0) / item.totalInstallments) * 100))}%` }}
                            />
                          </div>

                          {item.nextInstallmentDueDate && (
                            <div className="flex items-center justify-between text-[11px] pt-1 text-slate-500">
                              <span>{language === 'bn' ? 'পরবর্তী কিস্তি:' : 'Next Due:'}</span>
                              <strong className="text-slate-800">📅 {item.nextInstallmentDueDate}</strong>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Sanchayapatra Monthly Payout Highlight */}
                      {isSanchay && item.estimatedMonthlyProfit && (
                        <div className="mt-3 bg-teal-50/70 border border-teal-200/70 rounded-2xl p-3 flex items-center justify-between">
                          <div>
                            <span className="text-[10px] font-bold uppercase text-teal-800 block">
                              {language === 'bn' ? 'মাসিক সম্ভাব্য মুনাফা' : 'Monthly Profit'}
                            </span>
                            <span className="text-sm font-black text-teal-900">
                              +{formatMoney(item.estimatedMonthlyProfit)}
                            </span>
                          </div>

                          <button
                            onClick={() => {
                              setSelectedProfitItem(item);
                              setIsProfitPayoutModalOpen(true);
                            }}
                            className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs active:scale-95 transition-all"
                          >
                            {language === 'bn' ? 'মুনাফা রিসিভ' : 'Log Payout'}
                          </button>
                        </div>
                      )}

                      {/* Values Grid: Invested Principal vs Current Valuation */}
                      <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-100">
                        <div>
                          <span className="text-[10px] font-bold text-slate-400 block uppercase">
                            {language === 'bn' ? 'আসল বিনিয়োগ' : 'Invested Principal'}
                          </span>
                          <span className="text-sm font-bold text-slate-700">
                            {formatMoney(item.investedAmount)}
                          </span>
                        </div>

                        <div className="text-right">
                          <span className="text-[10px] font-bold text-slate-400 block uppercase">
                            {language === 'bn' ? 'বর্তমান মূল্য' : 'Current Value'}
                          </span>
                          <span className="text-base font-black text-slate-900">
                            {formatMoney(item.currentValue)}
                          </span>
                        </div>
                      </div>
                    </div>

                    {/* Bottom Action Footer */}
                    <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
                      <div>
                        {profit !== 0 ? (
                          <span className={`text-xs font-bold inline-flex items-center gap-0.5 ${profit > 0 ? 'text-emerald-700' : 'text-rose-600'}`}>
                            {profit > 0 ? '+' : ''}{formatMoney(profit)} ({profitPercent > 0 ? '+' : ''}{profitPercent}%)
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400">
                            {language === 'bn' ? 'আসল পরিমাণ' : 'Face value'}
                          </span>
                        )}
                      </div>

                      {/* Action buttons based on asset type */}
                      <div className="flex items-center gap-1.5">
                        {isDPS && (
                          <button
                            onClick={() => {
                              setSelectedDPS(item);
                              setIsPayDPSModalOpen(true);
                            }}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold transition-colors"
                          >
                            <DollarSign className="w-3.5 h-3.5" />
                            <span>{language === 'bn' ? 'কিস্তি দিন' : 'Pay Installment'}</span>
                          </button>
                        )}

                        {(isSanchay || isFDR) && (
                          <button
                            onClick={() => {
                              setSelectedProfitItem(item);
                              setIsProfitPayoutModalOpen(true);
                            }}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-800 rounded-xl text-xs font-bold transition-colors"
                          >
                            <Award className="w-3.5 h-3.5" />
                            <span>{language === 'bn' ? 'মুনাফা গ্রহণ' : 'Claim Profit'}</span>
                          </button>
                        )}

                        {isGold && (
                          <button
                            onClick={() => setIsGoldRateModalOpen(true)}
                            className="inline-flex items-center gap-1 px-3 py-1.5 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-bold transition-colors"
                          >
                            <Coins className="w-3.5 h-3.5" />
                            <span>{language === 'bn' ? 'দর আপডেট' : 'Rates'}</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

        </div>
      )}

      {/* ========================================================= */}
      {/* COMPREHENSIVE FINANCIAL CALCULATOR SUITE */}
      {/* ========================================================= */}
      {activeTab === 'calculator' && (
        <div className="space-y-6">

          {/* Calculator Category Switcher */}
          <div className="flex items-center justify-center sm:justify-start gap-2 bg-white border border-slate-200/80 p-1.5 rounded-2xl shadow-xs w-fit">
            <button
              onClick={() => setCalcSubTab('dps')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                calcSubTab === 'dps'
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Clock className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'ডিপিএস ও চক্রবৃদ্ধি' : 'DPS & Growth'}</span>
            </button>

            <button
              onClick={() => setCalcSubTab('sanchay')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                calcSubTab === 'sanchay'
                  ? 'bg-teal-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Award className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'সঞ্চয়পত্র ও ট্যাক্স (AIT)' : 'Sanchayapatra & Tax'}</span>
            </button>

            <button
              onClick={() => setCalcSubTab('gold')}
              className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold transition-all ${
                calcSubTab === 'gold'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              <Coins className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'স্বর্ণের ভ্যালু ও যাকাত' : 'Gold & Zakat'}</span>
            </button>
          </div>

          {/* 1. DPS & COMPOUNDING CALCULATOR */}
          {calcSubTab === 'dps' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-150">
              
              {/* Controls Form */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-5 lg:col-span-1">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-emerald-600" />
                    <span>{language === 'bn' ? 'ডিপিএস ও চক্রবৃদ্ধি ক্যালকুলেটর' : 'DPS & Growth Calculator'}</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === 'bn' ? 'মাসিক কিস্তি ও মুনাফার হার অনুযায়ী ম্যাচুরিটি হিসাব করুন' : 'Calculate expected maturity and profit returns'}
                  </p>
                </div>

                <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'মাসিক জমার পরিমাণ' : 'Monthly Deposit'} ({currency.symbol})
                    </label>
                    <input
                      type="number"
                      step="500"
                      min="500"
                      value={calcMonthlyDeposit}
                      onChange={e => setCalcMonthlyDeposit(parseFloat(e.target.value) || 0)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500"
                    />
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {[1000, 2000, 5000, 10000, 20000].map(val => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => setCalcMonthlyDeposit(val)}
                          className={`text-[10px] font-bold px-2 py-1 rounded-lg border transition-colors ${
                            calcMonthlyDeposit === val
                              ? 'bg-emerald-50 border-emerald-300 text-emerald-800'
                              : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {currency.symbol}{val.toLocaleString()}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'মেয়াদকাল (বছর)' : 'Tenure (Years)'}
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {[1, 3, 5, 10].map(yr => (
                        <button
                          key={yr}
                          type="button"
                          onClick={() => setCalcYears(yr)}
                          className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                            calcYears === yr
                              ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                              : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                          }`}
                        >
                          {yr} {language === 'bn' ? 'বছর' : 'Yr'}
                        </button>
                      ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'বার্ষিক মুনাফার হার (%)' : 'Annual Interest Rate (%)'}
                    </label>
                    <input
                      type="number"
                      step="0.25"
                      min="1"
                      max="20"
                      value={calcInterestRate}
                      onChange={e => setCalcInterestRate(parseFloat(e.target.value) || 0)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold focus:ring-2 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              </div>

              {/* Results Card */}
              <div className="bg-gradient-to-br from-emerald-900 to-teal-900 text-white rounded-3xl p-6 sm:p-8 shadow-lg lg:col-span-2 flex flex-col justify-between space-y-6">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-300 block mb-1">
                    {language === 'bn' ? 'মেয়াদান্তে সম্ভাব্য প্রাপ্তি' : 'Maturity Forecast'} ({calcYears} {language === 'bn' ? 'বছর পর' : 'Years'})
                  </span>
                  <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight">
                    {formatMoney(calculatorResult.maturityVal)}
                  </h2>
                </div>

                <div className="grid grid-cols-2 gap-4 pt-6 border-t border-white/15">
                  <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-xs">
                    <span className="text-xs text-emerald-200 block">{language === 'bn' ? 'আপনার মোট জমা (আসল)' : 'Your Total Deposit'}</span>
                    <span className="text-xl sm:text-2xl font-black text-white">
                      {formatMoney(calculatorResult.totalPrincipal)}
                    </span>
                    <p className="text-[11px] text-emerald-200/70 mt-0.5">
                      {calcYears * 12} {language === 'bn' ? 'টি কিস্তি' : 'monthly installments'}
                    </p>
                  </div>

                  <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-xs">
                    <span className="text-xs text-emerald-200 block">{language === 'bn' ? 'মোট অর্জিত মুনাফা / সুদ' : 'Total Profit Earned'}</span>
                    <span className="text-xl sm:text-2xl font-black text-emerald-300">
                      +{formatMoney(calculatorResult.totalProfit)}
                    </span>
                    <p className="text-[11px] text-emerald-200/70 mt-0.5">
                      @{calcInterestRate}% {language === 'bn' ? 'চক্রবৃদ্ধি হারে' : 'compounded'}
                    </p>
                  </div>
                </div>

                <div className="bg-white/15 rounded-2xl p-4 text-xs text-emerald-100 flex items-start gap-2.5">
                  <Info className="w-4 h-4 text-emerald-300 shrink-0 mt-0.5" />
                  <span>
                    {language === 'bn'
                      ? 'এই হিসাব চক্রবৃদ্ধি সূত্রের ওপর ভিত্তি করে তৈরি। ব্যাংকের আবগারি শুল্ক (Excise Duty) ও উৎসে কর (AIT ৫% বা ১০%) কর্তনের কারণে বাস্তব প্রাপ্তিতে সামান্য তারতম্য হতে পারে।'
                      : 'Based on standard compound interest formula. Actual payout may vary slightly due to bank excise duty and withholding tax.'}
                  </span>
                </div>
              </div>

            </div>
          )}

          {/* 2. SANCHAYAPATRA PROFIT & TAX CALCULATOR */}
          {calcSubTab === 'sanchay' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-150">
              
              {/* Sanchay Controls Form */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-5 lg:col-span-1">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                    <Award className="w-5 h-5 text-teal-600" />
                    <span>{language === 'bn' ? 'জাতীয় সঞ্চয়পত্র মুনাফা ক্যালকুলেটর' : 'National Savings Certificate'}</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === 'bn' ? 'স্কিম নির্বাচন ও উৎসে কর কর্তন (AIT) পরবর্তী নিট মুনাফা' : 'Calculate net payout after 5% / 10% tax deduction'}
                  </p>
                </div>

                <div className="space-y-4">
                  {/* Scheme selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'সঞ্চয়পত্রের স্কিম' : 'Savings Certificate Scheme'}
                    </label>
                    <select
                      value={sanchayScheme}
                      onChange={e => setSanchayScheme(e.target.value as SanchayapatraCategory)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:ring-2 focus:ring-teal-500"
                    >
                      <option value="poribar">পরিবার সঞ্চয়পত্র (৫ বছর - ১১.৫২% মাসিক)</option>
                      <option value="three_month">৩ মাস অন্তর মুনাফাভিত্তিক (৩ বছর - ১১.০৪%)</option>
                      <option value="pensioner">পেনশনার সঞ্চয়পত্র (৫ বছর - ১১.৭৬% কোয়ার্টারলি)</option>
                      <option value="bangladesh_5yr">৫ বছর মেয়াদী বাংলাদেশ সঞ্চয়পত্র (১১.২৮%)</option>
                      <option value="post_office">ডাকঘর সঞ্চয় ব্যাংক - মেয়াদী (৩ বছর - ১১.২%)</option>
                    </select>
                  </div>

                  {/* Principal Amount */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'বিনিয়োগের পরিমাণ (আসল)' : 'Investment Amount'} ({currency.symbol})
                    </label>
                    <input
                      type="number"
                      step="50000"
                      min="50000"
                      value={sanchayPrincipal}
                      onChange={e => setSanchayPrincipal(parseFloat(e.target.value) || 0)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-black text-slate-900 focus:ring-2 focus:ring-teal-500"
                    />

                    {/* Preset buttons */}
                    <div className="flex flex-wrap gap-1.5 mt-2">
                      {[100000, 200000, 500000, 1000000, 2000000].map(val => (
                        <button
                          key={val}
                          type="button"
                          onClick={() => setSanchayPrincipal(val)}
                          className={`text-[10px] font-bold px-2 py-1 rounded-lg border transition-colors ${
                            sanchayPrincipal === val
                              ? 'bg-teal-50 border-teal-300 text-teal-800'
                              : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
                          }`}
                        >
                          {val >= 100000 ? `${val / 100000} লাখ` : `${val.toLocaleString()} ৳`}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Tax tier selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'উৎসে কর (AIT) হার' : 'Source Tax (AIT Rate)'}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setSanchayTaxTier(5)}
                        className={`py-2 px-2 text-xs font-bold rounded-xl border text-center transition-all ${
                          sanchayTaxTier === 5
                            ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        ৫% কর (৫ লাখ পর্যন্ত)
                      </button>
                      <button
                        type="button"
                        onClick={() => setSanchayTaxTier(10)}
                        className={`py-2 px-2 text-xs font-bold rounded-xl border text-center transition-all ${
                          sanchayTaxTier === 10
                            ? 'bg-teal-600 text-white border-teal-600 shadow-xs'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        ১০% কর (৫ লাখের বেশি)
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Sanchay Results Card */}
              <div className="bg-gradient-to-br from-teal-950 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-lg lg:col-span-2 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-teal-300">
                      {sanchayResult.schemeName} ({sanchayResult.rate}% {language === 'bn' ? 'মুনাফা' : 'Yield'})
                    </span>
                    <span className="text-xs bg-teal-500/20 text-teal-200 border border-teal-400/30 px-2 py-0.5 rounded-full font-bold">
                      {sanchayTaxTier}% AIT কর কর্তন
                    </span>
                  </div>

                  <span className="text-xs text-slate-300 block">
                    {sanchayResult.frequency === 'monthly'
                      ? (language === 'bn' ? 'প্রতি মাসে নিট ব্যাংক একাউন্টে জমা হবে' : 'Net Monthly Payout')
                      : sanchayResult.frequency === 'quarterly'
                      ? (language === 'bn' ? 'প্রতি ৩ মাসে নিট ব্যাংক একাউন্টে জমা হবে' : 'Net Quarterly Payout')
                      : (language === 'bn' ? 'মেয়াদান্তে নিট মুনাফা' : 'Net Maturity Profit')}
                  </span>

                  <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-1">
                    {formatMoney(sanchayResult.netPayout)}
                  </h2>

                  {sanchayResult.frequency === 'quarterly' && (
                    <p className="text-xs text-teal-300 font-semibold mt-1">
                      ≈ সমতুল্য মাসিক প্যাসিভ ইনকাম: <strong>{formatMoney(sanchayResult.monthlyEquivalent)}</strong>/মাস
                    </p>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-3 pt-6 border-t border-white/15">
                  <div className="bg-white/10 rounded-2xl p-3.5 backdrop-blur-xs">
                    <span className="text-[11px] text-teal-200 block">{language === 'bn' ? 'মোট গ্রস প্রাপ্তি' : 'Gross Payout'}</span>
                    <span className="text-base sm:text-lg font-black text-white">
                      {formatMoney(sanchayResult.grossPayout)}
                    </span>
                  </div>

                  <div className="bg-white/10 rounded-2xl p-3.5 backdrop-blur-xs">
                    <span className="text-[11px] text-rose-300 block">{language === 'bn' ? 'উৎসে কর (AIT)' : 'Tax Deducted'}</span>
                    <span className="text-base sm:text-lg font-black text-rose-300">
                      -{formatMoney(sanchayResult.taxAmount)}
                    </span>
                  </div>

                  <div className="bg-white/10 rounded-2xl p-3.5 backdrop-blur-xs">
                    <span className="text-[11px] text-emerald-300 block">{language === 'bn' ? 'বাৎসরিক নিট আয়' : 'Net Annual'}</span>
                    <span className="text-base sm:text-lg font-black text-emerald-300">
                      {formatMoney(sanchayResult.netPayout * (sanchayResult.frequency === 'monthly' ? 12 : sanchayResult.frequency === 'quarterly' ? 4 : 1))}
                    </span>
                  </div>
                </div>

                <div className="bg-white/10 rounded-2xl p-4 text-xs text-teal-100 flex items-start gap-2.5">
                  <ShieldCheck className="w-4 h-4 text-teal-300 shrink-0 mt-0.5" />
                  <span>
                    {language === 'bn'
                      ? 'বাংলাদেশ সরকারের জাতীয় সঞ্চয় অধিদপ্তরের বর্তমান নীতি অনুযায়ী পরিবার সঞ্চয়পত্রে একজন নারী সর্বোচ্চ ৪৫ লাখ টাকা এবং ৩ মাস অন্তর মুনাফাভিত্তিক সঞ্চয়পত্রে একক নামে ৩০ লাখ ও যৌথ নামে ৬০ লাখ টাকা পর্যন্ত বিনিয়োগ করা যায়।'
                      : 'Subject to National Savings Department limits: Paribar max 45L for women, 3-Month max 30L single / 60L joint.'}
                  </span>
                </div>
              </div>

            </div>
          )}

          {/* 3. GOLD CONVERTER & ZAKAT CALCULATOR */}
          {calcSubTab === 'gold' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-in fade-in duration-150">
              
              {/* Gold Controls Form */}
              <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-5 lg:col-span-1">
                <div>
                  <h3 className="text-base font-extrabold text-slate-900 flex items-center gap-2">
                    <Coins className="w-5 h-5 text-amber-600" />
                    <span>{language === 'bn' ? 'স্বর্ণ কনভার্টার ও যাকাত ক্যালকুলেটর' : 'Gold & Zakat Calculator'}</span>
                  </h3>
                  <p className="text-xs text-slate-400 mt-1">
                    {language === 'bn' ? 'ভরি, আনা, রতি ও গ্রাম রূপান্তর এবং বাৎসরিক যাকাত' : 'Convert bhori/ana/roti to grams and calculate Zakat'}
                  </p>
                </div>

                <div className="space-y-4">
                  {/* Mode selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'ওজন পরিমাপের একক' : 'Unit Mode'}
                    </label>
                    <div className="grid grid-cols-2 gap-2">
                      <button
                        type="button"
                        onClick={() => setGoldInputMode('bhori_ana')}
                        className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                          goldInputMode === 'bhori_ana'
                            ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        ভরি, আনা ও রতি
                      </button>
                      <button
                        type="button"
                        onClick={() => setGoldInputMode('grams')}
                        className={`py-2 text-xs font-bold rounded-xl border transition-all ${
                          goldInputMode === 'grams'
                            ? 'bg-amber-600 text-white border-amber-600 shadow-xs'
                            : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                        }`}
                      >
                        সরাসরি গ্রাম (Grams)
                      </button>
                    </div>
                  </div>

                  {/* Inputs for Bhori / Ana / Roti */}
                  {goldInputMode === 'bhori_ana' ? (
                    <div className="grid grid-cols-3 gap-2">
                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 mb-1">
                          {language === 'bn' ? 'ভরি' : 'Bhori'}
                        </label>
                        <input
                          type="number"
                          min="0"
                          value={calcGoldBhori}
                          onChange={e => setCalcGoldBhori(parseFloat(e.target.value) || 0)}
                          className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 mb-1">
                          {language === 'bn' ? 'আনা (০-১৫)' : 'Ana'}
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="15"
                          value={calcGoldAna}
                          onChange={e => setCalcGoldAna(parseFloat(e.target.value) || 0)}
                          className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-slate-500 mb-1">
                          {language === 'bn' ? 'রতি (০-৫)' : 'Roti'}
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="5"
                          value={calcGoldRoti}
                          onChange={e => setCalcGoldRoti(parseFloat(e.target.value) || 0)}
                          className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold"
                        />
                      </div>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-xs font-bold text-slate-500 mb-1">
                        {language === 'bn' ? 'স্বর্ণের ওজন (গ্রামে)' : 'Weight in Grams'}
                      </label>
                      <input
                        type="number"
                        step="0.1"
                        min="0"
                        value={calcGoldGrams}
                        onChange={e => setCalcGoldGrams(parseFloat(e.target.value) || 0)}
                        className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold"
                      />
                    </div>
                  )}

                  {/* Gold Purity Karat */}
                  <div>
                    <label className="block text-xs font-bold text-slate-500 mb-1">
                      {language === 'bn' ? 'ক্যারেট / মান' : 'Karat Grade'}
                    </label>
                    <select
                      value={calcGoldPurity}
                      onChange={e => setCalcGoldPurity(e.target.value as GoldPurity)}
                      className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800"
                    >
                      <option value="24k">২৪ ক্যারেট পাকা সোনা ({formatMoney(goldMarketRates.price24k)}/ভরি)</option>
                      <option value="22k">২২ ক্যারেট হলমার্ক গহনা ({formatMoney(goldMarketRates.price22k)}/ভরি)</option>
                      <option value="21k">২১ ক্যারেট গহনা ({formatMoney(goldMarketRates.price21k)}/ভরি)</option>
                      <option value="18k">১৮ ক্যারেট ({formatMoney(goldMarketRates.price18k)}/ভরি)</option>
                      <option value="traditional">সনাতন পদ্ধতি ({formatMoney(goldMarketRates.priceTraditional)}/ভরি)</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Gold Results Card */}
              <div className="bg-gradient-to-br from-amber-950 via-yellow-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-lg lg:col-span-2 flex flex-col justify-between space-y-6">
                <div>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-amber-300">
                      {language === 'bn' ? 'বর্তমান বাজুস বাজারদর অনুযায়ী মোট মূল্য' : 'BAJUS Market Valuation'}
                    </span>
                    <button
                      onClick={() => setIsGoldRateModalOpen(true)}
                      className="text-xs px-2.5 py-1 bg-amber-500/20 text-amber-200 hover:bg-amber-500/30 rounded-xl border border-amber-400/30 font-semibold"
                    >
                      দর আপডেট
                    </button>
                  </div>

                  <h2 className="text-3xl sm:text-5xl font-black text-white tracking-tight mt-1">
                    {formatMoney(goldResult.totalMarketValue)}
                  </h2>

                  <p className="text-xs sm:text-sm text-amber-200 font-semibold mt-1">
                    মোট ওজন: <strong>{goldResult.totalBhori} ভরি</strong> (≈ {goldResult.totalGrams} গ্রাম)
                  </p>
                </div>

                {/* Zakat status and calculation */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-6 border-t border-white/15">
                  <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-xs">
                    <span className="text-xs text-amber-200 block mb-0.5">{language === 'bn' ? 'নেসাব মানদণ্ড (৭.৫ ভরি)' : 'Nisab Benchmark (7.5 Bhori)'}</span>
                    <div className="text-sm sm:text-base font-black flex items-center gap-1.5">
                      {goldResult.meetsNisab ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                          <span className="text-emerald-300">{language === 'bn' ? 'নেসাব পূর্ণ হয়েছে' : 'Nisab Reached'}</span>
                        </>
                      ) : (
                        <>
                          <Info className="w-4 h-4 text-amber-300" />
                          <span className="text-amber-200">{language === 'bn' ? '৭.৫ ভরির নিচে' : 'Below 7.5 bhori'}</span>
                        </>
                      )}
                    </div>
                    <p className="text-[10px] text-slate-300 mt-1">
                      {goldResult.meetsNisab
                        ? (language === 'bn' ? '১ চন্দ্রবছর অতিবাহিত হলে যাকাত প্রদেয়' : 'Subject to 2.5% annual zakat')
                        : (language === 'bn' ? 'অন্য নগদ অর্থ বা রুপা না থাকলে শুধু স্বর্ণে এককভাবে বাধ্যতামূলক নয়' : 'Alone does not meet standalone nisab')}
                    </p>
                  </div>

                  <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-xs">
                    <span className="text-xs text-amber-200 block mb-0.5">{language === 'bn' ? 'বাৎসরিক প্রদেয় যাকাত (২.৫%)' : 'Estimated Annual Zakat (2.5%)'}</span>
                    <span className="text-xl sm:text-2xl font-black text-amber-300">
                      {goldResult.meetsNisab ? formatMoney(goldResult.zakatAmount) : (language === 'bn' ? 'প্রযোজ্য নয়' : 'N/A')}
                    </span>
                    <p className="text-[10px] text-slate-300 mt-1">
                      {language === 'bn' ? 'বর্তমান বিক্রয়মূল্যের ওপর ১/৪০ অংশ' : '1/40th of current market liquidation value'}
                    </p>
                  </div>
                </div>

                <div className="bg-white/10 rounded-2xl p-4 text-xs text-amber-100 flex items-start gap-2.5">
                  <Scale className="w-4 h-4 text-amber-300 shrink-0 mt-0.5" />
                  <span>
                    {language === 'bn'
                      ? 'বাণিজ্যিক রূপান্তর সূত্র: ১ ভরি = ১৬ আনা = ৯৬ রতি = ১১.৬৬৪ গ্রাম। গহনা বিক্রয়ের ক্ষেত্রে বাজুস স্বর্ণ নীতিমালা অনুযায়ী শতকরা ১০-১৫% মেকিং চার্জ ও অবচয় বাদ পড়তে পারে।'
                      : '1 Bhori = 16 Ana = 96 Roti = 11.664 Grams. Jewellers may deduct 10-15% making charge upon cash sale.'}
                  </span>
                </div>
              </div>

            </div>
          )}

        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: ADD / EDIT INVESTMENT */}
      {/* ========================================================= */}
      {isAddModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsAddModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-lg w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {editingItem ? (language === 'bn' ? 'বিনিয়োগ তথ্য এডিট' : 'Edit Investment') : (language === 'bn' ? 'নতুন বিনিয়োগ / সম্পদ যোগ' : 'Add New Investment')}
              </h3>
              <button onClick={() => setIsAddModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const type = (form.elements.namedItem('invType') as HTMLSelectElement).value as InvestmentType;
                const title = (form.elements.namedItem('invTitle') as HTMLInputElement).value.trim();
                const institutionName = (form.elements.namedItem('institution') as HTMLInputElement).value.trim();
                const accountOrCertificateNo = (form.elements.namedItem('accNo') as HTMLInputElement).value.trim();
                const investedAmount = parseFloat((form.elements.namedItem('invested') as HTMLInputElement).value) || 0;
                const currentValue = parseFloat((form.elements.namedItem('currentVal') as HTMLInputElement).value) || investedAmount;
                const interestRate = parseFloat((form.elements.namedItem('interestRate') as HTMLInputElement).value) || undefined;
                const startDate = (form.elements.namedItem('startDate') as HTMLInputElement).value;
                const maturityDate = (form.elements.namedItem('maturityDate') as HTMLInputElement).value || undefined;
                const notes = (form.elements.namedItem('notes') as HTMLInputElement).value.trim();

                // Type-specific inputs
                const monthlyInstallment = parseFloat((form.elements.namedItem('monthlyInstallment') as HTMLInputElement)?.value) || undefined;
                const totalInstallments = parseInt((form.elements.namedItem('totalInstallments') as HTMLInputElement)?.value) || undefined;
                const paidInstallmentsCount = parseInt((form.elements.namedItem('paidInstallments') as HTMLInputElement)?.value) || undefined;
                const nextDueDate = (form.elements.namedItem('nextDueDate') as HTMLInputElement)?.value || undefined;

                const estimatedMonthlyProfit = parseFloat((form.elements.namedItem('monthlyProfit') as HTMLInputElement)?.value) || undefined;
                const goldWeightBhori = parseFloat((form.elements.namedItem('goldWeight') as HTMLInputElement)?.value) || undefined;
                const goldPurity = (form.elements.namedItem('goldPurity') as HTMLSelectElement)?.value as GoldPurity || undefined;

                if (!title || !institutionName) return;

                if (editingItem) {
                  editInvestment({
                    ...editingItem,
                    type,
                    title,
                    institutionName,
                    accountOrCertificateNo,
                    investedAmount,
                    currentValue,
                    interestRate,
                    startDate,
                    maturityDate,
                    notes,
                    monthlyInstallment,
                    totalInstallments,
                    paidInstallmentsCount,
                    nextInstallmentDueDate: nextDueDate,
                    estimatedMonthlyProfit,
                    goldWeightBhori,
                    goldPurity,
                  });
                  showToast(language === 'bn' ? 'বিনিয়োগ আপডেট হয়েছে' : 'Investment updated');
                } else {
                  addInvestment({
                    type,
                    title,
                    institutionName,
                    accountOrCertificateNo,
                    investedAmount,
                    currentValue,
                    interestRate,
                    startDate,
                    maturityDate,
                    status: 'active',
                    notes,
                    monthlyInstallment,
                    totalInstallments,
                    paidInstallmentsCount: paidInstallmentsCount || 1,
                    nextInstallmentDueDate: nextDueDate,
                    estimatedMonthlyProfit,
                    goldWeightBhori,
                    goldPurity: goldPurity || '22k',
                    hasZakatPayable: type === 'gold',
                  });
                  showToast(language === 'bn' ? 'নতুন বিনিয়োগ যোগ হয়েছে' : 'Investment added');
                }

                setIsAddModalOpen(false);
              }}
              className="space-y-4"
            >
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'বিনিয়োগের ধরন' : 'Asset Type'} *
                  </label>
                  <select
                    name="invType"
                    defaultValue={editingItem?.type || 'dps'}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  >
                    <option value="dps">{language === 'bn' ? 'ডিপিএস (DPS)' : 'DPS'}</option>
                    <option value="sanchayapatra">{language === 'bn' ? 'সঞ্চয়পত্র (Savings Certificate)' : 'Sanchayapatra'}</option>
                    <option value="fdr">{language === 'bn' ? 'স্থায়ী আমানত (FDR)' : 'Fixed Deposit (FDR)'}</option>
                    <option value="gold">{language === 'bn' ? 'স্বর্ণ ও অলংকার (Gold)' : 'Gold & Jewelry'}</option>
                    <option value="stocks">{language === 'bn' ? 'শেয়ার ও স্টকস (Stocks)' : 'Stocks'}</option>
                    <option value="mutual_fund">{language === 'bn' ? 'মিউচুয়াল ফান্ড (Mutual Fund)' : 'Mutual Fund'}</option>
                    <option value="provident_fund">{language === 'bn' ? 'প্রভিডেন্ট ফান্ড (GPF/CPF)' : 'Provident Fund'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'ব্যাংক বা প্রতিষ্ঠান' : 'Bank / Institution'} *
                  </label>
                  <input
                    type="text"
                    name="institution"
                    required
                    defaultValue={editingItem?.institutionName || 'City Bank'}
                    placeholder="যেমন: City Bank বা বাংলাদেশ ব্যাংক"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'বিনিয়োগের নাম / স্কিম' : 'Investment Title'} *
                </label>
                <input
                  type="text"
                  name="invTitle"
                  required
                  defaultValue={editingItem?.title || ''}
                  placeholder="যেমন: ৫ বছর মেয়াদী সিটি ব্যাংক ডিপিএস"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'মোট বিনিয়োগকৃত আসল' : 'Invested Principal'} ({currency.symbol}) *
                  </label>
                  <input
                    type="number"
                    name="invested"
                    required
                    min="0"
                    defaultValue={editingItem?.investedAmount ?? 50000}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'বর্তমান মূল্য / স্থিতি' : 'Current Value'} ({currency.symbol})
                  </label>
                  <input
                    type="number"
                    name="currentVal"
                    min="0"
                    defaultValue={editingItem?.currentValue ?? 50000}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-emerald-800"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'বার্ষিক মুনাফার হার (%)' : 'Interest Rate (%)'}
                  </label>
                  <input
                    type="number"
                    step="0.1"
                    name="interestRate"
                    defaultValue={editingItem?.interestRate ?? 9.0}
                    placeholder="9.0"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'একাউন্ট বা সনদ নং' : 'Account / Certificate #'}
                  </label>
                  <input
                    type="text"
                    name="accNo"
                    defaultValue={editingItem?.accountOrCertificateNo || ''}
                    placeholder="DPS-12345"
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                  />
                </div>
              </div>

              {/* DPS specific parameters */}
              <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-3.5 space-y-3 text-xs">
                <span className="font-bold text-slate-700 block">
                  {language === 'bn' ? 'ডিপিএস / সঞ্চয়পত্র / স্বর্ণের বিস্তারিত (প্রযোজ্য ক্ষেত্রে)' : 'Extra Parameters'}
                </span>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] text-slate-500 font-semibold mb-0.5">
                      {language === 'bn' ? 'ডিপিএস মাসিক কিস্তি' : 'DPS Monthly Deposit'}
                    </label>
                    <input
                      type="number"
                      name="monthlyInstallment"
                      defaultValue={editingItem?.monthlyInstallment || 5000}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-500 font-semibold mb-0.5">
                      {language === 'bn' ? 'সঞ্চয়পত্রের মাসিক মুনাফা' : 'Monthly Payout'}
                    </label>
                    <input
                      type="number"
                      name="monthlyProfit"
                      defaultValue={editingItem?.estimatedMonthlyProfit || ''}
                      placeholder="যেমন: ৪৬০০"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="block text-[11px] text-slate-500 font-semibold mb-0.5">
                      {language === 'bn' ? 'স্বর্ণের ওজন (ভরি)' : 'Gold Weight (Bhori)'}
                    </label>
                    <input
                      type="number"
                      step="0.01"
                      name="goldWeight"
                      defaultValue={editingItem?.goldWeightBhori || ''}
                      placeholder="যেমন: ৩.২৫"
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                    />
                  </div>

                  <div>
                    <label className="block text-[11px] text-slate-500 font-semibold mb-0.5">
                      {language === 'bn' ? 'স্বর্ণের ক্যারেট' : 'Gold Purity'}
                    </label>
                    <select
                      name="goldPurity"
                      defaultValue={editingItem?.goldPurity || '22k'}
                      className="w-full px-2.5 py-1.5 bg-white border border-slate-200 rounded-lg text-xs"
                    >
                      <option value="24k">24 Karat (২৪ ক্যারেট)</option>
                      <option value="22k">22 Karat Hallmark (২২ ক্যারেট)</option>
                      <option value="21k">21 Karat (২১ ক্যারেট)</option>
                      <option value="18k">18 Karat (১৮ ক্যারেট)</option>
                      <option value="traditional">Traditional (সনাতন)</option>
                    </select>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'শুরুর তারিখ' : 'Start Date'}
                  </label>
                  <input
                    type="date"
                    name="startDate"
                    defaultValue={editingItem?.startDate || new Date().toISOString().split('T')[0]}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'মেয়াদ শেষের তারিখ' : 'Maturity Date'}
                  </label>
                  <input
                    type="date"
                    name="maturityDate"
                    defaultValue={editingItem?.maturityDate || ''}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'নোট বা বিবরণ' : 'Notes'}
                </label>
                <input
                  type="text"
                  name="notes"
                  defaultValue={editingItem?.notes || ''}
                  placeholder="যেমন: স্বয়ংক্রিয় ডেবিট সক্রিয়"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'সংরক্ষণ' : 'Save'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: BAJUS GOLD RATES UPDATE */}
      {/* ========================================================= */}
      {isGoldRateModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsGoldRateModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
                  <Coins className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="font-bold text-base text-slate-800">
                    {language === 'bn' ? 'আজকের স্বর্ণের বাজারদর (BAJUS)' : 'Gold Market Rates'}
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    {language === 'bn' ? 'ভরি প্রতি বর্তমান বাজারমূল্য আপডেট করুন' : 'Benchmark price per bhori (11.664g)'}
                  </p>
                </div>
              </div>

              <button onClick={() => setIsGoldRateModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const p22 = parseFloat((form.elements.namedItem('p22') as HTMLInputElement).value);
                const p24 = parseFloat((form.elements.namedItem('p24') as HTMLInputElement).value);
                const p21 = parseFloat((form.elements.namedItem('p21') as HTMLInputElement).value);
                const p18 = parseFloat((form.elements.namedItem('p18') as HTMLInputElement).value);

                if (isNaN(p22) || p22 <= 0) return;

                updateGoldRates({
                  price22k: p22,
                  price24k: p24 || Math.round(p22 * 1.08),
                  price21k: p21 || Math.round(p22 * 0.95),
                  price18k: p18 || Math.round(p22 * 0.82),
                });

                confetti({
                  particleCount: 40,
                  spread: 50,
                  origin: { y: 0.7 },
                });
                showToast(language === 'bn' ? 'স্বর্ণের দর আপডেট হয়েছে ও পোর্টফোলিও পুনঃমূল্যায়িত হয়েছে!' : 'Gold rates updated & portfolio revalued!');
                setIsGoldRateModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-amber-900 mb-1">
                  ⭐ {language === 'bn' ? '২২ ক্যারেট হলমার্ক গোল্ড (প্রতি ভরি)' : '22 Karat Hallmark (Per Bhori)'} *
                </label>
                <input
                  type="number"
                  name="p22"
                  required
                  defaultValue={goldMarketRates.price22k}
                  className="w-full px-3.5 py-2.5 bg-amber-50/70 border border-amber-300 rounded-xl text-sm font-black text-amber-950 focus:ring-2 focus:ring-amber-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? '২৪ ক্যারেট (পাকা সোনা)' : '24 Karat Pure'}
                  </label>
                  <input
                    type="number"
                    name="p24"
                    defaultValue={goldMarketRates.price24k}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? '২১ ক্যারেট' : '21 Karat'}
                  </label>
                  <input
                    type="number"
                    name="p21"
                    defaultValue={goldMarketRates.price21k}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? '১৮ ক্যারেট' : '18 Karat'}
                </label>
                <input
                  type="number"
                  name="p18"
                  defaultValue={goldMarketRates.price18k}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsGoldRateModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-amber-600 hover:bg-amber-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'দর আপডেট করুন' : 'Update Rates'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: PAY DPS INSTALLMENT */}
      {/* ========================================================= */}
      {isPayDPSModalOpen && selectedDPS && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsPayDPSModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-base text-slate-800">
                  {language === 'bn' ? 'ডিপিএস কিস্তি পরিশোধ' : 'Pay DPS Installment'}
                </h3>
                <p className="text-xs text-slate-400">
                  {selectedDPS.title} ({selectedDPS.institutionName})
                </p>
              </div>
              <button onClick={() => setIsPayDPSModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const amount = parseFloat((form.elements.namedItem('dpsPayAmount') as HTMLInputElement).value);
                const accountId = (form.elements.namedItem('payAccId') as HTMLSelectElement).value;
                const payDate = (form.elements.namedItem('payDate') as HTMLInputElement).value;

                if (isNaN(amount) || amount <= 0) return;

                const res = payDPSInstallment(selectedDPS.id, accountId, amount, payDate);
                if (res.success) {
                  confetti({
                    particleCount: 45,
                    spread: 60,
                    origin: { y: 0.8 },
                  });
                  showToast(res.message);
                }

                setIsPayDPSModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'কিস্তির পরিমাণ' : 'Installment Amount'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  name="dpsPayAmount"
                  required
                  min="1"
                  defaultValue={selectedDPS.monthlyInstallment || 5000}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base font-black text-slate-900"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'কোন একাউন্ট থেকে কর্তন হবে?' : 'Pay from Wallet / Bank'}
                </label>
                <select
                  name="payAccId"
                  defaultValue={selectedDPS.linkedAccountId || accounts[0]?.id}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                >
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} ({formatMoney(acc.balance)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'পরিশোধের তারিখ' : 'Payment Date'}
                </label>
                <input
                  type="date"
                  name="payDate"
                  defaultValue={new Date().toISOString().split('T')[0]}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsPayDPSModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'কিস্তি পরিশোধ সম্পন্ন' : 'Confirm Payment'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ========================================================= */}
      {/* MODAL: LOG SANCHAYAPATRA / FDR PROFIT PAYOUT */}
      {/* ========================================================= */}
      {isProfitPayoutModalOpen && selectedProfitItem && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setIsProfitPayoutModalOpen(false);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 space-y-4 shadow-2xl max-h-[90dvh] overflow-y-auto"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div>
                <h3 className="font-bold text-base text-slate-800">
                  {language === 'bn' ? 'সঞ্চয়পত্র / এফডিআর মুনাফা গ্রহণ' : 'Record Profit Payout'}
                </h3>
                <p className="text-xs text-slate-400">
                  {selectedProfitItem.title}
                </p>
              </div>
              <button onClick={() => setIsProfitPayoutModalOpen(false)} className="p-1 rounded-full text-slate-400 hover:text-slate-600">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={e => {
                e.preventDefault();
                const form = e.currentTarget;
                const amount = parseFloat((form.elements.namedItem('profitAmount') as HTMLInputElement).value);
                const accountId = (form.elements.namedItem('receiveAccId') as HTMLSelectElement).value;
                const date = (form.elements.namedItem('receiveDate') as HTMLInputElement).value;

                if (isNaN(amount) || amount <= 0) return;

                const res = recordInvestmentProfitPayout(selectedProfitItem.id, accountId, amount, date);
                if (res.success) {
                  confetti({
                    particleCount: 45,
                    spread: 60,
                    origin: { y: 0.8 },
                  });
                  showToast(res.message);
                }

                setIsProfitPayoutModalOpen(false);
              }}
              className="space-y-4"
            >
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'মুনাফার পরিমাণ (AIT কর্তন পরবর্তী)' : 'Net Profit Amount'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  name="profitAmount"
                  required
                  min="1"
                  defaultValue={selectedProfitItem.estimatedMonthlyProfit || 4600}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-base font-black text-emerald-800"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'কোন একাউন্টে জমা হবে?' : 'Deposit to Account'}
                </label>
                <select
                  name="receiveAccId"
                  defaultValue={selectedProfitItem.linkedAccountId || accounts[0]?.id}
                  className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                >
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {acc.name} ({formatMoney(acc.balance)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'প্রাপ্তির তারিখ' : 'Received Date'}
                </label>
                <input
                  type="date"
                  name="receiveDate"
                  defaultValue={new Date().toISOString().split('T')[0]}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsProfitPayoutModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {language === 'bn' ? 'মুনাফা যোগ করুন' : 'Confirm Receipt'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
