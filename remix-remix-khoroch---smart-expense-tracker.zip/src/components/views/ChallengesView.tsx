import React, { useState, useMemo } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { SavingsChallenge, ChallengeCategory } from '../../types';
import {
  Flame,
  Trophy,
  Award,
  Sparkles,
  Calendar as CalendarIcon,
  Plus,
  CheckCircle2,
  Circle,
  TrendingUp,
  Zap,
  ShieldCheck,
  PiggyBank,
  UtensilsCrossed,
  Coins,
  Crown,
  ChevronLeft,
  ChevronRight,
  Info,
  Check,
  X,
  Wallet,
  ArrowRight,
  Share2,
  AlertCircle,
  HelpCircle,
  Target,
  Clock,
  Coffee,
} from 'lucide-react';
import confetti from 'canvas-confetti';

export const ChallengesView: React.FC = () => {
  const {
    savingsChallenges,
    noSpendRecords,
    gamificationBadges,
    userXP,
    userLevel,
    currentNoSpendStreak,
    bestNoSpendStreak,
    totalSavedFromChallenges,
    toggleNoSpendDay,
    addSavingsChallenge,
    checkInChallengeDay,
    deleteSavingsChallenge,
    accounts,
    formatMoney,
    language,
    currency,
  } = useExpense();

  const [activeTab, setActiveTab] = useState<'challenges' | 'calendar' | 'badges'>('challenges');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modals
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [checkInModalChallenge, setCheckInModalChallenge] = useState<SavingsChallenge | null>(null);
  const [checkInDepositAmount, setCheckInDepositAmount] = useState<number>(100);
  const [checkInAccountId, setCheckInAccountId] = useState<string>(accounts[0]?.id || '');
  const [selectedCalendarDate, setSelectedCalendarDate] = useState<string | null>(null);
  const [calendarDayNote, setCalendarDayNote] = useState<string>('');

  // Calendar month state
  const [currentCalendarDate, setCurrentCalendarDate] = useState<Date>(new Date());

  // Form state for creating a new challenge
  const [newTitle, setNewTitle] = useState('');
  const [newTitleBn, setNewTitleBn] = useState('');
  const [newDescription, setNewDescription] = useState('');
  const [newCategory, setNewCategory] = useState<ChallengeCategory>('daily');
  const [newTargetAmount, setNewTargetAmount] = useState<number>(3000);
  const [newDurationDays, setNewDurationDays] = useState<number>(30);
  const [newDailyTarget, setNewDailyTarget] = useState<number>(100);
  const [newIcon, setNewIcon] = useState('PiggyBank');
  const [newColor, setNewColor] = useState('#10b981');

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3500);
  };

  // Level title helper
  const getLevelInfo = (level: number) => {
    switch (level) {
      case 1:
        return {
          title: language === 'bn' ? 'সেভিংস শিক্ষানবিস' : 'Savings Rookie',
          color: 'text-emerald-400',
          nextXP: 500,
        };
      case 2:
        return {
          title: language === 'bn' ? 'হিসেবী যোদ্ধা' : 'Smart Saver',
          color: 'text-teal-400',
          nextXP: 1000,
        };
      case 3:
        return {
          title: language === 'bn' ? 'বাজেট মাস্টার' : 'Budget Master',
          color: 'text-cyan-400',
          nextXP: 1500,
        };
      case 4:
        return {
          title: language === 'bn' ? 'মানি নিনজা' : 'Money Ninja',
          color: 'text-amber-400',
          nextXP: 2000,
        };
      case 5:
      default:
        return {
          title: language === 'bn' ? 'আর্থিক স্বাধীনতা চ্যাম্পিয়ন' : 'Wealth Champion',
          color: 'text-purple-400',
          nextXP: 3000,
        };
    }
  };

  const levelInfo = getLevelInfo(userLevel);
  const xpInCurrentLevel = userXP % 500;
  const levelProgressPercent = Math.min(100, Math.round((xpInCurrentLevel / 500) * 100));

  // Today check
  const todayStr = new Date().toISOString().split('T')[0];
  const isTodayNoSpend = noSpendRecords.some(r => r.date === todayStr && r.status === 'no_spend');

  // Handle Mark Today
  const handleMarkTodayNoSpend = () => {
    toggleNoSpendDay(todayStr, 'no_spend', language === 'bn' ? 'আজকের নো-স্পেন্ড ডে সফল!' : 'Successful No-Spend day!');
    confetti({ particleCount: 40, spread: 70, origin: { y: 0.6 } });
    showToast(
      language === 'bn'
        ? '🔥 আজকের দিনটি নো-স্পেন্ড ডে হিসেবে চিহ্নিত হয়েছে! (+৫০ XP)'
        : '🔥 Today marked as No-Spend Day! (+50 XP)'
    );
  };

  // Calendar days generation
  const calendarDays = useMemo(() => {
    const year = currentCalendarDate.getFullYear();
    const month = currentCalendarDate.getMonth();
    const firstDay = new Date(year, month, 1).getDay(); // 0 is Sunday
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    const days = [];
    // Padding for days before the 1st
    for (let i = 0; i < firstDay; i++) {
      days.push({ dayNumber: null, dateStr: null, record: null });
    }

    // Month days
    for (let day = 1; day <= daysInMonth; day++) {
      const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
      const record = noSpendRecords.find(r => r.date === dateStr) || null;
      days.push({ dayNumber: day, dateStr, record });
    }

    return days;
  }, [currentCalendarDate, noSpendRecords]);

  // Filter challenges
  const filteredChallenges = useMemo(() => {
    return savingsChallenges.filter(c => {
      if (filterCategory === 'all') return true;
      if (filterCategory === 'active') return c.status === 'active';
      if (filterCategory === 'completed') return c.status === 'completed';
      return c.category === filterCategory;
    });
  }, [savingsChallenges, filterCategory]);

  // Open Check-in Modal
  const handleOpenCheckIn = (challenge: SavingsChallenge) => {
    setCheckInModalChallenge(challenge);
    setCheckInDepositAmount(challenge.dailyTarget || 100);
    setCheckInAccountId(accounts[0]?.id || '');
  };

  // Execute Check-in
  const handleExecuteCheckIn = () => {
    if (!checkInModalChallenge) return;
    const res = checkInChallengeDay(checkInModalChallenge.id, checkInDepositAmount, checkInAccountId);
    if (res.success) {
      confetti({ particleCount: res.completed ? 100 : 50, spread: 80, origin: { y: 0.6 } });
      showToast(res.message);
      setCheckInModalChallenge(null);
    } else {
      showToast(res.message);
    }
  };

  // Create Challenge Submission
  const handleCreateChallenge = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTitle.trim()) return;

    addSavingsChallenge({
      title: newTitle.trim(),
      titleBn: newTitleBn.trim() || newTitle.trim(),
      description: newDescription.trim() || 'Daily savings target to build disciplined wealth.',
      descriptionBn: newDescription.trim() || 'সঞ্চয়ের ধারাবাহিক অভ্যাস গড়ে তোলার চ্যালেঞ্জ।',
      category: newCategory,
      targetAmount: newTargetAmount,
      durationDays: newDurationDays,
      dailyTarget: newDailyTarget,
      rewardXP: Math.round(newDurationDays * 15),
      iconName: newIcon,
      color: newColor,
      startDate: todayStr,
    });

    confetti({ particleCount: 35, spread: 60, origin: { y: 0.7 } });
    showToast(language === 'bn' ? 'নতুন সেভিংস চ্যালেঞ্জ শুরু হয়েছে! (+৫০ XP)' : 'New Savings Challenge launched! (+50 XP)');
    setIsCreateModalOpen(false);

    // Reset
    setNewTitle('');
    setNewTitleBn('');
    setNewDescription('');
  };

  // Preset Template selector
  const handleApplyTemplate = (type: 'clay_bank' | 'cafe_ban' | 'step_up' | 'weekend') => {
    if (type === 'clay_bank') {
      setNewTitle('Daily ৳100 Clay Bank Challenge');
      setNewTitleBn('৳১০০ দৈনিক মাটির ব্যাংক চ্যালেঞ্জ');
      setNewCategory('daily');
      setNewTargetAmount(3000);
      setNewDurationDays(30);
      setNewDailyTarget(100);
      setNewIcon('PiggyBank');
      setNewColor('#10b981');
    } else if (type === 'cafe_ban') {
      setNewTitle('30-Day Zero Food Order Challenge');
      setNewTitleBn('৩০ দিনের নো-ফুড-ডেলিভারি চ্যালেঞ্জ');
      setNewCategory('category_ban');
      setNewTargetAmount(6000);
      setNewDurationDays(30);
      setNewDailyTarget(200);
      setNewIcon('UtensilsCrossed');
      setNewColor('#06b6d4');
    } else if (type === 'step_up') {
      setNewTitle('52-Week Step Up Challenge');
      setNewTitleBn('৫২-সপ্তাহের স্টেপ আপ সঞ্চয়');
      setNewCategory('weekly');
      setNewTargetAmount(137800);
      setNewDurationDays(365);
      setNewDailyTarget(350);
      setNewIcon('TrendingUp');
      setNewColor('#8b5cf6');
    } else if (type === 'weekend') {
      setNewTitle('Weekend No-Spend Sprint');
      setNewTitleBn('সাপ্তাহিক নো-স্পেন্ড উইকএন্ড');
      setNewCategory('category_ban');
      setNewTargetAmount(4000);
      setNewDurationDays(14);
      setNewDailyTarget(500);
      setNewIcon('Flame');
      setNewColor('#f59e0b');
    }
  };

  const getChallengeIcon = (name?: string) => {
    switch (name) {
      case 'PiggyBank':
        return PiggyBank;
      case 'UtensilsCrossed':
        return UtensilsCrossed;
      case 'TrendingUp':
        return TrendingUp;
      case 'Flame':
        return Flame;
      case 'Crown':
        return Crown;
      default:
        return Target;
    }
  };

  const getBadgeIcon = (name: string) => {
    switch (name) {
      case 'Flame':
        return Flame;
      case 'ShieldCheck':
        return ShieldCheck;
      case 'Zap':
        return Zap;
      case 'Trophy':
        return Trophy;
      case 'Coins':
        return Coins;
      case 'Sparkles':
        return Sparkles;
      case 'Crown':
        return Crown;
      default:
        return Award;
    }
  };

  // Share Streak text
  const handleShareStreak = () => {
    const text = `
🔥 আমার নো-স্পেন্ড স্ট্রিক: ${currentNoSpendStreak} দিন!
🏆 সেরা স্ট্রিক রেকর্ড: ${bestNoSpendStreak} দিন
💰 সেভিংস চ্যালেঞ্জে সঞ্চিত: ${currency.symbol}${totalSavedFromChallenges.toLocaleString()}
⭐ গ্যামিফিকেশন লেভেল: Level ${userLevel} (${levelInfo.title})

খরচ (Khoroch) অ্যাপের মাধ্যমে অপচয় কমিয়ে সঞ্চয় করছি!
    `.trim();
    navigator.clipboard.writeText(text);
    showToast(language === 'bn' ? 'স্ট্রিক বিবরণী কপি করা হয়েছে!' : 'Streak summary copied to clipboard!');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12 animate-in fade-in duration-200">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-70 bg-slate-900 text-white px-4 py-3 rounded-2xl shadow-xl flex items-center gap-2.5 text-xs font-semibold animate-in slide-in-from-bottom-3 border border-slate-700">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Gamified Hero Banner */}
      <div className="bg-gradient-to-br from-slate-950 via-teal-950 to-emerald-950 text-white rounded-3xl p-6 sm:p-8 shadow-sm border border-emerald-800/40 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-radial from-amber-500/10 via-emerald-500/10 to-transparent blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-60 h-60 bg-radial from-teal-500/10 to-transparent blur-2xl pointer-events-none" />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/20 text-amber-300 border border-amber-500/30 text-xs font-bold uppercase tracking-wider">
              <Flame className="w-4 h-4 text-amber-400 fill-amber-400 animate-pulse" />
              <span>{language === 'bn' ? 'নো-স্পেন্ড স্ট্রিক ও চ্যালেঞ্জ' : 'No-Spend Streak & Savings'}</span>
            </div>
            
            <div className="flex flex-wrap items-baseline gap-3">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-black text-white tracking-tight flex items-center gap-2.5">
                <span>{currentNoSpendStreak}</span>
                <span className="text-xl sm:text-2xl font-bold text-amber-300">
                  {language === 'bn' ? 'দিনের স্ট্রিক!' : 'Day Streak!'}
                </span>
                <Flame className="w-7 h-7 sm:w-9 sm:h-9 text-amber-400 fill-amber-400 shrink-0 animate-bounce" />
              </h1>
            </div>

            <p className="text-slate-300 text-xs sm:text-sm max-w-xl leading-relaxed">
              {language === 'bn'
                ? 'প্রতিদিনের ছোট ছোট অপচয় বন্ধ করে টানা নো-স্পেন্ড স্ট্রিক বজায় রাখুন। প্রতিদিন টাকা জমান, লেভেল আপ করুন এবং ট্রফি অর্জন করুন!'
                : 'Build unbreakable financial restraint with daily no-spend streaks and gamified savings challenges.'}
            </p>

            {/* Level & XP Progress Bar */}
            <div className="pt-2 max-w-md space-y-1.5">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="flex items-center gap-1.5">
                  <Award className="w-4 h-4 text-amber-400" />
                  <span>Level {userLevel}: <span className={levelInfo.color}>{levelInfo.title}</span></span>
                </span>
                <span className="text-slate-300 font-mono text-[11px]">{userXP} XP</span>
              </div>
              <div className="w-full h-2.5 bg-white/10 rounded-full overflow-hidden p-0.5 border border-white/15">
                <div
                  className="h-full bg-gradient-to-r from-emerald-400 to-amber-400 rounded-full transition-all duration-500"
                  style={{ width: `${levelProgressPercent}%` }}
                />
              </div>
            </div>
          </div>

          {/* Quick Action Buttons */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 shrink-0">
            <button
              onClick={handleMarkTodayNoSpend}
              disabled={isTodayNoSpend}
              className={`px-5 py-3.5 rounded-2xl text-xs sm:text-sm font-black transition-all flex items-center justify-center gap-2.5 shadow-md cursor-pointer ${
                isTodayNoSpend
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 cursor-default'
                  : 'bg-gradient-to-r from-amber-500 to-emerald-500 hover:from-amber-400 hover:to-emerald-400 text-slate-950 active:scale-98'
              }`}
            >
              <Flame className={`w-4 h-4 ${isTodayNoSpend ? 'text-emerald-400' : 'fill-slate-950'}`} />
              <span>
                {isTodayNoSpend
                  ? (language === 'bn' ? '✓ আজকের নো-স্পেন্ড সম্পন্ন' : '✓ Today Checked In')
                  : (language === 'bn' ? 'আজকের দিনটি মার্ক করুন' : 'Mark Today No-Spend')}
              </span>
            </button>

            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="px-4 py-3.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white border border-white/20 text-xs sm:text-sm font-bold transition-all flex items-center justify-center gap-2 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>{language === 'bn' ? 'নতুন চ্যালেঞ্জ' : 'New Challenge'}</span>
            </button>

            <button
              onClick={handleShareStreak}
              className="p-3.5 rounded-2xl bg-white/10 hover:bg-white/20 text-white border border-white/20 transition-all flex items-center justify-center cursor-pointer shadow-xs"
              title="Share Streak"
            >
              <Share2 className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="mt-8 pt-6 border-t border-white/10 flex items-center gap-2 sm:gap-4 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('challenges')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer shrink-0 ${
              activeTab === 'challenges'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'bg-white/10 text-slate-300 hover:bg-white/15 hover:text-white'
            }`}
          >
            <Target className="w-4 h-4" />
            <span>{language === 'bn' ? 'সেভিংস চ্যালেঞ্জসমূহ' : 'Savings Challenges'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-black/20 text-[10px]">
              {savingsChallenges.filter(c => c.status === 'active').length}
            </span>
          </button>

          <button
            onClick={() => setActiveTab('calendar')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer shrink-0 ${
              activeTab === 'calendar'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'bg-white/10 text-slate-300 hover:bg-white/15 hover:text-white'
            }`}
          >
            <CalendarIcon className="w-4 h-4" />
            <span>{language === 'bn' ? 'স্ট্রিক ক্যালেন্ডার' : 'Streak Calendar'}</span>
          </button>

          <button
            onClick={() => setActiveTab('badges')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-xs sm:text-sm font-black transition-all cursor-pointer shrink-0 ${
              activeTab === 'badges'
                ? 'bg-emerald-500 text-slate-950 shadow-md'
                : 'bg-white/10 text-slate-300 hover:bg-white/15 hover:text-white'
            }`}
          >
            <Trophy className="w-4 h-4" />
            <span>{language === 'bn' ? 'ব্যাজ ও ট্রফি' : 'Badges & Trophies'}</span>
            <span className="px-1.5 py-0.2 rounded-full bg-black/20 text-[10px]">
              {gamificationBadges.filter(b => b.unlocked).length}/{gamificationBadges.length}
            </span>
          </button>
        </div>
      </div>

      {/* KPI Overview Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        
        {/* Active Streak */}
        <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? 'চলতি স্ট্রিক' : 'Current Streak'}
          </span>
          <p className="text-xl sm:text-2xl font-black text-amber-600 flex items-center gap-1.5">
            <span>{currentNoSpendStreak}</span>
            <span className="text-xs font-bold text-slate-500">{language === 'bn' ? 'দিন' : 'days'}</span>
            <Flame className="w-4 h-4 text-amber-500 fill-amber-500" />
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-500">
            {language === 'bn' ? `সর্বোচ্চ রেকর্ড: ${bestNoSpendStreak} দিন` : `Best record: ${bestNoSpendStreak} days`}
          </p>
        </div>

        {/* Total Money Saved */}
        <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? 'চ্যালেঞ্জে সঞ্চিত' : 'Total Saved'}
          </span>
          <p className="text-xl sm:text-2xl font-black text-emerald-600">
            {formatMoney(totalSavedFromChallenges)}
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-500">
            {language === 'bn' ? 'সরাসরি জমানো অর্থ' : 'Deposited to jars'}
          </p>
        </div>

        {/* Active Challenges */}
        <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? 'চলমান চ্যালেঞ্জ' : 'Active Challenges'}
          </span>
          <p className="text-xl sm:text-2xl font-black text-slate-900">
            {savingsChallenges.filter(c => c.status === 'active').length}
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-500">
            {language === 'bn'
              ? `${savingsChallenges.filter(c => c.status === 'completed').length} টি সম্পন্ন`
              : `${savingsChallenges.filter(c => c.status === 'completed').length} completed`}
          </p>
        </div>

        {/* Badges Unlocked */}
        <div className="bg-white p-4 sm:p-5 rounded-3xl border border-slate-200/80 shadow-xs space-y-1">
          <span className="text-[10px] sm:text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? 'অর্জিত ব্যাজ' : 'Badges Earned'}
          </span>
          <p className="text-xl sm:text-2xl font-black text-purple-600 flex items-center gap-1.5">
            <span>{gamificationBadges.filter(b => b.unlocked).length}</span>
            <span className="text-xs font-normal text-slate-400">/ {gamificationBadges.length}</span>
            <Trophy className="w-4 h-4 text-purple-500" />
          </p>
          <p className="text-[10px] sm:text-[11px] text-slate-500">
            {language === 'bn' ? 'ট্রফি ও সম্মাননা' : 'Trophies unlocked'}
          </p>
        </div>

      </div>

      {/* ========================================================================= */}
      {/* 1. SAVINGS CHALLENGES TAB */}
      {/* ========================================================================= */}
      {activeTab === 'challenges' && (
        <div className="space-y-6">
          
          {/* Filter Bar */}
          <div className="flex flex-wrap items-center justify-between gap-3 bg-white p-3 rounded-2xl border border-slate-200/80 shadow-xs">
            <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
              {[
                { id: 'all', label: language === 'bn' ? 'সকল চ্যালেঞ্জ' : 'All' },
                { id: 'active', label: language === 'bn' ? 'চলমান' : 'Active' },
                { id: 'completed', label: language === 'bn' ? 'সম্পন্ন' : 'Completed' },
                { id: 'daily', label: language === 'bn' ? 'দৈনিক' : 'Daily' },
                { id: 'weekly', label: language === 'bn' ? 'সাপ্তাহিক' : 'Weekly' },
                { id: 'category_ban', label: language === 'bn' ? 'খরচ বয়কট' : 'Bans' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setFilterCategory(f.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    filterCategory === f.id
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'text-slate-600 hover:bg-slate-100'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>

            <button
              onClick={() => setIsCreateModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-xs font-bold border border-emerald-200/80 transition-all cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5 text-emerald-600" />
              <span>{language === 'bn' ? 'নতুন চ্যালেঞ্জ যোগ' : 'Add Challenge'}</span>
            </button>
          </div>

          {/* Challenges Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {filteredChallenges.map(challenge => {
              const IconComponent = getChallengeIcon(challenge.iconName);
              const progressPercent = Math.min(100, Math.round((challenge.completedDays / challenge.durationDays) * 100));
              const moneyPercent = challenge.targetAmount > 0
                ? Math.min(100, Math.round((challenge.currentAmount / challenge.targetAmount) * 100))
                : progressPercent;
              const isCheckedInToday = challenge.checkInDates.includes(todayStr);

              return (
                <div
                  key={challenge.id}
                  className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-6 shadow-xs flex flex-col justify-between space-y-4 hover:shadow-md transition-all relative overflow-hidden"
                >
                  {/* Top Status & Category */}
                  <div>
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 shadow-xs"
                          style={{ backgroundColor: `${challenge.color || '#10b981'}15`, color: challenge.color || '#10b981' }}
                        >
                          <IconComponent className="w-6 h-6" />
                        </div>
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-slate-100 text-slate-700">
                              {challenge.category === 'daily'
                                ? (language === 'bn' ? 'দৈনিক জমানো' : 'Daily Jar')
                                : challenge.category === 'weekly'
                                ? (language === 'bn' ? 'সাপ্তাহিক স্টেপ' : 'Weekly Step')
                                : (language === 'bn' ? 'নো-স্পেন্ড বয়কট' : 'Spending Ban')}
                            </span>
                            <span className="text-[10px] font-bold text-amber-600 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200/60">
                              +{challenge.rewardXP} XP
                            </span>
                          </div>
                          <h3 className="text-base sm:text-lg font-bold text-slate-900 mt-1">
                            {language === 'bn' ? challenge.titleBn || challenge.title : challenge.title}
                          </h3>
                        </div>
                      </div>

                      <span
                        className={`text-[11px] font-bold px-2.5 py-1 rounded-full shrink-0 ${
                          challenge.status === 'completed'
                            ? 'bg-emerald-100 text-emerald-800'
                            : 'bg-blue-50 text-blue-700'
                        }`}
                      >
                        {challenge.status === 'completed'
                          ? (language === 'bn' ? 'সম্পন্ন ✓' : 'Completed ✓')
                          : (language === 'bn' ? 'চলমান' : 'In Progress')}
                      </span>
                    </div>

                    <p className="text-xs text-slate-500 mt-2 leading-relaxed">
                      {language === 'bn' ? challenge.descriptionBn || challenge.description : challenge.description}
                    </p>
                  </div>

                  {/* Progress Metrics & Bars */}
                  <div className="space-y-3 pt-3 border-t border-slate-100">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-500">
                        {language === 'bn' ? 'দিন সম্পন্ন:' : 'Days Completed:'}{' '}
                        <strong className="text-slate-800">
                          {challenge.completedDays} / {challenge.durationDays} {language === 'bn' ? 'দিন' : 'days'}
                        </strong>
                      </span>
                      <span className="font-bold text-slate-900 font-mono">
                        {progressPercent}%
                      </span>
                    </div>

                    <div className="w-full h-2.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{ width: `${progressPercent}%`, backgroundColor: challenge.color || '#10b981' }}
                      />
                    </div>

                    {challenge.targetAmount > 0 && (
                      <div className="flex items-center justify-between text-xs pt-1">
                        <span className="text-slate-500">
                          {language === 'bn' ? 'সঞ্চিত তহবিল:' : 'Saved:'}{' '}
                          <strong className="text-emerald-700 font-black">
                            {formatMoney(challenge.currentAmount)}
                          </strong>
                        </span>
                        <span className="text-slate-400 text-[11px]">
                          {language === 'bn' ? 'টার্গেট:' : 'Target:'} {formatMoney(challenge.targetAmount)}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Bottom Action Footer */}
                  <div className="pt-2 flex items-center justify-between gap-3">
                    <button
                      onClick={() => deleteSavingsChallenge(challenge.id)}
                      className="text-xs text-slate-400 hover:text-rose-600 transition-colors font-semibold"
                    >
                      {language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
                    </button>

                    {challenge.status === 'completed' ? (
                      <div className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-700 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        <span>{language === 'bn' ? 'চ্যালেঞ্জ সম্পন্ন হয়েছে!' : 'Challenge Completed!'}</span>
                      </div>
                    ) : (
                      <button
                        onClick={() => handleOpenCheckIn(challenge)}
                        disabled={isCheckedInToday}
                        className={`px-4 py-2 rounded-xl text-xs font-black transition-all flex items-center gap-2 cursor-pointer shadow-xs ${
                          isCheckedInToday
                            ? 'bg-slate-100 text-slate-400 cursor-default'
                            : 'bg-slate-900 hover:bg-slate-800 text-white'
                        }`}
                      >
                        <Check className="w-3.5 h-3.5" />
                        <span>
                          {isCheckedInToday
                            ? (language === 'bn' ? 'আজ চেক-ইন সম্পন্ন' : 'Checked In Today')
                            : (language === 'bn' ? 'আজকের চেক-ইন ও জমা' : 'Check In & Deposit')}
                        </span>
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>

          {filteredChallenges.length === 0 && (
            <div className="bg-white border border-slate-200/80 rounded-3xl p-10 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-slate-100 text-slate-400 flex items-center justify-center mx-auto">
                <Target className="w-6 h-6" />
              </div>
              <p className="text-sm font-bold text-slate-700">
                {language === 'bn' ? 'কোনো চ্যালেঞ্জ পাওয়া যায়নি।' : 'No challenges found.'}
              </p>
              <button
                onClick={() => setIsCreateModalOpen(true)}
                className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl hover:bg-emerald-700 cursor-pointer"
              >
                {language === 'bn' ? 'একটি চ্যালেঞ্জ শুরু করুন' : 'Start a Challenge'}
              </button>
            </div>
          )}

        </div>
      )}

      {/* ========================================================================= */}
      {/* 2. STREAK CALENDAR & HEATMAP TAB */}
      {/* ========================================================================= */}
      {activeTab === 'calendar' && (
        <div className="space-y-6">
          
          <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
            
            {/* Calendar Header with Navigation */}
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center font-black">
                  <Flame className="w-5 h-5 fill-amber-500 text-amber-500" />
                </div>
                <div>
                  <h3 className="text-base sm:text-lg font-bold text-slate-900">
                    {currentCalendarDate.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
                      month: 'long',
                      year: 'numeric',
                    })}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? 'অপচয়হীন ও নো-স্পেন্ড দিনসমূহ' : 'No-Spend streak calendar & discipline log'}
                  </p>
                </div>
              </div>

              {/* Month Navigation */}
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => {
                    const prev = new Date(currentCalendarDate);
                    prev.setMonth(prev.getMonth() - 1);
                    setCurrentCalendarDate(prev);
                  }}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  onClick={() => setCurrentCalendarDate(new Date())}
                  className="px-3 py-1.5 rounded-xl bg-slate-50 hover:bg-slate-100 text-xs font-bold text-slate-700 transition-colors cursor-pointer"
                >
                  {language === 'bn' ? 'চলতি মাস' : 'Current'}
                </button>
                <button
                  onClick={() => {
                    const next = new Date(currentCalendarDate);
                    next.setMonth(next.getMonth() + 1);
                    setCurrentCalendarDate(next);
                  }}
                  className="p-2 rounded-xl bg-slate-50 hover:bg-slate-100 text-slate-700 transition-colors cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>

            {/* Legend */}
            <div className="flex flex-wrap items-center gap-4 text-xs">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-md bg-emerald-500 flex items-center justify-center text-white text-[10px]">
                  🔥
                </div>
                <span className="text-slate-600 font-semibold">{language === 'bn' ? 'নো-স্পেন্ড ডে (০ খরচ)' : 'No-Spend Day (Clean)'}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-md bg-cyan-400 flex items-center justify-center text-white text-[10px]">
                  ⚡
                </div>
                <span className="text-slate-600 font-semibold">{language === 'bn' ? 'শুধু জরুরি খরচ (বাজার/ওষুধ)' : 'Essential Only'}</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded-md bg-slate-200 border border-slate-300" />
                <span className="text-slate-600 font-semibold">{language === 'bn' ? 'সাধারণ খরচের দিন' : 'Regular Spends'}</span>
              </div>
            </div>

            {/* Days of Week Header */}
            <div className="grid grid-cols-7 gap-2 text-center text-xs font-bold text-slate-400">
              {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map((dw, i) => (
                <div key={i} className="py-1">
                  {language === 'bn'
                    ? ['রবি', 'সোম', 'মঙ্গল', 'বুধ', 'বৃহঃ', 'শুক্র', 'শনি'][i]
                    : dw}
                </div>
              ))}
            </div>

            {/* Calendar Grid */}
            <div className="grid grid-cols-7 gap-2">
              {calendarDays.map((item, idx) => {
                if (!item.dayNumber || !item.dateStr) {
                  return <div key={idx} className="h-14 sm:h-20 rounded-2xl bg-slate-50/40" />;
                }

                const isToday = item.dateStr === todayStr;
                const status = item.record?.status;

                let bgClass = 'bg-slate-50 border-slate-200/80 hover:border-slate-300';
                if (status === 'no_spend') {
                  bgClass = 'bg-emerald-50 border-emerald-300 text-emerald-950 font-bold';
                } else if (status === 'essential_only') {
                  bgClass = 'bg-cyan-50 border-cyan-300 text-cyan-950 font-bold';
                } else if (status === 'spend') {
                  bgClass = 'bg-rose-50 border-rose-200 text-rose-950';
                }

                return (
                  <button
                    key={idx}
                    onClick={() => {
                      setSelectedCalendarDate(item.dateStr);
                      setCalendarDayNote(item.record?.note || '');
                    }}
                    className={`h-14 sm:h-20 p-1.5 sm:p-2.5 rounded-2xl border text-left flex flex-col justify-between transition-all cursor-pointer relative ${bgClass} ${
                      isToday ? 'ring-2 ring-emerald-500 shadow-sm' : ''
                    }`}
                  >
                    <div className="flex items-center justify-between w-full">
                      <span className={`text-xs sm:text-sm font-black ${isToday ? 'text-emerald-700' : 'text-slate-700'}`}>
                        {item.dayNumber}
                      </span>
                      {status === 'no_spend' && (
                        <Flame className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-amber-500 fill-amber-500 shrink-0" />
                      )}
                      {status === 'essential_only' && (
                        <Zap className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-cyan-600 shrink-0" />
                      )}
                    </div>

                    <div className="text-[10px] truncate max-w-full">
                      {status === 'no_spend' && (
                        <span className="hidden sm:inline-block text-[10px] text-emerald-700 font-bold">
                          {language === 'bn' ? 'জিরো স্পেন্ড' : 'Clean Win'}
                        </span>
                      )}
                      {item.record?.note && (
                        <span className="hidden sm:block text-[9px] text-slate-500 truncate">
                          {item.record.note}
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>

          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* 3. GAMIFICATION BADGES & TROPHIES TAB */}
      {/* ========================================================================= */}
      {activeTab === 'badges' && (
        <div className="space-y-6">
          
          <div className="bg-white border border-slate-200/80 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100">
              <div>
                <h3 className="text-base sm:text-lg font-bold text-slate-900 flex items-center gap-2">
                  <Trophy className="w-5 h-5 text-amber-500" />
                  <span>{language === 'bn' ? 'অর্জন ও সম্মাননা ব্যাজ' : 'Achievements & Trophies'}</span>
                </h3>
                <p className="text-xs text-slate-400">
                  {language === 'bn' ? 'টানা স্ট্রিক ও সেভিংস সম্পন্ন করে আনলক করুন' : 'Unlock exclusive trophies by sticking to your goals'}
                </p>
              </div>

              <span className="px-3 py-1 rounded-full bg-purple-50 text-purple-700 border border-purple-200 text-xs font-bold">
                {gamificationBadges.filter(b => b.unlocked).length} / {gamificationBadges.length} {language === 'bn' ? 'আনলকড' : 'Unlocked'}
              </span>
            </div>

            {/* Badges Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {gamificationBadges.map(badge => {
                const BadgeIcon = getBadgeIcon(badge.icon);

                return (
                  <div
                    key={badge.id}
                    className={`p-5 rounded-3xl border flex items-start gap-4 transition-all relative overflow-hidden ${
                      badge.unlocked
                        ? 'bg-gradient-to-br from-white to-amber-50/30 border-amber-200/80 shadow-xs'
                        : 'bg-slate-50 border-slate-200/60 opacity-60'
                    }`}
                  >
                    <div
                      className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
                        badge.unlocked
                          ? 'bg-amber-100 text-amber-600 border border-amber-300'
                          : 'bg-slate-200 text-slate-400 border border-slate-300'
                      }`}
                    >
                      <BadgeIcon className="w-7 h-7" />
                    </div>

                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <h4 className="text-sm font-bold text-slate-900">
                          {language === 'bn' ? badge.titleBn : badge.title}
                        </h4>
                        {badge.unlocked ? (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                            ✓
                          </span>
                        ) : (
                          <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-slate-200 text-slate-600">
                            🔒
                          </span>
                        )}
                      </div>

                      <p className="text-xs text-slate-500 leading-relaxed">
                        {language === 'bn' ? badge.descBn : badge.desc}
                      </p>

                      <div className="pt-1 flex items-center gap-2 text-[11px] font-bold">
                        <span className="text-amber-600">+{badge.xpReward} XP</span>
                        {badge.unlockedAt && (
                          <span className="text-slate-400 font-normal">
                            • {badge.unlockedAt}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 1: CHECK IN & DEPOSIT MODAL */}
      {/* ========================================================================= */}
      {checkInModalChallenge && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 space-y-5 shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Check className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {language === 'bn' ? 'আজকের সেভিংস চেক-ইন' : 'Check In & Save Today'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? checkInModalChallenge.titleBn : checkInModalChallenge.title}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setCheckInModalChallenge(null)}
                className="p-1 rounded-xl hover:bg-slate-100 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'আজকের জমার পরিমাণ (৳)' : 'Deposit Amount Today'}
                </label>
                <input
                  type="number"
                  value={checkInDepositAmount || ''}
                  onChange={e => setCheckInDepositAmount(Number(e.target.value) || 0)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-base font-bold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'কোন ওয়ালেট/অ্যাকাউন্ট থেকে জমা দিবেন?' : 'Deduct from Account/Wallet'}
                </label>
                <select
                  value={checkInAccountId}
                  onChange={e => setCheckInAccountId(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-800 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                >
                  <option value="">{language === 'bn' ? 'ব্যালেন্স সমন্বয় ছাড়া শুধু চেক-ইন' : 'Check in without wallet deduction'}</option>
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {language === 'bn' ? acc.nameBn || acc.name : acc.name} ({formatMoney(acc.balance)})
                    </option>
                  ))}
                </select>
                <p className="text-[11px] text-slate-500 mt-1">
                  {language === 'bn'
                    ? 'অ্যাকাউন্ট সিলেক্ট করলে স্বয়ংক্রিয়ভাবে অ্যাকাউন্ট ব্যালেন্স থেকে জমার পরিমাণ সমন্বয় হবে।'
                    : 'Selecting an account records an authentic savings transfer from your balance.'}
                </p>
              </div>

              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  {language === 'bn'
                    ? 'চেক-ইন করলে পাবেন +৩০ XP এবং স্ট্রিক অক্ষুণ্ণ থাকবে!'
                    : 'Completing today grants +30 XP and keeps your momentum alive!'}
                </span>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-2">
              <button
                type="button"
                onClick={() => setCheckInModalChallenge(null)}
                className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="button"
                onClick={handleExecuteCheckIn}
                className="px-5 py-2.5 text-xs font-black text-slate-950 bg-emerald-500 hover:bg-emerald-400 rounded-xl shadow-sm cursor-pointer"
              >
                {language === 'bn' ? 'চেক-ইন নিশ্চিত করুন' : 'Confirm Check-in'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 2: DAY STATUS TOGGLE MODAL (From Calendar) */}
      {/* ========================================================================= */}
      {selectedCalendarDate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-sm w-full p-6 space-y-4 shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <h3 className="text-sm sm:text-base font-bold text-slate-900">
                {selectedCalendarDate} {language === 'bn' ? 'দিনের স্ট্যাটাস' : 'Day Status'}
              </h3>
              <button
                onClick={() => setSelectedCalendarDate(null)}
                className="p-1 rounded-xl hover:bg-slate-100 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-2">
              <button
                onClick={() => {
                  toggleNoSpendDay(selectedCalendarDate, 'no_spend', calendarDayNote);
                  setSelectedCalendarDate(null);
                  showToast(language === 'bn' ? 'নো-স্পেন্ড ডে চিহ্নিত হয়েছে!' : 'Marked as No-Spend Day!');
                }}
                className="w-full p-3 rounded-2xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-300 text-emerald-900 text-xs font-bold flex items-center gap-2.5 text-left cursor-pointer"
              >
                <Flame className="w-5 h-5 text-amber-500 fill-amber-500 shrink-0" />
                <div>
                  <p>{language === 'bn' ? '🔥 নো-স্পেন্ড ডে (০ অপ্রয়োজনীয় খরচ)' : '🔥 No-Spend Day (Clean Win)'}</p>
                  <p className="text-[10px] text-emerald-700 font-normal">কোনো অতিরিক্ত বা বিলাসী খরচ হয়নি</p>
                </div>
              </button>

              <button
                onClick={() => {
                  toggleNoSpendDay(selectedCalendarDate, 'essential_only', calendarDayNote);
                  setSelectedCalendarDate(null);
                  showToast(language === 'bn' ? 'শুধু জরুরি খরচ মার্ক হয়েছে!' : 'Marked as Essential Only!');
                }}
                className="w-full p-3 rounded-2xl bg-cyan-50 hover:bg-cyan-100 border border-cyan-300 text-cyan-900 text-xs font-bold flex items-center gap-2.5 text-left cursor-pointer"
              >
                <Zap className="w-5 h-5 text-cyan-600 shrink-0" />
                <div>
                  <p>{language === 'bn' ? '⚡ শুধু নিত্যপ্রয়োজনীয় (বাজার/ওষুধ)' : '⚡ Essential Spends Only'}</p>
                  <p className="text-[10px] text-cyan-700 font-normal">কাঁচাবাজার বা ওষুধ ছাড়া কোনো অপচয় হয়নি</p>
                </div>
              </button>

              <button
                onClick={() => {
                  toggleNoSpendDay(selectedCalendarDate, 'spend', calendarDayNote);
                  setSelectedCalendarDate(null);
                  showToast(language === 'bn' ? 'সাধারণ খরচের দিন হিসেবে সংরক্ষিত' : 'Marked as Regular Spend Day');
                }}
                className="w-full p-3 rounded-2xl bg-slate-50 hover:bg-slate-100 border border-slate-200 text-slate-700 text-xs font-bold flex items-center gap-2.5 text-left cursor-pointer"
              >
                <div className="w-5 h-5 rounded-lg bg-slate-200 flex items-center justify-center text-[10px]">
                  🛍️
                </div>
                <div>
                  <p>{language === 'bn' ? 'সাধারণ খরচের দিন (Regular Spend)' : 'Regular Spend Day'}</p>
                  <p className="text-[10px] text-slate-500 font-normal">বাইরে খাওয়া বা কেনাকাটার খরচ হয়েছে</p>
                </div>
              </button>
            </div>

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                {language === 'bn' ? 'নোট বা মন্তব্য (ঐচ্ছিক):' : 'Note / Reason (Optional):'}
              </label>
              <input
                type="text"
                value={calendarDayNote}
                onChange={e => setCalendarDayNote(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: চা-নাস্তা ঘরে খেয়েছি' : 'e.g., home cooked meal'}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 text-xs bg-slate-50 focus:bg-white"
              />
            </div>
          </div>
        </div>
      )}

      {/* ========================================================================= */}
      {/* MODAL 3: CREATE NEW CHALLENGE MODAL */}
      {/* ========================================================================= */}
      {isCreateModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-xs animate-in fade-in">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-7 space-y-5 shadow-2xl border border-slate-200 animate-in zoom-in-95 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-slate-900">
                    {language === 'bn' ? 'নতুন সেভিংস চ্যালেঞ্জ শুরু করুন' : 'Start New Savings Challenge'}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {language === 'bn' ? 'ধারাবাহিক সঞ্চয় ও সংযমের লড়াই' : 'Create a custom or preset challenge'}
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsCreateModalOpen(false)}
                className="p-1 rounded-xl hover:bg-slate-100 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Quick Templates */}
            <div>
              <p className="text-xs font-bold text-slate-700 mb-2">
                {language === 'bn' ? 'জনপ্রিয় টেমপ্লেট নির্বাচন করুন:' : 'Pick a Popular Template:'}
              </p>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('clay_bank')}
                  className="p-2.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 text-left text-xs font-bold text-emerald-950 flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <PiggyBank className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span className="truncate">৳১০০ মাটির ব্যাংক</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('cafe_ban')}
                  className="p-2.5 rounded-2xl bg-cyan-50 hover:bg-cyan-100 border border-cyan-200 text-left text-xs font-bold text-cyan-950 flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <UtensilsCrossed className="w-4 h-4 text-cyan-600 shrink-0" />
                  <span className="truncate">নো-ফুড ডেলিভারি</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('weekend')}
                  className="p-2.5 rounded-2xl bg-amber-50 hover:bg-amber-100 border border-amber-200 text-left text-xs font-bold text-amber-950 flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <Flame className="w-4 h-4 text-amber-600 shrink-0" />
                  <span className="truncate">উইকএন্ড নো-স্পেন্ড</span>
                </button>
                <button
                  type="button"
                  onClick={() => handleApplyTemplate('step_up')}
                  className="p-2.5 rounded-2xl bg-purple-50 hover:bg-purple-100 border border-purple-200 text-left text-xs font-bold text-purple-950 flex items-center gap-2 cursor-pointer transition-colors"
                >
                  <TrendingUp className="w-4 h-4 text-purple-600 shrink-0" />
                  <span className="truncate">৫২-সপ্তাহের স্টেপ আপ</span>
                </button>
              </div>
            </div>

            <form onSubmit={handleCreateChallenge} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'চ্যালেঞ্জের নাম (বাংলা)' : 'Title (Bangla)'}
                </label>
                <input
                  type="text"
                  required
                  value={newTitleBn}
                  onChange={e => setNewTitleBn(e.target.value)}
                  placeholder="যেমন: ৩০ দিনের নো-ক্যাফে চ্যালেঞ্জ"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  {language === 'bn' ? 'চ্যালেঞ্জের নাম (English)' : 'Title (English)'}
                </label>
                <input
                  type="text"
                  required
                  value={newTitle}
                  onChange={e => setNewTitle(e.target.value)}
                  placeholder="e.g., 30-Day Zero Cafe Challenge"
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-900 bg-slate-50 focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
                  </label>
                  <select
                    value={newCategory}
                    onChange={e => setNewCategory(e.target.value as ChallengeCategory)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-800 bg-slate-50"
                  >
                    <option value="daily">{language === 'bn' ? 'দৈনিক জমানো' : 'Daily Jar'}</option>
                    <option value="weekly">{language === 'bn' ? 'সাপ্তাহিক' : 'Weekly'}</option>
                    <option value="category_ban">{language === 'bn' ? 'খরচ বয়কট' : 'Spending Ban'}</option>
                    <option value="custom">{language === 'bn' ? 'কাস্টম' : 'Custom'}</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'স্থায়িত্ব (দিন)' : 'Duration (Days)'}
                  </label>
                  <input
                    type="number"
                    value={newDurationDays || ''}
                    onChange={e => setNewDurationDays(Number(e.target.value) || 1)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 bg-slate-50"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'টার্গেট জমার পরিমাণ (৳)' : 'Target Amount (৳)'}
                  </label>
                  <input
                    type="number"
                    value={newTargetAmount || ''}
                    onChange={e => setNewTargetAmount(Number(e.target.value) || 0)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 bg-slate-50"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    {language === 'bn' ? 'দৈনিক জমার লক্ষ্য (৳)' : 'Daily Target (৳)'}
                  </label>
                  <input
                    type="number"
                    value={newDailyTarget || ''}
                    onChange={e => setNewDailyTarget(Number(e.target.value) || 0)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-900 bg-slate-50"
                  />
                </div>
              </div>

              <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsCreateModalOpen(false)}
                  className="px-4 py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
                >
                  {language === 'bn' ? 'বাতিল' : 'Cancel'}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2.5 text-xs font-black text-slate-950 bg-emerald-500 hover:bg-emerald-400 rounded-xl shadow-sm cursor-pointer"
                >
                  {language === 'bn' ? 'চ্যালেঞ্জ শুরু করুন' : 'Launch Challenge'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
