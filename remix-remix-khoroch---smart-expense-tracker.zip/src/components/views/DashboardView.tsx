import React, { useState, useMemo } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { Transaction, TransactionType } from '../../types';
import { CategoryIcon } from '../CategoryIcon';
import {
  Wallet,
  ArrowUpRight,
  ArrowDownLeft,
  PiggyBank,
  Eye,
  EyeOff,
  Calendar,
  MapPin,
  TrendingUp,
  Plus,
  ArrowRightLeft,
  Camera,
  Wifi,
  Smartphone,
  Zap,
  ChevronRight,
  Sun,
  ShieldCheck,
  CheckCircle2,
  Utensils,
  Bus,
  ShoppingBag,
  CreditCard,
  Building2,
  Coins,
  ReceiptText,
  Banknote,
  AlertCircle,
} from 'lucide-react';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import { PaymentPriorityDashboardCard } from '../PaymentPriorityDashboardCard';
import wolfImage from '../../assets/images/wolf_mindset_landscape_1791559675074.jpg';

interface DashboardProps {
  onOpenAddModal: (type?: TransactionType) => void;
  onOpenTransferModal: () => void;
  onEditTx?: (tx: Transaction) => void;
}

export const DashboardView: React.FC<DashboardProps> = ({
  onOpenAddModal,
  onOpenTransferModal,
  onEditTx,
}) => {
  const {
    transactions,
    categories,
    accounts,
    subscriptions,
    currency,
    setCurrency,
    formatMoney,
    language,
    setActiveTab,
    currentUser,
    isCloudSyncing,
  } = useExpense();

  // Show/Hide Balance State
  const [showBalance, setShowBalance] = useState(true);

  // Time Range Filter for Expense Overview (7D, 30D, 3M, 1Y)
  const [timeRange, setTimeRange] = useState<'7D' | '30D' | '3M' | '1Y'>('7D');

  // Greeting dynamic by time of day
  const greeting = useMemo(() => {
    const hour = new Date().getHours();
    if (hour < 12) return language === 'bn' ? 'শুভ সকাল' : 'Good Morning';
    if (hour < 17) return language === 'bn' ? 'শুভ অপরাহ্ন' : 'Good Afternoon';
    return language === 'bn' ? 'শুভ সন্ধ্যা' : 'Good Evening';
  }, [language]);

  const userName = currentUser?.displayName || currentUser?.email?.split('@')[0] || '';

  // Format today's date
  const todayFormatted = useMemo(() => {
    const now = new Date();
    return now.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-GB', {
      weekday: 'short',
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }, [language]);

  // Compute Core Metrics purely from real user data (Zero demo fallbacks)
  const totalBalanceVal = useMemo(() => {
    return accounts.reduce((sum, a) => sum + (a.balance || 0), 0);
  }, [accounts]);

  const totalIncomeVal = useMemo(() => {
    return transactions
      .filter((t) => t.type === 'income')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
  }, [transactions]);

  const totalExpensesVal = useMemo(() => {
    return transactions
      .filter((t) => t.type === 'expense')
      .reduce((sum, t) => sum + (t.amount || 0), 0);
  }, [transactions]);

  const savingsVal = useMemo(() => {
    return totalIncomeVal - totalExpensesVal;
  }, [totalIncomeVal, totalExpensesVal]);

  // Chart Data: Expense Overview calculated dynamically from real transactions
  const chartData = useMemo(() => {
    const now = new Date();
    const result: { date: string; amount: number }[] = [];

    if (timeRange === '7D') {
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i);
        const dateStr = d.toISOString().split('T')[0];
        const dayLabel = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
        const dayExpense = transactions
          .filter((t) => t.type === 'expense' && t.date === dateStr)
          .reduce((sum, t) => sum + t.amount, 0);
        result.push({
          date: dayLabel,
          amount: dayExpense,
        });
      }
    } else if (timeRange === '30D') {
      // 10 key intervals across past 30 days
      for (let i = 9; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i * 3);
        const dateStr = d.toISOString().split('T')[0];
        const dayLabel = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
        const dayExpense = transactions
          .filter((t) => t.type === 'expense' && t.date === dateStr)
          .reduce((sum, t) => sum + t.amount, 0);
        result.push({
          date: dayLabel,
          amount: dayExpense,
        });
      }
    } else if (timeRange === '3M') {
      // 12 weeks
      for (let i = 11; i >= 0; i--) {
        const d = new Date();
        d.setDate(now.getDate() - i * 7);
        const dayLabel = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
        const weekStart = new Date(d);
        weekStart.setDate(weekStart.getDate() - 3);
        const weekEnd = new Date(d);
        weekEnd.setDate(weekEnd.getDate() + 3);

        const weekExpense = transactions
          .filter((t) => {
            if (t.type !== 'expense') return false;
            const tDate = new Date(t.date);
            return tDate >= weekStart && tDate <= weekEnd;
          })
          .reduce((sum, t) => sum + t.amount, 0);

        result.push({
          date: dayLabel,
          amount: weekExpense,
        });
      }
    } else {
      // 1Y - past 12 months
      for (let i = 11; i >= 0; i--) {
        const d = new Date();
        d.setMonth(now.getMonth() - i);
        const monthStr = d.toISOString().slice(0, 7);
        const monthLabel = d.toLocaleDateString('en-GB', { month: 'short' });
        const monthExpense = transactions
          .filter((t) => t.type === 'expense' && t.date.startsWith(monthStr))
          .reduce((sum, t) => sum + t.amount, 0);
        result.push({
          date: monthLabel,
          amount: monthExpense,
        });
      }
    }

    return result;
  }, [transactions, timeRange]);

  const maxChartAmount = useMemo(() => {
    const maxVal = Math.max(...chartData.map((d) => d.amount), 0);
    return maxVal > 0 ? Math.ceil(maxVal * 1.25) : 5000;
  }, [chartData]);

  // Category Breakdown Data for Donut Chart (Real data only, no demo data)
  const categoryData = useMemo(() => {
    const expenseTxs = transactions.filter((t) => t.type === 'expense');
    if (expenseTxs.length === 0 || totalExpensesVal === 0) {
      return [];
    }

    const map: { [catId: string]: number } = {};
    expenseTxs.forEach((t) => {
      map[t.categoryId] = (map[t.categoryId] || 0) + t.amount;
    });

    return Object.entries(map)
      .map(([catId, amount]) => {
        const cat = categories.find((c) => c.id === catId);
        const value = Math.max(1, Math.round((amount / totalExpensesVal) * 100));
        return {
          name: language === 'bn' ? cat?.nameBn || cat?.name || 'সাধারণ' : cat?.name || 'General',
          value,
          amount,
          color: cat?.color || '#10B981',
        };
      })
      .sort((a, b) => b.amount - a.amount);
  }, [transactions, categories, totalExpensesVal, language]);

  // Recent Transactions - Pure real user transactions
  const recentTransactionsList = useMemo(() => {
    return transactions.slice(0, 6);
  }, [transactions]);

  // Upcoming Bills - Pure real subscriptions
  const upcomingBillsList = useMemo(() => {
    return subscriptions.slice(0, 3);
  }, [subscriptions]);

  const getAccountInfo = (accountId: string) => {
    const acc = accounts.find((a) => a.id === accountId);
    if (!acc) return { name: 'Cash', icon: Banknote };
    const name = language === 'bn' ? acc.nameBn || acc.name : acc.name;
    let icon = Banknote;
    if (acc.type === 'bank') icon = Building2;
    if (acc.type === 'mobile_wallet') icon = Smartphone;
    if (acc.type === 'credit_card') icon = CreditCard;
    if (acc.type === 'savings') icon = PiggyBank;
    return { name, icon };
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-200">
      
      {/* 1. Welcome Greeting Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div className="space-y-0.5">
          <div className="flex items-center gap-2">
            <span className="text-xl">☀️</span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {userName ? `${greeting}, ${userName}` : `${greeting}!`}
            </h2>
          </div>
          <p className="text-xs sm:text-sm font-medium text-slate-400">
            {language === 'bn'
              ? 'আপনার খরচ ট্র্যাক করুন, অর্থ নিয়ন্ত্রণ করুন এবং লক্ষ্য অর্জন করুন।'
              : 'Track your expenses, control your money, achieve your goals.'}
          </p>
        </div>

        {/* Date and Location */}
        <div className="flex items-center gap-3 text-xs font-semibold text-slate-600 bg-white border border-slate-200/80 px-3.5 py-2 rounded-xl shadow-2xs self-start sm:self-auto">
          <div className="flex items-center gap-1.5">
            <Calendar className="w-3.5 h-3.5 text-slate-400" />
            <span>{todayFormatted}</span>
          </div>
          <span className="text-slate-300">·</span>
          <div className="flex items-center gap-1 text-slate-500">
            <MapPin className="w-3.5 h-3.5 text-slate-400" />
            <span>Dhaka, Bangladesh</span>
          </div>
        </div>
      </div>

      {/* 2. Top 4 Metric KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        
        {/* Card 1: Total Balance */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/90 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
              <Wallet className="w-5 h-5 stroke-[2]" />
            </div>
            <button
              onClick={() => setShowBalance(!showBalance)}
              className="text-slate-400 hover:text-slate-600 p-1 rounded-lg transition-colors cursor-pointer"
              title={showBalance ? 'Hide balance' : 'Show balance'}
            >
              {showBalance ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
            </button>
          </div>

          <div className="mt-3">
            <p className="text-xs font-semibold text-slate-400">
              {language === 'bn' ? 'মোট ব্যালেন্স' : 'Total Balance'}
            </p>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
              {showBalance ? `${currency.symbol} ${totalBalanceVal.toLocaleString()}.00` : '••••••••'}
            </h3>
            <p className="text-[11px] font-bold text-slate-500 flex items-center gap-1 mt-1.5">
              <span>💳</span>
              <span>{accounts.length} {language === 'bn' ? 'টি সক্রিয় অ্যাকাউন্ট' : 'Active accounts'}</span>
            </p>
          </div>
        </div>

        {/* Card 2: Total Income */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/90 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600">
              <ArrowUpRight className="w-5 h-5 stroke-[2.3]" />
            </div>
          </div>

          <div className="mt-3">
            <p className="text-xs font-semibold text-slate-400">
              {language === 'bn' ? 'মোট আয়' : 'Total Income'}
            </p>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
              {currency.symbol} {totalIncomeVal.toLocaleString()}.00
            </h3>
            <p className="text-[11px] font-bold text-emerald-600 flex items-center gap-1 mt-1.5">
              <span>↑</span>
              <span>{transactions.filter((t) => t.type === 'income').length} {language === 'bn' ? 'টি আয় এন্ট্রি' : 'Income entries'}</span>
            </p>
          </div>
        </div>

        {/* Card 3: Total Expenses */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/90 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-500">
              <ArrowDownLeft className="w-5 h-5 stroke-[2.3]" />
            </div>
          </div>

          <div className="mt-3">
            <p className="text-xs font-semibold text-slate-400">
              {language === 'bn' ? 'মোট ব্যয়' : 'Total Expenses'}
            </p>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
              {currency.symbol} {totalExpensesVal.toLocaleString()}.00
            </h3>
            <p className="text-[11px] font-bold text-rose-500 flex items-center gap-1 mt-1.5">
              <span>↓</span>
              <span>{transactions.filter((t) => t.type === 'expense').length} {language === 'bn' ? 'টি ব্যয় এন্ট্রি' : 'Expense entries'}</span>
            </p>
          </div>
        </div>

        {/* Card 4: Savings */}
        <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200/90 shadow-2xs hover:shadow-xs transition-shadow">
          <div className="flex items-center justify-between">
            <div className="w-10 h-10 rounded-xl bg-purple-50 border border-purple-100 flex items-center justify-center text-purple-600">
              <PiggyBank className="w-5 h-5 stroke-[2]" />
            </div>
          </div>

          <div className="mt-3">
            <p className="text-xs font-semibold text-slate-400">
              {language === 'bn' ? 'মোট সঞ্চয়' : 'Savings'}
            </p>
            <h3 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-0.5">
              {currency.symbol} {savingsVal.toLocaleString()}.00
            </h3>
            <p className="text-[11px] font-bold text-purple-600 flex items-center gap-1 mt-1.5">
              <span>★</span>
              <span>
                {totalIncomeVal > 0
                  ? `${Math.round((savingsVal / totalIncomeVal) * 100)}% ${language === 'bn' ? 'সঞ্চয়ের হার' : 'savings rate'}`
                  : language === 'bn' ? 'হিসাব শুরু করুন' : 'Start tracking'}
              </span>
            </p>
          </div>
        </div>

      </div>

      {/* 3. Main Dashboard Body: Split into Left Content (66%) and Right Panel (34%) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* LEFT CONTENT AREA: Charts + Recent Transactions Table (8 cols on lg) */}
        <div className="lg:col-span-8 space-y-6">
          
          {/* Middle Charts Row (Expense Overview + Spending by Category) */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
            
            {/* Expense Overview Area Spline Chart (7 cols on md) */}
            <div className="md:col-span-7 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <div className="flex items-center gap-2">
                    <Calendar className="w-4 h-4 text-emerald-600" />
                    <h3 className="text-sm font-bold text-slate-900">
                      {language === 'bn' ? 'ব্যয় ওভারভিউ' : 'Expense Overview'}
                    </h3>
                  </div>

                  {/* Range Selector Pills: 7D, 30D, 3M, 1Y */}
                  <div className="flex items-center gap-1 bg-slate-100/90 p-1 rounded-lg">
                    {(['7D', '30D', '3M', '1Y'] as const).map((r) => (
                      <button
                        key={r}
                        onClick={() => setTimeRange(r)}
                        className={`px-2 py-0.5 rounded-md text-[10px] font-bold transition-all cursor-pointer ${
                          timeRange === r
                            ? 'bg-[#0B3B2C] text-white shadow-xs'
                            : 'text-slate-500 hover:text-slate-900'
                        }`}
                      >
                        {r}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="text-[11px] text-slate-400 mb-4 font-medium">
                  {timeRange === '7D'
                    ? (language === 'bn' ? 'গত ৭ দিন' : 'Last 7 days')
                    : timeRange === '30D'
                    ? (language === 'bn' ? 'গত ৩০ দিন' : 'Last 30 days')
                    : timeRange === '3M'
                    ? (language === 'bn' ? 'গত ৩ মাস' : 'Last 3 months')
                    : (language === 'bn' ? 'গত ১ বছর' : 'Last 1 year')}
                </p>
              </div>

              {/* Area Chart Container */}
              <div className="h-52 w-full">
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -15, bottom: 0 }}>
                    <defs>
                      <linearGradient id="emeraldGradient" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#10B981" stopOpacity={0.25} />
                        <stop offset="95%" stopColor="#10B981" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <XAxis
                      dataKey="date"
                      tickLine={false}
                      axisLine={{ stroke: '#E2E8F0' }}
                      tick={{ fill: '#94A3B8', fontSize: 10, fontWeight: 500 }}
                    />
                    <YAxis
                      tickLine={false}
                      axisLine={false}
                      tick={{ fill: '#94A3B8', fontSize: 10 }}
                      tickFormatter={(v) => `${currency.symbol} ${v.toLocaleString()}`}
                      domain={[0, maxChartAmount]}
                    />
                    <Tooltip
                      formatter={(val: any) => [`${currency.symbol} ${Number(val).toLocaleString()}`, language === 'bn' ? 'ব্যয়' : 'Expense']}
                      contentStyle={{
                        backgroundColor: '#FFFFFF',
                        border: '1px solid #E2E8F0',
                        borderRadius: '12px',
                        fontSize: '11px',
                        fontWeight: 600,
                        boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.05)',
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="amount"
                      stroke="#10B981"
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#emeraldGradient)"
                      dot={{ r: 3.5, fill: '#10B981', stroke: '#FFFFFF', strokeWidth: 1.5 }}
                      activeDot={{ r: 5, fill: '#059669', stroke: '#FFFFFF', strokeWidth: 2 }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Spending by Category Donut Chart (5 cols on md) */}
            <div className="md:col-span-5 bg-white rounded-2xl p-5 border border-slate-200/90 shadow-2xs flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-bold text-slate-900 mb-2">
                  {language === 'bn' ? 'ক্যাটাগরি অনুযায়ী ব্যয়' : 'Spending by Category'}
                </h3>
                
                {categoryData.length > 0 ? (
                  <>
                    {/* Donut Chart with Center Hole Label */}
                    <div className="h-44 relative flex items-center justify-center">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={categoryData}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            innerRadius={50}
                            outerRadius={70}
                            paddingAngle={3}
                            stroke="none"
                          >
                            {categoryData.map((entry, index) => (
                              <Cell key={`cell-${index}`} fill={entry.color} />
                            ))}
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>

                      {/* Hole Center Text */}
                      <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                        <span className="text-sm font-extrabold text-slate-900 tracking-tight">
                          {currency.symbol} {totalExpensesVal.toLocaleString()}
                        </span>
                        <span className="text-[10px] text-slate-400 font-medium">
                          {language === 'bn' ? 'মোট ব্যয়' : 'Total Expenses'}
                        </span>
                      </div>
                    </div>

                    {/* Legend rows with clean dots and percentages */}
                    <div className="space-y-1.5 pt-2 border-t border-slate-100 max-h-32 overflow-y-auto">
                      {categoryData.slice(0, 5).map((item) => (
                        <div key={item.name} className="flex items-center justify-between text-xs">
                          <div className="flex items-center gap-2">
                            <span className="w-2 h-2 rounded-full shrink-0" style={{ backgroundColor: item.color }} />
                            <span className="text-slate-600 font-medium text-[11px] truncate">{item.name}</span>
                          </div>
                          <span className="font-bold text-slate-700 text-[11px]">{item.value}%</span>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  /* Clean Empty State when no expense recorded */
                  <div className="py-8 flex flex-col items-center justify-center text-center">
                    <div className="w-28 h-28 rounded-full border-4 border-dashed border-slate-200 flex flex-col items-center justify-center">
                      <span className="text-sm font-black text-slate-400">0%</span>
                      <span className="text-[10px] font-semibold text-slate-400 mt-0.5">
                        {language === 'bn' ? 'খরচ শূন্য' : 'No expenses'}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 font-medium mt-4">
                      {language === 'bn'
                        ? 'খরচ রেকর্ড করলে এখানে ক্যাটাগরি বিশ্লেষণ দেখতে পাবেন'
                        : 'Record expenses to see category breakdown'}
                    </p>
                  </div>
                )}
              </div>

            </div>

          </div>

          {/* Recent Transactions Table Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs overflow-hidden">
            <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ReceiptText className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  {language === 'bn' ? 'সাম্প্রতিক লেনদেন' : 'Recent Transactions'}
                </h3>
              </div>
              <button
                onClick={() => setActiveTab('transactions')}
                className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 transition-colors cursor-pointer"
              >
                <span>{language === 'bn' ? 'সবগুলো দেখুন' : 'View All'}</span>
                <span>→</span>
              </button>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-100 text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                    <th className="py-3 px-5">{language === 'bn' ? 'তারিখ' : 'Date'}</th>
                    <th className="py-3 px-5">{language === 'bn' ? 'বিবরণ' : 'Description'}</th>
                    <th className="py-3 px-5">{language === 'bn' ? 'ক্যাটাগরি' : 'Category'}</th>
                    <th className="py-3 px-5">{language === 'bn' ? 'পেমেন্ট মেথড' : 'Payment Method'}</th>
                    <th className="py-3 px-5 text-right">{language === 'bn' ? 'পরিমাণ' : 'Amount'}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100/80 text-xs">
                  {recentTransactionsList.length > 0 ? (
                    recentTransactionsList.map((tx: Transaction) => {
                      const isIncome = tx.type === 'income';
                      const isTransfer = tx.type === 'transfer';
                      const cat = categories.find((c) => c.id === tx.categoryId);
                      const catName = language === 'bn' ? cat?.nameBn || cat?.name || 'সাধারণ' : cat?.name || 'General';
                      const catColor = cat?.color || '#10B981';
                      const catIconName = cat?.icon || 'ShoppingBag';
                      const accountInfo = getAccountInfo(tx.accountId);
                      const AccountIcon = accountInfo.icon;

                      return (
                        <tr
                          key={tx.id}
                          onClick={() => onEditTx && onEditTx(tx)}
                          className="hover:bg-slate-50/70 transition-colors cursor-pointer"
                        >
                          {/* Date Column */}
                          <td className="py-3.5 px-5 whitespace-nowrap text-slate-500 font-medium text-[11px]">
                            <div>{tx.date}</div>
                            <div className="text-[10px] text-slate-400">{tx.time || '12:00 PM'}</div>
                          </td>

                          {/* Description Column with colored icon badge */}
                          <td className="py-3.5 px-5 whitespace-nowrap">
                            <div className="flex items-center gap-3">
                              <div
                                className="w-8 h-8 rounded-full flex items-center justify-center shrink-0"
                                style={{ backgroundColor: `${catColor}15`, color: catColor }}
                              >
                                <CategoryIcon iconName={catIconName} size={16} />
                              </div>
                              <span className="font-semibold text-slate-800 text-xs">
                                {tx.note || (language === 'bn' ? 'লেনদেন' : 'Transaction')}
                              </span>
                            </div>
                          </td>

                          {/* Category Badge Column */}
                          <td className="py-3.5 px-5 whitespace-nowrap">
                            <span
                              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[11px] font-bold"
                              style={{ backgroundColor: `${catColor}15`, color: catColor }}
                            >
                              <CategoryIcon iconName={catIconName} size={12} />
                              <span>{catName}</span>
                            </span>
                          </td>

                          {/* Payment Method Column */}
                          <td className="py-3.5 px-5 whitespace-nowrap text-slate-600 font-medium text-xs">
                            <div className="flex items-center gap-1.5">
                              <AccountIcon className="w-3.5 h-3.5 text-slate-400" />
                              <span>{accountInfo.name}</span>
                            </div>
                          </td>

                          {/* Amount Column */}
                          <td
                            className={`py-3.5 px-5 whitespace-nowrap text-right font-bold text-xs ${
                              isIncome ? 'text-emerald-600' : isTransfer ? 'text-blue-600' : 'text-rose-500'
                            }`}
                          >
                            {isIncome ? '+ ' : isTransfer ? '⇄ ' : '- '}
                            {currency.symbol} {tx.amount.toLocaleString()}
                          </td>
                        </tr>
                      );
                    })
                  ) : (
                    /* Clean Empty State when no transactions exist */
                    <tr>
                      <td colSpan={5} className="py-12 text-center">
                        <div className="flex flex-col items-center justify-center space-y-3 max-w-sm mx-auto">
                          <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
                            <ReceiptText className="w-6 h-6 stroke-[1.8]" />
                          </div>
                          <p className="text-sm font-bold text-slate-800">
                            {language === 'bn' ? 'কোনো লেনদেন পাওয়া যায়নি' : 'No transactions recorded yet'}
                          </p>
                          <p className="text-xs text-slate-400">
                            {language === 'bn'
                              ? 'নতুন লেনদেন বা আয়-ব্যয়ের হিসাব যোগ করতে নিচের বোতামে চাপুন।'
                              : 'Start tracking by recording your first expense or income.'}
                          </p>
                          <div className="flex items-center gap-2 pt-1">
                            <button
                              onClick={() => onOpenAddModal('expense')}
                              className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition-all shadow-xs cursor-pointer"
                            >
                              {language === 'bn' ? '+ খরচ যোগ করুন' : '+ Add Expense'}
                            </button>
                            <button
                              onClick={() => onOpenAddModal('income')}
                              className="px-3.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition-all cursor-pointer"
                            >
                              {language === 'bn' ? '+ আয় যোগ করুন' : '+ Add Income'}
                            </button>
                          </div>
                        </div>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>

        </div>

        {/* RIGHT SIDE PANEL (4 cols on lg): My Wallet, Quick Actions, Upcoming Bills, Quote */}
        <div className="lg:col-span-4 space-y-5">
          
          {/* Card 1: My Wallet Banner (Deep Forest Green) */}
          <div className="bg-gradient-to-br from-[#0B3B2C] to-[#124E3D] text-white rounded-3xl p-5 sm:p-6 shadow-sm space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Wallet className="w-4 h-4 text-emerald-300" />
                <span className="text-xs font-semibold text-emerald-100 uppercase tracking-wider">
                  {language === 'bn' ? 'আমার ওয়ালেট' : 'My Wallet'}
                </span>
              </div>
              <button
                onClick={() => onOpenAddModal('expense')}
                className="flex items-center gap-1 text-[11px] font-bold bg-white/15 hover:bg-white/25 px-2.5 py-1 rounded-lg backdrop-blur-xs transition-colors cursor-pointer"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'যোগ' : 'Add'}</span>
              </button>
            </div>

            {/* Wallet Big Balance purely from user accounts */}
            <div>
              <h3 className="text-2xl sm:text-3xl font-black tracking-tight text-white">
                {currency.symbol} {totalBalanceVal.toLocaleString()}.00
              </h3>
              <p className="text-[11px] text-emerald-200/80 font-medium mt-1">
                {accounts.length} {language === 'bn' ? 'টি সক্রিয় অ্যাকাউন্ট ও কার্ড' : 'Connected accounts & cards'}
              </p>
            </div>

            {/* Currency Switcher Segmented Pills */}
            <div className="grid grid-cols-4 gap-1.5 pt-1">
              {[
                { code: 'BDT', symbol: '৳' },
                { code: 'USD', symbol: '$' },
                { code: 'EUR', symbol: '€' },
                { code: 'INR', symbol: '₹' },
              ].map((c) => {
                const isSelected = currency.code === c.code || (c.code === 'BDT' && !['USD', 'EUR', 'INR'].includes(currency.code));
                return (
                  <button
                    key={c.code}
                    onClick={() => {
                      if (c.code === 'BDT') setCurrency({ code: 'BDT', symbol: '৳', name: 'Taka' });
                      if (c.code === 'USD') setCurrency({ code: 'USD', symbol: '$', name: 'US Dollar' });
                      if (c.code === 'EUR') setCurrency({ code: 'EUR', symbol: '€', name: 'Euro' });
                      if (c.code === 'INR') setCurrency({ code: 'INR', symbol: '₹', name: 'Rupee' });
                    }}
                    className={`py-2 px-1 rounded-xl text-center font-bold text-xs transition-all cursor-pointer ${
                      isSelected
                        ? 'bg-[#06241B] text-white shadow-2xs border border-emerald-600/30 font-extrabold'
                        : 'bg-white/10 text-emerald-100 hover:bg-white/20'
                    }`}
                  >
                    <div className="text-xs">{c.symbol}</div>
                    <div className="text-[10px] text-emerald-200/80 mt-0.5">{c.code}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Card 2: 4 Quick Actions (2x2 Grid) */}
          <div className="grid grid-cols-2 gap-3">
            
            {/* Add Income */}
            <button
              onClick={() => onOpenAddModal('income')}
              className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-emerald-300 hover:shadow-xs transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-emerald-50 text-emerald-600 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <ArrowUpRight className="w-5 h-5 stroke-[2.3]" />
              </div>
              <span className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'আয় যোগ করুন' : 'Add Income'}
              </span>
            </button>

            {/* Add Expense */}
            <button
              onClick={() => onOpenAddModal('expense')}
              className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-rose-300 hover:shadow-xs transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-rose-50 text-rose-500 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <ArrowDownLeft className="w-5 h-5 stroke-[2.3]" />
              </div>
              <span className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'ব্যয় যোগ করুন' : 'Add Expense'}
              </span>
            </button>

            {/* Transfer */}
            <button
              onClick={onOpenTransferModal}
              className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-blue-300 hover:shadow-xs transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-blue-50 text-blue-500 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <ArrowRightLeft className="w-5 h-5 stroke-[2]" />
              </div>
              <span className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'ট্রান্সফার' : 'Transfer'}
              </span>
            </button>

            {/* Scan Receipt */}
            <button
              onClick={() => onOpenAddModal('expense')}
              className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-2xs hover:border-purple-300 hover:shadow-xs transition-all flex flex-col items-center justify-center text-center group cursor-pointer"
            >
              <div className="w-10 h-10 rounded-full bg-purple-50 text-purple-600 flex items-center justify-center mb-2 group-hover:scale-105 transition-transform">
                <Camera className="w-5 h-5 stroke-[2]" />
              </div>
              <span className="text-xs font-bold text-slate-800">
                {language === 'bn' ? 'রসিদ স্ক্যান' : 'Scan Receipt'}
              </span>
            </button>

          </div>

          {/* Smart Payment Priority Engine Dashboard Card */}
          <PaymentPriorityDashboardCard />

          {/* Card 3: Upcoming Bills & Reminders Card */}
          <div className="bg-white rounded-2xl border border-slate-200/90 shadow-2xs p-5 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-600" />
                <h3 className="text-sm font-bold text-slate-900">
                  {language === 'bn' ? 'আসন্ন বিল ও রিমাইন্ডার' : 'Upcoming Bills & Reminders'}
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('calendar')}
                  className="text-xs font-bold text-teal-700 hover:text-teal-800 flex items-center gap-1 cursor-pointer bg-teal-50 hover:bg-teal-100 px-2 py-1 rounded-lg border border-teal-200/80 transition-colors"
                  title={language === 'bn' ? 'ক্যালেন্ডারে সম্পূর্ণ মাসিক ভিউ দেখুন' : 'View Full Monthly Calendar'}
                >
                  <span>{language === 'bn' ? 'ক্যালেন্ডার ভিউ' : 'Calendar'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveTab('subscriptions')}
                  className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                >
                  <span>{language === 'bn' ? 'সবগুলো' : 'View All'}</span>
                  <span>→</span>
                </button>
              </div>
            </div>

            <div className="space-y-3 pt-1">
              {upcomingBillsList.length > 0 ? (
                upcomingBillsList.map((bill) => {
                  const billName = language === 'bn' ? bill.nameBn || bill.name : bill.name;
                  return (
                    <div
                      key={bill.id}
                      onClick={() => setActiveTab('subscriptions')}
                      className="flex items-center justify-between text-xs p-2 rounded-xl hover:bg-slate-50 transition-colors cursor-pointer"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-9 h-9 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-700 shrink-0">
                          {bill.category === 'internet' ? (
                            <Wifi className="w-4 h-4 text-emerald-600" />
                          ) : bill.category === 'mobile' ? (
                            <Smartphone className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Zap className="w-4 h-4 text-emerald-600" />
                          )}
                        </div>
                        <div>
                          <p className="font-bold text-slate-800 leading-tight">{billName}</p>
                          <p className="text-[11px] font-bold text-slate-900 mt-0.5">
                            {currency.symbol} {bill.amount.toLocaleString()}
                          </p>
                        </div>
                      </div>

                      <div className="text-right space-y-1">
                        <span className="inline-block px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                          {bill.status === 'active' ? (language === 'bn' ? 'সক্রিয়' : 'Active') : bill.status}
                        </span>
                        <p className="text-[10px] text-slate-400 font-medium">{bill.dueDate}</p>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="py-6 text-center space-y-2">
                  <div className="w-10 h-10 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-400 mx-auto">
                    <Calendar className="w-5 h-5 stroke-[1.8]" />
                  </div>
                  <p className="text-xs font-bold text-slate-700">
                    {language === 'bn' ? 'কোনো বকেয়া বিল বা সাবস্ক্রিপশন নেই' : 'No upcoming bills or subscriptions'}
                  </p>
                  <button
                    onClick={() => setActiveTab('subscriptions')}
                    className="text-[11px] font-bold text-emerald-700 hover:text-emerald-800 cursor-pointer"
                  >
                    {language === 'bn' ? '+ নতুন বিল যোগ করুন' : '+ Add New Bill'}
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Card 4: Mindset Quote Card with Wolf Artwork */}
          <div className="rounded-2xl overflow-hidden border border-emerald-100/80 shadow-2xs relative bg-emerald-950 text-white min-h-[140px] flex items-center">
            {/* Background Wolf Landscape */}
            <div
              className="absolute inset-0 bg-cover bg-center opacity-65"
              style={{ backgroundImage: `url(${wolfImage})` }}
            />
            <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 via-slate-900/60 to-transparent" />

            <div className="relative z-10 p-5 space-y-2 max-w-[70%]">
              <h4 className="text-sm font-extrabold text-white leading-snug tracking-tight">
                Small steps every day lead to big results.
              </h4>
              <p className="text-[11px] font-bold text-emerald-300 flex items-center gap-1">
                <span>👑</span>
                <span>- Wolf Mindset</span>
              </p>
            </div>
          </div>

          {/* Status and Security Footnote */}
          <div className="pt-2 flex items-center justify-between text-[11px] text-slate-400 px-1">
            <span className="flex items-center gap-1.5 font-medium">
              <ShieldCheck className="w-3.5 h-3.5 text-slate-400" />
              <span>{language === 'bn' ? 'আপনার তথ্য সুরক্ষিত' : 'Your data is secure'}</span>
            </span>
            <span className="flex items-center gap-1.5 font-semibold text-emerald-700">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>{isCloudSyncing ? (language === 'bn' ? 'ক্লাউড সিঙ্ক হচ্ছে' : 'Cloud Syncing') : (language === 'bn' ? 'ক্লাউড সুরক্ষিত' : 'Cloud Protected')}</span>
            </span>
          </div>

        </div>

      </div>

      {/* Bottom Subtle Footer */}
      <div className="pt-8 pb-4 text-center text-xs text-slate-400 font-medium border-t border-slate-200/60">
        <p>Expense Tracker v1.0.0 · Better Money · Better Life</p>
      </div>

    </div>
  );
};
