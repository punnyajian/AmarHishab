import React, { useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { CategoryIcon } from '../CategoryIcon';
import { 
  PieChart as PieIcon, 
  BarChart3, 
  TrendingUp, 
  TrendingDown, 
  Printer, 
  Calendar,
  CreditCard,
  Zap,
  Award,
  ChevronRight,
  Droplets,
} from 'lucide-react';
import { EndOfMonthPredictionModal } from '../EndOfMonthPredictionModal';
import { MoneyLeakModal } from '../MoneyLeakModal';

export const AnalyticsView: React.FC = () => {
  const {
    transactions,
    categories,
    accounts,
    formatMoney,
    language,
    t,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    netSavingsThisMonth,
    savingsRateThisMonth,
  } = useExpense();

  const [activeDonutIdx, setActiveDonutIdx] = useState<number | null>(null);
  const [isPredictionModalOpen, setIsPredictionModalOpen] = useState(false);
  const [isMoneyLeakModalOpen, setIsMoneyLeakModalOpen] = useState(false);

  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const monthTransactions = transactions.filter(t => t.date.startsWith(currentMonthStr));
  const expenseTxs = monthTransactions.filter(t => t.type === 'expense');

  // Category Breakdown
  const categoryMap: { [catId: string]: number } = {};
  expenseTxs.forEach(tx => {
    categoryMap[tx.categoryId] = (categoryMap[tx.categoryId] || 0) + tx.amount;
  });

  const categoryData = Object.entries(categoryMap)
    .map(([catId, amount]) => {
      const cat = categories.find(c => c.id === catId);
      const percentage = totalExpenseThisMonth > 0 ? (amount / totalExpenseThisMonth) * 100 : 0;
      return {
        id: catId,
        name: language === 'bn' ? cat?.nameBn || cat?.name || '' : cat?.name || '',
        amount,
        percentage,
        color: cat?.color || '#10b981',
        icon: cat?.icon || 'CircleDot',
      };
    })
    .sort((a, b) => b.amount - a.amount);

  // Daily Trend for the past 7 days
  const past7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date();
    d.setDate(d.getDate() - (6 - i));
    const dateStr = d.toISOString().split('T')[0];
    const dayExpense = transactions
      .filter(t => t.type === 'expense' && t.date === dateStr)
      .reduce((sum, t) => sum + t.amount, 0);

    return {
      date: dateStr,
      label: d.toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', { weekday: 'short' }),
      amount: dayExpense,
    };
  });

  const maxDailyExpense = Math.max(...past7Days.map(d => d.amount), 100);

  // SVG Donut calculation
  const radius = 68;
  const circumference = 2 * Math.PI * radius;
  let accumulatedPercent = 0;

  // Most used payment method
  const accountUsageMap: { [accId: string]: number } = {};
  expenseTxs.forEach(t => {
    accountUsageMap[t.accountId] = (accountUsageMap[t.accountId] || 0) + t.amount;
  });
  const mostUsedAccId = Object.entries(accountUsageMap).sort((a, b) => b[1] - a[1])[0]?.[0];
  const mostUsedAcc = accounts.find(a => a.id === mostUsedAccId);

  // Average daily spend this month
  const now = new Date();
  const dayOfMonth = Math.max(1, now.getDate());
  const avgDailySpend = Math.round(totalExpenseThisMonth / dayOfMonth);

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 no-print">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {t('analytics')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {language === 'bn'
              ? 'খরচের গভীর বিশ্লেষণ ও চার্ট রিপোর্ট'
              : 'Detailed charts and spending breakdown'}
          </p>
        </div>

        <button
          onClick={() => window.print()}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors self-start sm:self-auto"
        >
          <Printer className="w-3.5 h-3.5 text-slate-600" />
          <span>{t('printReport')}</span>
        </button>
      </div>

      {/* Quick Highlights Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? 'দৈনিক গড় খরচ' : 'Avg Daily Spend'}
          </span>
          <div className="text-lg sm:text-xl font-black text-slate-900 mt-1">
            {formatMoney(avgDailySpend)}
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            {language === 'bn' ? 'চলতি মাসের হিসাব' : 'This month avg'}
          </span>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {t('savingsRate')}
          </span>
          <div className="text-lg sm:text-xl font-black text-emerald-700 mt-1">
            {savingsRateThisMonth}%
          </div>
          <span className="text-[10px] text-emerald-600 mt-0.5 block">
            {savingsRateThisMonth >= 20 ? (language === 'bn' ? 'খুব ভালো' : 'Healthy') : (language === 'bn' ? 'উন্নতি দরকার' : 'Below target')}
          </span>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? 'সর্বাধিক ব্যবহৃত ওয়ালেট' : 'Top Wallet Used'}
          </span>
          <div className="text-sm sm:text-base font-bold text-slate-900 mt-1 truncate">
            {mostUsedAcc ? (language === 'bn' ? mostUsedAcc.nameBn : mostUsedAcc.name) : 'Cash'}
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            {formatMoney(mostUsedAcc ? accountUsageMap[mostUsedAcc.id] || 0 : 0)}
          </span>
        </div>

        <div className="bg-white border border-slate-200/80 rounded-2xl p-4 shadow-xs">
          <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? 'মোট লেনদেন সংখ্যা' : 'Transactions Count'}
          </span>
          <div className="text-lg sm:text-xl font-black text-slate-900 mt-1">
            {monthTransactions.length}
          </div>
          <span className="text-[10px] text-slate-400 mt-0.5 block">
            {expenseTxs.length} {language === 'bn' ? 'খরচ' : 'expenses'}
          </span>
        </div>
      </div>

      {/* AI Intelligence Banners: Prediction & Money Leak Detector */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 no-print">
        {/* End-of-Month Prediction Banner */}
        <div 
          onClick={() => setIsPredictionModalOpen(true)}
          className="bg-gradient-to-r from-slate-950 via-indigo-950 to-purple-950 text-white rounded-3xl p-4 sm:p-5 shadow-xs border border-indigo-800/40 hover:border-indigo-400 cursor-pointer transition-all hover:shadow-md flex items-center justify-between gap-3 group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 text-indigo-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <span className="text-xl">🔮</span>
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-white group-hover:text-indigo-200 transition-colors">
                {language === 'bn' ? 'মাস শেষের ব্যয় পূর্বাভাস' : 'End-of-Month Spend Forecast'}
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {language === 'bn'
                  ? 'বর্তমান গতিতে মাস শেষে সম্ভাব্য মোট ব্যয় ও সঞ্চয়'
                  : 'Predict month-end outcome based on spending burn rate.'}
              </p>
            </div>
          </div>

          <div className="p-1 rounded-xl bg-white/10 text-indigo-300 group-hover:translate-x-0.5 transition-transform shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>

        {/* Money Leak Detector Banner */}
        <div 
          onClick={() => setIsMoneyLeakModalOpen(true)}
          className="bg-gradient-to-r from-slate-950 via-rose-950 to-slate-900 text-white rounded-3xl p-4 sm:p-5 shadow-xs border border-rose-800/40 hover:border-rose-400 cursor-pointer transition-all hover:shadow-md flex items-center justify-between gap-3 group"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-rose-500/20 border border-rose-400/30 text-rose-300 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
              <Droplets className="w-5 h-5 animate-pulse" />
            </div>
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-white group-hover:text-rose-200 transition-colors">
                {language === 'bn' ? 'স্মার্ট মানি লিক ডিটেক্টর' : 'AI Money Leak Detector'}
              </h3>
              <p className="text-[11px] text-slate-400 mt-0.5">
                {language === 'bn'
                  ? 'ছোট ছোট খরচে কোথায় অলক্ষ্যে টাকা গলে যাচ্ছে তা শনাক্ত করুন'
                  : 'Detect hidden repetitive micro-spending draining money.'}
              </p>
            </div>
          </div>

          <div className="p-1 rounded-xl bg-white/10 text-rose-300 group-hover:translate-x-0.5 transition-transform shrink-0">
            <ChevronRight className="w-4 h-4" />
          </div>
        </div>
      </div>

      {/* Visual Analytics 2-Column Section */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Category Breakdown with Interactive SVG Donut */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <PieIcon className="w-4 h-4 text-emerald-600" />
              {language === 'bn' ? 'খাত অনুযায়ী খরচের অনুপাত' : 'Spending by Category'}
            </h2>
            <span className="text-xs font-semibold text-slate-400">
              {formatMoney(totalExpenseThisMonth)}
            </span>
          </div>

          {categoryData.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              {language === 'bn' ? 'কোনো খরচের তথ্য নেই।' : 'No expense data for this month.'}
            </div>
          ) : (
            <div className="flex flex-col sm:flex-row items-center gap-6">
              
              {/* SVG Donut Chart */}
              <div className="relative w-44 h-44 shrink-0 flex items-center justify-center">
                <svg className="w-full h-full -rotate-90 transform" viewBox="0 0 160 160">
                  <circle
                    cx="80"
                    cy="80"
                    r={radius}
                    stroke="#f1f5f9"
                    strokeWidth="18"
                    fill="transparent"
                  />
                  {categoryData.map((cat, idx) => {
                    const strokeDasharray = `${(cat.percentage / 100) * circumference} ${circumference}`;
                    const strokeDashoffset = -((accumulatedPercent / 100) * circumference);
                    accumulatedPercent += cat.percentage;

                    const isHovered = activeDonutIdx === idx;

                    return (
                      <circle
                        key={cat.id}
                        cx="80"
                        cy="80"
                        r={radius}
                        stroke={cat.color}
                        strokeWidth={isHovered ? '22' : '18'}
                        strokeDasharray={strokeDasharray}
                        strokeDashoffset={strokeDashoffset}
                        fill="transparent"
                        className="transition-all duration-300 cursor-pointer"
                        onMouseEnter={() => setActiveDonutIdx(idx)}
                        onMouseLeave={() => setActiveDonutIdx(null)}
                      />
                    );
                  })}
                </svg>

                {/* Donut center text */}
                <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
                  <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">
                    {activeDonutIdx !== null ? categoryData[activeDonutIdx]?.name : (language === 'bn' ? 'মোট খরচ' : 'Total')}
                  </span>
                  <span className="text-sm font-black text-slate-800">
                    {activeDonutIdx !== null
                      ? formatMoney(categoryData[activeDonutIdx]?.amount)
                      : formatMoney(totalExpenseThisMonth)}
                  </span>
                  {activeDonutIdx !== null && (
                    <span className="text-[10px] font-bold text-emerald-700">
                      {Math.round(categoryData[activeDonutIdx]?.percentage)}%
                    </span>
                  )}
                </div>
              </div>

              {/* Legend List */}
              <div className="flex-1 space-y-2 w-full max-h-52 overflow-y-auto pr-1">
                {categoryData.map((cat, idx) => (
                  <div
                    key={cat.id}
                    onMouseEnter={() => setActiveDonutIdx(idx)}
                    onMouseLeave={() => setActiveDonutIdx(null)}
                    className={`flex items-center justify-between p-2 rounded-xl text-xs transition-colors cursor-pointer ${
                      activeDonutIdx === idx ? 'bg-emerald-50' : 'hover:bg-slate-50'
                    }`}
                  >
                    <div className="flex items-center gap-2 min-w-0">
                      <span
                        className="w-3 h-3 rounded-full shrink-0"
                        style={{ backgroundColor: cat.color }}
                      />
                      <span className="font-semibold text-slate-700 truncate">{cat.name}</span>
                    </div>
                    <div className="text-right shrink-0 ml-2">
                      <span className="font-bold text-slate-900">{formatMoney(cat.amount)}</span>
                      <span className="text-[10px] text-slate-400 ml-1.5 font-mono">
                        {Math.round(cat.percentage)}%
                      </span>
                    </div>
                  </div>
                ))}
              </div>

            </div>
          )}
        </div>

        {/* 7-Day Spending Bar Chart */}
        <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
              <BarChart3 className="w-4 h-4 text-emerald-600" />
              {language === 'bn' ? 'গত ৭ দিনের দৈনিক ব্যয়ের ধারা' : '7-Day Daily Spending Trend'}
            </h2>
            <span className="text-xs text-slate-400 font-medium">
              {language === 'bn' ? 'দৈনিক প্যাটার্ন' : 'Daily Pattern'}
            </span>
          </div>

          <div className="h-48 pt-6 flex items-end justify-between gap-2 sm:gap-4 px-2">
            {past7Days.map(day => {
              const heightPercent = Math.max(8, Math.round((day.amount / maxDailyExpense) * 100));
              const isToday = day.date === new Date().toISOString().split('T')[0];

              return (
                <div key={day.date} className="flex-1 flex flex-col items-center gap-2 h-full justify-end group">
                  <span className="text-[10px] font-bold text-slate-500 opacity-0 group-hover:opacity-100 transition-opacity">
                    {formatMoney(day.amount)}
                  </span>
                  
                  <div className="w-full max-w-[36px] bg-slate-100 rounded-t-xl overflow-hidden flex flex-col justify-end h-32">
                    <div
                      className={`w-full rounded-t-xl transition-all duration-500 ${
                        isToday
                          ? 'bg-emerald-600 shadow-sm'
                          : 'bg-emerald-400 group-hover:bg-emerald-500'
                      }`}
                      style={{ height: `${heightPercent}%` }}
                    />
                  </div>

                  <span
                    className={`text-[11px] font-semibold ${
                      isToday ? 'text-emerald-700 font-bold' : 'text-slate-500'
                    }`}
                  >
                    {day.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>

      </div>

      {/* Cashflow Income vs Expense Comparison Bar */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-3">
        <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
          <TrendingUp className="w-4 h-4 text-emerald-600" />
          {language === 'bn' ? 'আয় ও ব্যয়ের তুলনা (ক্যাশ ফ্লো)' : 'Cash Flow Breakdown'}
        </h2>

        <div className="space-y-2">
          <div className="flex justify-between text-xs font-bold">
            <span className="text-emerald-700">
              {t('totalIncome')}: +{formatMoney(totalIncomeThisMonth)}
            </span>
            <span className="text-rose-600">
              {t('totalExpense')}: -{formatMoney(totalExpenseThisMonth)}
            </span>
          </div>

          <div className="w-full h-4 bg-slate-100 rounded-full overflow-hidden flex">
            <div
              className="bg-emerald-500 h-full transition-all duration-500"
              style={{
                width: `${
                  totalIncomeThisMonth + totalExpenseThisMonth > 0
                    ? (totalIncomeThisMonth / (totalIncomeThisMonth + totalExpenseThisMonth)) * 100
                    : 50
                }%`,
              }}
              title="Income ratio"
            />
            <div
              className="bg-rose-500 h-full transition-all duration-500"
              style={{
                width: `${
                  totalIncomeThisMonth + totalExpenseThisMonth > 0
                    ? (totalExpenseThisMonth / (totalIncomeThisMonth + totalExpenseThisMonth)) * 100
                    : 50
                }%`,
              }}
              title="Expense ratio"
            />
          </div>

          <div className="flex justify-between text-[11px] text-slate-500">
            <span>
              {language === 'bn' ? 'নিট লাভ/সঞ্চয়' : 'Net Surplus'}:{' '}
              <strong className={netSavingsThisMonth >= 0 ? 'text-emerald-700' : 'text-rose-600'}>
                {formatMoney(netSavingsThisMonth)}
              </strong>
            </span>
            <span>
              {language === 'bn' ? 'সঞ্চয়ের অনুপাত' : 'Savings Ratio'}: <strong>{savingsRateThisMonth}%</strong>
            </span>
          </div>
        </div>
      </div>

      {/* End-of-Month Prediction Forecast Modal */}
      <EndOfMonthPredictionModal
        isOpen={isPredictionModalOpen}
        onClose={() => setIsPredictionModalOpen(false)}
      />

      {/* AI Money Leak Detector Modal */}
      <MoneyLeakModal
        isOpen={isMoneyLeakModalOpen}
        onClose={() => setIsMoneyLeakModalOpen(false)}
      />

    </div>
  );
};
