import React, { useState, useMemo } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import {
  RankedObligation,
  PaymentObligation,
  PaymentStrategyType,
  PriorityLevel,
} from '../../types/paymentPriority';
import { PaymentDetailsModal } from '../payment-priority/PaymentDetailsModal';
import { PayObligationModal } from '../payment-priority/PayObligationModal';
import { AddCustomObligationModal } from '../payment-priority/AddCustomObligationModal';
import { PriorityConfigModal } from '../payment-priority/PriorityConfigModal';
import { WhatIfSimulatorModal } from '../payment-priority/WhatIfSimulatorModal';
import {
  ShieldAlert,
  Sparkles,
  Sliders,
  Plus,
  Play,
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle2,
  Receipt,
  CreditCard,
  Building2,
  Wallet,
  Zap,
  ArrowRight,
  ChevronDown,
  ChevronUp,
  Search,
  Filter,
  DollarSign,
  Info,
  Flame,
  Droplets,
  Wifi,
  Smartphone,
  Home,
  GraduationCap,
  HeartPulse,
  TrendingDown,
  RotateCcw,
  ShieldCheck,
  X,
} from 'lucide-react';

export const PaymentPriorityView: React.FC = () => {
  const {
    rankedPaymentObligations,
    cashFlowAnalysis,
    selectedPaymentStrategy,
    setSelectedPaymentStrategy,
    paymentEngineConfig,
    rescheduleObligation,
    formatMoney,
    currency,
    language,
    isPriorityConfigModalOpen,
    setIsPriorityConfigModalOpen,
    isAddCustomObligationModalOpen,
    setIsAddCustomObligationModalOpen,
  } = useExpense();

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<'all' | 'critical' | 'high' | 'overdue' | 'essential' | 'credit_card' | 'loan'>('all');
  const [expandedScoreItemId, setExpandedScoreItemId] = useState<string | null>(null);

  // Modals state
  const [selectedDetailsItem, setSelectedDetailsItem] = useState<RankedObligation | null>(null);
  const [selectedPayObligation, setSelectedPayObligation] = useState<PaymentObligation | null>(null);
  const [isSimulatorOpen, setIsSimulatorOpen] = useState(false);
  const [reschedulingObligation, setReschedulingObligation] = useState<PaymentObligation | null>(null);
  const [newDueDateInput, setNewDueDateInput] = useState('');

  // Filtering obligations
  const filteredItems = useMemo(() => {
    return rankedPaymentObligations.filter((item) => {
      const ob = item.obligation;
      const query = searchQuery.toLowerCase().trim();
      if (query) {
        const nameMatch = (ob.name || '').toLowerCase().includes(query) || (ob.nameBn || '').toLowerCase().includes(query);
        const catMatch = (ob.category || '').toLowerCase().includes(query);
        const providerMatch = (ob.providerName || '').toLowerCase().includes(query);
        if (!nameMatch && !catMatch && !providerMatch) return false;
      }

      if (activeFilter === 'critical') return item.scoreBreakdown.level === 'critical';
      if (activeFilter === 'high') return item.scoreBreakdown.level === 'high';
      if (activeFilter === 'overdue') return ob.isOverdue;
      if (activeFilter === 'essential') return ob.isEssential;
      if (activeFilter === 'credit_card') return ob.category === 'credit_card';
      if (activeFilter === 'loan') return ob.category === 'loan' || ob.category === 'debt';

      return true;
    });
  }, [rankedPaymentObligations, searchQuery, activeFilter]);

  // Critical & Overdue count
  const criticalItems = useMemo(() => {
    return rankedPaymentObligations.filter((item) => item.scoreBreakdown.level === 'critical' || item.obligation.isOverdue);
  }, [rankedPaymentObligations]);

  // Strategy options with clear financial rationale
  const strategies: {
    id: PaymentStrategyType;
    label: string;
    labelBn: string;
    description: string;
    descriptionBn: string;
    badge?: string;
  }[] = [
    {
      id: 'balanced_smart',
      label: 'Balanced Smart Safety',
      labelBn: 'সুষম ও নিরাপদ (প্রস্তাবিত)',
      description: 'Protects food/living essentials, covers mandatory minimums, then attacks high penalties & APRs.',
      descriptionBn: 'খাবার ও জীবনধারণের জরুরি খরচ রক্ষা করে, বাধ্যতামূলক ন্যূনতম পরিশোধ নিশ্চিত করে ও চড়া জরিমানা এড়ায়।',
      badge: 'Recommended',
    },
    {
      id: 'deadline_first',
      label: 'Deadline First',
      labelBn: 'মেয়াদকাল অনুযায়ী (Chronological)',
      description: 'Strictly orders by earliest due date, clearing imminent deadlines regardless of interest rate.',
      descriptionBn: 'যে বিলের তারিখ সবচেয়ে কাছে সেটি আগে পরিশোধের ক্রমানুসারে সাজায়।',
    },
    {
      id: 'highest_interest',
      label: 'Highest Interest (Avalanche)',
      labelBn: 'সর্বোচ্চ সুদ সাশ্রয় (Debt Avalanche)',
      description: 'Prioritizes high APR debts (like credit cards) to minimize compounding interest expense.',
      descriptionBn: 'উচ্চ সুদের ঋণ ও ক্রেডিট কার্ড আগে পরিশোধ করে দীর্ঘমেয়াদী সুদ ব্যয় কমায়।',
    },
    {
      id: 'highest_penalty',
      label: 'Highest Penalty First',
      labelBn: 'সর্বোচ্চ জরিমানা এড়ানো',
      description: 'Targets bills with the most expensive late fees to avoid instant financial fines.',
      descriptionBn: 'যেসব বিলে বিলম্ব ফি বা জরিমানা সবচেয়ে বেশি সেগুলোকে অগ্রাধিকার দেয়।',
    },
    {
      id: 'essential_first',
      label: 'Essential Living First',
      labelBn: 'মৌলিক প্রয়োজন অগ্রাধিকার',
      description: 'Guarantees power, water, rent, and food before a single penny goes to optional debts.',
      descriptionBn: 'বিদ্যুৎ, গ্যাস, পানি, বাসা ভাড়া ও চিকিৎসা নিশ্চিত না করে কোনো ঋণ দেওয়া হয় না।',
    },
  ];

  // Helper for obligation icon
  const getObligationIcon = (ob: PaymentObligation) => {
    if (ob.category === 'utility') return Zap;
    if (ob.category === 'rent') return Home;
    if (ob.category === 'internet') return Wifi;
    if (ob.category === 'mobile') return Smartphone;
    if (ob.category === 'credit_card') return CreditCard;
    if (ob.category === 'loan' || ob.category === 'debt') return Building2;
    if (ob.category === 'education') return GraduationCap;
    if (ob.category === 'medical') return HeartPulse;
    return Receipt;
  };

  const handleOpenReschedule = (ob: PaymentObligation) => {
    setReschedulingObligation(ob);
    setNewDueDateInput(ob.dueDate);
  };

  const handleSaveReschedule = () => {
    if (reschedulingObligation && newDueDateInput) {
      rescheduleObligation(reschedulingObligation.id, newDueDateInput);
      setReschedulingObligation(null);
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      {/* Top Header Card */}
      <div className="bg-white rounded-3xl p-5 sm:p-7 border border-slate-100 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2.5 flex-wrap">
            <span className="p-2 rounded-xl bg-emerald-50 text-emerald-600 border border-emerald-100">
              <ShieldAlert className="w-5 h-5 stroke-[2.2]" />
            </span>
            <h1 className="text-xl sm:text-2xl font-black text-slate-800 tracking-tight">
              {language === 'bn' ? 'স্মার্ট পেমেন্ট প্রায়োরিটি ইঞ্জিন' : 'Smart Payment Priority Engine'}
            </h1>
            <span className="px-2.5 py-0.5 rounded-full text-[11px] font-black bg-emerald-600 text-white shadow-2xs">
              Advanced Edition
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
            {language === 'bn'
              ? 'বকেয়া বিল, কিস্তি, ক্রেডিট কার্ড ও ঋণের গাণিতিক বিশ্লেষণ এবং ঝুঁকিমুক্ত অগ্রাধিকার তালিকা।'
              : 'Algorithmic ranking of upcoming obligations based on urgency, penalties, interest, and cash safety.'}
          </p>
        </div>

        {/* Top Header Actions */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setIsSimulatorOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-sm hover:shadow transition-all cursor-pointer"
          >
            <Sparkles className="w-4 h-4 text-emerald-400" />
            <span>{language === 'bn' ? 'হোয়াট-ইফ সিমুলেটর' : 'What-If Simulator'}</span>
          </button>

          <button
            onClick={() => setIsAddCustomObligationModalOpen(true)}
            className="flex items-center gap-1.5 px-3.5 py-2.5 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{language === 'bn' ? 'নতুন দায় যোগ' : 'Add Obligation'}</span>
          </button>

          <button
            onClick={() => setIsPriorityConfigModalOpen(true)}
            className="p-2.5 rounded-2xl border border-slate-200 hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
            title={language === 'bn' ? 'স্কোরিং কনফিগারেশন' : 'Scoring Weights & Rules'}
          >
            <Sliders className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* CASH FLOW & AVAILABLE FUNDS SAFETY SUMMARY BAR */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
        {/* Metric 1: Available Balance */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? 'হাতে থাকা ব্যালেন্স' : 'Liquid Funds'}
            </span>
            <Wallet className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-lg font-black text-slate-900">
            {formatMoney(cashFlowAnalysis.availableBalance)}
          </p>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5">
            {language === 'bn' ? 'ব্যাংক, ক্যাশ ও ওয়ালেট' : 'Cash + Bank + MFS'}
          </p>
        </div>

        {/* Metric 2: Due in 24 Hours */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? '২৪ ঘণ্টায় প্রদেয়' : 'Due in 24h'}
            </span>
            <Clock className="w-4 h-4 text-red-500" />
          </div>
          <p className={`text-lg font-black ${cashFlowAnalysis.dueIn24Hours > 0 ? 'text-red-600' : 'text-slate-900'}`}>
            {formatMoney(cashFlowAnalysis.dueIn24Hours)}
          </p>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5">
            {language === 'bn' ? 'আজ বা কালকের শেষ দিন' : 'Urgent today/tomorrow'}
          </p>
        </div>

        {/* Metric 3: Due in 3 Days */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? '৩ দিনের মধ্যে' : 'Due in 3 Days'}
            </span>
            <Calendar className="w-4 h-4 text-amber-500" />
          </div>
          <p className="text-lg font-black text-slate-900">
            {formatMoney(cashFlowAnalysis.dueIn3Days)}
          </p>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5">
            {language === 'bn' ? 'আসন্ন সময়সীমা' : 'Imminent window'}
          </p>
        </div>

        {/* Metric 4: Due in 7 Days */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? '৭ দিনের মধ্যে' : 'Due in 7 Days'}
            </span>
            <Calendar className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-lg font-black text-slate-900">
            {formatMoney(cashFlowAnalysis.dueIn7Days)}
          </p>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5">
            {language === 'bn' ? 'চলতি সপ্তাহের মোট' : 'Week-ahead total'}
          </p>
        </div>

        {/* Metric 5: Total Essential Needs */}
        <div className="bg-white rounded-2xl p-4 border border-slate-100 shadow-2xs">
          <div className="flex items-center justify-between text-slate-400 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {language === 'bn' ? 'জরুরি জীবনযাত্রা' : 'Essential Needs'}
            </span>
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-lg font-black text-emerald-700">
            {formatMoney(cashFlowAnalysis.totalEssentialDue)}
          </p>
          <p className="text-[10px] text-slate-400 font-medium mt-0.5">
            {language === 'bn' ? 'বিদ্যুৎ, বাসা ভাড়া ও খাবার' : 'Power, rent & survival'}
          </p>
        </div>

        {/* Metric 6: Estimated Remaining / Shortfall */}
        <div
          className={`rounded-2xl p-4 border shadow-2xs ${
            cashFlowAnalysis.hasShortfall
              ? 'bg-red-50/70 border-red-200'
              : 'bg-emerald-50/70 border-emerald-200'
          }`}
        >
          <div className="flex items-center justify-between text-slate-600 mb-1">
            <span className="text-[11px] font-bold uppercase tracking-wider">
              {cashFlowAnalysis.hasShortfall
                ? language === 'bn'
                  ? 'ফান্ড ঘাটতি (Shortfall)'
                  : 'Cash Shortfall'
                : language === 'bn'
                ? 'অবশিষ্ট ব্যালেন্স'
                : 'Projected Left'}
            </span>
            {cashFlowAnalysis.hasShortfall ? (
              <AlertTriangle className="w-4 h-4 text-red-600" />
            ) : (
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            )}
          </div>
          <p
            className={`text-lg font-black ${
              cashFlowAnalysis.hasShortfall ? 'text-red-700' : 'text-emerald-800'
            }`}
          >
            {cashFlowAnalysis.hasShortfall
              ? `-${formatMoney(cashFlowAnalysis.shortfallAmount)}`
              : formatMoney(cashFlowAnalysis.projectedRemaining)}
          </p>
          <p className="text-[10px] font-bold mt-0.5 text-slate-600">
            {cashFlowAnalysis.hasShortfall
              ? language === 'bn'
                ? '⚠️ জরুরি বিল আগে দিন'
                : 'Prioritize essentials'
              : language === 'bn'
              ? 'সবগুলো বিল কভার করা সম্ভব'
              : '100% payments covered'}
          </p>
        </div>
      </div>

      {/* CRITICAL SHORTFALL ALERT BANNER (If funds are insufficient) */}
      {cashFlowAnalysis.hasShortfall && (
        <div className="p-4 sm:p-5 rounded-3xl bg-red-500/10 border border-red-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-2xl bg-red-600 text-white flex items-center justify-center shrink-0 shadow-sm mt-0.5">
              <AlertTriangle className="w-5 h-5 stroke-[2.2]" />
            </div>
            <div>
              <h4 className="text-sm font-black text-red-950">
                {language === 'bn'
                  ? `ফান্ড ঘাটতি সতর্কতা: আসন্ন সকল পেমেন্ট করার জন্য ${formatMoney(cashFlowAnalysis.shortfallAmount)} কম রয়েছে!`
                  : `Cash Shortfall Alert: You need ${formatMoney(cashFlowAnalysis.shortfallAmount)} more to cover all upcoming payments.`}
              </h4>
              <p className="text-xs text-red-800 font-medium mt-0.5 leading-relaxed">
                {language === 'bn'
                  ? 'ইঞ্জিনের কঠোর নিরাপত্তা নিয়ম চালু হয়েছে: বাসা ভাড়া, বিদ্যুৎ ও খাবারের মতো আবশ্যক ব্যয় আগে সুরক্ষিত রাখা হয়েছে। ঐচ্ছিক ঋণ বা সাবস্ক্রিপশন আপাতত স্থগিত রাখার পরামর্শ দেওয়া হচ্ছে।'
                  : 'Safety Safeguard active: Vital living costs (utilities, housing, medical) are locked first. Optional debt or non-essential renewals are deprioritized.'}
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsSimulatorOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-red-700 hover:bg-red-800 text-white text-xs font-bold shrink-0 transition-colors shadow-xs cursor-pointer"
          >
            {language === 'bn' ? 'ঘাটতি সমাধান সিমুলেট করুন' : 'Simulate Solutions'}
          </button>
        </div>
      )}

      {/* STRATEGY SELECTOR & ACTIVE RATIONALE */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-100 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
          <div>
            <h3 className="text-sm font-black text-slate-800 uppercase tracking-wider flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              {language === 'bn' ? 'পেমেন্ট প্রায়োরিটি কৌশল (Strategy Selector)' : 'Optimization Strategy'}
            </h3>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {language === 'bn'
                ? 'আপনার বর্তমান অর্থনৈতিক অগ্রাধিকার অনুযায়ী তালিকা স্বয়ংক্রিয়ভাবে সাজানো হবে।'
                : 'Select the optimal financial heuristic for ordering and allocating funds.'}
            </p>
          </div>
        </div>

        {/* 5 Strategy Pills */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-2.5">
          {strategies.map((strat) => {
            const isSelected = selectedPaymentStrategy === strat.id;
            return (
              <button
                key={strat.id}
                onClick={() => setSelectedPaymentStrategy(strat.id)}
                className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer relative flex flex-col justify-between ${
                  isSelected
                    ? 'border-emerald-600 bg-emerald-50/60 shadow-xs ring-1 ring-emerald-500/30'
                    : 'border-slate-200/80 hover:bg-slate-50 text-slate-700'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-xs font-black text-slate-900 leading-tight">
                      {language === 'bn' ? strat.labelBn : strat.label}
                    </span>
                    {strat.badge && (
                      <span className="text-[9px] font-black uppercase bg-emerald-600 text-white px-1.5 py-0.5 rounded-md">
                        {strat.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500 leading-relaxed font-medium">
                    {language === 'bn' ? strat.descriptionBn : strat.description}
                  </p>
                </div>

                <div className="mt-2.5 flex items-center gap-1.5 text-[11px] font-bold">
                  {isSelected ? (
                    <span className="text-emerald-700 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                      {language === 'bn' ? 'সক্রিয় কৌশল' : 'Active Plan'}
                    </span>
                  ) : (
                    <span className="text-slate-400 hover:text-slate-600">
                      {language === 'bn' ? 'নির্বাচন করুন' : 'Select'}
                    </span>
                  )}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* FILTER & SEARCH BAR */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
        {/* Search Input */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
          <input
            type="text"
            placeholder={
              language === 'bn'
                ? 'পেমেন্টের নাম, ডেসকো, ব্র্যাক ব্যাংক বা ক্যাটাগরি দিয়ে খুঁজুন...'
                : 'Search by obligation name, provider, or category...'
            }
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2.5 rounded-2xl bg-white border border-slate-200 text-xs font-bold text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/30 focus:border-emerald-500 shadow-2xs"
          />
        </div>

        {/* Filter Pills */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          {[
            { id: 'all', label: language === 'bn' ? 'সবগুলো' : 'All', count: rankedPaymentObligations.length },
            { id: 'critical', label: language === 'bn' ? 'জরুরি' : 'Critical', count: rankedPaymentObligations.filter(i => i.scoreBreakdown.level === 'critical').length },
            { id: 'overdue', label: language === 'bn' ? 'বকেয়া' : 'Overdue', count: rankedPaymentObligations.filter(i => i.obligation.isOverdue).length },
            { id: 'essential', label: language === 'bn' ? 'মৌলিক প্রয়োজন' : 'Essential', count: rankedPaymentObligations.filter(i => i.obligation.isEssential).length },
            { id: 'credit_card', label: language === 'bn' ? 'কার্ড' : 'Cards', count: rankedPaymentObligations.filter(i => i.obligation.category === 'credit_card').length },
            { id: 'loan', label: language === 'bn' ? 'ঋণ ও কিস্তি' : 'Loans', count: rankedPaymentObligations.filter(i => i.obligation.category === 'loan' || i.obligation.category === 'debt').length },
          ].map((f) => {
            const isSelected = activeFilter === f.id;
            return (
              <button
                key={f.id}
                onClick={() => setActiveFilter(f.id as any)}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold shrink-0 transition-colors cursor-pointer flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white shadow-2xs'
                    : 'bg-white text-slate-600 hover:bg-slate-50 border border-slate-200'
                }`}
              >
                <span>{f.label}</span>
                <span
                  className={`text-[10px] px-1.5 py-0.2 rounded-full ${
                    isSelected ? 'bg-white/20 text-white' : 'bg-slate-100 text-slate-600'
                  }`}
                >
                  {f.count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* RANKED OBLIGATION LIST */}
      <div className="space-y-3">
        {filteredItems.length > 0 ? (
          filteredItems.map((item) => {
            const ob = item.obligation;
            const score = item.scoreBreakdown;
            const Icon = getObligationIcon(ob);
            const isScoreExpanded = expandedScoreItemId === ob.id;

            // Score badge styling
            const getScoreStyle = () => {
              if (score.level === 'critical') return 'bg-red-50 text-red-700 border-red-200';
              if (score.level === 'high') return 'bg-amber-50 text-amber-700 border-amber-200';
              if (score.level === 'medium') return 'bg-emerald-50 text-emerald-700 border-emerald-200';
              return 'bg-slate-50 text-slate-700 border-slate-200';
            };

            return (
              <div
                key={ob.id}
                className={`bg-white rounded-3xl p-5 border shadow-xs transition-all ${
                  ob.isOverdue
                    ? 'border-red-300 ring-1 ring-red-500/10'
                    : score.level === 'critical'
                    ? 'border-amber-200'
                    : 'border-slate-100'
                }`}
              >
                <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                  {/* Left: Rank, Category Icon, Name & Countdown */}
                  <div className="flex items-start gap-3.5">
                    {/* Rank Badge */}
                    <div className="w-11 h-11 rounded-2xl bg-slate-900 text-white flex flex-col items-center justify-center shrink-0 font-black shadow-xs">
                      <span className="text-[10px] text-emerald-400 uppercase tracking-widest leading-none font-bold">
                        Rank
                      </span>
                      <span className="text-base leading-none mt-0.5">#{item.rank}</span>
                    </div>

                    {/* Category Icon */}
                    <div className="w-11 h-11 rounded-2xl bg-slate-50 border border-slate-100 flex items-center justify-center text-slate-700 shrink-0">
                      <Icon className="w-5 h-5 text-emerald-600" />
                    </div>

                    {/* Details */}
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Score Badge */}
                        <span
                          className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-black border ${getScoreStyle()}`}
                        >
                          <span>{score.score} pts</span>
                          <span>•</span>
                          <span className="capitalize">{score.level}</span>
                        </span>

                        {/* Overdue / Due Countdown Badge */}
                        <span
                          className={`text-[11px] font-bold px-2 py-0.5 rounded-md ${
                            ob.isOverdue
                              ? 'bg-red-100 text-red-800'
                              : ob.daysRemaining <= 1
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-700'
                          }`}
                        >
                          {ob.isOverdue
                            ? language === 'bn'
                              ? `মেয়াদ উত্তীর্ণ (${ob.overdueDays} দিন)`
                              : `Overdue (${ob.overdueDays}d)`
                            : ob.daysRemaining === 0
                            ? language === 'bn'
                              ? 'আজকেই শেষ দিন!'
                              : 'Due Today!'
                            : language === 'bn'
                            ? `${ob.daysRemaining} দিন বাকি (${ob.dueDate})`
                            : `${ob.daysRemaining} days left (${ob.dueDate})`}
                        </span>

                        {/* Essential Living Pill */}
                        {ob.isEssential && (
                          <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                            {language === 'bn' ? 'মৌলিক প্রয়োজন' : 'Essential'}
                          </span>
                        )}

                        {/* Hard Override Pill */}
                        {score.hardOverrideApplied && (
                          <span className="text-[10px] font-bold bg-amber-500 text-white px-2 py-0.5 rounded-full flex items-center gap-1">
                            <ShieldAlert className="w-3 h-3" />
                            {language === 'bn' ? 'সেফটি ওভাররাইড' : 'Safety Override'}
                          </span>
                        )}
                      </div>

                      <h4 className="text-base font-black text-slate-800 mt-1 leading-snug">
                        {language === 'bn' ? ob.nameBn || ob.name : ob.name}
                      </h4>

                      {/* Explanation Snippet */}
                      <p className="text-xs text-slate-500 font-medium mt-0.5 max-w-xl">
                        {language === 'bn' ? score.explanationSummaryBn : score.explanationSummary}
                      </p>
                    </div>
                  </div>

                  {/* Middle: Amount & Post-payment balance */}
                  <div className="flex items-center gap-6 lg:text-right border-y sm:border-y-0 sm:border-l border-slate-100 py-3 sm:py-0 sm:pl-6">
                    <div>
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        {language === 'bn' ? 'প্রদেয় পরিমাণ' : 'Amount Due'}
                      </p>
                      <p className="text-lg font-black text-slate-900 mt-0.5">
                        {formatMoney(ob.amountConverted)}
                      </p>
                      {ob.minimumAmountDue > 0 && ob.minimumAmountDue < ob.amountConverted && (
                        <p className="text-[10px] font-bold text-emerald-700">
                          {language === 'bn' ? 'ন্যূনতম: ' : 'Min: '}
                          {formatMoney(ob.minimumAmountDue)}
                        </p>
                      )}
                    </div>

                    <div>
                      <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider">
                        {language === 'bn' ? 'পরিশোধের পর ব্যালেন্স' : 'Left After Pay'}
                      </p>
                      <p
                        className={`text-sm font-black mt-0.5 ${
                          item.remainingBalanceAfter > 0 ? 'text-slate-800' : 'text-red-600'
                        }`}
                      >
                        {formatMoney(item.remainingBalanceAfter)}
                      </p>
                      <span
                        className={`inline-block text-[10px] font-bold px-2 py-0.2 rounded-full mt-0.5 ${
                          item.coverageStatus === 'fully_covered'
                            ? 'bg-emerald-100 text-emerald-800'
                            : item.coverageStatus === 'minimum_covered_only'
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-red-100 text-red-800'
                        }`}
                      >
                        {item.coverageStatus === 'fully_covered'
                          ? language === 'bn'
                            ? 'সম্পূর্ণ নিরাপদ'
                            : 'Covered'
                          : item.coverageStatus === 'minimum_covered_only'
                          ? language === 'bn'
                            ? 'শুধু ন্যূনতম'
                            : 'Min Only'
                          : language === 'bn'
                          ? 'ঘাটতি (Uncovered)'
                          : 'Shortfall'}
                      </span>
                    </div>
                  </div>

                  {/* Right Actions */}
                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={() => setSelectedDetailsItem(item)}
                      className="px-3 py-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-700 font-bold text-xs transition-colors cursor-pointer"
                    >
                      {language === 'bn' ? 'বিস্তারিত' : 'Details'}
                    </button>

                    <button
                      onClick={() => handleOpenReschedule(ob)}
                      className="p-2 rounded-xl border border-slate-200 hover:bg-slate-50 text-slate-500 hover:text-slate-700 transition-colors cursor-pointer"
                      title={language === 'bn' ? 'তারিখ পরিবর্তন' : 'Reschedule'}
                    >
                      <Calendar className="w-4 h-4" />
                    </button>

                    <button
                      onClick={() => setSelectedPayObligation(ob)}
                      className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm hover:shadow transition-all cursor-pointer"
                    >
                      <span>{language === 'bn' ? 'পরিশোধ' : 'Pay Now'}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>

                {/* Optional Score Factor Accordion */}
                <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <button
                    onClick={() => setExpandedScoreItemId(isScoreExpanded ? null : ob.id)}
                    className="text-slate-500 hover:text-emerald-700 font-bold flex items-center gap-1 cursor-pointer"
                  >
                    <span>{language === 'bn' ? 'কেন এই প্রায়োরিটি স্কোর?' : 'Why this priority score?'}</span>
                    {isScoreExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                  </button>

                  <div className="flex items-center gap-3 text-slate-400 text-[11px]">
                    {ob.hasLateFee && (
                      <span className="text-amber-700 font-bold">
                        ⚠️ {language === 'bn' ? 'বিলম্ব জরিমানা প্রযোজ্য' : 'Late fine applies'}
                      </span>
                    )}
                    {ob.interestRateAPR && (
                      <span className="text-red-700 font-bold">
                        📈 {ob.interestRateAPR}% APR
                      </span>
                    )}
                  </div>
                </div>

                {isScoreExpanded && (
                  <div className="mt-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-100 text-xs space-y-2 animate-in fade-in duration-150">
                    <p className="font-bold text-slate-700">
                      {language === 'bn' ? 'স্কোর নির্ণয় বিশ্লেষণ:' : 'Score Calculation Breakdown:'}
                    </p>
                    <div className="grid grid-cols-2 sm:grid-cols-6 gap-2 text-[11px]">
                      <div className="bg-white p-2 rounded-xl border border-slate-100">
                        <span className="text-slate-400 block">{language === 'bn' ? 'জরুরিতা' : 'Urgency'}</span>
                        <span className="font-bold text-slate-800">{score.urgencyScore} / 100</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-100">
                        <span className="text-slate-400 block">{language === 'bn' ? 'বকেয়া' : 'Overdue'}</span>
                        <span className="font-bold text-slate-800">{score.overdueScore} / 100</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-100">
                        <span className="text-slate-400 block">{language === 'bn' ? 'পেনাল্টি' : 'Penalty'}</span>
                        <span className="font-bold text-slate-800">{score.penaltyScore} / 100</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-100">
                        <span className="text-slate-400 block">{language === 'bn' ? 'সুদের হার' : 'Interest'}</span>
                        <span className="font-bold text-slate-800">{score.interestScore} / 100</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-100">
                        <span className="text-slate-400 block">{language === 'bn' ? 'পরিণতি' : 'Severity'}</span>
                        <span className="font-bold text-slate-800">{score.consequenceScore} / 100</span>
                      </div>
                      <div className="bg-white p-2 rounded-xl border border-slate-100">
                        <span className="text-slate-400 block">{language === 'bn' ? 'অপরিহার্য' : 'Essential'}</span>
                        <span className="font-bold text-slate-800">{score.essentialScore} / 100</span>
                      </div>
                    </div>

                    {score.hardOverrideApplied && (
                      <div className="p-2.5 rounded-xl bg-amber-100/70 text-amber-900 font-bold text-[11px]">
                        🛡️ {score.overrideReasonBn || score.overrideReason}
                      </div>
                    )}
                  </div>
                )}
              </div>
            );
          })
        ) : (
          <div className="bg-white rounded-3xl p-12 text-center border border-slate-100 space-y-3">
            <div className="w-16 h-16 rounded-3xl bg-emerald-50 text-emerald-600 flex items-center justify-center mx-auto">
              <CheckCircle2 className="w-8 h-8 stroke-[2.2]" />
            </div>
            <h4 className="text-lg font-black text-slate-800">
              {language === 'bn'
                ? 'অভিনন্দন! কোনো বকেয়া বা আসন্ন পেমেন্ট পাওয়া যায়নি'
                : 'All Clear! No Pending Financial Obligations'}
            </h4>
            <p className="text-xs text-slate-500 font-medium max-w-md mx-auto">
              {language === 'bn'
                ? 'আপনার সকল বিল, কিস্তি ও ঋণ পরিশোধিত রয়েছে। নতুন কোনো টিউশন বা মেডিকেল দায় থাকলে যোগ করতে পারেন।'
                : 'All your bills, debts, and credit cards are up to date. You can add custom obligations anytime.'}
            </p>
            <button
              onClick={() => setIsAddCustomObligationModalOpen(true)}
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 text-white font-bold text-xs hover:bg-emerald-700 transition-colors shadow-2xs cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>{language === 'bn' ? '+ নতুন দায় যোগ করুন' : '+ Add Obligation'}</span>
            </button>
          </div>
        )}
      </div>

      {/* QUICK RESCHEDULE DIALOG (If user clicked reschedule) */}
      {reschedulingObligation && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-slate-900/50 backdrop-blur-xs animate-in fade-in"
          onClick={() => setReschedulingObligation(null)}
        >
          <div
            className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-100 space-y-4"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between">
              <h4 className="font-black text-sm text-slate-800">
                {language === 'bn' ? 'পেমেন্টের তারিখ পরিবর্তন' : 'Reschedule Due Date'}
              </h4>
              <button
                onClick={() => setReschedulingObligation(null)}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-500">
              {reschedulingObligation.nameBn || reschedulingObligation.name}
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'নতুন তারিখ নির্বাচন করুন' : 'Select New Due Date'}
              </label>
              <input
                type="date"
                value={newDueDateInput}
                onChange={(e) => setNewDueDateInput(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 font-bold text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setReschedulingObligation(null)}
                className="px-3 py-2 rounded-xl text-slate-500 font-bold text-xs hover:bg-slate-50"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                onClick={handleSaveReschedule}
                className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-2xs"
              >
                {language === 'bn' ? 'আপডেট করুন' : 'Save New Date'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODALS */}
      <PaymentDetailsModal
        item={selectedDetailsItem}
        isOpen={!!selectedDetailsItem}
        onClose={() => setSelectedDetailsItem(null)}
        onPayNow={(ob) => setSelectedPayObligation(ob)}
        onReschedule={(ob) => handleOpenReschedule(ob)}
      />

      <PayObligationModal
        obligation={selectedPayObligation}
        isOpen={!!selectedPayObligation}
        onClose={() => setSelectedPayObligation(null)}
      />

      <AddCustomObligationModal
        isOpen={isAddCustomObligationModalOpen}
        onClose={() => setIsAddCustomObligationModalOpen(false)}
      />

      <PriorityConfigModal
        isOpen={isPriorityConfigModalOpen}
        onClose={() => setIsPriorityConfigModalOpen(false)}
      />

      <WhatIfSimulatorModal
        isOpen={isSimulatorOpen}
        onClose={() => setIsSimulatorOpen(false)}
      />
    </div>
  );
};
