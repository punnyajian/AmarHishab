import React, { useState, useMemo, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import { CategoryIcon } from '../CategoryIcon';
import { Transaction, TransactionType } from '../../types';
import { getBengaliDate } from '../../utils/bengaliCalendar';
import { NaturalLanguageQuickEntry } from '../NaturalLanguageQuickEntry';
import {
  Search,
  Filter,
  Download,
  Printer,
  Plus,
  Trash2,
  Edit2,
  Calendar,
  Eye,
  X,
  FileSpreadsheet,
} from 'lucide-react';

interface TransactionsViewProps {
  onOpenAddModal: () => void;
  onEditTx: (tx: Transaction) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({
  onOpenAddModal,
  onEditTx,
}) => {
  const {
    transactions,
    categories,
    accounts,
    deleteTransaction,
    formatMoney,
    exportCSV,
    language,
    t,
  } = useExpense();

  const [search, setSearch] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedAccount, setSelectedAccount] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'this_month' | 'this_week'>('all');
  const [viewingReceipt, setViewingReceipt] = useState<string | null>(null);

  useLockBodyScroll(!!viewingReceipt);

  useEffect(() => {
    if (!viewingReceipt) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setViewingReceipt(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [viewingReceipt]);

  // Filter transactions
  const filteredTransactions = useMemo(() => {
    const today = new Date();
    const currentMonthPrefix = today.toISOString().slice(0, 7);

    return transactions.filter(tx => {
      // Type filter
      if (selectedType !== 'all' && tx.type !== selectedType) return false;

      // Account filter
      if (selectedAccount !== 'all' && tx.accountId !== selectedAccount && tx.targetAccountId !== selectedAccount) {
        return false;
      }

      // Category filter
      if (selectedCategory !== 'all' && tx.categoryId !== selectedCategory) return false;

      // Date preset
      if (dateFilter === 'this_month' && !tx.date.startsWith(currentMonthPrefix)) return false;
      if (dateFilter === 'this_week') {
        const txDate = new Date(tx.date);
        const diffTime = Math.abs(today.getTime() - txDate.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays > 7) return false;
      }

      // Search query
      if (search.trim()) {
        const query = search.toLowerCase();
        const cat = categories.find(c => c.id === tx.categoryId);
        const acc = accounts.find(a => a.id === tx.accountId);
        const catName = (cat?.name || '').toLowerCase() + ' ' + (cat?.nameBn || '').toLowerCase();
        const accName = (acc?.name || '').toLowerCase() + ' ' + (acc?.nameBn || '').toLowerCase();
        const note = (tx.note || '').toLowerCase();
        const amountStr = tx.amount.toString();

        return (
          catName.includes(query) ||
          accName.includes(query) ||
          note.includes(query) ||
          amountStr.includes(query)
        );
      }

      return true;
    });
  }, [transactions, selectedType, selectedAccount, selectedCategory, dateFilter, search, categories, accounts]);

  // Group by date
  const groupedTransactions = useMemo(() => {
    const groups: { [date: string]: Transaction[] } = {};
    filteredTransactions.forEach(tx => {
      if (!groups[tx.date]) {
        groups[tx.date] = [];
      }
      groups[tx.date].push(tx);
    });
    return groups;
  }, [filteredTransactions]);

  const dates = Object.keys(groupedTransactions).sort((a, b) => new Date(b).getTime() - new Date(a).getTime());

  // Print view
  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 no-print">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {t('transactions')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {language === 'bn'
              ? `মোট ${filteredTransactions.length} টি লেনদেন পাওয়া গেছে`
              : `${filteredTransactions.length} transactions recorded`}
          </p>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
          <button
            onClick={exportCSV}
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors"
          >
            <Download className="w-3.5 h-3.5 text-emerald-600" />
            <span>{language === 'bn' ? 'CSV' : 'Export'}</span>
          </button>

          <button
            onClick={handlePrint}
            className="inline-flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 sm:py-2 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-xl shadow-xs transition-colors"
          >
            <Printer className="w-3.5 h-3.5 text-slate-600" />
            <span>{language === 'bn' ? 'প্রিন্ট' : 'Print'}</span>
          </button>

          <button
            onClick={onOpenAddModal}
            className="inline-flex items-center gap-1.5 px-3.5 sm:px-4 py-1.5 sm:py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors"
          >
            <Plus className="w-4 h-4 stroke-[2.5]" />
            <span>{t('addTransaction')}</span>
          </button>
        </div>
      </div>

      {/* Smart Natural Language Input Bar */}
      <NaturalLanguageQuickEntry className="no-print" />

      {/* Filter and Search Bar (no-print) */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-3.5 sm:p-4 shadow-xs space-y-2.5 sm:space-y-3 no-print">
        
        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder={t('search')}
            className="w-full pl-10 pr-4 py-2 sm:py-2.5 bg-slate-50 border border-slate-200 rounded-2xl text-xs sm:text-sm font-medium focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 text-xs px-1"
            >
              Clear
            </button>
          )}
        </div>

        {/* Filters Row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 sm:gap-2 pt-0.5">
          
          {/* Type Filter */}
          <select
            value={selectedType}
            onChange={e => setSelectedType(e.target.value)}
            className="w-full px-2 sm:px-3 py-1.5 sm:py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{language === 'bn' ? 'সব ধরন' : 'All Types'}</option>
            <option value="expense">{language === 'bn' ? 'শুধু খরচ' : 'Expenses'}</option>
            <option value="income">{language === 'bn' ? 'শুধু আয়' : 'Incomes'}</option>
            <option value="transfer">{language === 'bn' ? 'শুধু স্থানান্তর' : 'Transfers'}</option>
          </select>

          {/* Account Filter */}
          <select
            value={selectedAccount}
            onChange={e => setSelectedAccount(e.target.value)}
            className="w-full px-2 sm:px-3 py-1.5 sm:py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{language === 'bn' ? 'সকল ওয়ালেট' : 'All Accounts'}</option>
            {accounts.map(acc => (
              <option key={acc.id} value={acc.id}>
                {language === 'bn' ? acc.nameBn : acc.name}
              </option>
            ))}
          </select>

          {/* Category Filter */}
          <select
            value={selectedCategory}
            onChange={e => setSelectedCategory(e.target.value)}
            className="w-full px-2 sm:px-3 py-1.5 sm:py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{language === 'bn' ? 'সকল ক্যাটাগরি' : 'All Categories'}</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.id}>
                {language === 'bn' ? cat.nameBn : cat.name}
              </option>
            ))}
          </select>

          {/* Date Filter */}
          <select
            value={dateFilter}
            onChange={e => setDateFilter(e.target.value as any)}
            className="w-full px-2 sm:px-3 py-1.5 sm:py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
          >
            <option value="all">{language === 'bn' ? 'সকল সময়' : 'All Time'}</option>
            <option value="this_month">{language === 'bn' ? 'চলতি মাস' : 'This Month'}</option>
            <option value="this_week">{language === 'bn' ? 'গত ৭ দিন' : 'Past 7 Days'}</option>
          </select>

        </div>
      </div>

      {/* Transactions List Grouped by Date */}
      {dates.length === 0 ? (
        <div className="bg-white border border-slate-200/80 rounded-3xl p-12 text-center shadow-xs">
          <FileSpreadsheet className="w-12 h-12 text-slate-300 mx-auto mb-3" />
          <p className="text-sm font-bold text-slate-700">{t('noTransactionsFound')}</p>
          <p className="text-xs text-slate-400 mt-1">
            {language === 'bn'
              ? 'ফিল্টার পরিবর্তন করুন অথবা নতুন হিসাব যোগ করুন।'
              : 'Try clearing filters or add a new transaction.'}
          </p>
        </div>
      ) : (
        <div className="space-y-4">
          {dates.map(dateStr => {
            const list = groupedTransactions[dateStr];
            const dayExpense = list
              .filter(t => t.type === 'expense')
              .reduce((sum, t) => sum + t.amount, 0);
            const dayIncome = list
              .filter(t => t.type === 'income')
              .reduce((sum, t) => sum + t.amount, 0);

            return (
              <div key={dateStr} className="bg-white border border-slate-200/80 rounded-3xl shadow-xs overflow-hidden">
                
                {/* Date Header with Daily Totals */}
                <div className="bg-slate-50/90 px-4 sm:px-6 py-2.5 border-b border-slate-100 flex items-center justify-between text-xs font-bold text-slate-700">
                  <div className="flex items-center gap-2 flex-wrap">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>
                      {new Date(dateStr).toLocaleDateString(language === 'bn' ? 'bn-BD' : 'en-US', {
                        weekday: 'short',
                        year: 'numeric',
                        month: 'short',
                        day: 'numeric',
                      })}
                    </span>
                    <span className="text-slate-300">·</span>
                    <span className="text-[11px] font-semibold text-emerald-800 bg-emerald-100/70 border border-emerald-200/60 px-2 py-0.5 rounded-md">
                      {getBengaliDate(dateStr).fullDateBn}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 text-[11px]">
                    {dayIncome > 0 && (
                      <span className="text-emerald-700">
                        +{formatMoney(dayIncome)}
                      </span>
                    )}
                    {dayExpense > 0 && (
                      <span className="text-rose-600">
                        -{formatMoney(dayExpense)}
                      </span>
                    )}
                  </div>
                </div>

                {/* Date Transactions Items */}
                <div className="divide-y divide-slate-100">
                  {list.map(tx => {
                    const cat = categories.find(c => c.id === tx.categoryId);
                    const acc = accounts.find(a => a.id === tx.accountId);
                    const targetAcc = accounts.find(a => a.id === tx.targetAccountId);
                    const isExpense = tx.type === 'expense';
                    const isIncome = tx.type === 'income';

                    return (
                      <div
                        key={tx.id}
                        onClick={() => onEditTx(tx)}
                        className="p-3 sm:p-4 flex items-center justify-between hover:bg-slate-50 active:bg-slate-100/60 transition-colors group cursor-pointer"
                      >
                        <div className="flex items-center gap-2.5 sm:gap-3 min-w-0 flex-1 mr-2">
                          <div
                            className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl flex items-center justify-center shrink-0"
                            style={{
                              backgroundColor: cat ? `${cat.color}15` : '#ecfdf5',
                              color: cat?.color || '#10b981',
                            }}
                          >
                            <CategoryIcon iconName={cat?.icon || 'CircleDot'} size={18} />
                          </div>

                          <div className="min-w-0 flex-1">
                            <p className="text-xs sm:text-sm font-bold text-slate-800 truncate">
                              {tx.note || (cat ? (language === 'bn' ? cat.nameBn : cat.name) : 'Transaction')}
                            </p>
                            
                            <div className="flex items-center gap-1.5 text-[10px] sm:text-[11px] text-slate-400 mt-0.5 flex-wrap">
                              <span className="font-semibold text-slate-600 truncate max-w-[100px] sm:max-w-none">
                                {cat ? (language === 'bn' ? cat.nameBn : cat.name) : ''}
                              </span>
                              <span>•</span>
                              
                              {/* Account indicator */}
                              <span className="bg-slate-100 px-1.5 py-0.5 rounded-sm text-slate-700 font-mono text-[9px] sm:text-[10px]">
                                {tx.type === 'transfer'
                                  ? `${acc ? (language === 'bn' ? acc.nameBn : acc.name) : ''} → ${targetAcc ? (language === 'bn' ? targetAcc.nameBn : targetAcc.name) : ''}`
                                  : (acc ? (language === 'bn' ? acc.nameBn : acc.name) : '')}
                              </span>

                              {tx.time && (
                                <>
                                  <span className="hidden xs:inline">•</span>
                                  <span className="hidden xs:inline">{tx.time}</span>
                                </>
                              )}

                              {tx.receiptUrl && (
                                <button
                                  type="button"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    setViewingReceipt(tx.receiptUrl || null);
                                  }}
                                  className="text-emerald-700 hover:text-emerald-900 inline-flex items-center gap-0.5 ml-1 font-semibold"
                                >
                                  <Eye className="w-3 h-3" />
                                  <span>{language === 'bn' ? 'রসিদ' : 'Receipt'}</span>
                                </button>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Amount & Actions */}
                        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
                          <div className="text-right">
                            <div
                              className={`text-xs sm:text-sm font-black whitespace-nowrap ${
                                isExpense ? 'text-rose-600' : isIncome ? 'text-emerald-700' : 'text-sky-600'
                              }`}
                            >
                              {isExpense ? '-' : isIncome ? '+' : ''}
                              {formatMoney(tx.amount)}
                            </div>
                            <span className="text-[9px] sm:text-[10px] text-slate-400 capitalize block">
                              {tx.type}
                            </span>
                          </div>

                          {/* Quick action icons (Edit, Delete) - no-print */}
                          <div className="flex items-center gap-0.5 opacity-80 group-hover:opacity-100 transition-opacity no-print">
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                onEditTx(tx);
                              }}
                              className="p-1 sm:p-1.5 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors"
                              title="Edit"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              type="button"
                              onClick={(e) => {
                                e.stopPropagation();
                                if (window.confirm(language === 'bn' ? 'আপনি কি নিশ্চিত যে এই লেনদেনটি মুছে ফেলতে চান?' : 'Delete this transaction?')) {
                                  deleteTransaction(tx.id);
                                }
                              }}
                              className="p-1 sm:p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                              title="Delete"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>

                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Receipt Photo Modal */}
      {viewingReceipt && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setViewingReceipt(null);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-3xl max-w-md w-full p-4 space-y-3 shadow-2xl animate-in zoom-in-95 duration-150 max-h-[90dvh] overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="text-sm font-bold text-slate-800">
                {language === 'bn' ? 'সংযুক্ত রসিদ / মেমো' : 'Attached Receipt'}
              </span>
              <button
                type="button"
                onClick={() => setViewingReceipt(null)}
                className="p-1 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <img
              src={viewingReceipt}
              alt="Receipt preview"
              className="w-full max-h-[60vh] object-contain rounded-2xl bg-slate-100"
            />
          </div>
        </div>
      )}

    </div>
  );
};
