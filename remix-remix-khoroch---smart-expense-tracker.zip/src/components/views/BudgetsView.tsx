import React, { useState, useEffect } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { useLockBodyScroll } from '../../utils/useLockBodyScroll';
import { CategoryIcon } from '../CategoryIcon';
import { Target, AlertCircle, CheckCircle2, Plus, Edit2, Sparkles, X, ShieldAlert } from 'lucide-react';
import { Category } from '../../types';

export const BudgetsView: React.FC = () => {
  const {
    categories,
    budgets,
    transactions,
    setCategoryBudget,
    formatMoney,
    language,
    t,
    currency,
  } = useExpense();

  const [editingBudgetCat, setEditingBudgetCat] = useState<Category | null>(null);
  const [budgetLimitInput, setBudgetLimitInput] = useState<string>('');

  useLockBodyScroll(!!editingBudgetCat);

  useEffect(() => {
    if (!editingBudgetCat) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        setEditingBudgetCat(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [editingBudgetCat]);

  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const now = new Date();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysRemaining = Math.max(1, daysInMonth - now.getDate());

  // Filter only expense categories
  const expenseCategories = categories.filter(c => c.type === 'expense');

  // Calculate spent per category for current month
  const categoryBudgets = expenseCategories.map(cat => {
    const budgetObj = budgets.find(b => b.categoryId === cat.id && b.month === currentMonthStr);
    const limit = budgetObj?.monthlyLimit || cat.budgetLimit || 0;
    
    const spent = transactions
      .filter(t => t.type === 'expense' && t.categoryId === cat.id && t.date.startsWith(currentMonthStr))
      .reduce((sum, t) => sum + t.amount, 0);

    const remaining = Math.max(0, limit - spent);
    const percentage = limit > 0 ? Math.round((spent / limit) * 100) : 0;
    const isOver = spent > limit && limit > 0;
    const isNear = percentage >= 80 && !isOver;

    return {
      category: cat,
      limit,
      spent,
      remaining,
      percentage,
      isOver,
      isNear,
    };
  });

  const totalMonthlyLimit = categoryBudgets.reduce((sum, b) => sum + b.limit, 0);
  const totalMonthlySpent = categoryBudgets.reduce((sum, b) => sum + b.spent, 0);
  const totalRemaining = Math.max(0, totalMonthlyLimit - totalMonthlySpent);
  const overallPercentage = totalMonthlyLimit > 0 ? Math.round((totalMonthlySpent / totalMonthlyLimit) * 100) : 0;
  const safeDailySpend = Math.round(totalRemaining / daysRemaining);

  const handleOpenEdit = (cat: Category, currentLimit: number) => {
    setEditingBudgetCat(cat);
    setBudgetLimitInput(currentLimit ? currentLimit.toString() : '');
  };

  const handleSaveBudget = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingBudgetCat) return;
    const limit = parseFloat(budgetLimitInput);
    if (!isNaN(limit) && limit >= 0) {
      setCategoryBudget(editingBudgetCat.id, limit);
    }
    setEditingBudgetCat(null);
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {t('budgets')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {language === 'bn'
              ? 'মাসিক খরচের সীমা নির্ধারণ করুন ও অতিরিক্ত ব্যয় নিয়ন্ত্রণ করুন'
              : 'Set monthly limits to keep your finances disciplined'}
          </p>
        </div>

        {/* Days left in month badge */}
        <div className="flex items-center gap-2 bg-emerald-50 border border-emerald-200/80 px-3.5 py-1.5 rounded-2xl text-xs font-semibold text-emerald-800">
          <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
          <span>
            {language === 'bn'
              ? `মাসের আর ${daysRemaining} দিন বাকি`
              : `${daysRemaining} days remaining this month`}
          </span>
        </div>
      </div>

      {/* Main Budget Summary Hero Card */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pb-4 border-b border-slate-100">
          <div>
            <span className="text-xs text-slate-400 font-medium">{t('monthlyBudget')}</span>
            <div className="text-2xl font-black text-slate-900 mt-0.5">{formatMoney(totalMonthlyLimit)}</div>
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">{t('spent')}</span>
            <div className="text-2xl font-black text-rose-600 mt-0.5">{formatMoney(totalMonthlySpent)}</div>
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium">{t('remaining')}</span>
            <div className="text-2xl font-black text-emerald-700 mt-0.5">{formatMoney(totalRemaining)}</div>
          </div>
        </div>

        {/* Overall progress bar */}
        <div className="space-y-1.5">
          <div className="flex justify-between text-xs font-semibold text-slate-700">
            <span>{language === 'bn' ? 'চলতি মাসের মোট খরচ' : 'Monthly Usage'}: {overallPercentage}%</span>
            <span>
              {language === 'bn' ? `নিরাপদ দৈনিক খরচ: ${formatMoney(safeDailySpend)}/দিন` : `Safe Daily Spend: ${formatMoney(safeDailySpend)}/day`}
            </span>
          </div>
          <div className="w-full bg-slate-100 rounded-full h-3 overflow-hidden">
            <div
              className={`h-3 rounded-full transition-all duration-500 ${
                overallPercentage > 100
                  ? 'bg-rose-500'
                  : overallPercentage > 80
                  ? 'bg-amber-500'
                  : 'bg-emerald-500'
              }`}
              style={{ width: `${Math.min(100, overallPercentage)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Category Budgets Grid */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-800 flex items-center gap-2">
            <Target className="w-4 h-4 text-emerald-600" />
            {language === 'bn' ? 'ক্যাটাগরিভিত্তিক বাজেট' : 'Category Budgets'}
          </h2>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {categoryBudgets.map(({ category, limit, spent, remaining, percentage, isOver, isNear }) => {
            return (
              <div
                key={category.id}
                className={`bg-white border rounded-3xl p-5 shadow-xs transition-all hover:shadow-md flex flex-col justify-between space-y-4 ${
                  isOver
                    ? 'border-rose-300 bg-rose-50/20'
                    : isNear
                    ? 'border-amber-300 bg-amber-50/20'
                    : 'border-slate-200/80 hover:border-emerald-300'
                }`}
              >
                {/* Category Top Row */}
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-2xl flex items-center justify-center shrink-0"
                      style={{
                        backgroundColor: `${category.color}15`,
                        color: category.color,
                      }}
                    >
                      <CategoryIcon iconName={category.icon} size={20} />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-800">
                        {language === 'bn' ? category.nameBn : category.name}
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        {limit > 0 ? `${formatMoney(limit)} ${t('limit')}` : (language === 'bn' ? 'বাজেট সেট নেই' : 'No budget set')}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => handleOpenEdit(category, limit)}
                    className="p-1.5 text-slate-400 hover:text-emerald-700 hover:bg-emerald-50 rounded-xl transition-colors"
                    title={language === 'bn' ? 'বাজেট পরিবর্তন করুন' : 'Edit Budget'}
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Progress bar and metrics */}
                <div className="space-y-2">
                  <div className="flex justify-between text-xs">
                    <span className="font-semibold text-slate-600">
                      {t('spent')}: {formatMoney(spent)}
                    </span>
                    <span
                      className={`font-bold ${
                        isOver ? 'text-rose-600' : isNear ? 'text-amber-600' : 'text-emerald-700'
                      }`}
                    >
                      {percentage}%
                    </span>
                  </div>

                  <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-2 rounded-full transition-all duration-300 ${
                        isOver ? 'bg-rose-500' : isNear ? 'bg-amber-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, percentage)}%` }}
                    />
                  </div>

                  <div className="flex justify-between items-center text-[11px] pt-1">
                    {isOver ? (
                      <span className="text-rose-600 font-bold flex items-center gap-1">
                        <ShieldAlert className="w-3.5 h-3.5" />
                        {language === 'bn' ? 'বাজেট অতিক্রান্ত!' : 'Over Budget!'}
                      </span>
                    ) : isNear ? (
                      <span className="text-amber-700 font-semibold flex items-center gap-1">
                        <AlertCircle className="w-3.5 h-3.5" />
                        {t('nearLimit')}
                      </span>
                    ) : (
                      <span className="text-emerald-700 font-medium flex items-center gap-1">
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        {t('onTrack')}
                      </span>
                    )}

                    <span className="text-slate-400">
                      {t('remaining')}: {formatMoney(remaining)}
                    </span>
                  </div>
                </div>

                {/* Quick set budget if 0 */}
                {limit === 0 && (
                  <button
                    onClick={() => handleOpenEdit(category, 0)}
                    className="w-full py-2 bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>{language === 'bn' ? 'বাজেট সেট করুন' : 'Set Budget'}</span>
                  </button>
                )}

              </div>
            );
          })}
        </div>
      </div>

      {/* Adjust Budget Modal */}
      {editingBudgetCat && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-150"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              setEditingBudgetCat(null);
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-sm w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
            onClick={e => e.stopPropagation()}
            onMouseDown={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div
                  className="w-8 h-8 rounded-xl flex items-center justify-center text-white"
                  style={{ backgroundColor: editingBudgetCat.color }}
                >
                  <CategoryIcon iconName={editingBudgetCat.icon} size={16} />
                </div>
                <div>
                  <h3 className="font-bold text-sm text-slate-800">
                    {language === 'bn' ? editingBudgetCat.nameBn : editingBudgetCat.name}
                  </h3>
                  <span className="text-[10px] text-slate-400">{language === 'bn' ? 'মাসিক বাজেট সীমা' : 'Monthly Limit'}</span>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setEditingBudgetCat(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveBudget} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'সর্বোচ্চ মাসিক বাজেট' : 'Maximum Monthly Limit'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  min="0"
                  placeholder="0"
                  value={budgetLimitInput}
                  onChange={e => setBudgetLimitInput(e.target.value)}
                  className="w-full px-4 py-3 text-xl font-bold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  autoFocus
                />
              </div>

              {/* Quick Preset Buttons */}
              <div className="flex gap-2">
                {[3000, 5000, 10000, 15000].map(val => (
                  <button
                    type="button"
                    key={val}
                    onClick={() => setBudgetLimitInput(val.toString())}
                    className="flex-1 py-1 text-xs font-medium bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 rounded-lg transition-colors"
                  >
                    {val}
                  </button>
                ))}
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingBudgetCat(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
