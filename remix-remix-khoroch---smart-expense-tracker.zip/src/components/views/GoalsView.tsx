import React, { useState } from 'react';
import { useExpense } from '../../context/ExpenseContext';
import { SavingsGoal } from '../../types';
import confetti from 'canvas-confetti';
import {
  PiggyBank,
  Plus,
  Calendar,
  Sparkles,
  TrendingUp,
  X,
  Trash2,
  CheckCircle,
  Laptop,
  ShieldCheck,
  Compass,
  Home,
  Car,
  Gift,
} from 'lucide-react';

export const GoalsView: React.FC = () => {
  const {
    goals,
    addGoal,
    updateGoalSavings,
    deleteGoal,
    formatMoney,
    language,
    t,
    currency,
  } = useExpense();

  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [fundingGoal, setFundingGoal] = useState<SavingsGoal | null>(null);
  const [fundingAmount, setFundingAmount] = useState('');
  const [isDeposit, setIsDeposit] = useState(true);

  // New goal form state
  const [name, setName] = useState('');
  const [nameBn, setNameBn] = useState('');
  const [targetAmount, setTargetAmount] = useState('');
  const [initialSaved, setInitialSaved] = useState('');
  const [deadline, setDeadline] = useState('2026-12-31');
  const [icon, setIcon] = useState('PiggyBank');
  const [notes, setNotes] = useState('');

  const handleOpenAdd = () => {
    setName('');
    setNameBn('');
    setTargetAmount('');
    setInitialSaved('');
    setDeadline('2026-12-31');
    setIcon('PiggyBank');
    setNotes('');
    setIsAddModalOpen(true);
  };

  const handleCreateGoal = (e: React.FormEvent) => {
    e.preventDefault();
    const targetNum = parseFloat(targetAmount);
    const savedNum = parseFloat(initialSaved) || 0;
    if (isNaN(targetNum) || targetNum <= 0 || !name.trim()) return;

    addGoal({
      name: name.trim(),
      nameBn: nameBn.trim() || name.trim(),
      targetAmount: targetNum,
      currentAmount: savedNum,
      deadline,
      icon,
      color: '#10b981',
      notes: notes.trim() || undefined,
    });

    setIsAddModalOpen(false);
  };

  const handleFundingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fundingGoal) return;
    const amountNum = parseFloat(fundingAmount);
    if (isNaN(amountNum) || amountNum <= 0) return;

    const delta = isDeposit ? amountNum : -amountNum;
    updateGoalSavings(fundingGoal.id, delta);

    if (isDeposit && fundingGoal.currentAmount + amountNum >= fundingGoal.targetAmount) {
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
      });
    }

    setFundingGoal(null);
    setFundingAmount('');
  };

  const totalSavedAcrossGoals = goals.reduce((sum, g) => sum + g.currentAmount, 0);
  const totalTargetAcrossGoals = goals.reduce((sum, g) => sum + g.targetAmount, 0);

  const getGoalIcon = (iconName: string) => {
    switch (iconName) {
      case 'Laptop':
        return Laptop;
      case 'ShieldCheck':
        return ShieldCheck;
      case 'Compass':
        return Compass;
      case 'Home':
        return Home;
      case 'Car':
        return Car;
      case 'Gift':
        return Gift;
      default:
        return PiggyBank;
    }
  };

  return (
    <div className="space-y-6 pb-12 animate-in fade-in duration-200">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
        <div>
          <h1 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
            {t('goals')}
          </h1>
          <p className="text-xs sm:text-sm text-slate-500">
            {language === 'bn'
              ? 'স্বপ্ন ও ভবিষ্যতের জন্য সঞ্চয়ের লক্ষ্য নির্ধারণ এবং অগ্রগতি ট্র্যাক করুন'
              : 'Set milestones and save step-by-step for your dream targets'}
          </p>
        </div>

        <button
          onClick={handleOpenAdd}
          className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs transition-colors self-start sm:self-auto"
        >
          <Plus className="w-4 h-4 stroke-[2.5]" />
          <span>{t('addGoal')}</span>
        </button>
      </div>

      {/* Overview Banner */}
      <div className="bg-white border border-slate-200/80 rounded-3xl p-6 shadow-xs grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div>
          <span className="text-xs font-semibold text-slate-400">{language === 'bn' ? 'মোট সঞ্চিত অর্থ' : 'Total Saved in Goals'}</span>
          <div className="text-2xl font-black text-emerald-700 mt-1">{formatMoney(totalSavedAcrossGoals)}</div>
        </div>
        <div>
          <span className="text-xs font-semibold text-slate-400">{language === 'bn' ? 'সর্বমোট লক্ষ্যমাত্রা' : 'Target Sum'}</span>
          <div className="text-2xl font-black text-slate-900 mt-1">{formatMoney(totalTargetAcrossGoals)}</div>
        </div>
        <div>
          <span className="text-xs font-semibold text-slate-400">{language === 'bn' ? 'সামগ্রিক অর্জন' : 'Overall Progress'}</span>
          <div className="text-2xl font-black text-slate-800 mt-1">
            {totalTargetAcrossGoals > 0 ? Math.round((totalSavedAcrossGoals / totalTargetAcrossGoals) * 100) : 0}%
          </div>
        </div>
      </div>

      {/* Goals Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {goals.map(goal => {
          const percent = Math.min(100, Math.round((goal.currentAmount / goal.targetAmount) * 100));
          const remaining = Math.max(0, goal.targetAmount - goal.currentAmount);
          const isCompleted = goal.currentAmount >= goal.targetAmount;
          const IconComponent = getGoalIcon(goal.icon);

          // Calculate days until deadline
          const deadlineDate = new Date(goal.deadline);
          const today = new Date();
          const diffDays = Math.ceil((deadlineDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

          return (
            <div
              key={goal.id}
              className={`bg-white border rounded-3xl p-5 shadow-xs transition-all hover:shadow-md flex flex-col justify-between space-y-4 ${
                isCompleted ? 'border-emerald-300 bg-emerald-50/20' : 'border-slate-200/80'
              }`}
            >
              <div>
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-11 h-11 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center">
                      <IconComponent className="w-5 h-5" />
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-slate-800">
                        {language === 'bn' ? goal.nameBn : goal.name}
                      </h3>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-400 mt-0.5">
                        <Calendar className="w-3 h-3" />
                        <span>
                          {diffDays > 0
                            ? (language === 'bn' ? `আর ${diffDays} দিন বাকি` : `${diffDays} days left`)
                            : (language === 'bn' ? 'সময় শেষ' : 'Due passed')}
                        </span>
                      </div>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      if (window.confirm(language === 'bn' ? 'এই সঞ্চয় লক্ষ্যটি মুছে ফেলতে চান?' : 'Delete this goal?')) {
                        deleteGoal(goal.id);
                      }
                    }}
                    className="p-1.5 text-slate-300 hover:text-rose-600 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {goal.notes && (
                  <p className="text-xs text-slate-500 mt-3 line-clamp-2">
                    {goal.notes}
                  </p>
                )}
              </div>

              {/* Progress */}
              <div className="space-y-2 pt-2">
                <div className="flex justify-between items-baseline text-xs">
                  <div>
                    <span className="font-black text-slate-900 text-base">{formatMoney(goal.currentAmount)}</span>
                    <span className="text-slate-400 text-[11px]"> / {formatMoney(goal.targetAmount)}</span>
                  </div>
                  <span className="font-extrabold text-emerald-700 text-sm">{percent}%</span>
                </div>

                <div className="w-full bg-slate-100 rounded-full h-2.5 overflow-hidden">
                  <div
                    className={`h-2.5 rounded-full transition-all duration-500 ${
                      isCompleted ? 'bg-emerald-500' : 'bg-emerald-600'
                    }`}
                    style={{ width: `${percent}%` }}
                  />
                </div>

                <div className="flex items-center justify-between text-[11px]">
                  {isCompleted ? (
                    <span className="text-emerald-700 font-bold flex items-center gap-1">
                      <CheckCircle className="w-3.5 h-3.5" />
                      {language === 'bn' ? 'অভিনন্দন! লক্ষ্য অর্জিত!' : 'Goal Completed!'}
                    </span>
                  ) : (
                    <span className="text-slate-400">
                      {language === 'bn' ? 'বাকি আছে:' : 'Remaining:'} {formatMoney(remaining)}
                    </span>
                  )}

                  {!isCompleted && diffDays > 0 && remaining > 0 && (
                    <span className="text-slate-500 font-medium">
                      {formatMoney(Math.ceil(remaining / Math.max(1, diffDays / 30)))}/{language === 'bn' ? 'মাস' : 'mo'}
                    </span>
                  )}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="pt-2 border-t border-slate-100 flex gap-2">
                <button
                  onClick={() => {
                    setFundingGoal(goal);
                    setIsDeposit(true);
                    setFundingAmount('');
                  }}
                  className="flex-1 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>{language === 'bn' ? 'জমা করুন' : 'Add Funds'}</span>
                </button>

                {goal.currentAmount > 0 && (
                  <button
                    onClick={() => {
                      setFundingGoal(goal);
                      setIsDeposit(false);
                      setFundingAmount('');
                    }}
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold transition-colors"
                  >
                    {language === 'bn' ? 'উত্তোলন' : 'Withdraw'}
                  </button>
                )}
              </div>

            </div>
          );
        })}
      </div>

      {/* Add / Withdraw Funds Modal */}
      {fundingGoal && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          onClick={() => setFundingGoal(null)}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-sm w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[85vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
            onClick={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {isDeposit
                  ? (language === 'bn' ? 'টাকা জমা দিন' : 'Deposit to Goal')
                  : (language === 'bn' ? 'টাকা উত্তোলন করুন' : 'Withdraw from Goal')}
              </h3>
              <button
                onClick={() => setFundingGoal(null)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-500 font-medium">
              {language === 'bn' ? fundingGoal.nameBn : fundingGoal.name} (
              {formatMoney(fundingGoal.currentAmount)} / {formatMoney(fundingGoal.targetAmount)})
            </p>

            <form onSubmit={handleFundingSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'টাকার পরিমাণ' : 'Amount'} ({currency.symbol})
                </label>
                <input
                  type="number"
                  step="any"
                  required
                  min="1"
                  placeholder="0.00"
                  value={fundingAmount}
                  onChange={e => setFundingAmount(e.target.value)}
                  className="w-full px-4 py-3 text-xl font-bold bg-slate-50 border border-slate-200 rounded-xl focus:bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  autoFocus
                />
              </div>

              <div className="flex gap-2">
                {[500, 1000, 2000, 5000].map(val => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setFundingAmount(val.toString())}
                    className="flex-1 py-1 text-xs font-medium bg-slate-100 hover:bg-emerald-50 hover:text-emerald-700 rounded-lg"
                  >
                    +{val}
                  </button>
                ))}
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setFundingGoal(null)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {isDeposit ? (language === 'bn' ? 'জমা নিশ্চিত করুন' : 'Confirm Deposit') : (language === 'bn' ? 'উত্তোলন নিশ্চিত করুন' : 'Confirm Withdraw')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Create New Goal Modal */}
      {isAddModalOpen && (
        <div 
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          onClick={() => setIsAddModalOpen(false)}
        >
          <div 
            className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-5 sm:p-6 space-y-4 shadow-2xl max-h-[88vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
            onClick={e => e.stopPropagation()}
          >
            <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-bold text-base text-slate-800">
                {language === 'bn' ? 'নতুন সঞ্চয় লক্ষ্য তৈরি' : 'Create Savings Goal'}
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateGoal} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'লক্ষ্যের নাম' : 'Goal Name'}
                </label>
                <input
                  type="text"
                  required
                  placeholder={language === 'bn' ? 'যেমন: নতুন ফোন কেনা বা ইমার্জেন্সি ফান্ড' : 'e.g. Dream Laptop, Vacation Trip'}
                  value={name}
                  onChange={e => {
                    setName(e.target.value);
                    if (!nameBn) setNameBn(e.target.value);
                  }}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {t('targetAmount')} ({currency.symbol})
                  </label>
                  <input
                    type="number"
                    step="any"
                    required
                    min="1"
                    placeholder="50000"
                    value={targetAmount}
                    onChange={e => setTargetAmount(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'শুরুর জমা (ঐচ্ছিক)' : 'Already Saved'}
                  </label>
                  <input
                    type="number"
                    step="any"
                    min="0"
                    placeholder="0"
                    value={initialSaved}
                    onChange={e => setInitialSaved(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {t('deadline')}
                  </label>
                  <input
                    type="date"
                    required
                    value={deadline}
                    onChange={e => setDeadline(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-500 mb-1">
                    {language === 'bn' ? 'আইকন' : 'Icon'}
                  </label>
                  <select
                    value={icon}
                    onChange={e => setIcon(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold"
                  >
                    <option value="PiggyBank">Piggy Bank</option>
                    <option value="Laptop">Laptop / Tech</option>
                    <option value="ShieldCheck">Emergency Fund</option>
                    <option value="Compass">Travel / Tour</option>
                    <option value="Home">Home / Flat</option>
                    <option value="Car">Vehicle</option>
                    <option value="Gift">Shopping / Gift</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1">
                  {t('notes')}
                </label>
                <input
                  type="text"
                  placeholder={language === 'bn' ? 'অতিরিক্ত কোনো নোট বা পরিকল্পনা' : 'Why this goal matters...'}
                  value={notes}
                  onChange={e => setNotes(e.target.value)}
                  className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 bg-slate-100 rounded-xl"
                >
                  {t('cancel')}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 rounded-xl shadow-xs"
                >
                  {t('save')}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
};
