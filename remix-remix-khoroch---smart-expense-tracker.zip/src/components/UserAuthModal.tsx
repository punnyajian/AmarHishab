import React, { useState, useEffect } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { PRESET_SECURITY_QUESTIONS, SecurityQuestionItem, SecurityQuestionPrompt } from '../types/auth';
import {
  User,
  Lock,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  LogOut,
  RefreshCw,
  X,
  HelpCircle,
  KeyRound,
  ShieldCheck,
  Cloud,
  CloudOff,
  Copy,
  Check,
  Plus,
  Trash2,
  ArrowLeft,
} from 'lucide-react';

interface UserAuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialMode?: 'login' | 'register' | 'forgot' | 'profile';
}

export const UserAuthModal: React.FC<UserAuthModalProps> = ({
  isOpen,
  onClose,
  initialMode = 'login',
}) => {
  useModalBehavior({ isOpen, onClose });

  const {
    currentUser,
    authSession,
    isAuthLoading,
    isCloudSyncing,
    syncStatus,
    lastSyncedTime,
    registerUser,
    loginUser,
    handleSignOut,
    changePassword,
    checkUsernameAvailable,
    getSecurityQuestionsForRecovery,
    verifySecurityAnswersForRecovery,
    resetPasswordWithToken,
    syncAllToCloudNow,
    language,
    transactions,
    accounts,
  } = useExpense();

  const isBn = language === 'bn';

  // Modal mode: 'login' | 'register' | 'forgot' | 'profile'
  const [mode, setMode] = useState<'login' | 'register' | 'forgot' | 'profile'>('login');

  // Input states
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Username validation state
  const [usernameStatus, setUsernameStatus] = useState<{
    checking: boolean;
    available?: boolean;
    message?: string;
  }>({ checking: false });

  // Security questions for registration
  const [securityQuestions, setSecurityQuestions] = useState<SecurityQuestionItem[]>([
    { id: 'q1', question: PRESET_SECURITY_QUESTIONS[0], answer: '' },
    { id: 'q2', question: PRESET_SECURITY_QUESTIONS[1], answer: '' },
  ]);
  const [customQuestionTexts, setCustomQuestionTexts] = useState<Record<string, string>>({});

  // Forgot password flow states: Step 1 (username), Step 2 (answers), Step 3 (new password)
  const [forgotStep, setForgotStep] = useState<1 | 2 | 3>(1);
  const [recoveryPrompts, setRecoveryPrompts] = useState<SecurityQuestionPrompt[]>([]);
  const [recoveryAnswers, setRecoveryAnswers] = useState<Record<string, string>>({});
  const [resetToken, setResetToken] = useState<string>('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmNewPassword, setConfirmNewPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);

  // Change password in profile
  const [showChangePasswordSection, setShowChangePasswordSection] = useState(false);
  const [currentPasswordInput, setCurrentPasswordInput] = useState('');
  const [changeNewPasswordInput, setChangeNewPasswordInput] = useState('');
  const [changeConfirmPasswordInput, setChangeConfirmPasswordInput] = useState('');
  const [showCurrentPassword, setShowCurrentPassword] = useState(false);

  // Status feedback
  const [actionLoading, setActionLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState(false);

  // Sync mode with prop
  useEffect(() => {
    if (isOpen) {
      if (currentUser) {
        setMode('profile');
      } else {
        setMode(initialMode === 'profile' ? 'login' : initialMode);
      }
      setErrorMessage(null);
      setSuccessMessage(null);
    }
  }, [isOpen, currentUser, initialMode]);

  // Username availability live debounce check
  useEffect(() => {
    if (mode !== 'register' || !username.trim() || username.trim().length < 3) {
      setUsernameStatus({ checking: false });
      return;
    }

    const timer = setTimeout(async () => {
      setUsernameStatus({ checking: true });
      try {
        const res = await checkUsernameAvailable(username.trim());
        setUsernameStatus({
          checking: false,
          available: res.available,
          message: res.available
            ? isBn
              ? 'ইউজারনেম উপলব্ধ আছে'
              : 'Username is available'
            : res.reason || (isBn ? 'ইউজারনেম ইতোমধ্যে ব্যবহৃত' : 'Username is taken'),
        });
      } catch {
        setUsernameStatus({ checking: false });
      }
    }, 400);

    return () => clearTimeout(timer);
  }, [username, mode, isBn, checkUsernameAvailable]);

  if (!isOpen) return null;

  // Handlers
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || !password) {
      setErrorMessage(isBn ? 'ইউজারনেম এবং পাসওয়ার্ড দিন' : 'Please provide username and password');
      return;
    }

    setActionLoading(true);
    setErrorMessage(null);
    try {
      await loginUser(username.trim(), password);
      setSuccessMessage(isBn ? 'সফলভাবে লগইন হয়েছে!' : 'Successfully signed in!');
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'লগইন ব্যর্থ হয়েছে' : 'Login failed'));
    } finally {
      setActionLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = username.trim();
    if (!cleanUser) {
      setErrorMessage(isBn ? 'ইউজারনেম খালি হতে পারে না' : 'Username cannot be empty');
      return;
    }
    if (cleanUser.length < 3) {
      setErrorMessage(isBn ? 'ইউজারনেম কমপক্ষে ৩ অক্ষরের হতে হবে' : 'Username must be at least 3 characters');
      return;
    }
    if (!password) {
      setErrorMessage(isBn ? 'পাসওয়ার্ড দিন' : 'Password cannot be empty');
      return;
    }
    if (password !== confirmPassword) {
      setErrorMessage(isBn ? 'পাসওয়ার্ড দুটি মিলছে না' : 'Passwords do not match');
      return;
    }

    // Validate security questions
    const finalQuestions: SecurityQuestionItem[] = [];
    for (const q of securityQuestions) {
      const qText = q.question === '__CUSTOM__' ? (customQuestionTexts[q.id] || '').trim() : q.question.trim();
      const ansText = q.answer.trim();
      if (!qText || !ansText) {
        setErrorMessage(
          isBn
            ? 'সকল নিরাপত্তা প্রশ্ন ও উত্তর পূরণ করুন (কমপক্ষে ২টি)'
            : 'Please complete all security questions and answers (minimum 2 required)'
        );
        return;
      }
      finalQuestions.push({
        id: q.id,
        question: qText,
        answer: ansText,
      });
    }

    if (finalQuestions.length < 2) {
      setErrorMessage(
        isBn
          ? 'অ্যাকাউন্ট সুরক্ষার জন্য কমপক্ষে ২টি নিরাপত্তা প্রশ্ন আবশ্যক'
          : 'At least 2 security questions are required for account recovery'
      );
      return;
    }

    setActionLoading(true);
    setErrorMessage(null);
    try {
      await registerUser(cleanUser, password, confirmPassword, finalQuestions);
      setSuccessMessage(isBn ? 'অ্যাকাউন্ট সফলভাবে তৈরি হয়েছে!' : 'Account successfully created!');
      setTimeout(() => {
        onClose();
      }, 1200);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'রেজিস্ট্রেশন ব্যর্থ হয়েছে' : 'Registration failed'));
    } finally {
      setActionLoading(false);
    }
  };

  // Forgot Password: Step 1 (Find questions)
  const handleForgotStep1 = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = username.trim();
    if (!cleanUser) {
      setErrorMessage(isBn ? 'আপনার ইউজারনেম লিখুন' : 'Enter your username');
      return;
    }

    setActionLoading(true);
    setErrorMessage(null);
    try {
      const result = await getSecurityQuestionsForRecovery(cleanUser);
      if (!result.exists || result.questions.length === 0) {
        setErrorMessage(
          isBn
            ? 'এই ইউজারনেমের জন্য কোনো রিকভারি প্রশ্ন পাওয়া যায়নি'
            : 'No security recovery questions configured for this account'
        );
        return;
      }
      setRecoveryPrompts(result.questions);
      setRecoveryAnswers({});
      setForgotStep(2);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'ইউজারনেম যাচাই ব্যর্থ হয়েছে' : 'User verification failed'));
    } finally {
      setActionLoading(false);
    }
  };

  // Forgot Password: Step 2 (Verify answers)
  const handleForgotStep2 = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanUser = username.trim();
    const answerPayload = recoveryPrompts.map((p) => ({
      id: p.id,
      question: p.question,
      answer: (recoveryAnswers[p.id] || '').trim(),
    }));

    const allAnswered = answerPayload.every((a) => a.answer.length > 0);
    if (!allAnswered) {
      setErrorMessage(isBn ? 'সকল প্রশ্নের উত্তর লিখুন' : 'Please provide answers for all questions');
      return;
    }

    setActionLoading(true);
    setErrorMessage(null);
    try {
      const resp = await verifySecurityAnswersForRecovery(cleanUser, answerPayload);
      setResetToken(resp.resetToken);
      setForgotStep(3);
    } catch (err: any) {
      setErrorMessage(
        err?.message || (isBn ? 'নিরাপত্তা প্রশ্নের উত্তর ভুল হয়েছে' : 'Security answers did not match')
      );
    } finally {
      setActionLoading(false);
    }
  };

  // Forgot Password: Step 3 (Reset password)
  const handleForgotStep3 = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPassword) {
      setErrorMessage(isBn ? 'নতুন পাসওয়ার্ড লিখুন' : 'Enter new password');
      return;
    }
    if (newPassword !== confirmNewPassword) {
      setErrorMessage(isBn ? 'পাসওয়ার্ড দুটি মেলেনি' : 'Passwords do not match');
      return;
    }

    setActionLoading(true);
    setErrorMessage(null);
    try {
      await resetPasswordWithToken(resetToken, newPassword, confirmNewPassword);
      setSuccessMessage(
        isBn
          ? 'পাসওয়ার্ড সফলভাবে রিসেট করা হয়েছে! নতুন পাসওয়ার্ড দিয়ে লগইন করুন।'
          : 'Password reset successfully! Please sign in with your new password.'
      );
      setTimeout(() => {
        setMode('login');
        setForgotStep(1);
        setPassword('');
        setConfirmPassword('');
        setSuccessMessage(null);
      }, 2000);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'পাসওয়ার্ড রিসেট ব্যর্থ হয়েছে' : 'Password reset failed'));
    } finally {
      setActionLoading(false);
    }
  };

  // Profile: Change Password
  const handleChangePasswordSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentPasswordInput || !changeNewPasswordInput) {
      setErrorMessage(isBn ? 'সব ঘর পূরণ করুন' : 'Fill all fields');
      return;
    }
    if (changeNewPasswordInput !== changeConfirmPasswordInput) {
      setErrorMessage(isBn ? 'নতুন পাসওয়ার্ড দুটি মিলছে না' : 'New passwords do not match');
      return;
    }

    setActionLoading(true);
    setErrorMessage(null);
    try {
      await changePassword(currentPasswordInput, changeNewPasswordInput, changeConfirmPasswordInput);
      setSuccessMessage(isBn ? 'পাসওয়ার্ড সফলভাবে পরিবর্তন হয়েছে!' : 'Password successfully updated!');
      setCurrentPasswordInput('');
      setChangeNewPasswordInput('');
      setChangeConfirmPasswordInput('');
      setShowChangePasswordSection(false);
      setTimeout(() => setSuccessMessage(null), 3000);
    } catch (err: any) {
      setErrorMessage(err?.message || (isBn ? 'পাসওয়ার্ড পরিবর্তন ব্যর্থ' : 'Failed to update password'));
    } finally {
      setActionLoading(false);
    }
  };

  const handleCopyUserId = () => {
    if (currentUser?.id) {
      navigator.clipboard.writeText(currentUser.id);
      setCopiedId(true);
      setTimeout(() => setCopiedId(false), 2000);
    }
  };

  const handleSignOutClick = async () => {
    setActionLoading(true);
    try {
      await handleSignOut();
      onClose();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Sign out failed');
    } finally {
      setActionLoading(false);
    }
  };

  const addSecurityQuestionRow = () => {
    if (securityQuestions.length >= 4) return;
    const nextPreset =
      PRESET_SECURITY_QUESTIONS.find(
        (pq) => !securityQuestions.some((sq) => sq.question === pq)
      ) || PRESET_SECURITY_QUESTIONS[0];
    const newId = 'q_' + Math.random().toString(36).substring(2, 7);
    setSecurityQuestions([...securityQuestions, { id: newId, question: nextPreset, answer: '' }]);
  };

  const removeSecurityQuestionRow = (id: string) => {
    if (securityQuestions.length <= 2) return;
    setSecurityQuestions(securityQuestions.filter((q) => q.id !== id));
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md overflow-y-auto overscroll-contain animate-fade-in"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div
        className="bg-white rounded-2xl max-w-md w-full shadow-2xl border border-emerald-100 overflow-hidden animate-scale-up max-h-[92dvh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-600 px-6 py-4 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-md flex items-center justify-center shadow-inner">
              <ShieldCheck className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="font-bold text-base md:text-lg leading-snug">
                {currentUser
                  ? isBn
                    ? 'আপনার সুরক্ষিত অ্যাকাউন্ট'
                    : 'Account & Cloud Sync'
                  : mode === 'register'
                  ? isBn
                    ? 'নতুন অ্যাকাউন্ট তৈরি করুন'
                    : 'Create AmarHishab Account'
                  : mode === 'forgot'
                  ? isBn
                    ? 'পাসওয়ার্ড রিকভারি'
                    : 'Password Recovery'
                  : isBn
                  ? 'অ্যাকাউন্টে সাইন ইন'
                  : 'Sign In to AmarHishab'}
              </h3>
              <p className="text-xs text-emerald-100">
                {currentUser
                  ? `@${currentUser.username}`
                  : isBn
                  ? 'ইউজারনেম ভিত্তিক ক্রস-ডিভাইস ক্লাউড সিঙ্ক'
                  : 'Username-only cloud sync & data isolation'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Tabs (when not logged in and not in forgot mode) */}
        {!currentUser && mode !== 'forgot' && (
          <div className="grid grid-cols-2 p-1.5 bg-emerald-50/60 border-b border-emerald-100 shrink-0">
            <button
              onClick={() => {
                setMode('login');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                mode === 'login'
                  ? 'bg-white text-emerald-800 shadow-sm border border-emerald-200'
                  : 'text-slate-600 hover:text-emerald-700'
              }`}
            >
              {isBn ? 'লগইন' : 'Sign In'}
            </button>
            <button
              onClick={() => {
                setMode('register');
                setErrorMessage(null);
                setSuccessMessage(null);
              }}
              className={`py-2 text-xs font-semibold rounded-xl transition-all cursor-pointer ${
                mode === 'register'
                  ? 'bg-white text-emerald-800 shadow-sm border border-emerald-200'
                  : 'text-slate-600 hover:text-emerald-700'
              }`}
            >
              {isBn ? 'নতুন অ্যাকাউন্ট' : 'Create Account'}
            </button>
          </div>
        )}

        {/* Body Content */}
        <div className="p-6 overflow-y-auto space-y-4 flex-1">
          {/* Status Banners */}
          {errorMessage && (
            <div className="p-3 bg-rose-50 border border-rose-200 rounded-xl flex items-start gap-2.5 text-xs text-rose-700 animate-shake">
              <AlertCircle className="w-4 h-4 text-rose-500 shrink-0 mt-0.5" />
              <span className="flex-1">{errorMessage}</span>
            </div>
          )}

          {successMessage && (
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl flex items-start gap-2.5 text-xs text-emerald-700 animate-fade-in">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="flex-1">{successMessage}</span>
            </div>
          )}

          {/* VIEW: LOGGED IN USER PROFILE & SYNC */}
          {currentUser ? (
            <div className="space-y-4">
              {/* User Card */}
              <div className="p-4 bg-emerald-50/50 rounded-2xl border border-emerald-200/80 flex items-center justify-between">
                <div className="flex items-center gap-3 min-w-0">
                  <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white font-bold flex items-center justify-center text-lg shadow-sm shrink-0">
                    {currentUser.username ? currentUser.username[0].toUpperCase() : 'U'}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-slate-800 text-sm truncate">
                        @{currentUser.username}
                      </h4>
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-200 text-emerald-800">
                        {isBn ? 'সক্রিয়' : 'Online'}
                      </span>
                    </div>
                    <div className="flex items-center gap-1.5 mt-0.5 text-xs text-slate-500">
                      <span className="font-mono text-[11px] truncate max-w-[130px]">
                        ID: {currentUser.id.substring(0, 10)}...
                      </span>
                      <button
                        onClick={handleCopyUserId}
                        className="p-1 hover:text-emerald-700 text-slate-400 transition-colors cursor-pointer"
                        title={isBn ? 'ইউজার আইডি কপি করুন' : 'Copy User ID'}
                      >
                        {copiedId ? (
                          <Check className="w-3.5 h-3.5 text-emerald-600" />
                        ) : (
                          <Copy className="w-3.5 h-3.5" />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
              </div>

              {/* Cloud Sync Status Pill & Overview */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2.5 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-medium text-slate-600 flex items-center gap-1.5">
                    {syncStatus === 'offline' ? (
                      <CloudOff className="w-4 h-4 text-amber-500" />
                    ) : (
                      <Cloud className="w-4 h-4 text-emerald-600" />
                    )}
                    {isBn ? 'ক্লাউড সিঙ্ক স্ট্যাটাস' : 'Cloud Sync Status'}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span
                      className={`w-2 h-2 rounded-full ${
                        syncStatus === 'syncing'
                          ? 'bg-amber-500 animate-ping'
                          : syncStatus === 'offline'
                          ? 'bg-amber-400'
                          : syncStatus === 'error'
                          ? 'bg-rose-500'
                          : 'bg-emerald-500'
                      }`}
                    />
                    <span
                      className={`font-semibold capitalize text-xs ${
                        syncStatus === 'syncing'
                          ? 'text-amber-700'
                          : syncStatus === 'offline'
                          ? 'text-amber-600'
                          : syncStatus === 'error'
                          ? 'text-rose-600'
                          : 'text-emerald-700'
                      }`}
                    >
                      {syncStatus === 'syncing'
                        ? isBn
                          ? 'সিঙ্ক হচ্ছে...'
                          : 'Syncing...'
                        : syncStatus === 'offline'
                        ? isBn
                          ? 'অফলাইন'
                          : 'Offline'
                        : syncStatus === 'error'
                        ? isBn
                          ? 'ত্রুটি'
                          : 'Error'
                        : isBn
                        ? 'সিঙ্ক সম্পন্ন'
                        : 'Synced'}
                    </span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-slate-500 pt-1 border-t border-slate-200/60">
                  <span>{isBn ? 'সর্বশেষ ক্লাউড আপডেট' : 'Last Synced'}:</span>
                  <span className="font-mono text-slate-700">
                    {lastSyncedTime
                      ? lastSyncedTime.toLocaleTimeString([], {
                          hour: '2-digit',
                          minute: '2-digit',
                          second: '2-digit',
                        })
                      : isBn
                      ? 'এখনই'
                      : 'Just now'}
                  </span>
                </div>

                <div className="flex items-center justify-between text-slate-500">
                  <span>{isBn ? 'সংরক্ষিত লেনদেন' : 'Synced Records'}:</span>
                  <span className="font-semibold text-slate-700">
                    {transactions.length} {isBn ? 'লেনদেন' : 'tx'} / {accounts.length}{' '}
                    {isBn ? 'ওয়ালেট' : 'wallets'}
                  </span>
                </div>
              </div>

              {/* Sync Actions */}
              <div className="flex gap-2">
                <button
                  onClick={() => syncAllToCloudNow()}
                  disabled={isCloudSyncing || actionLoading}
                  className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs flex items-center justify-center gap-2 shadow-sm transition-all disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isCloudSyncing ? 'animate-spin' : ''}`} />
                  {isBn ? 'এখনই ক্লাউডে সেভ করুন' : 'Sync to Cloud Now'}
                </button>
              </div>

              {/* Change Password Collapsible */}
              <div className="pt-2 border-t border-slate-100">
                <button
                  onClick={() => setShowChangePasswordSection(!showChangePasswordSection)}
                  className="w-full py-2 px-3 text-xs font-semibold text-slate-700 hover:text-emerald-700 bg-slate-50 hover:bg-emerald-50 rounded-xl border border-slate-200 flex items-center justify-between transition-colors cursor-pointer"
                >
                  <span className="flex items-center gap-2">
                    <KeyRound className="w-3.5 h-3.5 text-emerald-600" />
                    {isBn ? 'পাসওয়ার্ড পরিবর্তন করুন' : 'Change Password'}
                  </span>
                  <span className="text-[11px] text-slate-400">
                    {showChangePasswordSection ? '▲' : '▼'}
                  </span>
                </button>

                {showChangePasswordSection && (
                  <form onSubmit={handleChangePasswordSubmit} className="mt-3 p-3.5 bg-slate-50/70 border border-slate-200 rounded-xl space-y-3">
                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">
                        {isBn ? 'বর্তমান পাসওয়ার্ড' : 'Current Password'}
                      </label>
                      <div className="relative">
                        <input
                          type={showCurrentPassword ? 'text' : 'password'}
                          value={currentPasswordInput}
                          onChange={(e) => setCurrentPasswordInput(e.target.value)}
                          placeholder="••••••••"
                          className="w-full py-1.5 pl-3 pr-9 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                        />
                        <button
                          type="button"
                          onClick={() => setShowCurrentPassword(!showCurrentPassword)}
                          className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                        >
                          {showCurrentPassword ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                        </button>
                      </div>
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">
                        {isBn ? 'নতুন পাসওয়ার্ড' : 'New Password'}
                      </label>
                      <input
                        type="password"
                        value={changeNewPasswordInput}
                        onChange={(e) => setChangeNewPasswordInput(e.target.value)}
                        placeholder="••••••••"
                        className="w-full py-1.5 px-3 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                      />
                    </div>

                    <div>
                      <label className="block text-[11px] font-medium text-slate-600 mb-1">
                        {isBn ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm New Password'}
                      </label>
                      <input
                        type="password"
                        value={changeConfirmPasswordInput}
                        onChange={(e) => setChangeConfirmPasswordInput(e.target.value)}
                        placeholder="••••••••"
                        className="w-full py-1.5 px-3 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                      />
                    </div>

                    <button
                      type="submit"
                      disabled={actionLoading}
                      className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-semibold shadow-sm transition-all disabled:opacity-50 cursor-pointer"
                    >
                      {actionLoading ? (isBn ? 'সংরক্ষণ হচ্ছে...' : 'Updating...') : (isBn ? 'পাসওয়ার্ড আপডেট করুন' : 'Update Password')}
                    </button>
                  </form>
                )}
              </div>

              {/* Sign Out Button */}
              <div className="pt-2">
                <button
                  onClick={handleSignOutClick}
                  disabled={actionLoading}
                  className="w-full py-2.5 px-4 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-semibold text-xs border border-rose-200 flex items-center justify-center gap-2 transition-colors cursor-pointer"
                >
                  <LogOut className="w-3.5 h-3.5" />
                  {isBn ? 'নিরাপদে লগআউট করুন' : 'Log Out & Clear Local Session'}
                </button>
                <p className="text-[10px] text-center text-slate-400 mt-1.5">
                  {isBn
                    ? 'লগআউট করলে ডিভাইসের স্থানীয় ক্যাশ সাফ হবে কিন্তু ক্লাউডে সব তথ্য সংরক্ষিত থাকবে।'
                    : 'Logging out purges device cache for user isolation. Data remains safe in the cloud.'}
                </p>
              </div>
            </div>
          ) : mode === 'forgot' ? (
            /* VIEW: FORGOT PASSWORD RECOVERY */
            <div className="space-y-4">
              <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setForgotStep(1);
                    setErrorMessage(null);
                  }}
                  className="flex items-center gap-1 text-xs font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer"
                >
                  <ArrowLeft className="w-3.5 h-3.5" />
                  {isBn ? 'লগইন পেজে ফিরুন' : 'Back to Login'}
                </button>
                <span className="text-[11px] font-semibold text-slate-500">
                  {isBn ? `ধাপ ${forgotStep} / ৩` : `Step ${forgotStep} of 3`}
                </span>
              </div>

              {forgotStep === 1 && (
                <form onSubmit={handleForgotStep1} className="space-y-3.5">
                  <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs text-emerald-800">
                    <p className="font-medium">
                      {isBn
                        ? 'অ্যাকাউন্ট রিকভার করতে আপনার ইউজারনেম দিন।'
                        : 'Enter your registered username to verify your security questions.'}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isBn ? 'ইউজারনেম' : 'Username'}
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        placeholder="e.g. rahim123"
                        autoFocus
                        className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    disabled={actionLoading || !username.trim()}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-sm transition-all disabled:opacity-50 cursor-pointer"
                  >
                    {actionLoading ? (isBn ? 'যাচাই হচ্ছে...' : 'Verifying...') : (isBn ? 'নিরাপত্তা প্রশ্ন দেখুন' : 'Find My Security Questions')}
                  </button>
                </form>
              )}

              {forgotStep === 2 && (
                <form onSubmit={handleForgotStep2} className="space-y-3.5">
                  <div className="p-3 bg-amber-50/70 border border-amber-200 rounded-xl text-xs text-amber-800">
                    <p className="font-semibold">
                      {isBn
                        ? 'নিরাপত্তা প্রশ্নের সঠিক উত্তর দিন'
                        : 'Answer your configured security questions'}
                    </p>
                    <p className="text-[11px] text-amber-700 mt-0.5">
                      {isBn
                        ? 'উত্তর বড় বা ছোট হাতের অক্ষরে সংবেদনশীল নয়।'
                        : 'Answers are case-insensitive and normalized.'}
                    </p>
                  </div>

                  <div className="space-y-3">
                    {recoveryPrompts.map((q, idx) => (
                      <div key={q.id} className="p-3 bg-slate-50 border border-slate-200 rounded-xl space-y-1.5">
                        <label className="block text-xs font-semibold text-slate-700">
                          {idx + 1}. {q.question}
                        </label>
                        <input
                          type="text"
                          value={recoveryAnswers[q.id] || ''}
                          onChange={(e) =>
                            setRecoveryAnswers({
                              ...recoveryAnswers,
                              [q.id]: e.target.value,
                            })
                          }
                          placeholder={isBn ? 'আপনার উত্তর লিখুন' : 'Enter your answer'}
                          className="w-full px-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                        />
                      </div>
                    ))}
                  </div>

                  <button
                    type="submit"
                    disabled={actionLoading}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-sm transition-all disabled:opacity-50 cursor-pointer"
                  >
                    {actionLoading ? (isBn ? 'উত্তর যাচাই হচ্ছে...' : 'Verifying Answers...') : (isBn ? 'উত্তর নিশ্চিত করুন' : 'Verify Answers & Continue')}
                  </button>
                </form>
              )}

              {forgotStep === 3 && (
                <form onSubmit={handleForgotStep3} className="space-y-3.5">
                  <div className="p-3 bg-emerald-50/70 border border-emerald-200 rounded-xl text-xs text-emerald-800">
                    <p className="font-semibold">
                      {isBn ? 'নিরাপত্তা যাচাই সফল হয়েছে!' : 'Verification successful!'}
                    </p>
                    <p className="text-[11px] text-emerald-700 mt-0.5">
                      {isBn
                        ? 'আপনার অ্যাকাউন্টের জন্য নতুন একটি পাসওয়ার্ড নির্ধারণ করুন।'
                        : 'Choose a new password for your account.'}
                    </p>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isBn ? 'নতুন পাসওয়ার্ড' : 'New Password'}
                    </label>
                    <div className="relative">
                      <input
                        type={showNewPassword ? 'text' : 'password'}
                        value={newPassword}
                        onChange={(e) => setNewPassword(e.target.value)}
                        placeholder="e.g. 1234 or mypass"
                        className="w-full pl-3 pr-9 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                      />
                      <button
                        type="button"
                        onClick={() => setShowNewPassword(!showNewPassword)}
                        className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                      >
                        {showNewPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-700 mb-1">
                      {isBn ? 'নতুন পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm New Password'}
                    </label>
                    <input
                      type="password"
                      value={confirmNewPassword}
                      onChange={(e) => setConfirmNewPassword(e.target.value)}
                      placeholder="e.g. 1234 or mypass"
                      className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                    />
                  </div>

                  <button
                    type="submit"
                    disabled={actionLoading}
                    className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-sm transition-all disabled:opacity-50 cursor-pointer"
                  >
                    {actionLoading ? (isBn ? 'রিসেট হচ্ছে...' : 'Resetting...') : (isBn ? 'পাসওয়ার্ড রিসেট করুন' : 'Reset Password & Finish')}
                  </button>
                </form>
              )}
            </div>
          ) : mode === 'register' ? (
            /* VIEW: CREATE ACCOUNT / REGISTER */
            <form onSubmit={handleRegisterSubmit} className="space-y-4">
              {/* Username Input with live availability */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700">
                    {isBn ? 'ইউজারনেম' : 'Username'}
                  </label>
                  {usernameStatus.checking ? (
                    <span className="text-[10px] text-slate-400 flex items-center gap-1">
                      <RefreshCw className="w-3 h-3 animate-spin" />
                      {isBn ? 'যাচাই হচ্ছে...' : 'Checking...'}
                    </span>
                  ) : usernameStatus.message ? (
                    <span
                      className={`text-[10px] font-medium flex items-center gap-1 ${
                        usernameStatus.available ? 'text-emerald-600' : 'text-rose-600'
                      }`}
                    >
                      {usernameStatus.available ? (
                        <CheckCircle2 className="w-3 h-3" />
                      ) : (
                        <AlertCircle className="w-3 h-3" />
                      )}
                      {usernameStatus.message}
                    </span>
                  ) : null}
                </div>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. karim99"
                    autoComplete="username"
                    maxLength={32}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                  />
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  {isBn
                    ? 'ছোট/বড় হাতের অক্ষর ও সংখ্যা ব্যবহার করা যাবে। ইমেইলের প্রয়োজন নেই।'
                    : 'Letters and numbers allowed. No email or phone needed.'}
                </p>
              </div>

              {/* Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {isBn ? 'পাসওয়ার্ড' : 'Password'}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="e.g. 1234 or hello"
                    maxLength={128}
                    className="w-full pl-9 pr-9 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                <p className="text-[10px] text-slate-400 mt-1">
                  {isBn
                    ? 'যে কোনো টেক্সট গ্রহণযোগ্য (যেমন 1234, hello বা নিজের ইচ্ছা মতো)।'
                    : 'Any text accepted (e.g. 1234, hello, or complex phrases).'}
                </p>
              </div>

              {/* Confirm Password */}
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {isBn ? 'পাসওয়ার্ড নিশ্চিত করুন' : 'Confirm Password'}
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showConfirmPassword ? 'text' : 'password'}
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    placeholder="e.g. 1234 or hello"
                    maxLength={128}
                    className="w-full pl-9 pr-9 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showConfirmPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-[10px] text-rose-500 mt-1">
                    {isBn ? 'পাসওয়ার্ড মেলেনি' : 'Passwords do not match'}
                  </p>
                )}
              </div>

              {/* Security Questions Setup (Requirement 6) */}
              <div className="pt-2 border-t border-slate-100 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h5 className="text-xs font-bold text-slate-800 flex items-center gap-1.5">
                      <HelpCircle className="w-3.5 h-3.5 text-emerald-600" />
                      {isBn ? 'অ্যাকাউন্ট রিকভারি প্রশ্ন' : 'Account Recovery Questions'}
                    </h5>
                    <p className="text-[10px] text-slate-500">
                      {isBn
                        ? 'পাসওয়ার্ড ভুলে গেলে এই প্রশ্নগুলোর উত্তর দিয়ে রিকভার করতে পারবেন।'
                        : 'Used to recover your account if you forget your password.'}
                    </p>
                  </div>
                  {securityQuestions.length < 4 && (
                    <button
                      type="button"
                      onClick={addSecurityQuestionRow}
                      className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
                    >
                      <Plus className="w-3 h-3" />
                      {isBn ? 'প্রশ্ন যোগ' : 'Add Question'}
                    </button>
                  )}
                </div>

                <div className="space-y-3 pt-1">
                  {securityQuestions.map((sq, index) => (
                    <div
                      key={sq.id}
                      className="p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-2 relative"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[11px] font-bold text-slate-700">
                          {isBn ? `প্রশ্ন ${index + 1}` : `Question ${index + 1}`}
                        </span>
                        {securityQuestions.length > 2 && (
                          <button
                            type="button"
                            onClick={() => removeSecurityQuestionRow(sq.id)}
                            className="text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {/* Question selector */}
                      <select
                        value={sq.question}
                        onChange={(e) => {
                          const val = e.target.value;
                          setSecurityQuestions(
                            securityQuestions.map((q) =>
                              q.id === sq.id ? { ...q, question: val } : q
                            )
                          );
                        }}
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
                      >
                        {PRESET_SECURITY_QUESTIONS.map((pq) => (
                          <option key={pq} value={pq}>
                            {pq}
                          </option>
                        ))}
                        <option value="__CUSTOM__">
                          {isBn ? '✍️ কাস্টম প্রশ্ন লিখুন...' : '✍️ Write custom question...'}
                        </option>
                      </select>

                      {/* Custom question text if selected */}
                      {sq.question === '__CUSTOM__' && (
                        <input
                          type="text"
                          value={customQuestionTexts[sq.id] || ''}
                          onChange={(e) =>
                            setCustomQuestionTexts({
                              ...customQuestionTexts,
                              [sq.id]: e.target.value,
                            })
                          }
                          placeholder={isBn ? 'আপনার নিজস্ব প্রশ্নটি লিখুন...' : 'Type your custom question...'}
                          className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-emerald-300 bg-white focus:outline-none focus:border-emerald-500"
                        />
                      )}

                      {/* Answer input */}
                      <input
                        type="text"
                        value={sq.answer}
                        onChange={(e) => {
                          const val = e.target.value;
                          setSecurityQuestions(
                            securityQuestions.map((q) =>
                              q.id === sq.id ? { ...q, answer: val } : q
                            )
                          );
                        }}
                        placeholder={isBn ? 'প্রশ্নের উত্তর লিখুন' : 'Enter your answer'}
                        className="w-full px-2.5 py-1.5 text-xs rounded-lg border border-slate-300 bg-white focus:outline-none focus:border-emerald-500"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={actionLoading || isAuthLoading}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-md shadow-emerald-600/20 transition-all disabled:opacity-50 cursor-pointer"
              >
                {actionLoading ? (isBn ? 'অ্যাকাউন্ট তৈরি হচ্ছে...' : 'Creating Account...') : (isBn ? 'অ্যাকাউন্ট তৈরি করুন' : 'Create Account')}
              </button>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setMode('login');
                    setErrorMessage(null);
                  }}
                  className="text-xs text-slate-500 hover:text-emerald-700 cursor-pointer"
                >
                  {isBn ? 'ইতোমধ্যে অ্যাকাউন্ট আছে? সাইন ইন করুন' : 'Already have an account? Sign In'}
                </button>
              </div>
            </form>
          ) : (
            /* VIEW: LOGIN */
            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  {isBn ? 'ইউজারনেম' : 'Username'}
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="e.g. rahim123"
                    autoComplete="username"
                    autoFocus
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                  />
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-semibold text-slate-700">
                    {isBn ? 'পাসওয়ার্ড' : 'Password'}
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('forgot');
                      setForgotStep(1);
                      setErrorMessage(null);
                      setSuccessMessage(null);
                    }}
                    className="text-[11px] font-semibold text-emerald-700 hover:text-emerald-800 cursor-pointer"
                  >
                    {isBn ? 'পাসওয়ার্ড ভুলে গেছেন?' : 'Forgot Password?'}
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    autoComplete="current-password"
                    className="w-full pl-9 pr-9 py-2 text-xs rounded-xl border border-slate-300 focus:outline-none focus:border-emerald-500 bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              <button
                type="submit"
                disabled={actionLoading || isAuthLoading}
                className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-semibold text-xs shadow-md shadow-emerald-600/20 transition-all disabled:opacity-50 cursor-pointer"
              >
                {actionLoading ? (isBn ? 'লগইন হচ্ছে...' : 'Signing in...') : (isBn ? 'লগইন করুন' : 'Sign In')}
              </button>

              <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100 text-xs text-slate-600 space-y-1">
                <p className="font-semibold text-emerald-800 flex items-center gap-1.5">
                  <Cloud className="w-3.5 h-3.5 text-emerald-600" />
                  {isBn ? 'ক্লাউড সিঙ্ক ফিচার' : 'Instant Multi-Device Sync'}
                </p>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  {isBn
                    ? 'লগইন করলেই আপনার সব লেনদেন ক্লাউডে সেভ হবে এবং যেকোনো ডিভাইস থেকে অ্যাক্সেস করা যাবে।'
                    : 'Sign in from any laptop or mobile browser using your username and password to seamlessly access all your accounts and expense records.'}
                </p>
              </div>

              <div className="text-center pt-1">
                <button
                  type="button"
                  onClick={() => {
                    setMode('register');
                    setErrorMessage(null);
                  }}
                  className="text-xs text-slate-500 hover:text-emerald-700 cursor-pointer"
                >
                  {isBn ? 'নতুন ব্যবহারকারী? অ্যাকাউন্ট তৈরি করুন' : 'New here? Create an account'}
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
