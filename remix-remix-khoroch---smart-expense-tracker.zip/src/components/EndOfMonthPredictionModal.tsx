import React, { useState, useMemo } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import {
  Sparkles,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  X,
  Target,
  Calendar,
  Layers,
  Sliders,
  DollarSign,
  HelpCircle,
  ShieldCheck,
  Receipt,
  Lightbulb,
  Zap,
} from 'lucide-react';

interface EndOfMonthPredictionModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const EndOfMonthPredictionModal: React.FC<EndOfMonthPredictionModalProps> = ({
  isOpen,
  onClose,
}) => {
  useModalBehavior({ isOpen, onClose });

  const {
    transactions,
    categories,
    budgets,
    subscriptions,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    formatMoney,
    language,
    currency,
  } = useExpense();

  // "What-if" scenario adjustment slider (-50% to +50%)
  const [spendingAdjustmentPercent, setSpendingAdjustmentPercent] = useState<number>(0);

  // Time calculations
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthIdx = now.getMonth();
  const currentDayOfMonth = now.getDate();
  const totalDaysInMonth = new Date(currentYear, currentMonthIdx + 1, 0).getDate();
  const daysElapsed = Math.max(1, currentDayOfMonth);
  const daysRemaining = Math.max(0, totalDaysInMonth - currentDayOfMonth);

  // Calculate upcoming unpaid subscription bills due in the remainder of this month
  const currentMonthPrefix = `${currentYear}-${String(currentMonthIdx + 1).padStart(2, '0')}`;
  
  const upcomingBillsTotal = useMemo(() => {
    return subscriptions
      .filter(s => s.status === 'active' && s.dueDate)
      .filter(s => {
        // Due between tomorrow and end of month
        const due = new Date(s.dueDate);
        return due.getFullYear() === currentYear && due.getMonth() === currentMonthIdx && due.getDate() > currentDayOfMonth;
      })
      .reduce((sum, s) => sum + s.amount, 0);
  }, [subscriptions, currentYear, currentMonthIdx, currentDayOfMonth]);

  // Total monthly budget limit across all categories
  const totalBudgetLimit = useMemo(() => {
    const fromBudgets = budgets.reduce((sum, b) => sum + b.monthlyLimit, 0);
    if (fromBudgets > 0) return fromBudgets;
    const catLimits = categories.reduce((sum, c) => sum + (c.budgetLimit || 0), 0);
    return catLimits > 0 ? catLimits : 0;
  }, [budgets, categories]);

  // Current spending velocity (Daily Burn Rate so far)
  const currentDailyBurnRate = Math.round(totalExpenseThisMonth / daysElapsed);

  // Projection model:
  // Base projected remaining = currentDailyBurnRate * daysRemaining
  // Add upcoming known fixed bills
  const baseRemainingProjected = currentDailyBurnRate * daysRemaining;
  const adjustedRemainingProjected = Math.round(baseRemainingProjected * (1 + spendingAdjustmentPercent / 100));

  const projectedTotalExpense = Math.round(totalExpenseThisMonth + adjustedRemainingProjected + (spendingAdjustmentPercent === 0 ? upcomingBillsTotal * 0.5 : 0));
  
  const projectedNetSavings = totalIncomeThisMonth - projectedTotalExpense;
  const projectedSavingsRate = totalIncomeThisMonth > 0 ? Math.round((projectedNetSavings / totalIncomeThisMonth) * 100) : 0;
  const projectedVarianceVsBudget = totalBudgetLimit - projectedTotalExpense; // positive = under budget, negative = over budget

  // Target daily spending to strictly stay within budget
  const remainingBudgetAmount = Math.max(0, totalBudgetLimit - totalExpenseThisMonth);
  const targetSafeDailyBurn = daysRemaining > 0 ? Math.round(remainingBudgetAmount / daysRemaining) : 0;

  // Category breakdown projection
  const categoryProjections = useMemo(() => {
    const currentMonthTxs = transactions.filter(t => t.date.startsWith(currentMonthPrefix) && t.type === 'expense');
    
    return categories
      .map(cat => {
        const spent = currentMonthTxs.filter(t => t.categoryId === cat.id).reduce((s, t) => s + t.amount, 0);
        const dailyCatBurn = spent / daysElapsed;
        const projected = Math.round(spent + dailyCatBurn * daysRemaining);
        const limit = budgets.find(b => b.categoryId === cat.id)?.monthlyLimit || cat.budgetLimit || 0;
        const percentOfBudget = limit > 0 ? Math.round((projected / limit) * 100) : null;

        return {
          cat,
          spent,
          projected,
          limit,
          percentOfBudget,
          isOver: limit > 0 && projected > limit,
        };
      })
      .filter(item => item.spent > 0 || item.limit > 0)
      .sort((a, b) => b.projected - a.projected);
  }, [transactions, currentMonthPrefix, categories, daysElapsed, daysRemaining, budgets]);

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-md animate-in fade-in overflow-y-auto overscroll-contain"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-7 space-y-6 shadow-2xl border border-slate-200 animate-in zoom-in-95 my-8 max-h-[90dvh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
        onMouseDown={(e) => e.stopPropagation()}
      >
        
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white flex items-center justify-center font-black shadow-md shadow-indigo-500/20">
              <span className="text-2xl animate-pulse">🔮</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-black text-slate-900 tracking-tight">
                  {language === 'bn' ? 'মাস শেষের ব্যয় পূর্বাভাস (End-of-Month Prediction)' : 'End-of-Month Expense Forecast'}
                </h3>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-700 border border-indigo-200">
                  AI & Pattern Engine
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-0.5">
                {language === 'bn'
                  ? `মাসের ${daysElapsed} দিন অতিবাহিত হয়েছে, বাকি ${daysRemaining} দিনের খরচের গতিপ্রকৃতি বিশ্লেষণ`
                  : `Day ${daysElapsed} of ${totalDaysInMonth} elapsed. Forecasting remaining ${daysRemaining} days.`}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Prediction Hero Result Card */}
        <div className={`p-5 sm:p-6 rounded-3xl border shadow-sm space-y-4 relative overflow-hidden ${
          projectedVarianceVsBudget >= 0
            ? 'bg-gradient-to-br from-slate-950 via-teal-950 to-emerald-950 text-white border-emerald-700/60'
            : 'bg-gradient-to-br from-slate-950 via-rose-950 to-slate-900 text-white border-rose-700/60'
        }`}>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="space-y-1">
              <span className="text-xs font-bold text-slate-300 uppercase tracking-wider block">
                {language === 'bn' ? 'মাস শেষে সম্ভাব্য মোট ব্যয়' : 'Projected Total Month-End Expense'}
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl sm:text-4xl font-black tracking-tight text-white">
                  {formatMoney(projectedTotalExpense)}
                </span>
                <span className="text-xs text-slate-300">
                  / {formatMoney(totalBudgetLimit)} {language === 'bn' ? 'বাজেট' : 'budget'}
                </span>
              </div>
            </div>

            {totalBudgetLimit > 0 ? (
              <div className={`px-3.5 py-1.5 rounded-2xl text-xs font-black inline-flex items-center gap-1.5 self-start sm:self-auto shadow-xs ${
                projectedVarianceVsBudget >= 0
                  ? 'bg-emerald-500 text-slate-950'
                  : 'bg-rose-500 text-white'
              }`}>
                {projectedVarianceVsBudget >= 0 ? (
                  <>
                    <CheckCircle2 className="w-4 h-4" />
                    <span>
                      {language === 'bn'
                        ? `বাজেটের ভেতরে! ~${formatMoney(projectedVarianceVsBudget)} সাশ্রয় হবে`
                        : `Within Budget! Save ~${formatMoney(projectedVarianceVsBudget)}`}
                    </span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-4 h-4" />
                    <span>
                      {language === 'bn'
                        ? `বাজেট ছাড়িয়ে ${formatMoney(Math.abs(projectedVarianceVsBudget))} বাড়তি খরচের ঝুঁকি!`
                        : `Projected Over Budget by ${formatMoney(Math.abs(projectedVarianceVsBudget))}!`}
                    </span>
                  </>
                )}
              </div>
            ) : (
              <div className="px-3.5 py-1.5 rounded-2xl text-xs font-bold bg-white/10 text-white border border-white/20 self-start sm:self-auto">
                {language === 'bn' ? 'বাজেট সীমা সেট করা নেই' : 'No Budget Cap Set'}
              </div>
            )}
          </div>

          {/* Three Key Indicators */}
          <div className="grid grid-cols-3 gap-2 pt-3 border-t border-white/10 text-xs">
            <div>
              <span className="text-[10px] text-slate-400 block">
                {language === 'bn' ? 'দৈনিক খরচের গড় গতি' : 'Current Daily Burn'}
              </span>
              <span className="font-bold text-white text-sm">
                {formatMoney(currentDailyBurnRate)}<span className="text-[10px] font-normal text-slate-300">/দিন</span>
              </span>
            </div>

            <div>
              <span className="text-[10px] text-slate-400 block">
                {language === 'bn' ? 'বাজেটে থাকার নিরাপদ সীমা' : 'Target Safe Burn'}
              </span>
              <span className="font-bold text-amber-300 text-sm">
                {formatMoney(targetSafeDailyBurn)}<span className="text-[10px] font-normal text-slate-300">/দিন</span>
              </span>
            </div>

            <div className="text-right">
              <span className="text-[10px] text-slate-400 block">
                {language === 'bn' ? 'সম্ভাব্য নিট সঞ্চয়' : 'Projected Savings'}
              </span>
              <span className={`font-bold text-sm ${projectedNetSavings >= 0 ? 'text-emerald-300' : 'text-rose-400'}`}>
                {formatMoney(projectedNetSavings)}
              </span>
            </div>
          </div>
        </div>

        {/* "What-If" Scenario Simulator */}
        <div className="bg-slate-50 border border-slate-200/80 rounded-3xl p-5 space-y-3.5">
          <div className="flex items-center justify-between">
            <h4 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
              <Sliders className="w-4 h-4 text-indigo-600" />
              <span>{language === 'bn' ? 'খরচের অভ্যাস পরিবর্তন সিমুলেটর ("What-If" Simulator)' : 'Scenario Simulator ("What-If")'}</span>
            </h4>
            <span className={`text-xs font-bold px-2 py-0.5 rounded-full ${
              spendingAdjustmentPercent < 0
                ? 'bg-emerald-100 text-emerald-800'
                : spendingAdjustmentPercent > 0
                ? 'bg-rose-100 text-rose-800'
                : 'bg-slate-200 text-slate-700'
            }`}>
              {spendingAdjustmentPercent > 0 ? `+${spendingAdjustmentPercent}%` : `${spendingAdjustmentPercent}%`} {language === 'bn' ? 'খরচ পরিবর্তন' : 'Spending Shift'}
            </span>
          </div>

          <p className="text-xs text-slate-500 leading-relaxed">
            {language === 'bn'
              ? 'বাকি দিনগুলোতে যদি আপনি খরচের গতি কিছুটা কমান বা বাড়ান, মাস শেষে আপনার মোট ব্যয় ও সঞ্চয়ে কী প্রভাব পড়বে তা স্লাইডার টেনে দেখুন:'
              : 'Slide to simulate how cutting or increasing your daily discretionary spend for the rest of the month impacts your bottom line.'}
          </p>

          <div className="space-y-1">
            <div className="flex justify-between text-[11px] font-semibold text-slate-400">
              <span className="text-emerald-600">-৩০% খরচ কমানো (সংযম)</span>
              <span>বর্তমান গতি (০%)</span>
              <span className="text-rose-600">+৩০% খরচ বৃদ্ধি (অতিরিক্ত)</span>
            </div>
            <input
              type="range"
              min="-30"
              max="30"
              step="5"
              value={spendingAdjustmentPercent}
              onChange={e => setSpendingAdjustmentPercent(Number(e.target.value))}
              className="w-full accent-indigo-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
            />
          </div>

          {spendingAdjustmentPercent !== 0 && (
            <div className="p-3 rounded-2xl bg-white border border-slate-200/80 text-xs text-slate-700 flex items-center justify-between">
              <span>
                {spendingAdjustmentPercent < 0 ? (
                  <strong className="text-emerald-700">
                    {language === 'bn'
                      ? `খরচ ${Math.abs(spendingAdjustmentPercent)}% কমালে মাস শেষে অতিরিক্ত ${formatMoney(Math.abs(adjustedRemainingProjected - baseRemainingProjected))} সাশ্রয় হবে!`
                      : `Cutting spend by ${Math.abs(spendingAdjustmentPercent)}% will save you an extra ${formatMoney(Math.abs(adjustedRemainingProjected - baseRemainingProjected))}!`}
                  </strong>
                ) : (
                  <strong className="text-rose-700">
                    {language === 'bn'
                      ? `খরচ ${spendingAdjustmentPercent}% বাড়লে মাস শেষে অতিরিক্ত ${formatMoney(adjustedRemainingProjected - baseRemainingProjected)} ব্যয় বেড়ে যাবে!`
                      : `Increasing spend by ${spendingAdjustmentPercent}% will add ${formatMoney(adjustedRemainingProjected - baseRemainingProjected)} to your costs!`}
                  </strong>
                )}
              </span>
              <button
                type="button"
                onClick={() => setSpendingAdjustmentPercent(0)}
                className="text-[11px] text-indigo-600 hover:underline font-bold shrink-0 ml-2"
              >
                {language === 'bn' ? 'রিসেট' : 'Reset'}
              </button>
            </div>
          )}
        </div>

        {/* Category Velocity Watch */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs sm:text-sm font-bold text-slate-900 flex items-center gap-2">
              <Layers className="w-4 h-4 text-emerald-600" />
              <span>{language === 'bn' ? 'খাতভিত্তিক ব্যয়ের পূর্বাভাস (Category Velocity)' : 'Category Forecast Breakdown'}</span>
            </h4>
            <span className="text-[11px] text-slate-400">
              {language === 'bn' ? 'বর্তমান গতির ভিত্তিতে' : 'Paced from current trends'}
            </span>
          </div>

          <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
            {categoryProjections.slice(0, 5).map(({ cat, spent, projected, limit, isOver }) => (
              <div
                key={cat.id}
                className="p-3 rounded-2xl bg-white border border-slate-100 shadow-2xs space-y-1.5 text-xs"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 min-w-0">
                    <span
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: cat.color }}
                    />
                    <span className="font-bold text-slate-800 truncate">
                      {language === 'bn' ? cat.nameBn : cat.name}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-slate-500">
                      {formatMoney(spent)} → <strong className={isOver ? 'text-rose-600' : 'text-slate-900'}>{formatMoney(projected)}</strong>
                    </span>
                    {limit > 0 && (
                      <span className={`text-[10px] px-1.5 py-0.5 rounded-md font-bold ${
                        isOver ? 'bg-rose-100 text-rose-800' : 'bg-emerald-100 text-emerald-800'
                      }`}>
                        {isOver ? (language === 'bn' ? 'বাজেট পার' : 'Over') : (language === 'bn' ? 'নিয়ন্ত্রণে' : 'Safe')}
                      </span>
                    )}
                  </div>
                </div>

                {limit > 0 && (
                  <div className="w-full bg-slate-100 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isOver ? 'bg-rose-500' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${Math.min(100, Math.round((projected / limit) * 100))}%` }}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Actionable Advice Footer */}
        <div className="p-4 rounded-2xl bg-gradient-to-r from-indigo-50 to-purple-50 border border-indigo-200/80 text-xs text-indigo-950 flex items-start gap-3">
          <Lightbulb className="w-5 h-5 text-indigo-600 shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-bold">
              {language === 'bn' ? 'পূর্বাভাস নিয়ন্ত্রণের স্মার্ট পরামর্শ:' : 'Predictive Budget Advice:'}
            </p>
            <p className="text-indigo-900/90 leading-relaxed">
              {projectedVarianceVsBudget < 0
                ? (language === 'bn'
                    ? `বর্তমান গতিতে চললে মাস শেষে ${formatMoney(Math.abs(projectedVarianceVsBudget))} টাকা বাজেট ঘাটতি হবে। পরবর্তী ${daysRemaining} দিন প্রতিদিনের খরচ ${formatMoney(targetSafeDailyBurn)}-এর নিচে সীমাবদ্ধ রাখলে বাজেট সুরক্ষিত থাকবে।`
                    : `At your current velocity, you risk a ${formatMoney(Math.abs(projectedVarianceVsBudget))} budget overrun. Cap daily spend below ${formatMoney(targetSafeDailyBurn)} for the next ${daysRemaining} days to stay green.`)
                : (language === 'bn'
                    ? `চমৎকার নিয়ন্ত্রণ! আপনার খরচের গতি এখন সুস্থ ধারায় আছে। এভাবে চালিয়ে গেলে মাস শেষে আনুমানিক ${formatMoney(projectedVarianceVsBudget)} টাকা অতিরিক্ত সঞ্চয় জমা হবে।`
                    : `Great discipline! Your burn rate is sustainable. If maintained, you are projected to save an additional ${formatMoney(projectedVarianceVsBudget)} this month.`)}
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};
