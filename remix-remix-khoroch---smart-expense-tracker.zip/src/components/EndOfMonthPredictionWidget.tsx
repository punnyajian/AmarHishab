import React, { useMemo } from 'react';
import { useExpense } from '../context/ExpenseContext';
import {
  Sparkles,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Flame,
  Zap,
} from 'lucide-react';

interface EndOfMonthPredictionWidgetProps {
  onOpenDetails: () => void;
}

export const EndOfMonthPredictionWidget: React.FC<EndOfMonthPredictionWidgetProps> = ({
  onOpenDetails,
}) => {
  const {
    transactions,
    categories,
    budgets,
    subscriptions,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    formatMoney,
    language,
    currency,
  } = useExpense();

  // Current date calculations
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonthIdx = now.getMonth();
  const currentDayOfMonth = now.getDate();
  const totalDaysInMonth = new Date(currentYear, currentMonthIdx + 1, 0).getDate();
  const daysElapsed = Math.max(1, currentDayOfMonth);
  const daysRemaining = Math.max(0, totalDaysInMonth - currentDayOfMonth);

  // Total monthly budget limit
  const totalBudgetLimit = useMemo(() => {
    const fromBudgets = budgets.reduce((sum, b) => sum + b.monthlyLimit, 0);
    if (fromBudgets > 0) return fromBudgets;
    const catLimits = categories.reduce((sum, c) => sum + (c.budgetLimit || 0), 0);
    return catLimits > 0 ? catLimits : 0;
  }, [budgets, categories]);

  // Current spending velocity
  const currentDailyBurnRate = Math.round(totalExpenseThisMonth / daysElapsed);
  const remainingProjected = currentDailyBurnRate * daysRemaining;
  const projectedTotalExpense = Math.round(totalExpenseThisMonth + remainingProjected);

  // Variance vs Budget (positive = savings, negative = over budget)
  const projectedVariance = totalBudgetLimit > 0 ? totalBudgetLimit - projectedTotalExpense : 0;
  const isWithinBudget = totalBudgetLimit === 0 || projectedVariance >= 0;

  // Target safe daily spending to stay in budget
  const remainingBudgetAmount = Math.max(0, totalBudgetLimit - totalExpenseThisMonth);
  const targetSafeDailyBurn = totalBudgetLimit > 0 && daysRemaining > 0 ? Math.round(remainingBudgetAmount / daysRemaining) : 0;

  // Progress percentage of projected vs budget
  const projectedPercent = totalBudgetLimit > 0
    ? Math.min(100, Math.round((projectedTotalExpense / totalBudgetLimit) * 100))
    : 0;

  return (
    <div
      onClick={onOpenDetails}
      className={`rounded-3xl p-5 shadow-xs border transition-all cursor-pointer hover:shadow-md group relative overflow-hidden ${
        isWithinBudget
          ? 'bg-gradient-to-br from-slate-950 via-teal-950 to-slate-900 text-white border-teal-800/50 hover:border-teal-400'
          : 'bg-gradient-to-br from-slate-950 via-rose-950 to-slate-900 text-white border-rose-800/50 hover:border-rose-400'
      }`}
    >
      {/* Background glow */}
      <div className={`absolute top-0 right-0 w-48 h-48 rounded-full blur-3xl pointer-events-none ${
        isWithinBudget ? 'bg-teal-500/10' : 'bg-rose-500/10'
      }`} />

      <div className="relative z-10 space-y-4">
        
        {/* Top Header */}
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className={`w-10 h-10 rounded-2xl flex items-center justify-center shrink-0 shadow-xs group-hover:scale-105 transition-transform ${
              isWithinBudget ? 'bg-teal-500/20 text-teal-300 border border-teal-400/30' : 'bg-rose-500/20 text-rose-300 border border-rose-400/30'
            }`}>
              <span className="text-xl">🔮</span>
            </div>
            <div>
              <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full bg-white/10 text-slate-300 border border-white/10">
                {language === 'bn' ? 'ব্যয় পূর্বাভাস' : 'End-of-Month Forecast'}
              </span>
              <h3 className="text-sm font-bold text-white group-hover:text-teal-200 transition-colors mt-0.5">
                {language === 'bn' ? 'মাস শেষের আনুমানিক খরচ' : 'Projected Month-End Spend'}
              </h3>
            </div>
          </div>

          <div className="p-1.5 rounded-xl bg-white/10 group-hover:bg-white/20 transition-colors">
            <ChevronRight className="w-4 h-4 text-slate-300" />
          </div>
        </div>

        {/* Projected Value & Badge */}
        <div className="space-y-1">
          <div className="flex items-baseline justify-between gap-2">
            <span className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              {formatMoney(projectedTotalExpense)}
            </span>
            {totalBudgetLimit > 0 ? (
              <span className={`text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full flex items-center gap-1 ${
                isWithinBudget
                  ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-400/30'
                  : 'bg-rose-500/30 text-rose-200 border border-rose-400/30'
              }`}>
                {isWithinBudget ? (
                  <>
                    <CheckCircle2 className="w-3.5 h-3.5 shrink-0 text-emerald-400" />
                    <span>{language === 'bn' ? `বাজেটে থাকবে (~${formatMoney(projectedVariance)} সাশ্রয়)` : `Within Budget (~${formatMoney(projectedVariance)} saved)`}</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="w-3.5 h-3.5 shrink-0 text-rose-400" />
                    <span>{language === 'bn' ? `বাজেট ছাড়িয়ে ${formatMoney(Math.abs(projectedVariance))} ঝুঁকি` : `Over Budget by ${formatMoney(Math.abs(projectedVariance))}`}</span>
                  </>
                )}
              </span>
            ) : (
              <span className="text-[10px] sm:text-xs font-bold px-2.5 py-1 rounded-full bg-white/10 text-slate-300 border border-white/10">
                {language === 'bn' ? 'বাজেট সেট নেই' : 'No Budget Set'}
              </span>
            )}
          </div>

          <p className="text-[11px] text-slate-400">
            {language === 'bn'
              ? `বর্তমান খরচ: ${formatMoney(totalExpenseThisMonth)} · বাকি ${daysRemaining} দিনের সম্ভাব্য ব্যয়: ${formatMoney(remainingProjected)}`
              : `Spent: ${formatMoney(totalExpenseThisMonth)} · Projected ${daysRemaining} days: ${formatMoney(remainingProjected)}`}
          </p>
        </div>

        {/* Comparison Bar */}
        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-[11px] text-slate-300">
            <span>{language === 'bn' ? 'বাজেট সীমা:' : 'Budget Limit:'} {formatMoney(totalBudgetLimit)}</span>
            <span className="font-bold text-white font-mono">{projectedPercent}% Projected</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden p-0.5 border border-white/10">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                isWithinBudget ? 'bg-gradient-to-r from-teal-400 to-emerald-400' : 'bg-gradient-to-r from-amber-400 to-rose-500'
              }`}
              style={{ width: `${Math.min(100, projectedPercent)}%` }}
            />
          </div>
        </div>

        {/* Daily Velocity Footer */}
        <div className="pt-2 border-t border-white/10 flex items-center justify-between text-xs">
          <div>
            <span className="text-[10px] text-slate-400 block">
              {language === 'bn' ? 'বর্তমান দৈনিক গড়' : 'Current Daily Burn'}
            </span>
            <span className="font-bold text-white text-xs sm:text-sm">
              {formatMoney(currentDailyBurnRate)}<span className="text-[10px] font-normal text-slate-400">/দিন</span>
            </span>
          </div>

          <div className="text-right">
            <span className="text-[10px] text-slate-400 block">
              {language === 'bn' ? 'বাজেট রক্ষার নিরাপদ সীমা' : 'Safe Daily Target'}
            </span>
            <span className="font-bold text-amber-300 text-xs sm:text-sm">
              {formatMoney(targetSafeDailyBurn)}<span className="text-[10px] font-normal text-slate-400">/দিন</span>
            </span>
          </div>
        </div>

      </div>
    </div>
  );
};
