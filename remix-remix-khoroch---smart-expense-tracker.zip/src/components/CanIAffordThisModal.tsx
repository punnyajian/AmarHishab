import React, { useState, useMemo } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { calculateAffordability, AffordabilityInput } from '../utils/affordabilityCalculator';
import {
  X,
  Scale,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  Clock,
  Wallet,
  Shield,
  Hourglass,
  PiggyBank,
  PlusCircle,
  HelpCircle,
  Check,
  ChevronRight,
  TrendingDown,
  Percent,
  Calendar,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface CanIAffordThisModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAddExpense?: (item: { name: string; amount: number; categoryId: string }) => void;
}

export const CanIAffordThisModal: React.FC<CanIAffordThisModalProps> = ({
  isOpen,
  onClose,
  onOpenAddExpense,
}) => {
  useModalBehavior({ isOpen, onClose });

  const {
    accounts,
    categories,
    budgets,
    subscriptions,
    debts,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    formatMoney,
    language,
    addWishlistItem,
    addGoal,
    setActiveTab,
  } = useExpense();

  // Input states
  const [itemName, setItemName] = useState('স্মার্টওয়াচ');
  const [priceInput, setPriceInput] = useState('6500');
  const [selectedCategoryId, setSelectedCategoryId] = useState(() => {
    return categories.find(c => c.type === 'expense')?.id || 'cat-shopping';
  });
  const [priority, setPriority] = useState<'need' | 'want'>('want');
  const [paymentMode, setPaymentMode] = useState<'lump_sum' | 'emi'>('lump_sum');
  const [emiMonths, setEmiMonths] = useState(6);

  // Success action state
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);

  // Compute live affordability
  const affordabilityInput: AffordabilityInput = useMemo(() => ({
    itemName: itemName.trim() || 'Item',
    price: parseFloat(priceInput) || 0,
    categoryId: selectedCategoryId,
    priority,
    paymentMode,
    emiMonths: paymentMode === 'emi' ? emiMonths : undefined,
  }), [itemName, priceInput, selectedCategoryId, priority, paymentMode, emiMonths]);

  const result = useMemo(() => {
    return calculateAffordability(
      affordabilityInput,
      accounts,
      totalIncomeThisMonth,
      totalExpenseThisMonth,
      budgets,
      subscriptions,
      debts
    );
  }, [affordabilityInput, accounts, totalIncomeThisMonth, totalExpenseThisMonth, budgets, subscriptions, debts]);

  if (!isOpen) return null;

  // Add to 30-Day Wishlist
  const handleAddToWishlist = () => {
    const cost = parseFloat(priceInput) || 0;
    if (cost <= 0) return;

    addWishlistItem({
      title: itemName || 'Wishlist item',
      estimatedPrice: cost,
      categoryId: selectedCategoryId,
      priority: priority === 'need' ? 'high' : 'medium',
      necessityScore: priority === 'need' ? 4 : 2,
      addedDate: new Date().toISOString().split('T')[0],
      coolingPeriodDays: 30,
      notes: language === 'bn' ? 'কেনার আগে ৩০ দিনের আবেগ নিয়ন্ত্রণ অপেক্ষা' : '30-day impulse delay',
    });

    setActionSuccessMsg(
      language === 'bn'
        ? `"${itemName}" ৩০ দিনের উইশলিস্টে সফলভাবে যুক্ত হয়েছে!`
        : `"${itemName}" added to 30-day Wishlist!`
    );

    setTimeout(() => {
      setActionSuccessMsg(null);
      onClose();
      setActiveTab('wishlist');
    }, 1500);
  };

  // Create Savings Goal
  const handleCreateSavingsGoal = () => {
    const cost = parseFloat(priceInput) || 0;
    if (cost <= 0) return;

    // Target date 3 months from now
    const target = new Date();
    target.setMonth(target.getMonth() + 3);
    const deadline = target.toISOString().split('T')[0];

    addGoal({
      name: `${itemName} Fund`,
      nameBn: `${itemName} ফান্ড`,
      targetAmount: cost,
      currentAmount: 0,
      deadline,
      color: '#10b981',
      icon: 'Target',
    });

    setActionSuccessMsg(
      language === 'bn'
        ? `"${itemName}" এর জন্য নতুন সেভিংস গোল তৈরি হয়েছে!`
        : `Savings Goal created for "${itemName}"!`
    );

    try {
      confetti({ particleCount: 40, spread: 50, origin: { y: 0.6 } });
    } catch {
      // ignore
    }

    setTimeout(() => {
      setActionSuccessMsg(null);
      onClose();
      setActiveTab('goals');
    }, 1500);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div
        className="bg-white rounded-3xl w-full max-w-xl shadow-2xl border border-slate-100 overflow-hidden animate-in zoom-in-95 duration-200 max-h-[92dvh] sm:max-h-[88vh] flex flex-col"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        {/* Header */}
        <div className="bg-gradient-to-br from-slate-950 via-teal-950 to-slate-900 text-white p-5 sm:p-6 relative overflow-hidden shrink-0">
          <div className="absolute top-0 right-0 w-52 h-52 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />

          <div className="flex items-center justify-between relative z-10">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-2xl bg-teal-500/20 border border-teal-400/30 text-teal-300 flex items-center justify-center shadow-inner">
                <Scale className="w-6 h-6" />
              </div>
              <div>
                <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full bg-teal-500/20 border border-teal-400/30 text-teal-200 text-[10px] font-bold uppercase tracking-wider">
                  <Sparkles className="w-3 h-3 text-amber-300" />
                  <span>{language === 'bn' ? 'ক্রয় সামর্থ্য বিশ্লেষক' : 'Purchase Readiness AI'}</span>
                </div>
                <h2 className="text-lg sm:text-xl font-black text-white tracking-tight mt-0.5">
                  {language === 'bn' ? '“আমি কি এটা কিনতে পারি?”' : '“Can I Afford This?”'}
                </h2>
              </div>
            </div>

            <button
              onClick={onClose}
              className="p-2 rounded-full text-white/70 hover:text-white hover:bg-white/10 transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 text-slate-700 flex-1">
          
          {/* Action Success Toast Alert */}
          {actionSuccessMsg && (
            <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in duration-150">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{actionSuccessMsg}</span>
            </div>
          )}

          {/* Input Configuration Box */}
          <div className="bg-slate-50 border border-slate-200/80 rounded-2xl p-4 space-y-3.5">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {language === 'bn' ? 'পরিকল্পিত কেনাকাটার তথ্য দিন:' : 'Enter Purchase Details:'}
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  {language === 'bn' ? 'কী কিনতে চান?' : 'Item Name'}
                </label>
                <input
                  type="text"
                  value={itemName}
                  onChange={e => setItemName(e.target.value)}
                  placeholder={language === 'bn' ? 'যেমন: স্মার্টওয়াচ, জুতো, ফোন' : 'e.g. Smartwatch, Shoes'}
                  className="w-full px-3 py-2 text-xs font-semibold bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:border-teal-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-600 mb-1">
                  {language === 'bn' ? 'দাম বা খরচ (টাকা)' : 'Price (BDT)'}
                </label>
                <input
                  type="number"
                  min="0"
                  value={priceInput}
                  onChange={e => setPriceInput(e.target.value)}
                  placeholder="0"
                  className="w-full px-3 py-2 text-xs font-bold bg-white border border-slate-200 rounded-xl focus:outline-hidden focus:border-teal-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-1">
              {/* Category */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
                </label>
                <select
                  value={selectedCategoryId}
                  onChange={e => setSelectedCategoryId(e.target.value)}
                  className="w-full px-2.5 py-1.5 text-xs bg-white border border-slate-200 rounded-xl text-slate-700 font-semibold focus:outline-hidden"
                >
                  {categories.filter(c => c.type === 'expense').map(c => (
                    <option key={c.id} value={c.id}>
                      {language === 'bn' ? c.nameBn : c.name}
                    </option>
                  ))}
                </select>
              </div>

              {/* Priority Need vs Want */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'প্রয়োজন নাকি শখ?' : 'Priority'}
                </label>
                <div className="flex rounded-xl bg-slate-200/70 p-0.5">
                  <button
                    type="button"
                    onClick={() => setPriority('need')}
                    className={`flex-1 py-1 text-[11px] font-bold rounded-lg transition-all ${
                      priority === 'need' ? 'bg-white text-emerald-800 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    {language === 'bn' ? 'প্রয়োজন' : 'Need'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPriority('want')}
                    className={`flex-1 py-1 text-[11px] font-bold rounded-lg transition-all ${
                      priority === 'want' ? 'bg-white text-rose-800 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    {language === 'bn' ? 'শখ' : 'Want'}
                  </button>
                </div>
              </div>

              {/* Payment Mode */}
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'পরিশোধের ধরন' : 'Payment Type'}
                </label>
                <div className="flex rounded-xl bg-slate-200/70 p-0.5">
                  <button
                    type="button"
                    onClick={() => setPaymentMode('lump_sum')}
                    className={`flex-1 py-1 text-[11px] font-bold rounded-lg transition-all ${
                      paymentMode === 'lump_sum' ? 'bg-white text-teal-900 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    {language === 'bn' ? 'এককালীন' : 'One-time'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setPaymentMode('emi')}
                    className={`flex-1 py-1 text-[11px] font-bold rounded-lg transition-all ${
                      paymentMode === 'emi' ? 'bg-white text-indigo-900 shadow-2xs' : 'text-slate-600'
                    }`}
                  >
                    {language === 'bn' ? 'কিস্তি (EMI)' : 'EMI'}
                  </button>
                </div>
              </div>
            </div>

            {/* EMI months selector */}
            {paymentMode === 'emi' && (
              <div className="pt-1 flex items-center justify-between text-xs text-indigo-900 bg-indigo-50/70 p-2.5 rounded-xl border border-indigo-100">
                <span className="font-semibold">
                  {language === 'bn' ? 'কিস্তির মেয়াদ:' : 'EMI Installment Tenure:'}
                </span>
                <div className="flex gap-1.5">
                  {[3, 6, 12].map(m => (
                    <button
                      key={m}
                      type="button"
                      onClick={() => setEmiMonths(m)}
                      className={`px-2.5 py-1 rounded-lg text-xs font-bold cursor-pointer transition-colors ${
                        emiMonths === m ? 'bg-indigo-600 text-white' : 'bg-white text-indigo-700 border border-indigo-200'
                      }`}
                    >
                      {m} {language === 'bn' ? 'মাস' : 'mo'}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Affordability Verdict Hero Card */}
          <div
            className={`p-5 rounded-3xl border transition-all space-y-3 ${
              result.verdict === 'affordable'
                ? 'bg-emerald-50/70 border-emerald-300'
                : result.verdict === 'stretch'
                ? 'bg-amber-50/70 border-amber-300'
                : 'bg-rose-50/70 border-rose-300'
            }`}
          >
            <div className="flex items-start justify-between gap-3">
              <div>
                <span
                  className={`text-[11px] font-black uppercase px-2.5 py-0.5 rounded-full border inline-block mb-1.5 ${result.badgeBg}`}
                >
                  {language === 'bn' ? result.verdictTitleBn : result.verdictTitleEn}
                </span>
                <h3 className="text-base sm:text-lg font-black text-slate-900 tracking-tight">
                  {language === 'bn' ? result.verdictSubtitleBn : result.verdictSubtitleEn}
                </h3>
              </div>

              {/* Readiness Score Circle Badge */}
              <div
                className="w-14 h-14 rounded-2xl flex flex-col items-center justify-center font-black text-white shrink-0 shadow-md"
                style={{ backgroundColor: result.color }}
              >
                <span className="text-base leading-none">{result.score}</span>
                <span className="text-[9px] uppercase font-bold tracking-tighter opacity-80">/ 100</span>
              </div>
            </div>

            {/* AI Explanation Box */}
            <div className="bg-white/90 rounded-2xl p-3 border border-slate-200/70 text-xs text-slate-700 leading-relaxed flex items-start gap-2">
              <Sparkles className="w-4 h-4 text-amber-500 shrink-0 mt-0.5" />
              <div>
                <strong>{language === 'bn' ? 'এআই আর্থিক মূল্যায়ন:' : 'AI Financial Assessment:'}</strong>{' '}
                {language === 'bn' ? result.aiAdviceBn : result.aiAdviceEn}
              </div>
            </div>
          </div>

          {/* 4 Deep Financial Pillar Cards */}
          <div className="grid grid-cols-2 gap-3">
            
            {/* 1. Life Energy / Work Days Cost */}
            <div className="bg-white border border-slate-200 rounded-2xl p-3.5 space-y-1 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-bold">
                <Clock className="w-3.5 h-3.5 text-indigo-500" />
                <span>{language === 'bn' ? 'পরিশ্রমের মূল্য' : 'Life Energy Cost'}</span>
              </div>
              <span className="text-base sm:text-lg font-black text-slate-900 block">
                {result.workDaysCost} {language === 'bn' ? 'কর্মদিবস' : 'work days'}
              </span>
              <p className="text-[10px] text-slate-400">
                {result.workHoursCost} {language === 'bn' ? 'ঘণ্টা কাজের সমপরিমাণ' : 'hours of hard labor'}
              </p>
            </div>

            {/* 2. Remaining Liquid Balance Cushion */}
            <div className="bg-white border border-slate-200 rounded-2xl p-3.5 space-y-1 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-bold">
                <Wallet className="w-3.5 h-3.5 text-teal-600" />
                <span>{language === 'bn' ? 'কেনার পর ব্যালেন্স' : 'Balance After'}</span>
              </div>
              <span className={`text-base sm:text-lg font-black block ${result.balanceAfterPurchase >= 0 ? 'text-slate-900' : 'text-rose-600'}`}>
                {formatMoney(result.balanceAfterPurchase)}
              </span>
              <p className="text-[10px] text-slate-400">
                {result.balanceRemainingPercent}% {language === 'bn' ? 'রিজার্ভ অবশিষ্ট থাকবে' : 'cushion remains'}
              </p>
            </div>

            {/* 3. Upcoming Bills & Debts Safety */}
            <div className="bg-white border border-slate-200 rounded-2xl p-3.5 space-y-1 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-bold">
                <Shield className="w-3.5 h-3.5 text-emerald-600" />
                <span>{language === 'bn' ? 'জরুরি বিলের নিরাপত্তা' : 'Upcoming Bills'}</span>
              </div>
              <span className={`text-xs sm:text-sm font-extrabold flex items-center gap-1 ${result.isUpcomingBillsSafe ? 'text-emerald-700' : 'text-rose-600'}`}>
                {result.isUpcomingBillsSafe ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertTriangle className="w-4 h-4 text-rose-500" />}
                <span>{result.isUpcomingBillsSafe ? (language === 'bn' ? 'সম্পূর্ণ নিরাপদ' : 'Safe') : (language === 'bn' ? 'বিল ঝুঁকির মুখে' : 'At Risk')}</span>
              </span>
              <p className="text-[10px] text-slate-400">
                {language === 'bn' ? 'আসন্ন বিল:' : 'Committed:'} {formatMoney(result.upcomingBillsTotal)}
              </p>
            </div>

            {/* 4. Emergency Buffer */}
            <div className="bg-white border border-slate-200 rounded-2xl p-3.5 space-y-1 shadow-2xs">
              <div className="flex items-center gap-1.5 text-slate-500 text-[11px] font-bold">
                <Percent className="w-3.5 h-3.5 text-amber-500" />
                <span>{language === 'bn' ? 'জরুরি রিজার্ভ' : 'Emergency Cushion'}</span>
              </div>
              <span className={`text-xs sm:text-sm font-extrabold flex items-center gap-1 ${result.isEmergencyBufferSafe ? 'text-emerald-700' : 'text-amber-600'}`}>
                {result.isEmergencyBufferSafe ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <AlertTriangle className="w-4 h-4 text-amber-500" />}
                <span>{result.isEmergencyBufferSafe ? (language === 'bn' ? 'পর্যাপ্ত তহবিল' : 'Healthy Buffer') : (language === 'bn' ? 'রিজার্ভ কমে যাবে' : 'Low Cushion')}</span>
              </span>
              <p className="text-[10px] text-slate-400">
                {language === 'bn' ? 'নগদ ক্যাশ:' : 'Total Cash:'} {formatMoney(result.totalLiquidBalance)}
              </p>
            </div>

          </div>

          {/* Action Recommendations */}
          <div className="space-y-2.5 pt-1">
            <span className="text-[11px] font-bold text-slate-400 uppercase tracking-wider block">
              {language === 'bn' ? 'স্মার্ট সমাধান ও পরবর্তী পদক্ষেপ:' : 'Smart Recommendations & Next Steps:'}
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
              
              {/* Option 1: 30-Day Wishlist */}
              <button
                type="button"
                onClick={handleAddToWishlist}
                className="p-3 bg-amber-50 hover:bg-amber-100 border border-amber-200/90 rounded-2xl text-left transition-all group cursor-pointer flex items-start gap-2.5"
              >
                <div className="w-8 h-8 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-105 transition-transform">
                  <Hourglass className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-amber-950">
                    {language === 'bn' ? '৩০ দিনের উইশলিস্টে রাখুন' : 'Add to 30-Day Wishlist'}
                  </h4>
                  <p className="text-[10px] text-amber-800/80 mt-0.5">
                    {language === 'bn' ? 'আবেগি কেনাকাটা রোধে ৩০ দিন অপেক্ষা করুন' : 'Cool off impulse to see if you still need it'}
                  </p>
                </div>
              </button>

              {/* Option 2: Create Savings Goal */}
              <button
                type="button"
                onClick={handleCreateSavingsGoal}
                className="p-3 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200/90 rounded-2xl text-left transition-all group cursor-pointer flex items-start gap-2.5"
              >
                <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-2xs group-hover:scale-105 transition-transform">
                  <PiggyBank className="w-4 h-4" />
                </div>
                <div>
                  <h4 className="text-xs font-bold text-emerald-950">
                    {language === 'bn' ? 'সঞ্চয় লক্ষ্য (Goal) তৈরি করুন' : 'Start a Savings Goal'}
                  </h4>
                  <p className="text-[10px] text-emerald-800/80 mt-0.5">
                    {language === 'bn' ? 'টাকা জমিয়ে চাপমুক্তভাবে জিনিসটি কিনুন' : 'Save up for it stress-free over time'}
                  </p>
                </div>
              </button>

            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between shrink-0">
          <div className="text-[11px] text-slate-400">
            {language === 'bn' ? 'ব্যক্তিগত আর্থিক বিশ্লেষণ' : 'Personal Financial Diagnostics'}
          </div>

          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'Done'}
          </button>
        </div>

      </div>
    </div>
  );
};
