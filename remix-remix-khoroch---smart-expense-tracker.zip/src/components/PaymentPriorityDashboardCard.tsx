import React from 'react';
import { useExpense } from '../context/ExpenseContext';
import {
  ShieldAlert,
  ArrowRight,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Sparkles,
  Zap,
  CreditCard,
  Building2,
  Clock,
} from 'lucide-react';

interface PaymentPriorityDashboardCardProps {
  onOpenDetails?: () => void;
}

export const PaymentPriorityDashboardCard: React.FC<PaymentPriorityDashboardCardProps> = ({
  onOpenDetails,
}) => {
  const {
    rankedPaymentObligations,
    cashFlowAnalysis,
    setActiveTab,
    formatMoney,
    language,
  } = useExpense();

  const handleNavigate = () => {
    if (onOpenDetails) onOpenDetails();
    else setActiveTab('payment_priority');
  };

  const topObligation = rankedPaymentObligations[0];
  const criticalCount = rankedPaymentObligations.filter(
    (item) => item.scoreBreakdown.level === 'critical' || item.obligation.isOverdue
  ).length;

  return (
    <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-100 shadow-xs relative overflow-hidden flex flex-col justify-between space-y-4">
      {/* Decorative gradient aura */}
      <div className="absolute top-0 right-0 w-44 h-44 bg-gradient-to-br from-emerald-100/40 to-teal-100/10 rounded-full blur-2xl pointer-events-none" />

      {/* Card Header */}
      <div className="flex items-center justify-between relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-2xl bg-emerald-50 text-emerald-700 border border-emerald-100 flex items-center justify-center shrink-0">
            <ShieldAlert className="w-5 h-5 stroke-[2.2]" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm font-black text-slate-800 tracking-tight">
                {language === 'bn' ? 'স্মার্ট পেমেন্ট প্রায়োরিটি' : 'Smart Payment Priority'}
              </h3>
              {criticalCount > 0 && (
                <span className="text-[10px] font-black bg-red-100 text-red-700 px-2 py-0.5 rounded-full border border-red-200">
                  {criticalCount} {language === 'bn' ? 'জরুরি' : 'Critical'}
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 font-medium">
              {language === 'bn' ? 'ঝুঁকিমুক্ত পরিশোধ র‍্যাংকিং' : 'Algorithmic Financial Priority'}
            </p>
          </div>
        </div>

        <button
          onClick={handleNavigate}
          className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1 cursor-pointer"
        >
          <span>{language === 'bn' ? 'পুরো তালিকা' : 'View Engine'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Cash Flow Status Micro-grid */}
      <div className="grid grid-cols-2 gap-2 relative z-10">
        <div className="p-3 rounded-2xl bg-slate-50 border border-slate-100">
          <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block">
            {language === 'bn' ? '৭ দিনে মোট প্রদেয়' : 'Due in 7 Days'}
          </span>
          <span className="text-sm font-black text-slate-900 mt-0.5 block">
            {formatMoney(cashFlowAnalysis.dueIn7Days)}
          </span>
        </div>

        <div
          className={`p-3 rounded-2xl border ${
            cashFlowAnalysis.hasShortfall
              ? 'bg-red-50/60 border-red-200'
              : 'bg-emerald-50/50 border-emerald-200'
          }`}
        >
          <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">
            {cashFlowAnalysis.hasShortfall
              ? language === 'bn'
                ? 'ফান্ড ঘাটতি (Shortfall)'
                : 'Shortfall'
              : language === 'bn'
              ? 'অবশিষ্ট ক্যাশ বাফার'
              : 'Left Buffer'}
          </span>
          <span
            className={`text-sm font-black mt-0.5 block ${
              cashFlowAnalysis.hasShortfall ? 'text-red-700' : 'text-emerald-700'
            }`}
          >
            {cashFlowAnalysis.hasShortfall
              ? `-${formatMoney(cashFlowAnalysis.shortfallAmount)}`
              : formatMoney(cashFlowAnalysis.projectedRemaining)}
          </span>
        </div>
      </div>

      {/* Top Priority Obligation Spotlight */}
      <div className="relative z-10">
        {topObligation ? (
          <div
            onClick={handleNavigate}
            className="p-3.5 rounded-2xl bg-slate-50 hover:bg-slate-100/80 border border-slate-200/80 transition-colors cursor-pointer group"
          >
            <div className="flex items-center justify-between text-xs">
              <div className="flex items-center gap-2">
                <span className="w-5 h-5 rounded-lg bg-slate-900 text-white font-black text-[10px] flex items-center justify-center">
                  #1
                </span>
                <span className="font-bold text-slate-800 truncate max-w-[170px]">
                  {language === 'bn'
                    ? topObligation.obligation.nameBn || topObligation.obligation.name
                    : topObligation.obligation.name}
                </span>
              </div>
              <span className="font-black text-slate-900">
                {formatMoney(topObligation.obligation.amountConverted)}
              </span>
            </div>

            <div className="flex items-center justify-between text-[11px] text-slate-500 mt-2 font-medium">
              <span className="flex items-center gap-1">
                <Clock className="w-3 h-3 text-slate-400" />
                {topObligation.obligation.isOverdue
                  ? language === 'bn'
                    ? `মেয়াদ পার (${topObligation.obligation.overdueDays} দিন)`
                    : `Overdue (${topObligation.obligation.overdueDays}d)`
                  : topObligation.obligation.daysRemaining === 0
                  ? language === 'bn'
                    ? 'আজকেই শেষ দিন'
                    : 'Due today'
                  : language === 'bn'
                  ? `${topObligation.obligation.daysRemaining} দিন বাকি`
                  : `${topObligation.obligation.daysRemaining} days left`}
              </span>
              <span className="text-emerald-700 font-bold group-hover:translate-x-0.5 transition-transform">
                {language === 'bn' ? 'পরিশোধ করুন →' : 'Action Plan →'}
              </span>
            </div>
          </div>
        ) : (
          <div className="p-4 rounded-2xl bg-emerald-50/50 border border-emerald-100 text-center space-y-1">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 mx-auto" />
            <p className="text-xs font-black text-emerald-900">
              {language === 'bn' ? 'কোনো বকেয়া পেমেন্ট নেই!' : 'No Pending Obligations'}
            </p>
            <p className="text-[10px] text-emerald-700 font-medium">
              {language === 'bn' ? 'আপনার সকল বিল ও কিস্তি পরিশোধিত।' : 'All accounts in good standing.'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
