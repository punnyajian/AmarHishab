import React, { useState } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useOnClickOutside } from '../utils/useOnClickOutside';
import {
  Search,
  Bell,
  Globe,
  Sun,
  Moon,
  ChevronDown,
  User,
  Sparkles,
  Menu,
  MoreVertical,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';

interface NavbarProps {
  onOpenAddModal?: () => void;
  onOpenAIModal?: () => void;
  onOpenTransferModal?: () => void;
  onOpenAffordModal?: () => void;
  onToggleMobileMenu?: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleMobileMenu,
}) => {
  const {
    language,
    setLanguage,
    currentUser,
    syncStatus,
    activeTab,
    setIsAuthModalOpen,
    setActiveTab,
    toggleSidebar,
    toggleSidebarCollapsed,
    setIsSidebarOpen,
    unreadNotificationsCount,
    setIsNotificationCenterOpen,
  } = useExpense();

  const [searchQuery, setSearchQuery] = useState('');
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const langMenuRef = React.useRef<HTMLDivElement>(null);
  useOnClickOutside(langMenuRef, () => setShowLangMenu(false), showLangMenu);

  React.useEffect(() => {
    if (!showLangMenu) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setShowLangMenu(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showLangMenu]);

  const userName = currentUser?.username ? `@${currentUser.username}` : (currentUser?.displayName || '');

  const handleToggleMenu = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onToggleMobileMenu) {
      onToggleMobileMenu();
    } else {
      toggleSidebar();
    }
  };

  return (
    <header className="sticky top-0 z-30 bg-white/95 backdrop-blur-md border-b border-slate-200/80 px-4 sm:px-6 lg:px-8 py-3.5 no-print">
      <div className="flex items-center justify-between gap-4">
        
        {/* Left: Menu & 3-dot navigation triggers and Search input */}
        <div className="flex items-center gap-2 sm:gap-3 flex-1 max-w-xl">
          {/* Mobile & Tablet Sidebar Menu Trigger */}
          <button
            type="button"
            onClick={handleToggleMenu}
            className="lg:hidden p-2 rounded-xl text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition-colors cursor-pointer"
            title={language === 'bn' ? 'মেনু খুলুন' : 'Open menu'}
            aria-label="Open sidebar menu"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Desktop 3-Dot (⋮) Button - Toggles sidebar collapse */}
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              toggleSidebarCollapsed();
            }}
            className="hidden lg:flex p-2 rounded-xl text-slate-500 hover:text-slate-800 hover:bg-slate-100 transition-colors cursor-pointer"
            title={language === 'bn' ? 'সাইডবার মেনু টগল করুন (৩-ডট)' : 'Toggle sidebar collapse (3-dots)'}
            aria-label="Toggle sidebar collapse"
          >
            <MoreVertical className="w-5 h-5" />
          </button>

          <div className="relative w-full max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  setActiveTab('transactions');
                }
              }}
              placeholder={language === 'bn' ? 'লেনদেন, ক্যাটাগরি বা যেকোনো কিছু খুঁজুন...' : 'Search transactions, categories, or anything...'}
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200/90 rounded-full text-xs font-medium text-slate-800 placeholder-slate-400 focus:outline-hidden focus:bg-white focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all shadow-2xs"
            />
          </div>
        </div>

        {/* Right Controls: Bell, Language, Theme Toggle, User Profile */}
        <div className="flex items-center gap-2 sm:gap-3 shrink-0">
          {/* PWA In-App Install Trigger */}
          <PWAInstallButton variant="navbar" />
          
          {/* Notification Bell */}
          <button
            onClick={() => setIsNotificationCenterOpen(true)}
            className="relative p-2 rounded-full text-slate-600 hover:bg-slate-100 transition-colors"
            title={language === 'bn' ? `নোটিফিকেশন ও রিমাইন্ডার (${unreadNotificationsCount})` : `Notifications & Reminders (${unreadNotificationsCount})`}
          >
            <Bell className="w-4 h-4 stroke-[2]" />
            {unreadNotificationsCount > 0 && (
              <span className="min-w-4 h-4 px-1 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center ring-2 ring-white absolute -top-0.5 -right-0.5 animate-pulse">
                {unreadNotificationsCount > 9 ? '9+' : unreadNotificationsCount}
              </span>
            )}
          </button>

          {/* Language Selector */}
          <div className="relative" ref={langMenuRef}>
            <button
              onClick={() => setShowLangMenu(!showLangMenu)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200 rounded-lg transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-slate-500" />
              <span className="hidden sm:inline">{language === 'bn' ? 'বাংলা' : 'English'}</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showLangMenu && (
              <div className="absolute right-0 mt-1.5 w-32 bg-white border border-slate-200 rounded-xl shadow-lg py-1 z-40 animate-in fade-in duration-150">
                <button
                  onClick={() => {
                    setLanguage('en');
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-left px-3 py-1.5 text-xs font-medium hover:bg-emerald-50 ${language === 'en' ? 'text-emerald-700 font-bold bg-emerald-50/50' : 'text-slate-700'}`}
                >
                  English
                </button>
                <button
                  onClick={() => {
                    setLanguage('bn');
                    setShowLangMenu(false);
                  }}
                  className={`w-full text-left px-3 py-1.5 text-xs font-medium hover:bg-emerald-50 ${language === 'bn' ? 'text-emerald-700 font-bold bg-emerald-50/50' : 'text-slate-700'}`}
                >
                  বাংলা (Bengali)
                </button>
              </div>
            )}
          </div>

          {/* Theme Switcher Toggle Pill (Sun / Moon) */}
          <button
            onClick={() => setIsDarkMode(!isDarkMode)}
            className="p-1 bg-slate-100 border border-slate-200/90 rounded-full flex items-center gap-1 cursor-pointer hover:bg-slate-200/70 transition-colors"
            title="Toggle Light / Dark theme"
          >
            <div className={`p-1 rounded-full transition-all ${!isDarkMode ? 'bg-white shadow-2xs text-amber-500' : 'text-slate-400'}`}>
              <Sun className="w-3.5 h-3.5" />
            </div>
            <div className={`p-1 rounded-full transition-all ${isDarkMode ? 'bg-slate-900 shadow-2xs text-indigo-400' : 'text-slate-400'}`}>
              <Moon className="w-3.5 h-3.5" />
            </div>
          </button>

          {/* Cloud Sync Status Indicator (When logged in) */}
          {currentUser && (
            <button
              onClick={() => setActiveTab('profile')}
              className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-50/80 border border-emerald-200/90 text-[11px] font-semibold text-emerald-800 hover:bg-emerald-100/70 transition-colors cursor-pointer"
              title={syncStatus === 'syncing' ? 'Syncing with cloud' : syncStatus === 'offline' ? 'Offline' : 'Synced'}
            >
              <span
                className={`w-2 h-2 rounded-full ${
                  syncStatus === 'syncing'
                    ? 'bg-amber-500 animate-ping'
                    : syncStatus === 'offline'
                    ? 'bg-amber-400'
                    : syncStatus === 'error'
                    ? 'bg-rose-500'
                    : 'bg-emerald-500'
                }`}
              />
              <span className="capitalize">
                {syncStatus === 'syncing' ? 'Syncing...' : syncStatus === 'offline' ? 'Offline' : 'Synced'}
              </span>
            </button>
          )}

          {/* User Profile / Sign In trigger */}
          {currentUser ? (
            <button
              onClick={() => setActiveTab('profile')}
              className={`flex items-center gap-2 p-1 pr-2.5 rounded-full transition-colors border text-left cursor-pointer ${
                activeTab === 'profile'
                  ? 'border-emerald-300 bg-emerald-50/70 shadow-2xs'
                  : 'border-slate-200 bg-white hover:bg-slate-50'
              }`}
              title={userName}
              aria-label={userName}
            >
              <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-emerald-600 to-teal-500 text-white font-bold flex items-center justify-center text-xs shrink-0 shadow-xs">
                {currentUser.username ? currentUser.username[0].toUpperCase() : 'U'}
              </div>
              <span className="text-xs font-bold text-slate-800 leading-tight block truncate max-w-[120px]">
                {userName}
              </span>
            </button>
          ) : (
            <button
              onClick={() => setIsAuthModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs transition-all cursor-pointer"
            >
              <User className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'লগইন' : 'Sign In'}</span>
            </button>
          )}
        </div>
      </div>
    </header>
  );
};
