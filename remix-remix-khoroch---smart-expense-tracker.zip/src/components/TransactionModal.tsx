import React, { useState, useEffect } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { Transaction, TransactionType } from '../types';
import { CategoryIcon } from './CategoryIcon';
import { getBengaliDate } from '../utils/bengaliCalendar';
import { 
  X, 
  ArrowRightLeft, 
  Calendar as CalendarIcon, 
  Clock, 
  FileText, 
  RefreshCw,
  Camera,
  Check,
  Sparkles,
} from 'lucide-react';
import { parseNaturalLanguageTransaction } from '../utils/naturalLanguageParser';

interface TransactionModalProps {
  isOpen: boolean;
  onClose: () => void;
  editTx?: Transaction | null;
  initialType?: TransactionType;
}

export const TransactionModal: React.FC<TransactionModalProps> = ({
  isOpen,
  onClose,
  editTx,
  initialType = 'expense',
}) => {
  useModalBehavior({ isOpen, onClose });

  const { 
    categories, 
    accounts, 
    digitalCards,
    addTransaction, 
    editTransaction, 
    currency, 
    language, 
    t,
    formatMoney 
  } = useExpense();

  const [type, setType] = useState<TransactionType>(initialType);
  const [amount, setAmount] = useState<string>('');
  const [categoryId, setCategoryId] = useState<string>('');
  const [accountId, setAccountId] = useState<string>('');
  const [targetAccountId, setTargetAccountId] = useState<string>('');
  const [cardId, setCardId] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [time, setTime] = useState<string>(
    new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })
  );
  const [note, setNote] = useState<string>('');
  const [isRecurring, setIsRecurring] = useState<boolean>(false);
  const [recurringInterval, setRecurringInterval] = useState<'daily' | 'weekly' | 'monthly' | 'yearly'>('monthly');
  const [receiptImage, setReceiptImage] = useState<string | null>(null);
  const [naturalInput, setNaturalInput] = useState<string>('');

  // Filtered categories based on selected type
  const availableCategories = categories.filter(c => (type === 'transfer' ? true : c.type === type));

  useEffect(() => {
    if (editTx) {
      setType(editTx.type);
      setAmount(editTx.amount.toString());
      setCategoryId(editTx.categoryId);
      setAccountId(editTx.accountId);
      setTargetAccountId(editTx.targetAccountId || '');
      setDate(editTx.date);
      setTime(editTx.time || '12:00');
      setNote(editTx.note || '');
      setCardId(editTx.cardId || '');
      setIsRecurring(!!editTx.isRecurring);
      setRecurringInterval(editTx.recurringInterval || 'monthly');
      setReceiptImage(editTx.receiptUrl || null);
    } else {
      setType(initialType);
      setAmount('');
      const defaultCat = categories.find(c => c.type === initialType) || categories[0];
      setCategoryId(defaultCat ? defaultCat.id : '');
      setAccountId(accounts[0]?.id || '');
      setTargetAccountId(accounts[1]?.id || accounts[0]?.id || '');
      setCardId('');
      setDate(new Date().toISOString().split('T')[0]);
      setTime(new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false }));
      setNote('');
      setIsRecurring(false);
      setReceiptImage(null);
      setNaturalInput('');
    }
  }, [editTx, initialType, isOpen, categories, accounts]);

  // When type changes, adjust default category
  const handleTypeChange = (newType: TransactionType) => {
    setType(newType);
    const cat = categories.find(c => c.type === newType);
    if (cat) {
      setCategoryId(cat.id);
    }
  };

  const handleApplyNaturalInput = () => {
    if (!naturalInput.trim()) return;
    const res = parseNaturalLanguageTransaction(naturalInput, accounts, categories, language);
    if (res.success && res.amount > 0) {
      setType(res.type);
      setAmount(String(res.amount));
      setCategoryId(res.categoryId);
      setAccountId(res.accountId);
      setDate(res.date);
      if (res.time) setTime(res.time);
      setNote(res.note);
      setNaturalInput('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const numAmount = parseFloat(amount);
    if (isNaN(numAmount) || numAmount <= 0) return;
    if (!accountId) return;
    if (type === 'transfer' && (!targetAccountId || targetAccountId === accountId)) return;

    if (editTx) {
      editTransaction({
        id: editTx.id,
        type,
        amount: numAmount,
        categoryId: categoryId || 'cat-others',
        accountId,
        targetAccountId: type === 'transfer' ? targetAccountId : undefined,
        cardId: cardId || undefined,
        date,
        time,
        note: note.trim(),
        isRecurring,
        recurringInterval: isRecurring ? recurringInterval : undefined,
        receiptUrl: receiptImage || undefined,
      });
    } else {
      addTransaction({
        type,
        amount: numAmount,
        categoryId: categoryId || 'cat-others',
        accountId,
        targetAccountId: type === 'transfer' ? targetAccountId : undefined,
        cardId: cardId || undefined,
        date,
        time,
        note: note.trim(),
        isRecurring,
        recurringInterval: isRecurring ? recurringInterval : undefined,
        receiptUrl: receiptImage || undefined,
      });
    }

    onClose();
  };

  const handleSimulateReceiptUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        setReceiptImage(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  if (!isOpen) return null;

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg shadow-2xl border border-slate-100 flex flex-col max-h-[92dvh] sm:max-h-[88vh] overflow-hidden animate-in slide-in-from-bottom-4 sm:slide-in-from-bottom-0 duration-200 pb-[calc(env(safe-area-inset-bottom,0px)+0.8rem)] sm:pb-0"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        {/* Mobile drag handle */}
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden mt-2.5 -mb-1" />
        
        {/* Header */}
        <div className="flex items-center justify-between px-5 pt-3 pb-3 sm:px-6 sm:pt-5 border-b border-slate-100 shrink-0">
          <h2 className="text-base sm:text-lg font-bold text-slate-800">
            {editTx 
              ? (language === 'bn' ? 'লেনদেন সম্পাদনা' : 'Edit Transaction')
              : (language === 'bn' ? 'নতুন হিসাব যোগ করুন' : 'Add New Record')}
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4">
          
          {/* Type Selector (Expense, Income, Transfer) */}
          <div className="grid grid-cols-3 gap-1.5 sm:gap-2 p-1 bg-slate-100/80 rounded-2xl shrink-0">
            <button
              type="button"
              onClick={() => handleTypeChange('expense')}
              className={`py-2 text-xs sm:text-sm font-bold rounded-xl transition-all ${
                type === 'expense'
                  ? 'bg-white text-rose-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'খরচ' : 'Expense'}
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('income')}
              className={`py-2 text-xs sm:text-sm font-bold rounded-xl transition-all ${
                type === 'income'
                  ? 'bg-white text-emerald-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'আয়' : 'Income'}
            </button>
            <button
              type="button"
              onClick={() => handleTypeChange('transfer')}
              className={`py-2 text-xs sm:text-sm font-bold rounded-xl transition-all ${
                type === 'transfer'
                  ? 'bg-white text-sky-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              {language === 'bn' ? 'ট্রান্সফার' : 'Transfer'}
            </button>
          </div>

          {/* Amount Input with Currency Symbol */}
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1.5">
              {t('amount')} ({currency.symbol})
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="text-2xl font-bold text-slate-400">{currency.symbol}</span>
              </div>
              <input
                type="number"
                step="any"
                required
                min="0.01"
                placeholder="0.00"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                className="w-full pl-12 pr-4 py-3 text-xl sm:text-2xl font-extrabold text-slate-900 bg-slate-50 border border-slate-200 rounded-2xl focus:bg-white focus:outline-hidden focus:ring-2 focus:ring-emerald-500 focus:border-transparent transition-all placeholder:text-slate-300"
                autoFocus
              />
            </div>

            {/* Quick Amount Suggestion Pills */}
            <div className="flex gap-1.5 sm:gap-2 mt-2 overflow-x-auto pb-1 scrollbar-none">
              {[50, 100, 200, 500, 1000, 5000].map(val => (
                <button
                  type="button"
                  key={val}
                  onClick={() => {
                    const current = parseFloat(amount) || 0;
                    setAmount((current + val).toString());
                  }}
                  className="px-2.5 py-1 text-xs font-semibold bg-emerald-50 text-emerald-700 hover:bg-emerald-100 rounded-lg border border-emerald-100 transition-colors shrink-0"
                >
                  +{val}
                </button>
              ))}
            </div>
          </div>

          {/* Categories Selector (Not required for Transfer) */}
          {type !== 'transfer' && (
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5">
                {t('category')}
              </label>
              <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2 max-h-40 overflow-y-auto p-1.5 bg-slate-50 rounded-2xl border border-slate-100">
                {availableCategories.map(cat => {
                  const isSelected = categoryId === cat.id;
                  return (
                    <button
                      type="button"
                      key={cat.id}
                      onClick={() => setCategoryId(cat.id)}
                      className={`flex flex-col items-center justify-center p-2 rounded-xl text-center transition-all ${
                        isSelected
                          ? 'bg-emerald-600 text-white shadow-xs scale-95 font-bold'
                          : 'bg-white hover:bg-slate-100 text-slate-700 border border-slate-200/50'
                      }`}
                    >
                      <div
                        className="w-7 h-7 sm:w-8 sm:h-8 rounded-full flex items-center justify-center mb-1"
                        style={{
                          backgroundColor: isSelected ? 'rgba(255,255,255,0.2)' : `${cat.color}15`,
                          color: isSelected ? '#ffffff' : cat.color,
                        }}
                      >
                        <CategoryIcon iconName={cat.icon} size={15} />
                      </div>
                      <span className="text-[10px] leading-tight line-clamp-1">
                        {language === 'bn' ? cat.nameBn : cat.name}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Account / Wallet Selection */}
          {type === 'transfer' ? (
            <div className="grid grid-cols-2 gap-2 sm:gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">
                  {language === 'bn' ? 'কোন ওয়ালেট থেকে' : 'From Wallet'}
                </label>
                <select
                  value={accountId}
                  onChange={e => setAccountId(e.target.value)}
                  className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                >
                  {accounts.map(acc => (
                    <option key={acc.id} value={acc.id}>
                      {language === 'bn' ? acc.nameBn : acc.name} ({formatMoney(acc.balance)})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-500 mb-1.5">
                  {language === 'bn' ? 'কোন ওয়ালেটে জমা' : 'To Wallet'}
                </label>
                <select
                  value={targetAccountId}
                  onChange={e => setTargetAccountId(e.target.value)}
                  className="w-full px-2.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
                >
                  {accounts
                    .filter(a => a.id !== accountId)
                    .map(acc => (
                      <option key={acc.id} value={acc.id}>
                        {language === 'bn' ? acc.nameBn : acc.name} ({formatMoney(acc.balance)})
                      </option>
                    ))}
                </select>
              </div>
            </div>
          ) : (
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5">
                {language === 'bn' ? 'পেমেন্ট মেথড / ওয়ালেট' : 'Payment Account'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {accounts.map(acc => {
                  const isSelected = accountId === acc.id;
                  return (
                    <button
                      type="button"
                      key={acc.id}
                      onClick={() => setAccountId(acc.id)}
                      className={`flex items-center justify-between p-2 sm:p-2.5 rounded-xl border text-left transition-all ${
                        isSelected
                          ? 'border-emerald-500 bg-emerald-50/70 text-emerald-900 font-bold'
                          : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                      }`}
                    >
                      <div className="truncate pr-1">
                        <p className="text-xs truncate">{language === 'bn' ? acc.nameBn : acc.name}</p>
                        <p className="text-[10px] text-slate-400 font-mono">{formatMoney(acc.balance)}</p>
                      </div>
                      {isSelected && <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />}
                    </button>
                  );
                })}
              </div>

              {/* Optional Digital Card Picker (Google Wallet style) */}
              {type === 'expense' && digitalCards.length > 0 && (
                <div className="mt-3 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="text-[11px] font-bold text-slate-500">
                      {language === 'bn' ? 'Google Wallet কার্ড দিয়ে পরিশোধ (ঐচ্ছিক)' : 'Paid via Google Wallet Card (Optional)'}
                    </label>
                    {cardId && (
                      <button
                        type="button"
                        onClick={() => setCardId('')}
                        className="text-[10px] text-rose-500 font-semibold hover:underline"
                      >
                        {language === 'bn' ? 'কার্ড বাতিল' : 'Clear Card'}
                      </button>
                    )}
                  </div>
                  <div className="grid grid-cols-2 gap-2">
                    {digitalCards.map(c => {
                      const isCardSelected = cardId === c.id;
                      return (
                        <button
                          type="button"
                          key={c.id}
                          onClick={() => {
                            if (isCardSelected) {
                              setCardId('');
                            } else {
                              setCardId(c.id);
                              if (c.linkedAccountId && accounts.some(a => a.id === c.linkedAccountId)) {
                                setAccountId(c.linkedAccountId);
                              }
                            }
                          }}
                          className={`p-2 rounded-xl border text-left transition-all flex items-center justify-between ${
                            isCardSelected
                              ? 'border-slate-900 bg-slate-900 text-white font-bold shadow-xs'
                              : 'border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700'
                          }`}
                        >
                          <div className="truncate pr-1">
                            <p className="text-xs truncate font-bold">{c.issuerName}</p>
                            <p className={`text-[10px] font-mono ${isCardSelected ? 'text-slate-300' : 'text-slate-400'}`}>
                              •••• {c.last4}
                            </p>
                          </div>
                          {isCardSelected && <Check className="w-3.5 h-3.5 text-amber-300 shrink-0" />}
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Date & Time */}
          <div className="grid grid-cols-2 gap-2 sm:gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5 flex items-center gap-1">
                <CalendarIcon className="w-3.5 h-3.5 text-slate-400" />
                {t('date')}
              </label>
              <input
                type="date"
                required
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              {date && (
                <div className="mt-1.5 px-2 py-1 bg-emerald-50/80 border border-emerald-200/70 rounded-lg text-[11px] text-emerald-800 font-medium flex items-center justify-between">
                  <span className="text-emerald-700">{language === 'bn' ? 'বাংলা:' : 'Bangla:'}</span>
                  <span className="font-bold">{getBengaliDate(date).fullDateBn} ({getBengaliDate(date).seasonBn})</span>
                </div>
              )}
            </div>
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5 flex items-center gap-1">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                {language === 'bn' ? 'সময়' : 'Time'}
              </label>
              <input
                type="time"
                value={time}
                onChange={e => setTime(e.target.value)}
                className="w-full px-2.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Note / Memo */}
          <div>
            <label className="block text-xs font-bold text-slate-500 mb-1.5 flex items-center gap-1">
              <FileText className="w-3.5 h-3.5 text-slate-400" />
              {t('notes')}
            </label>
            <input
              type="text"
              placeholder={language === 'bn' ? 'যেমন: দুপুরের লাঞ্চ, বাজার, রিকশা...' : 'e.g. Office lunch, groceries, cab fare'}
              value={note}
              onChange={e => setNote(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          {/* Recurring & Receipt simulation options */}
          <div className="pt-1 flex items-center justify-between text-xs text-slate-600 flex-wrap gap-2">
            <label className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={isRecurring}
                onChange={e => setIsRecurring(e.target.checked)}
                className="w-4 h-4 rounded-sm text-emerald-600 focus:ring-emerald-500 border-slate-300"
              />
              <span className="flex items-center gap-1">
                <RefreshCw className="w-3.5 h-3.5 text-slate-400" />
                <span className="text-[11px] sm:text-xs">{language === 'bn' ? 'নিয়মিত খরচ' : 'Recurring bill'}</span>
              </span>
            </label>

            {/* Simulated Receipt Attachment */}
            <label className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-lg cursor-pointer transition-colors">
              <Camera className="w-3.5 h-3.5" />
              <span>{receiptImage ? (language === 'bn' ? 'রশিদ যুক্ত' : 'Receipt attached') : (language === 'bn' ? 'মেমো রসিদ' : 'Receipt photo')}</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleSimulateReceiptUpload}
                className="hidden"
              />
            </label>
          </div>

          {/* Actions */}
          <div className="pt-3 border-t border-slate-100 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:text-slate-800 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
            >
              {t('cancel')}
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-xs font-bold text-white bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 rounded-xl shadow-xs transition-colors"
            >
              {editTx ? t('save') : (language === 'bn' ? 'যুক্ত করুন' : 'Confirm')}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
};
