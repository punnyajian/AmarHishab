import React, { useState } from 'react';
import { DigitalCard } from '../types';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { 
  X, 
  Wifi, 
  CheckCircle2, 
  AlertCircle, 
  Sparkles,
  ShoppingBag,
  Coffee,
  Store,
  Fuel,
  ArrowRight
} from 'lucide-react';

interface ContactlessTapModalProps {
  card: DigitalCard | null;
  isOpen: boolean;
  onClose: () => void;
}

export const ContactlessTapModal: React.FC<ContactlessTapModalProps> = ({
  card,
  isOpen,
  onClose,
}) => {
  useModalBehavior({ isOpen, onClose });

  const { 
    categories, 
    simulateCardTapPayment, 
    formatMoney, 
    currency, 
    language 
  } = useExpense();

  const [amount, setAmount] = useState('450');
  const [merchant, setMerchant] = useState("Gloria Jean's Coffees");
  const [categoryId, setCategoryId] = useState('cat-food');
  const [isTapping, setIsTapping] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen || !card) return null;

  // Web Audio API clean synthetic payment chime (no external assets)
  const playPaymentChime = () => {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      // Note 1: E5 (659Hz)
      const osc1 = ctx.createOscillator();
      const gain1 = ctx.createGain();
      osc1.type = 'sine';
      osc1.frequency.setValueAtTime(659.25, now);
      gain1.gain.setValueAtTime(0.12, now);
      gain1.gain.exponentialRampToValueAtTime(0.001, now + 0.2);
      osc1.connect(gain1);
      gain1.connect(ctx.destination);
      osc1.start(now);
      osc1.stop(now + 0.2);

      // Note 2: B5 (987Hz)
      const osc2 = ctx.createOscillator();
      const gain2 = ctx.createGain();
      osc2.type = 'sine';
      osc2.frequency.setValueAtTime(987.77, now + 0.12);
      gain2.gain.setValueAtTime(0.15, now + 0.12);
      gain2.gain.exponentialRampToValueAtTime(0.001, now + 0.45);
      osc2.connect(gain2);
      gain2.connect(ctx.destination);
      osc2.start(now + 0.12);
      osc2.stop(now + 0.45);
    } catch {
      // Audio playback fails silently if restricted
    }
  };

  const handleSimulateTap = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    const numAmount = parseFloat(amount);

    if (isNaN(numAmount) || numAmount <= 0) {
      setErrorMessage(language === 'bn' ? 'সঠিক টাকার পরিমাণ দিন' : 'Please enter a valid amount');
      return;
    }

    if (card.isFrozen) {
      setErrorMessage(
        language === 'bn' 
          ? 'এই কার্ডটি ফ্রিজ/লক করা রয়েছে! আনলক করে চেষ্টা করুন।' 
          : 'This card is currently frozen! Unfreeze to pay.'
      );
      return;
    }

    setIsTapping(true);

    // Simulate the Google Wallet NFC transmission delay
    setTimeout(() => {
      const result = simulateCardTapPayment(
        card.id,
        numAmount,
        merchant.trim() || 'Google Wallet Contactless Tap',
        categoryId
      );

      setIsTapping(false);

      if (result.success) {
        setIsSuccess(true);
        playPaymentChime();
        // Reset after 2.5 seconds or let user close
        setTimeout(() => {
          setIsSuccess(false);
          onClose();
        }, 2200);
      } else {
        setErrorMessage(result.message);
      }
    }, 1100);
  };

  const quickPresets = [
    { label: 'কফি / নাস্তা', labelEn: 'Coffee', amount: '250', merchant: "Gloria Jean's", cat: 'cat-food', icon: Coffee },
    { label: 'সুপারশপ বাজার', labelEn: 'Grocery', amount: '1200', merchant: 'Shwapno Super Shop', cat: 'cat-grocery', icon: ShoppingBag },
    { label: 'ফুয়েল / তেল', labelEn: 'Fuel', amount: '800', merchant: 'Trust Filling Station', cat: 'cat-transport', icon: Fuel },
    { label: 'রেস্তোরাঁ ডিনার', labelEn: 'Dining', amount: '1650', merchant: 'Star Kabab & Restaurant', cat: 'cat-food', icon: Store },
  ];

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="bg-white rounded-t-3xl sm:rounded-3xl max-w-md w-full p-6 shadow-2xl space-y-5 max-h-[90dvh] sm:max-h-[88vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6 relative"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-2 mb-2" />

        {/* Modal Top Bar */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-slate-900 text-white flex items-center justify-center shadow-xs">
              <Wifi className="w-4 h-4 rotate-90" />
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base text-slate-800">
                {language === 'bn' ? 'Google Wallet কন্ট্যাক্টলেস ট্যাপ' : 'Google Wallet Contactless Tap'}
              </h3>
              <p className="text-[11px] text-slate-400">
                {card.issuerName} •••• {card.last4}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Success Feedback Screen */}
        {isSuccess ? (
          <div className="py-8 flex flex-col items-center justify-center text-center space-y-3 animate-in zoom-in-95 duration-200">
            <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center ring-8 ring-emerald-50 shadow-lg">
              <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
            </div>
            <div>
              <h4 className="text-lg font-black text-slate-900">
                {language === 'bn' ? 'ট্যাপ পেমেন্ট সফল হয়েছে!' : 'Payment Approved!'}
              </h4>
              <p className="text-xs text-slate-500 mt-1">
                {merchant} • {formatMoney(parseFloat(amount) || 0)}
              </p>
            </div>
            <span className="text-[11px] font-semibold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
              {language === 'bn' ? 'লেনদেনটি খরচের তালিকায় যুক্ত হয়েছে' : 'Expense recorded in Khoroch'}
            </span>
          </div>
        ) : (
          <form onSubmit={handleSimulateTap} className="space-y-4">
            
            {/* Wireless NFC Antenna Graphic with Concentric Pulsing Animation */}
            <div className="bg-gradient-to-b from-slate-900 to-slate-950 rounded-2xl p-6 text-white text-center relative overflow-hidden flex flex-col items-center justify-center min-h-[140px]">
              {/* Concentric rings */}
              <div className="relative flex items-center justify-center">
                <div className={`w-28 h-28 rounded-full border border-emerald-400/20 absolute ${isTapping ? 'animate-ping' : ''}`} />
                <div className={`w-20 h-20 rounded-full border border-emerald-400/30 absolute ${isTapping ? 'animate-pulse' : ''}`} />
                <div className="w-14 h-14 rounded-full bg-gradient-to-tr from-emerald-500 to-teal-400 text-slate-950 flex items-center justify-center shadow-lg shadow-emerald-500/30 z-10">
                  <Wifi className="w-7 h-7 rotate-90" />
                </div>
              </div>

              <div className="mt-3 z-10">
                <p className="text-xs font-bold text-white tracking-wide">
                  {isTapping 
                    ? (language === 'bn' ? 'পেমেন্ট টার্মিনালে ডাটা পাঠানো হচ্ছে...' : 'Transmitting encrypted token...') 
                    : (language === 'bn' ? 'কার্ডটি POS টার্মিনালের কাছে ধরুন' : 'Hold near contactless terminal')}
                </p>
                <p className="text-[10px] text-slate-400 mt-0.5">
                  {card.issuerName} • {card.cardholderName}
                </p>
              </div>
            </div>

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-rose-50 border border-rose-200 text-rose-700 rounded-xl text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Amount & Merchant Inputs */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'টাকার পরিমাণ' : 'Amount'}
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-2.5 text-xs font-bold text-slate-400">
                    {currency.symbol}
                  </span>
                  <input
                    type="number"
                    step="any"
                    required
                    value={amount}
                    onChange={e => setAmount(e.target.value)}
                    className="w-full pl-7 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900"
                    placeholder="0"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-500 mb-1">
                  {language === 'bn' ? 'মার্চেন্ট / দোকান' : 'Merchant / Store'}
                </label>
                <input
                  type="text"
                  required
                  value={merchant}
                  onChange={e => setMerchant(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-slate-900"
                  placeholder="e.g. Unimart, Coffee Shop"
                />
              </div>
            </div>

            {/* Category */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 mb-1">
                {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
              </label>
              <select
                value={categoryId}
                onChange={e => setCategoryId(e.target.value)}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-800"
              >
                {categories
                  .filter(c => c.type === 'expense')
                  .map(c => (
                    <option key={c.id} value={c.id}>
                      {language === 'bn' ? c.nameBn : c.name}
                    </option>
                  ))}
              </select>
            </div>

            {/* Quick Presets */}
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1.5">
                {language === 'bn' ? 'দ্রুত টেস্ট প্রিসেট' : 'Quick Test Presets'}
              </span>
              <div className="grid grid-cols-2 gap-1.5">
                {quickPresets.map((preset, idx) => {
                  const Icon = preset.icon;
                  return (
                    <button
                      key={idx}
                      type="button"
                      onClick={() => {
                        setAmount(preset.amount);
                        setMerchant(preset.merchant);
                        setCategoryId(preset.cat);
                      }}
                      className="p-2 rounded-xl border border-slate-200 hover:border-slate-400 bg-slate-50 hover:bg-white text-left transition-all flex items-center justify-between group"
                    >
                      <div className="flex items-center gap-1.5">
                        <Icon className="w-3.5 h-3.5 text-slate-500 group-hover:text-slate-900" />
                        <span className="text-[11px] font-bold text-slate-700">
                          {language === 'bn' ? preset.label : preset.labelEn}
                        </span>
                      </div>
                      <span className="text-[11px] font-mono font-bold text-slate-900">
                        {currency.symbol}{preset.amount}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Submit Action */}
            <div className="pt-2 flex items-center justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2.5 text-xs font-semibold text-slate-600 bg-slate-100 hover:bg-slate-200 rounded-xl transition-colors"
              >
                {language === 'bn' ? 'বাতিল' : 'Cancel'}
              </button>
              <button
                type="submit"
                disabled={isTapping}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs font-bold text-white bg-slate-900 hover:bg-slate-800 rounded-xl shadow-md shadow-slate-950/20 active:scale-95 transition-all disabled:opacity-50"
              >
                {isTapping ? (
                  <>
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>{language === 'bn' ? 'ট্যাপ হচ্ছে...' : 'Tapping...'}</span>
                  </>
                ) : (
                  <>
                    <Wifi className="w-3.5 h-3.5 rotate-90" />
                    <span>{language === 'bn' ? 'এখনই ট্যাপ করুন' : 'Tap to Pay Now'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </>
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
