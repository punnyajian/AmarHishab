import React, { useState } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { X, Sparkles, TrendingDown, Lightbulb, AlertCircle, CheckCircle2, RefreshCw, Landmark, Compass, Flame, Droplets } from 'lucide-react';
import { analyzeMoneyLeaks } from '../utils/moneyLeakDetector';

interface AIInsightsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AIInsightsModal: React.FC<AIInsightsModalProps> = ({ isOpen, onClose }) => {
  useModalBehavior({ isOpen, onClose });
  const { 
    transactions, 
    categories, 
    accounts, 
    budgets, 
    goals, 
    debts,
    language, 
    formatMoney,
    totalIncomeThisMonth,
    totalExpenseThisMonth,
    netSavingsThisMonth,
    savingsRateThisMonth,
    totalPortfolioValue,
    totalMonthlyEstimatedYield,
    upcomingDPSInstallments,
    activeTrip,
    currentNoSpendStreak,
    userLevel,
    userXP,
  } = useExpense();

  const [analyzing, setAnalyzing] = useState(false);

  if (!isOpen) return null;

  // Compute category spending ranking
  const categorySpendMap: { [catId: string]: number } = {};
  transactions
    .filter(t => t.type === 'expense')
    .forEach(t => {
      categorySpendMap[t.categoryId] = (categorySpendMap[t.categoryId] || 0) + t.amount;
    });

  const sortedCategories = Object.entries(categorySpendMap)
    .sort((a, b) => b[1] - a[1])
    .map(([catId, amount]) => {
      const cat = categories.find(c => c.id === catId);
      return {
        name: language === 'bn' ? cat?.nameBn || cat?.name || '' : cat?.name || '',
        amount,
        percentage: totalExpenseThisMonth > 0 ? Math.round((amount / totalExpenseThisMonth) * 100) : 0,
      };
    });

  const topCategory = sortedCategories[0];

  // Budget warnings
  const currentMonthStr = new Date().toISOString().slice(0, 7);
  const exceededBudgets = budgets
    .filter(b => b.month === currentMonthStr)
    .map(b => {
      const spent = transactions
        .filter(t => t.type === 'expense' && t.categoryId === b.categoryId && t.date.startsWith(currentMonthStr))
        .reduce((sum, t) => sum + t.amount, 0);
      const cat = categories.find(c => c.id === b.categoryId);
      return {
        categoryName: language === 'bn' ? cat?.nameBn || cat?.name : cat?.name,
        spent,
        limit: b.monthlyLimit,
        ratio: spent / b.monthlyLimit,
      };
    })
    .filter(item => item.ratio >= 0.8);

  const moneyLeakAnalysis = analyzeMoneyLeaks(transactions, categories, totalExpenseThisMonth, language);

  const handleRefreshAnalysis = () => {
    setAnalyzing(true);
    setTimeout(() => {
      setAnalyzing(false);
    }, 600);
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div 
        className="bg-white rounded-t-3xl sm:rounded-3xl w-full max-w-lg shadow-2xl border border-emerald-100 p-5 sm:p-6 space-y-4 max-h-[90dvh] sm:max-h-[88vh] overflow-y-auto pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        {/* Mobile drag handle */}
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden -mt-1 mb-2" />
        
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
              <Sparkles className="w-5 h-5 animate-spin-slow" />
            </div>
            <div>
              <h3 className="font-bold text-slate-800 text-sm sm:text-base">
                {language === 'bn' ? 'স্মার্ট ফাইন্যান্সিয়াল এডভাইজর' : 'Smart Financial Advisor'}
              </h3>
              <p className="text-[11px] sm:text-xs text-slate-500">
                {language === 'bn' ? 'আপনার খরচ বিশ্লেষণ ও সঞ্চয় বৃদ্ধির কৌশল' : 'Automated analysis of your spending habits'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Health score badge */}
        <div className="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200/80 rounded-2xl p-4 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-800">
              {language === 'bn' ? 'আর্থিক স্বাস্থ্য স্কোর' : 'Financial Health Score'}
            </span>
            <div className="text-2xl font-black text-emerald-950 mt-0.5">
              {savingsRateThisMonth > 30 ? '88/100' : savingsRateThisMonth > 10 ? '74/100' : '58/100'}{' '}
              <span className="text-sm font-semibold text-emerald-700">
                {savingsRateThisMonth > 30 
                  ? (language === 'bn' ? 'খুব চমৎকার!' : 'Excellent!') 
                  : (language === 'bn' ? 'মোটামুটি ভালো' : 'Moderate')}
              </span>
            </div>
          </div>
          <button
            onClick={handleRefreshAnalysis}
            disabled={analyzing}
            className="p-2 rounded-xl bg-white hover:bg-emerald-100 text-emerald-700 shadow-xs border border-emerald-200 transition-colors"
            title="Refresh Analysis"
          >
            <RefreshCw className={`w-4 h-4 ${analyzing ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {/* Generated Actionable Insights */}
        <div className="space-y-3">
          <p className="text-xs font-bold uppercase tracking-wider text-slate-400">
            {language === 'bn' ? 'গুরুত্বপূর্ণ অন্তর্দৃষ্টি' : 'Key Spending Takeaways'}
          </p>

          {/* Insight 1: Savings Rate */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/60">
            <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-bold text-slate-800">
                {language === 'bn' ? 'সঞ্চয়ের অনুপাত' : 'Monthly Savings Rate'}: {savingsRateThisMonth}%
              </p>
              <p className="text-slate-600 mt-0.5">
                {savingsRateThisMonth >= 20
                  ? (language === 'bn'
                      ? 'অসাধারণ! আপনি মানসম্মত ২০%+ সঞ্চয়ের লক্ষ্যমাত্রা বজায় রেখেছেন।'
                      : 'Great! You are hitting the recommended 20%+ monthly savings benchmark.')
                  : (language === 'bn'
                      ? 'সঞ্চয় আরও বাড়ানোর সুযোগ আছে। অপ্রয়োজনীয় ছোট ছোট খরচ কমানোর চেষ্টা করুন।'
                      : 'Try cutting discretionary spends to boost your savings buffer toward 20%.')}
              </p>
            </div>
          </div>

          {/* Insight 2: Top Expense Category */}
          {topCategory && (
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-slate-50 border border-slate-200/60">
              <TrendingDown className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-slate-800">
                  {language === 'bn' ? 'সর্বোচ্চ খরচের খাত' : 'Top Spending Category'}: {topCategory.name}
                </p>
                <p className="text-slate-600 mt-0.5">
                  {language === 'bn'
                    ? `এই খাতে মোট ${formatMoney(topCategory.amount)} খরচ হয়েছে যা আপনার মোট ব্যয়ের প্রায় ${topCategory.percentage}%।`
                    : `You spent ${formatMoney(topCategory.amount)} here, accounting for ${topCategory.percentage}% of your expenses.`}
                </p>
              </div>
            </div>
          )}

          {/* Insight 3: Budget Warnings */}
          {exceededBudgets.length > 0 ? (
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-rose-50 border border-rose-200/60">
              <AlertCircle className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-rose-900">
                  {language === 'bn' ? 'বাজেট সতর্কতা' : 'Budget Alerts'}
                </p>
                <p className="text-rose-700 mt-0.5">
                  {exceededBudgets.map(b => `${b.categoryName} (${Math.round(b.ratio * 100)}%)`).join(', ')} -{' '}
                  {language === 'bn' ? 'সীমার কাছাকাছি বা পার হয়ে গেছে!' : 'nearing or exceeded set monthly cap!'}
                </p>
              </div>
            </div>
          ) : (
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/60">
              <Lightbulb className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-emerald-900">
                  {language === 'bn' ? 'বাজেট নিয়ন্ত্রণ চমৎকার' : 'All Budgets Well Controlled'}
                </p>
                <p className="text-emerald-700 mt-0.5">
                  {language === 'bn'
                    ? 'আপনার সকল ক্যাটাগরি বাজেটের সীমার ভেতরে রয়েছে।'
                    : 'All your tracked categories are currently comfortably within limits.'}
                </p>
              </div>
            </div>
          )}

          {/* Insight: Money Leak Detector */}
          <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-rose-50 border border-rose-200/80">
            <Droplets className="w-5 h-5 text-rose-600 shrink-0 mt-0.5" />
            <div className="text-xs flex-1">
              <div className="flex items-center justify-between">
                <p className="font-bold text-rose-950">
                  {language === 'bn' ? 'মানি লিক ডিটেক্টর' : 'Money Leak Detector'}
                </p>
                {moneyLeakAnalysis.detectedLeaksCount > 0 && (
                  <span className="text-[10px] font-extrabold text-rose-800 bg-rose-200/60 px-2 py-0.5 rounded-full">
                    -{formatMoney(moneyLeakAnalysis.totalMonthlyLeak)}/{language === 'bn' ? 'মাস' : 'mo'}
                  </span>
                )}
              </div>
              <p className="text-rose-800 mt-1 leading-relaxed">
                {language === 'bn' ? moneyLeakAnalysis.insightSummaryBn : moneyLeakAnalysis.insightSummaryEn}
              </p>
            </div>
          </div>

          {/* Insight 4: Portfolio & Passive Yield */}
          {totalPortfolioValue > 0 && (
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-teal-50 border border-teal-200/60">
              <Landmark className="w-5 h-5 text-teal-700 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-teal-950">
                  {language === 'bn' ? 'বিনিয়োগ পোর্টফোলিও ও ডিপিএস' : 'Wealth & Investments'}: {formatMoney(totalPortfolioValue)}
                </p>
                <p className="text-teal-800 mt-0.5">
                  {language === 'bn'
                    ? `সঞ্চয়পত্র ও অন্যান্য সম্পদ থেকে প্রতি মাসে প্রায় +${formatMoney(totalMonthlyEstimatedYield)} সম্ভাব্য প্যাসিভ মুনাফা অর্জিত হচ্ছে।${
                        upcomingDPSInstallments[0]
                          ? ` পরবর্তী ডিপিএস কিস্তি: 📅 ${upcomingDPSInstallments[0].nextInstallmentDueDate}`
                          : ''
                      }`
                    : `Your portfolio generates ~+${formatMoney(totalMonthlyEstimatedYield)} in estimated monthly passive yield.${
                        upcomingDPSInstallments[0]
                          ? ` Next DPS installment due: ${upcomingDPSInstallments[0].nextInstallmentDueDate}`
                          : ''
                      }`}
                </p>
              </div>
            </div>
          )}

          {/* Insight 5: Active Tour & Event Budget */}
          {activeTrip && (() => {
            const tripSpent = activeTrip.expenses.reduce((s, e) => s + e.amount, 0);
            const spentPercent = activeTrip.totalBudget > 0 ? Math.round((tripSpent / activeTrip.totalBudget) * 100) : 0;
            const packedCount = activeTrip.packingList.filter(p => p.isPacked).length;
            return (
              <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200/60">
                <Compass className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <p className="font-bold text-emerald-950 flex items-center justify-between">
                    <span>
                      {language === 'bn' ? 'চলতি ট্যুর ট্র্যাকার' : 'Active Trip Tracker'}: {activeTrip.titleBn || activeTrip.title}
                    </span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-200 text-emerald-800 font-black">
                      {spentPercent}% {language === 'bn' ? 'ব্যয়' : 'spent'}
                    </span>
                  </p>
                  <p className="text-emerald-800 mt-1">
                    {language === 'bn'
                      ? `বাজেট ${formatMoney(activeTrip.totalBudget)}-এর মধ্যে মোট ${formatMoney(tripSpent)} খরচ হয়েছে। প্যাকিং চেকলিস্ট: ${packedCount}/${activeTrip.packingList.length} টি প্রস্তুত।`
                      : `Spent ${formatMoney(tripSpent)} of ${formatMoney(activeTrip.totalBudget)} allocated. Packing: ${packedCount}/${activeTrip.packingList.length} packed.`}
                  </p>
                </div>
              </div>
            );
          })()}

          {/* Insight 6: No-Spend Streak & Gamified Restraint */}
          {currentNoSpendStreak > 0 && (
            <div className="flex items-start gap-3 p-3.5 rounded-2xl bg-amber-50 border border-amber-200/60">
              <Flame className="w-5 h-5 text-amber-600 fill-amber-500 shrink-0 mt-0.5" />
              <div className="text-xs">
                <p className="font-bold text-amber-950 flex items-center justify-between">
                  <span>
                    {language === 'bn' ? '🔥 টানা নো-স্পেন্ড স্ট্রিক' : '🔥 Active No-Spend Streak'}: {currentNoSpendStreak} {language === 'bn' ? 'দিন' : 'Days'}
                  </span>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-200 text-amber-900 font-black">
                    Level {userLevel} · {userXP} XP
                  </span>
                </p>
                <p className="text-amber-800 mt-1 leading-relaxed">
                  {language === 'bn'
                    ? `দারুণ সংযম! টানা ${currentNoSpendStreak} দিন কোনো অপচয় বা অপ্রয়োজনীয় খরচ না করে আপনি সঞ্চয়ের আদর্শ শৃঙ্খলা বজায় রেখেছেন।`
                    : `Incredible financial discipline! Maintaining a ${currentNoSpendStreak}-day streak is actively stopping impulse leaks.`}
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Actionable Suggestions */}
        <div className="p-3.5 rounded-2xl bg-emerald-600 text-white text-xs space-y-1.5 shadow-sm">
          <p className="font-bold flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-emerald-200" />
            {language === 'bn' ? 'আজকের জন্য করণীয় পরামর্শ' : 'Actionable Recommendation'}
          </p>
          <p className="text-emerald-50 leading-relaxed">
            {language === 'bn'
              ? 'দৈনিক খরচের একটি নির্ধারিত সিলিং রাখুন। প্রতিদিনের ছোট নাস্তা বা অনলাইন অর্ডার ট্র্যাক করলে মাসে ১৫-২০% সহজে বাঁচানো যায়।'
              : 'Keep a daily spend ceiling. Small regular expenses like daily outside snacks or takeaway add up; tracking every coin saves 15-20% easily.'}
          </p>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-900 rounded-xl"
          >
            {language === 'bn' ? 'ঠিক আছে' : 'Got it'}
          </button>
        </div>

      </div>
    </div>
  );
};
