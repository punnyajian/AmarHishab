import React, { useState, useEffect } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { ActiveTab } from '../types';
import {
  LayoutDashboard,
  Calendar,
  ReceiptText,
  Target,
  Landmark,
  CreditCard,
  HandCoins,
  CalendarClock,
  Bell,
  PiggyBank,
  TrendingUp,
  FileBarChart,
  Settings as SettingsIcon,
  Leaf,
  ChevronDown,
  ShoppingBag,
  BrainCircuit,
  Compass,
  CookingPot,
  Flame,
  Scale,
  User,
  UsersRound,
  Hourglass,
  Coins,
  X,
  PanelLeftClose,
  PanelLeftOpen,
  ShieldAlert,
} from 'lucide-react';
import wolfImage from '../assets/images/wolf_mindset_landscape_1791559675074.jpg';
import { useLockBodyScroll } from '../utils/useLockBodyScroll';

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  isOpen: propIsOpen,
  onClose: propOnClose,
  isCollapsed: propIsCollapsed,
  onToggleCollapse: propOnToggleCollapse,
}) => {
  const {
    activeTab,
    setActiveTab,
    walletSubTab,
    setWalletSubTab,
    subscriptionFilterTab,
    setSubscriptionFilterTab,
    language,
    currentUser,
    isSidebarOpen,
    setIsSidebarOpen,
    isSidebarCollapsed,
    toggleSidebarCollapsed,
    unreadNotificationsCount,
    setIsNotificationCenterOpen,
    rankedPaymentObligations,
  } = useExpense();

  // Determine effective mobile drawer open state & desktop collapsed state
  const isMobileOpen = propIsOpen !== undefined ? propIsOpen : isSidebarOpen;
  const handleClose = propOnClose || (() => setIsSidebarOpen(false));
  const isCollapsed = propIsCollapsed !== undefined ? propIsCollapsed : isSidebarCollapsed;
  const handleToggleCollapse = propOnToggleCollapse || toggleSidebarCollapsed;

  // Lock body scroll only when mobile drawer is open
  useLockBodyScroll(isMobileOpen);

  // Close mobile drawer on Escape key
  useEffect(() => {
    if (!isMobileOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        handleClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isMobileOpen, handleClose]);

  const criticalObligationsCount = (rankedPaymentObligations || []).filter(
    (item) => item.scoreBreakdown?.level === 'critical' || item.obligation?.isOverdue
  ).length;

  // Primary menu items (Core financial workflow)
  const primaryMenuItems: {
    id: ActiveTab;
    label: string;
    icon: any;
    action?: () => void;
    isCurrentActive?: boolean;
    badge?: string;
  }[] = [
    {
      id: 'dashboard',
      label: language === 'bn' ? 'ড্যাশবোর্ড' : 'Dashboard',
      icon: LayoutDashboard,
      action: () => setActiveTab('dashboard'),
      isCurrentActive: activeTab === 'dashboard',
    },
    {
      id: 'payment_priority',
      label: language === 'bn' ? 'পেমেন্ট প্রায়োরিটি' : 'Payment Priority',
      icon: ShieldAlert,
      badge: criticalObligationsCount > 0 ? String(criticalObligationsCount) : undefined,
      action: () => setActiveTab('payment_priority'),
      isCurrentActive: activeTab === 'payment_priority',
    },
    {
      id: 'calendar',
      label: language === 'bn' ? 'ক্যাশফ্লো ক্যালেন্ডার' : 'Cashflow Calendar',
      icon: Calendar,
      action: () => setActiveTab('calendar'),
      isCurrentActive: activeTab === 'calendar',
    },
    {
      id: 'transactions',
      label: language === 'bn' ? 'লেনদেন' : 'Transactions',
      icon: ReceiptText,
      action: () => setActiveTab('transactions'),
      isCurrentActive: activeTab === 'transactions',
    },
    {
      id: 'budgets',
      label: language === 'bn' ? 'বাজেট' : 'Budgets',
      icon: Target,
      action: () => setActiveTab('budgets'),
      isCurrentActive: activeTab === 'budgets',
    },
    {
      id: 'wallets',
      label: language === 'bn' ? 'অ্যাকাউন্ট' : 'Accounts',
      icon: Landmark,
      action: () => {
        setActiveTab('wallets');
        setWalletSubTab('accounts');
      },
      isCurrentActive: activeTab === 'wallets' && walletSubTab === 'accounts',
    },
    {
      id: 'wallets',
      label: language === 'bn' ? 'কার্ড' : 'Cards',
      icon: CreditCard,
      action: () => {
        setActiveTab('wallets');
        setWalletSubTab('cards');
      },
      isCurrentActive: activeTab === 'wallets' && walletSubTab === 'cards',
    },
    {
      id: 'debts',
      label: language === 'bn' ? 'ঋণ ও ইএমআই' : 'Loans & EMI',
      icon: HandCoins,
      action: () => setActiveTab('debts'),
      isCurrentActive: activeTab === 'debts',
    },
    {
      id: 'subscriptions',
      label: language === 'bn' ? 'সাবস্ক্রিপশন' : 'Subscriptions',
      icon: CalendarClock,
      action: () => {
        setActiveTab('subscriptions');
        setSubscriptionFilterTab('all');
      },
      isCurrentActive: activeTab === 'subscriptions' && subscriptionFilterTab === 'all',
    },
    {
      id: 'subscriptions',
      label: language === 'bn' ? 'নোটিফিকেশন ও রিমাইন্ডার' : 'Alerts & Reminders',
      icon: Bell,
      badge: unreadNotificationsCount > 0 ? String(unreadNotificationsCount) : undefined,
      action: () => {
        setIsNotificationCenterOpen(true);
      },
      isCurrentActive: false,
    },
    {
      id: 'goals',
      label: language === 'bn' ? 'সঞ্চয় লক্ষ্য' : 'Savings Goals',
      icon: PiggyBank,
      action: () => setActiveTab('goals'),
      isCurrentActive: activeTab === 'goals',
    },
    {
      id: 'analytics',
      label: language === 'bn' ? 'নেট ওর্থ' : 'Net Worth',
      icon: TrendingUp,
      action: () => setActiveTab('analytics'),
      isCurrentActive: activeTab === 'analytics',
    },
    {
      id: 'analytics',
      label: language === 'bn' ? 'রিপোর্টস' : 'Reports',
      icon: FileBarChart,
      action: () => setActiveTab('analytics'),
      isCurrentActive: false,
    },
  ];

  // Secondary modules (Specialized financial tools) - All 10 items fully present
  const secondaryModules: {
    id: ActiveTab;
    label: string;
    icon: any;
    badge?: string;
  }[] = [
    {
      id: 'ai_control',
      label: language === 'bn' ? 'সেন্ট্রাল এআই' : 'Central AI Control',
      icon: BrainCircuit,
    },
    {
      id: 'bazar',
      label: language === 'bn' ? 'কাঁচাবাজার' : 'Smart Bazar',
      icon: ShoppingBag,
    },
    {
      id: 'investments',
      label: language === 'bn' ? 'বিনিয়োগ ও স্বর্ণ' : 'Investments & Gold',
      icon: Coins,
    },
    {
      id: 'tax_zakat',
      label: language === 'bn' ? 'ট্যাক্স ও যাকাত' : 'Tax & Zakat',
      icon: Scale,
    },
    {
      id: 'mess',
      label: language === 'bn' ? 'মেস ম্যানেজার' : 'Mess Manager',
      icon: CookingPot,
    },
    {
      id: 'trips',
      label: language === 'bn' ? 'ট্যুর প্ল্যানার' : 'Trips & Tours',
      icon: Compass,
    },
    {
      id: 'challenges',
      label: language === 'bn' ? 'চ্যালেঞ্জ ও স্ট্রিক' : 'Savings Challenges',
      icon: Flame,
    },
    {
      id: 'wishlist',
      label: language === 'bn' ? 'উইশলিস্ট ও কুলিং' : 'Mindful Wishlist',
      icon: Hourglass,
    },
    {
      id: 'split',
      label: language === 'bn' ? 'বিল ভাগাভাগি' : 'Split Group Bill',
      icon: UsersRound,
    },
    {
      id: 'profile',
      label: currentUser
        ? currentUser.displayName || currentUser.email?.split('@')[0] || (language === 'bn' ? 'প্রোফাইল' : 'Profile')
        : (language === 'bn' ? 'প্রোফাইল' : 'Profile'),
      icon: User,
    },
  ];

  // Determine if any secondary module is currently active
  const isSecondaryActive = secondaryModules.some(m => m.id === activeTab);

  // Default showMoreModules to true so all sidebar options are readily accessible and visible
  const [showMoreModules, setShowMoreModules] = useState<boolean>(true);

  // If activeTab switches to a secondary module, make sure section is expanded
  useEffect(() => {
    if (isSecondaryActive) {
      setShowMoreModules(true);
    }
  }, [isSecondaryActive]);

  const handleNavClick = (tab: ActiveTab, customAction?: () => void) => {
    if (customAction) {
      customAction();
    } else {
      setActiveTab(tab);
    }
    // On mobile, dismiss drawer after navigation
    if (isMobileOpen) {
      handleClose();
    }
  };

  // Reusable Sidebar content body
  const renderSidebarContent = (isMobileVariant: boolean) => (
    <div className="flex flex-col h-full justify-between">
      {/* Brand Header */}
      <div className={`px-4 py-4.5 border-b border-slate-100/90 flex items-center justify-between shrink-0 ${!isMobileVariant && isCollapsed ? 'px-2 justify-center' : ''}`}>
        <div className={`flex items-center gap-3 ${!isMobileVariant && isCollapsed ? 'justify-center' : ''}`}>
          <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-emerald-600 to-emerald-400 flex items-center justify-center text-white shadow-sm shrink-0">
            <Leaf className="w-5 h-5 fill-white/20 stroke-white stroke-[2.2]" />
          </div>
          {(isMobileVariant || !isCollapsed) && (
            <div className="min-w-0">
              <h1 className="text-base font-extrabold text-slate-900 tracking-tight leading-tight truncate">
                {language === 'bn' ? 'আমার হিসাব' : 'AmarHishab'}
              </h1>
              <p className="text-[11px] font-medium text-emerald-600 truncate">
                {language === 'bn' ? 'স্মার্ট খরচ ও বাজেট ট্র্যাকার' : 'Smart Financial Manager'}
              </p>
            </div>
          )}
        </div>

        {/* Mobile Close Button */}
        {isMobileVariant && (
          <button
            type="button"
            onClick={handleClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors cursor-pointer"
            aria-label="Close sidebar"
          >
            <X className="w-5 h-5" />
          </button>
        )}

        {/* Desktop Collapse / Expand Toggle Button */}
        {!isMobileVariant && (
          <button
            type="button"
            onClick={handleToggleCollapse}
            className={`p-1.5 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer ${isCollapsed ? 'hidden' : 'block'}`}
            title={language === 'bn' ? 'সাইডবার ছোট করুন' : 'Collapse sidebar'}
            aria-label="Toggle sidebar collapse"
          >
            <PanelLeftClose className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Main Navigation Scroll Area - h-[100dvh] constraint with overflow-y-auto */}
      <div className="flex-1 overflow-y-auto overscroll-contain px-3 py-3 space-y-4 custom-scrollbar">
        {/* Core Menu */}
        <div>
          {(isMobileVariant || !isCollapsed) && (
            <div className="px-3 pb-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'প্রধান মেনু' : 'Core Menu'}
            </div>
          )}
          <nav className="space-y-0.5">
            {primaryMenuItems.map((item, index) => {
              const Icon = item.icon;
              const isActive = item.isCurrentActive ?? (activeTab === item.id);

              return (
                <button
                  key={`${item.id}-${index}`}
                  onClick={() => handleNavClick(item.id, item.action)}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                    isActive
                      ? 'bg-emerald-50/90 text-emerald-800 font-bold shadow-2xs'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                  } ${!isMobileVariant && isCollapsed ? 'justify-center px-2' : ''}`}
                  title={!isMobileVariant && isCollapsed ? item.label : undefined}
                >
                  <Icon
                    className={`w-4 h-4 transition-colors shrink-0 ${
                      isActive ? 'text-emerald-700 stroke-[2.3]' : 'text-slate-400 stroke-[1.8]'
                    }`}
                  />
                  {(isMobileVariant || !isCollapsed) && (
                    <span className="truncate text-left flex-1">{item.label}</span>
                  )}
                  {(isMobileVariant || !isCollapsed) && item.badge && (
                    <span className="ml-auto px-1.5 py-0.5 text-[10px] font-bold rounded-full bg-rose-500 text-white animate-pulse">
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Specialized Modules Section - Fully accessible, never hidden */}
        <div className="pt-1 border-t border-slate-100/90">
          {(isMobileVariant || !isCollapsed) ? (
            <button
              type="button"
              onClick={() => setShowMoreModules(!showMoreModules)}
              className="w-full flex items-center justify-between px-3 py-1.5 rounded-lg text-[10px] font-bold text-slate-400 uppercase tracking-wider hover:text-slate-700 transition-colors cursor-pointer mb-1"
            >
              <span>{language === 'bn' ? 'বিশেষ সুবিধাসমূহ' : 'Specialized Tools'}</span>
              <ChevronDown
                className={`w-3.5 h-3.5 transition-transform duration-200 ${
                  showMoreModules ? 'rotate-180 text-emerald-600' : 'text-slate-400'
                }`}
              />
            </button>
          ) : (
            <div className="w-full border-t border-slate-100 my-2" />
          )}

          {showMoreModules && (
            <nav className="space-y-0.5">
              {secondaryModules.map(item => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;

                return (
                  <button
                    key={item.id}
                    onClick={() => handleNavClick(item.id)}
                    className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
                      isActive
                        ? 'bg-emerald-50/90 text-emerald-800 font-bold shadow-2xs'
                        : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
                    } ${!isMobileVariant && isCollapsed ? 'justify-center px-2' : ''}`}
                    title={!isMobileVariant && isCollapsed ? item.label : undefined}
                  >
                    <Icon
                      className={`w-4 h-4 transition-colors shrink-0 ${
                        isActive ? 'text-emerald-700 stroke-[2.3]' : 'text-slate-400 stroke-[1.8]'
                      }`}
                    />
                    {(isMobileVariant || !isCollapsed) && (
                      <span className="truncate text-left">{item.label}</span>
                    )}
                  </button>
                );
              })}
            </nav>
          )}
        </div>

        {/* Settings & Preferences */}
        <div className="pt-1 border-t border-slate-100/90">
          {(isMobileVariant || !isCollapsed) && (
            <div className="px-3 pb-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {language === 'bn' ? 'সিস্টেম' : 'System'}
            </div>
          )}
          <button
            onClick={() => handleNavClick('settings')}
            className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-xs font-semibold transition-all duration-150 cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-emerald-50/90 text-emerald-800 font-bold shadow-2xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
            } ${!isMobileVariant && isCollapsed ? 'justify-center px-2' : ''}`}
            title={!isMobileVariant && isCollapsed ? (language === 'bn' ? 'সেটিংস' : 'Settings') : undefined}
          >
            <SettingsIcon
              className={`w-4 h-4 transition-colors shrink-0 ${
                activeTab === 'settings' ? 'text-emerald-700 stroke-[2.3]' : 'text-slate-400 stroke-[1.8]'
              }`}
            />
            {(isMobileVariant || !isCollapsed) && (
              <span className="truncate text-left">{language === 'bn' ? 'সেটিংস' : 'Settings'}</span>
            )}
          </button>
        </div>

        {/* Bottom Wolf Mindset Card - Inside the scroll area so nothing is clipped */}
        {(isMobileVariant || !isCollapsed) && (
          <div className="pt-3 pb-6">
            <div className="rounded-2xl overflow-hidden border border-emerald-100/80 shadow-xs relative group bg-gradient-to-b from-emerald-50/50 to-teal-50/70 p-4">
              <div className="relative z-10 space-y-1.5">
                <div className="w-8 h-8 rounded-xl bg-white/90 shadow-2xs flex items-center justify-center text-slate-800 mb-2">
                  <span className="text-base leading-none">🐺</span>
                </div>
                <h4 className="text-xs font-black text-slate-900 leading-snug tracking-tight">
                  Discipline today builds freedom tomorrow.
                </h4>
                <p className="text-[10px] font-bold text-emerald-700 flex items-center gap-1 pt-0.5">
                  <span>👑</span>
                  <span>Wolf Mindset</span>
                </p>
              </div>

              <div
                className="absolute inset-0 opacity-20 pointer-events-none bg-cover bg-right"
                style={{ backgroundImage: `url(${wolfImage})` }}
              />
            </div>
          </div>
        )}
      </div>

      {/* When collapsed on desktop: Bottom expand icon */}
      {!isMobileVariant && isCollapsed && (
        <div className="p-3 border-t border-slate-100 flex justify-center shrink-0">
          <button
            type="button"
            onClick={handleToggleCollapse}
            className="p-2 rounded-xl text-slate-400 hover:text-slate-700 hover:bg-slate-100 transition-colors cursor-pointer"
            title={language === 'bn' ? 'সাইডবার প্রসারিত করুন' : 'Expand sidebar'}
            aria-label="Expand sidebar"
          >
            <PanelLeftOpen className="w-4 h-4" />
          </button>
        </div>
      )}
    </div>
  );

  return (
    <>
      {/* 1. Desktop Permanent Sidebar (lg:flex) with 100dvh height */}
      <aside
        className={`hidden lg:flex flex-col bg-white border-r border-slate-200/80 shrink-0 h-[100dvh] max-h-[100dvh] sticky top-0 z-20 no-print select-none transition-all duration-200 ${
          isCollapsed ? 'w-[76px]' : 'w-[260px]'
        }`}
      >
        {renderSidebarContent(false)}
      </aside>

      {/* 2. Mobile & Tablet Slide-in Off-Canvas Drawer (< lg) */}
      {isMobileOpen && (
        <div
          className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex lg:hidden animate-in fade-in duration-150 no-print"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              e.stopPropagation();
              handleClose();
            }
          }}
          onMouseDown={(e) => {
            if (e.target === e.currentTarget) e.stopPropagation();
          }}
        >
          <div
            className="w-[290px] max-w-[85vw] h-[100dvh] bg-white shadow-2xl flex flex-col animate-in slide-in-from-left duration-200"
            onClick={(e) => e.stopPropagation()}
            onMouseDown={(e) => e.stopPropagation()}
          >
            {renderSidebarContent(true)}
          </div>
        </div>
      )}
    </>
  );
};
