import React, { useState } from 'react';
import {
  X,
  Bell,
  Calendar,
  Clock,
  DollarSign,
  Repeat,
  FileText,
  Sparkles,
  Zap,
  Wifi,
  Home,
  PiggyBank,
  GraduationCap,
  CreditCard,
} from 'lucide-react';
import { useExpense } from '../../context/ExpenseContext';

interface AddReminderModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const AddReminderModal: React.FC<AddReminderModalProps> = ({ isOpen, onClose }) => {
  const {
    addCustomReminder,
    currency,
    language,
  } = useExpense();

  const [title, setTitle] = useState('');
  const [amount, setAmount] = useState('');
  const [dueDate, setDueDate] = useState(() => new Date().toISOString().slice(0, 10));
  const [dueTime, setDueTime] = useState('20:00');
  const [repeat, setRepeat] = useState<'none' | 'daily' | 'weekly' | 'monthly'>('none');
  const [notes, setNotes] = useState('');
  const [category, setCategory] = useState('');

  if (!isOpen) return null;

  const quickPresets = [
    { label: language === 'bn' ? 'বিদ্যুৎ বিল' : 'Electricity Bill', icon: Zap, cat: 'utility' },
    { label: language === 'bn' ? 'ওয়াইফাই বিল' : 'WiFi Bill', icon: Wifi, cat: 'internet' },
    { label: language === 'bn' ? 'বাসা ভাড়া' : 'House Rent', icon: Home, cat: 'rent' },
    { label: language === 'bn' ? 'ডিপিএস / সঞ্চয়' : 'DPS Savings', icon: PiggyBank, cat: 'savings' },
    { label: language === 'bn' ? 'টিউশন ফি' : 'Tuition Fee', icon: GraduationCap, cat: 'education' },
    { label: language === 'bn' ? 'ক্রেডিট কার্ড' : 'Credit Card', icon: CreditCard, cat: 'card' },
  ];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    addCustomReminder({
      title: title.trim(),
      amount: amount ? parseFloat(amount) : undefined,
      dueDate,
      dueTime,
      repeat,
      notes: notes.trim() || undefined,
      category: category || undefined,
    });

    setTitle('');
    setAmount('');
    setNotes('');
    setRepeat('none');
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-100 w-full max-w-lg overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4.5 bg-gradient-to-r from-emerald-600 to-teal-700 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/15 backdrop-blur-md rounded-xl text-emerald-100">
              <Bell className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {language === 'bn' ? 'নতুন রিমাইন্ডার যোগ করুন' : 'Add New Reminder'}
              </h3>
              <p className="text-xs text-emerald-100/90 font-medium">
                {language === 'bn' ? 'বিল, কিস্তি বা যে কোনো আর্থিক ডেডলাইনের সতর্কতা' : 'Set alerts for bills, dues, or financial deadlines'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Form */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-4">
          {/* Quick Presets */}
          <div>
            <label className="block text-xs font-semibold text-slate-500 mb-2 uppercase tracking-wider">
              {language === 'bn' ? 'কুইক প্রিসেট (ট্যাপ করুন)' : 'Quick Presets (Tap to fill)'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {quickPresets.map((preset, idx) => {
                const Icon = preset.icon;
                return (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setTitle(preset.label);
                      setCategory(preset.cat);
                    }}
                    className={`flex items-center gap-1.5 p-2 rounded-xl border text-xs font-medium transition-all ${
                      title === preset.label
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-700 ring-2 ring-emerald-500/20'
                        : 'bg-slate-50 border-slate-200 text-slate-700 hover:bg-slate-100'
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5 shrink-0 text-emerald-600" />
                    <span className="truncate">{preset.label}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Title */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {language === 'bn' ? 'রিমাইন্ডারের শিরোনাম *' : 'Reminder Title *'}
            </label>
            <div className="relative">
              <input
                type="text"
                required
                value={title}
                onChange={e => setTitle(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: বিদ্যুৎ বিল পরিশোধ, ডিপিএস জমা...' : 'e.g., Pay Electricity Bill, DPS deposit...'}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
              />
            </div>
          </div>

          {/* Amount & Currency */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {language === 'bn' ? `টাকার পরিমাণ (${currency.symbol}) [ঐচ্ছিক]` : `Amount (${currency.symbol}) [Optional]`}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <DollarSign className="w-4 h-4" />
              </div>
              <input
                type="number"
                min="0"
                step="any"
                value={amount}
                onChange={e => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
              />
            </div>
          </div>

          {/* Date & Time Row */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {language === 'bn' ? 'তারিখ *' : 'Due Date *'}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Calendar className="w-4 h-4" />
                </div>
                <input
                  type="date"
                  required
                  value={dueDate}
                  onChange={e => setDueDate(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1.5">
                {language === 'bn' ? 'সময়' : 'Due Time'}
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                  <Clock className="w-4 h-4" />
                </div>
                <input
                  type="time"
                  value={dueTime}
                  onChange={e => setDueTime(e.target.value)}
                  className="w-full pl-9 pr-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />
              </div>
            </div>
          </div>

          {/* Repeat Frequency */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {language === 'bn' ? 'পুনরাবৃত্তি (Repeat)' : 'Repeat Frequency'}
            </label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                <Repeat className="w-4 h-4" />
              </div>
              <select
                value={repeat}
                onChange={e => setRepeat(e.target.value as any)}
                className="w-full pl-9 pr-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
              >
                <option value="none">{language === 'bn' ? 'একবার (No Repeat)' : 'Once (No Repeat)'}</option>
                <option value="daily">{language === 'bn' ? 'প্রতিদিন (Daily)' : 'Every Day (Daily)'}</option>
                <option value="weekly">{language === 'bn' ? 'প্রতি সপ্তাহে (Weekly)' : 'Weekly'}</option>
                <option value="monthly">{language === 'bn' ? 'প্রতি মাসে (Monthly)' : 'Monthly'}</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1.5">
              {language === 'bn' ? 'নোট বা বিবরণ (ঐচ্ছিক)' : 'Notes / Description (Optional)'}
            </label>
            <div className="relative">
              <div className="absolute top-3 left-3 flex items-center pointer-events-none text-slate-400">
                <FileText className="w-4 h-4" />
              </div>
              <textarea
                rows={2}
                value={notes}
                onChange={e => setNotes(e.target.value)}
                placeholder={language === 'bn' ? 'যেমন: একাউন্ট নম্বর, মিটার রিডিং বা বিশেষ তথ্য...' : 'e.g., Meter reading, account number...'}
                className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
              />
            </div>
          </div>

          {/* Footer Buttons */}
          <div className="pt-2 flex items-center justify-end gap-3 border-t border-slate-100">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-xl transition-colors"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="flex items-center gap-1.5 px-5 py-2.5 text-xs font-bold text-white bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 rounded-xl shadow-md shadow-emerald-600/20 transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'রিমাইন্ডার সেট করুন' : 'Set Reminder'}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
