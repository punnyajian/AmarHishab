import React, { useState } from 'react';
import {
  X,
  Bell,
  CheckCheck,
  Trash2,
  Clock,
  AlertTriangle,
  AlertCircle,
  Receipt,
  Wallet,
  Calendar,
  Send,
  Plus,
  Settings,
  Sparkles,
  ExternalLink,
  ChevronRight,
  ShieldCheck,
  CheckCircle2,
  Circle,
  Repeat,
  MessageCircle,
} from 'lucide-react';
import { useExpense } from '../../context/ExpenseContext';
import { AppNotification } from '../../types';

interface NotificationCenterModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenAddExpenseModal?: () => void;
}

type TabFilter = 'all' | 'bills' | 'budgets' | 'debts' | 'custom';

export const NotificationCenterModal: React.FC<NotificationCenterModalProps> = ({
  isOpen,
  onClose,
  onOpenAddExpenseModal,
}) => {
  const {
    notifications,
    unreadNotificationsCount,
    customReminders,
    markNotificationAsRead,
    markAllNotificationsAsRead,
    dismissNotification,
    snoozeNotification,
    clearAllNotifications,
    toggleCustomReminder,
    deleteCustomReminder,
    paySubscriptionBill,
    debts,
    sendWhatsAppDebtReminder,
    setActiveTab,
    setIsAddReminderModalOpen,
    setIsNotificationSettingsModalOpen,
    language,
    formatMoney,
  } = useExpense();

  const [activeTabFilter, setActiveTabFilter] = useState<TabFilter>('all');
  const [successToast, setSuccessToast] = useState<string | null>(null);

  if (!isOpen) return null;

  const showToast = (msg: string) => {
    setSuccessToast(msg);
    setTimeout(() => setSuccessToast(null), 3000);
  };

  const billsNotifications = notifications.filter(n => n.type === 'bill_due');
  const budgetsNotifications = notifications.filter(n => n.type === 'budget_warning');
  const debtsNotifications = notifications.filter(n => n.type === 'debt_due');

  const filteredNotifications = notifications.filter(n => {
    if (activeTabFilter === 'all') return true;
    if (activeTabFilter === 'bills') return n.type === 'bill_due';
    if (activeTabFilter === 'budgets') return n.type === 'budget_warning';
    if (activeTabFilter === 'debts') return n.type === 'debt_due';
    return true;
  });

  const handleNotificationAction = (n: AppNotification) => {
    markNotificationAsRead(n.id);

    if (n.actionType === 'pay_bill' && n.entityId) {
      const res = paySubscriptionBill(n.entityId);
      if (res.success) {
        showToast(language === 'bn' ? 'বিল সফলভাবে পরিশোধিত ও এন্ট্রি হয়েছে!' : 'Bill paid and recorded successfully!');
      } else {
        showToast(res.message);
      }
    } else if (n.actionType === 'collect_debt' && n.entityId) {
      const debt = debts.find(d => d.id === n.entityId);
      if (debt) {
        sendWhatsAppDebtReminder(debt);
      }
    } else if (n.actionType === 'view_budget') {
      setActiveTab('budgets');
      onClose();
    } else if (n.actionType === 'log_expense') {
      onClose();
      if (onOpenAddExpenseModal) {
        onOpenAddExpenseModal();
      }
    } else if (n.targetTab) {
      setActiveTab(n.targetTab);
      onClose();
    }
  };

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case 'danger':
        return 'bg-rose-100 text-rose-700 border-rose-200';
      case 'warning':
        return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'success':
        return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      default:
        return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  const getNotificationIcon = (type: string, severity: string) => {
    switch (type) {
      case 'bill_due':
        return <Receipt className={`w-4 h-4 ${severity === 'danger' ? 'text-rose-600' : 'text-amber-600'}`} />;
      case 'budget_warning':
        return <AlertTriangle className="w-4 h-4 text-rose-600" />;
      case 'debt_due':
        return <Wallet className="w-4 h-4 text-indigo-600" />;
      case 'low_balance':
        return <AlertCircle className="w-4 h-4 text-amber-600" />;
      case 'daily_log':
        return <Calendar className="w-4 h-4 text-emerald-600" />;
      default:
        return <Bell className="w-4 h-4 text-slate-600" />;
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-100 w-full max-w-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-4 bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white">
          <div className="flex items-center gap-3">
            <div className="relative p-2 bg-white/15 backdrop-blur-md rounded-xl text-white">
              <Bell className="w-5 h-5" />
              {unreadNotificationsCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[10px] font-bold rounded-full flex items-center justify-center ring-2 ring-white">
                  {unreadNotificationsCount}
                </span>
              )}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-bold text-base sm:text-lg">
                  {language === 'bn' ? 'নোটিফিকেশন ও রিমাইন্ডার হাব' : 'Notification & Reminder Hub'}
                </h3>
                <span className="text-[11px] font-semibold px-2 py-0.5 rounded-full bg-white/20 text-white">
                  {notifications.length} {language === 'bn' ? 'টি অ্যাক্টিভ' : 'active'}
                </span>
              </div>
              <p className="text-xs text-emerald-100/90 font-medium">
                {language === 'bn' ? 'বিল ডেডলাইন, ওভারস্পেন্ডিং সতর্কতা ও কাস্টম রিমাইন্ডার' : 'Bill deadlines, budget alerts & scheduled reminders'}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setIsNotificationSettingsModalOpen(true)}
              className="p-2 text-white/80 hover:text-white hover:bg-white/15 rounded-xl transition-colors"
              title={language === 'bn' ? 'নোটিফিকেশন সেটিংস' : 'Notification Settings'}
            >
              <Settings className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 text-white/80 hover:text-white hover:bg-white/15 rounded-xl transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Quick Action & Controls Bar */}
        <div className="px-5 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          {/* Tabs */}
          <div className="flex items-center gap-1 overflow-x-auto no-scrollbar py-0.5">
            <button
              onClick={() => setActiveTabFilter('all')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTabFilter === 'all'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              {language === 'bn' ? 'সব' : 'All'} ({notifications.length})
            </button>
            <button
              onClick={() => setActiveTabFilter('bills')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTabFilter === 'bills'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              {language === 'bn' ? 'বিল ও কিস্তি' : 'Bills'} ({billsNotifications.length})
            </button>
            <button
              onClick={() => setActiveTabFilter('budgets')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTabFilter === 'budgets'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              {language === 'bn' ? 'বাজেট সতর্কতা' : 'Budgets'} ({budgetsNotifications.length})
            </button>
            <button
              onClick={() => setActiveTabFilter('debts')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTabFilter === 'debts'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              {language === 'bn' ? 'ঋণ ও পাওনা' : 'Debts'} ({debtsNotifications.length})
            </button>
            <button
              onClick={() => setActiveTabFilter('custom')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-all ${
                activeTabFilter === 'custom'
                  ? 'bg-emerald-600 text-white shadow-sm'
                  : 'text-slate-600 hover:bg-slate-200/60'
              }`}
            >
              {language === 'bn' ? 'কাস্টম রিমাইন্ডার' : 'Custom'} ({customReminders.length})
            </button>
          </div>

          {/* Action Buttons */}
          <div className="flex items-center gap-1.5 ml-auto">
            <button
              onClick={() => setIsAddReminderModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-bold text-emerald-700 bg-emerald-100/70 hover:bg-emerald-200/70 rounded-lg transition-colors"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? '+ রিমাইন্ডার' : '+ Reminder'}</span>
            </button>
            {activeTabFilter !== 'custom' && notifications.length > 0 && (
              <>
                <button
                  onClick={markAllNotificationsAsRead}
                  className="flex items-center gap-1 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-slate-900 hover:bg-slate-200/60 rounded-lg transition-colors"
                  title={language === 'bn' ? 'সব পড়া হয়েছে হিসেবে মার্ক করুন' : 'Mark all as read'}
                >
                  <CheckCheck className="w-3.5 h-3.5" />
                  <span className="hidden sm:inline">{language === 'bn' ? 'পড়া হয়েছে' : 'Mark Read'}</span>
                </button>
                <button
                  onClick={clearAllNotifications}
                  className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  title={language === 'bn' ? 'সব পরিষ্কার করুন' : 'Clear all'}
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </>
            )}
          </div>
        </div>

        {/* Toast Notification */}
        {successToast && (
          <div className="px-5 py-2 bg-emerald-50 border-b border-emerald-200 text-emerald-800 text-xs font-bold flex items-center gap-2 animate-in fade-in">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            <span>{successToast}</span>
          </div>
        )}

        {/* List Content */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-3 flex-1 bg-slate-50/50">
          {activeTabFilter === 'custom' ? (
            /* Custom Reminders Tab */
            customReminders.length === 0 ? (
              <div className="py-12 px-4 text-center">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
                  <Calendar className="w-7 h-7" />
                </div>
                <h4 className="font-bold text-slate-800 text-sm sm:text-base mb-1">
                  {language === 'bn' ? 'কোনো কাস্টম রিমাইন্ডার তৈরি করা নেই' : 'No Custom Reminders Set'}
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">
                  {language === 'bn'
                    ? 'বিদ্যুৎ বিল, ডিপিএস বা বাসা ভাড়ার নিজস্ব তারিখ ও সময় দিয়ে রিমাইন্ডার সেট করে রাখুন।'
                    : 'Set custom reminders for bills, savings, or payments with your own schedule.'}
                </p>
                <button
                  onClick={() => setIsAddReminderModalOpen(true)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-md transition-all"
                >
                  <Plus className="w-4 h-4" />
                  <span>{language === 'bn' ? 'নতুন রিমাইন্ডার যোগ করুন' : 'Add First Reminder'}</span>
                </button>
              </div>
            ) : (
              <div className="space-y-2.5">
                {customReminders.map(rem => (
                  <div
                    key={rem.id}
                    className={`p-3.5 sm:p-4 rounded-xl border transition-all ${
                      rem.completed
                        ? 'bg-slate-100/60 border-slate-200 opacity-60'
                        : 'bg-white border-slate-200 shadow-sm hover:shadow'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex items-start gap-3">
                        <button
                          type="button"
                          onClick={() => toggleCustomReminder(rem.id)}
                          className="mt-0.5 text-slate-400 hover:text-emerald-600 transition-colors"
                        >
                          {rem.completed ? (
                            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
                          ) : (
                            <Circle className="w-5 h-5" />
                          )}
                        </button>
                        <div>
                          <div className="flex items-center gap-2 flex-wrap">
                            <h4 className={`text-sm font-bold ${rem.completed ? 'line-through text-slate-500' : 'text-slate-800'}`}>
                              {rem.title}
                            </h4>
                            {rem.amount && (
                              <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                                {formatMoney(rem.amount)}
                              </span>
                            )}
                            {rem.repeat && rem.repeat !== 'none' && (
                              <span className="flex items-center gap-1 text-[10px] font-semibold text-indigo-700 bg-indigo-50 px-1.5 py-0.5 rounded border border-indigo-200">
                                <Repeat className="w-2.5 h-2.5" />
                                {rem.repeat === 'daily'
                                  ? (language === 'bn' ? 'প্রতিদিন' : 'Daily')
                                  : rem.repeat === 'weekly'
                                  ? (language === 'bn' ? 'সাপ্তাহিক' : 'Weekly')
                                  : (language === 'bn' ? 'মাসিক' : 'Monthly')}
                              </span>
                            )}
                          </div>
                          {rem.notes && (
                            <p className="text-xs text-slate-500 mt-0.5">{rem.notes}</p>
                          )}
                          <div className="flex items-center gap-3 mt-2 text-[11px] text-slate-400 font-medium">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-3.5 h-3.5 text-slate-400" />
                              {rem.dueDate} {rem.dueTime}
                            </span>
                          </div>
                        </div>
                      </div>

                      <button
                        onClick={() => deleteCustomReminder(rem.id)}
                        className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                        title={language === 'bn' ? 'মুছে ফেলুন' : 'Delete'}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : (
            /* System & Dynamic Notifications Tab */
            filteredNotifications.length === 0 ? (
              <div className="py-12 px-4 text-center">
                <div className="w-14 h-14 bg-emerald-100 text-emerald-600 rounded-2xl flex items-center justify-center mx-auto mb-3 shadow-inner">
                  <ShieldCheck className="w-7 h-7" />
                </div>
                <h4 className="font-bold text-slate-800 text-sm sm:text-base mb-1">
                  {language === 'bn' ? 'কোনো নতুন সতর্কতা নেই!' : 'All Clear! No Active Alerts'}
                </h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  {language === 'bn'
                    ? 'আপনার সব বিল পরিশোধিত, বাজেট সীমার মধ্যে এবং হিসাব পুরোপুরি আপ-টু-ডেট।'
                    : 'All bills are up to date, budgets are safe, and your finances are on track.'}
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {filteredNotifications.map(n => (
                  <div
                    key={n.id}
                    className={`p-4 rounded-2xl border transition-all relative ${
                      !n.isRead
                        ? 'bg-white border-slate-300 shadow-sm ring-1 ring-emerald-500/10'
                        : 'bg-white/80 border-slate-200'
                    }`}
                  >
                    {!n.isRead && (
                      <span className="absolute top-3 right-3 w-2 h-2 rounded-full bg-emerald-500 ring-4 ring-emerald-100" />
                    )}

                    <div className="flex items-start gap-3">
                      <div className="p-2.5 rounded-xl bg-slate-100 shrink-0 mt-0.5">
                        {getNotificationIcon(n.type, n.severity)}
                      </div>

                      <div className="flex-1 min-w-0 pr-4">
                        <div className="flex items-center gap-2 flex-wrap mb-1">
                          <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${getSeverityBadge(n.severity)}`}>
                            {n.severity === 'danger'
                              ? (language === 'bn' ? 'জরুরি' : 'Urgent')
                              : n.severity === 'warning'
                              ? (language === 'bn' ? 'সতর্কতা' : 'Warning')
                              : (language === 'bn' ? 'তথ্য' : 'Info')}
                          </span>
                          <h4 className="text-xs sm:text-sm font-bold text-slate-800">
                            {language === 'bn' ? n.titleBn : n.title}
                          </h4>
                          {n.amount && (
                            <span className="text-xs font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md border border-emerald-200">
                              {formatMoney(n.amount)}
                            </span>
                          )}
                        </div>

                        <p className="text-xs text-slate-600 leading-relaxed mb-3">
                          {language === 'bn' ? n.messageBn : n.message}
                        </p>

                        {/* Action Buttons Row */}
                        <div className="flex items-center gap-2 flex-wrap pt-1 border-t border-slate-100">
                          {/* Primary Action Button */}
                          {n.actionType === 'pay_bill' && (
                            <button
                              type="button"
                              onClick={() => handleNotificationAction(n)}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
                            >
                              <Receipt className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'পরিশোধ করুন' : 'Pay Now'}</span>
                            </button>
                          )}

                          {n.actionType === 'collect_debt' && (
                            <button
                              type="button"
                              onClick={() => handleNotificationAction(n)}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
                            >
                              <MessageCircle className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'হোয়াটসঅ্যাপে তাগাদা' : 'Send WhatsApp Reminder'}</span>
                            </button>
                          )}

                          {n.actionType === 'view_budget' && (
                            <button
                              type="button"
                              onClick={() => handleNotificationAction(n)}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-900 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
                            >
                              <ExternalLink className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'বাজেট দেখুন' : 'View Budget'}</span>
                            </button>
                          )}

                          {n.actionType === 'log_expense' && (
                            <button
                              type="button"
                              onClick={() => handleNotificationAction(n)}
                              className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-lg shadow-sm transition-all"
                            >
                              <Plus className="w-3.5 h-3.5" />
                              <span>{language === 'bn' ? 'খরচ যোগ করুন' : 'Log Expense'}</span>
                            </button>
                          )}

                          {/* Snooze Button */}
                          <button
                            type="button"
                            onClick={() => snoozeNotification(n.id, 1)}
                            className="flex items-center gap-1 px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold rounded-lg transition-colors"
                            title={language === 'bn' ? 'আগামীকাল পর্যন্ত স্নুজ করুন' : 'Snooze for 1 day'}
                          >
                            <Clock className="w-3 h-3 text-slate-500" />
                            <span>{language === 'bn' ? '১ দিন পেছান' : 'Snooze'}</span>
                          </button>

                          {/* Dismiss Button */}
                          <button
                            type="button"
                            onClick={() => dismissNotification(n.id)}
                            className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg ml-auto transition-colors"
                            title={language === 'bn' ? 'মুছে ফেলুন' : 'Dismiss'}
                          >
                            <X className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )
          )}
        </div>

        {/* Footer */}
        <div className="px-5 py-3 bg-slate-50 border-t border-slate-200 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>{language === 'bn' ? 'লাইভ সিনক্রোনাইজড রিমাইন্ডার' : 'Live synchronized alerts'}</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-1.5 font-bold text-slate-700 hover:bg-slate-200 rounded-lg transition-colors"
          >
            {language === 'bn' ? 'বন্ধ করুন' : 'Close'}
          </button>
        </div>
      </div>
    </div>
  );
};
