import React, { useState } from 'react';
import {
  X,
  Settings,
  Volume2,
  VolumeX,
  Bell,
  Clock,
  AlertTriangle,
  Calendar,
  Wallet,
  CheckCircle2,
  Send,
  Sparkles,
} from 'lucide-react';
import { useExpense } from '../../context/ExpenseContext';

interface NotificationSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationSettingsModal: React.FC<NotificationSettingsModalProps> = ({ isOpen, onClose }) => {
  const {
    notificationSettings,
    updateNotificationSettings,
    requestBrowserPush,
    triggerTestNotification,
    playNotificationSound,
    language,
    currency,
  } = useExpense();

  const [testSuccess, setTestSuccess] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<string>(() => {
    return 'Notification' in window ? Notification.permission : 'unsupported';
  });

  if (!isOpen) return null;

  const handleToggleSound = () => {
    updateNotificationSettings({ enableSound: !notificationSettings.enableSound });
    if (!notificationSettings.enableSound) {
      playNotificationSound();
    }
  };

  const handleTogglePush = async () => {
    const granted = await requestBrowserPush();
    setPermissionStatus(granted ? 'granted' : 'denied');
  };

  const handleRunTest = () => {
    triggerTestNotification();
    setTestSuccess(true);
    setTimeout(() => setTestSuccess(false), 3000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div 
        className="bg-white rounded-2xl shadow-2xl border border-slate-100 w-full max-w-lg overflow-hidden flex flex-col max-h-[92vh] animate-in zoom-in-95 duration-200"
        role="dialog"
        aria-modal="true"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4.5 bg-gradient-to-r from-slate-800 to-slate-900 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-white/10 rounded-xl text-slate-200">
              <Settings className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-base sm:text-lg">
                {language === 'bn' ? 'রিমাইন্ডার ও নোটিফিকেশন সেটিংস' : 'Reminder & Notification Settings'}
              </h3>
              <p className="text-xs text-slate-300">
                {language === 'bn' ? 'সাউন্ড, পুশ ও সতর্কবার্তার নিয়মাবলী কাস্টমাইজ করুন' : 'Configure sounds, push alerts, and threshold rules'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-white/80 hover:text-white hover:bg-white/10 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Audio Chime Setting */}
          <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-emerald-100 text-emerald-700 rounded-lg shrink-0 mt-0.5">
                {notificationSettings.enableSound ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-slate-800">
                  {language === 'bn' ? 'নোটিফিকেশন অডিও সাউন্ড' : 'Notification Audio Sound'}
                </h4>
                <p className="text-[11px] text-slate-500">
                  {language === 'bn' ? 'নতুন অ্যালার্ট আসলে মধুর মিষ্টি বেল সাউন্ড বাজবে' : 'Plays a subtle pleasant chime on new alerts'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={playNotificationSound}
                className="px-2.5 py-1 text-[11px] font-semibold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors"
              >
                {language === 'bn' ? 'টেস্ট' : 'Test'}
              </button>
              <button
                type="button"
                onClick={handleToggleSound}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  notificationSettings.enableSound ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    notificationSettings.enableSound ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
          </div>

          {/* Web Push Notification Setting */}
          <div className="flex items-center justify-between p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
            <div className="flex items-start gap-3">
              <div className="p-2 bg-indigo-100 text-indigo-700 rounded-lg shrink-0 mt-0.5">
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <h4 className="text-xs sm:text-sm font-bold text-slate-800">
                  {language === 'bn' ? 'ব্রাউজার পুশ নোটিফিকেশন' : 'Browser Push Notifications'}
                </h4>
                <p className="text-[11px] text-slate-500">
                  {language === 'bn' ? 'অ্যাপ ব্যাকগ্রাউন্ডে থাকলেও ডিভাইসে তাৎক্ষণিক ব্যানার অ্যালার্ট' : 'Receive instant desktop/mobile push popups'}
                </p>
                <div className="mt-1 flex items-center gap-1.5">
                  <span className="text-[10px] font-medium text-slate-400">
                    {language === 'bn' ? 'পারমিশন স্ট্যাটাস:' : 'Permission:'}
                  </span>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                    permissionStatus === 'granted' 
                      ? 'bg-emerald-100 text-emerald-700' 
                      : permissionStatus === 'denied' 
                      ? 'bg-rose-100 text-rose-700' 
                      : 'bg-amber-100 text-amber-700'
                  }`}>
                    {permissionStatus === 'granted' 
                      ? (language === 'bn' ? 'অনুমোদিত (Enabled)' : 'Granted') 
                      : permissionStatus === 'denied' 
                      ? (language === 'bn' ? 'বাতিল (Blocked)' : 'Denied') 
                      : (language === 'bn' ? 'অনুরোধ প্রয়োজন' : 'Default')}
                  </span>
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleTogglePush}
              className={`px-3 py-1.5 text-xs font-semibold rounded-lg border transition-colors ${
                notificationSettings.enableBrowserPush
                  ? 'bg-emerald-600 text-white border-emerald-600'
                  : 'bg-white text-slate-700 border-slate-300 hover:bg-slate-100'
              }`}
            >
              {notificationSettings.enableBrowserPush 
                ? (language === 'bn' ? 'সক্রিয়' : 'Active') 
                : (language === 'bn' ? 'অনুমতি দিন' : 'Enable')}
            </button>
          </div>

          {/* Daily Logging Reminder */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-emerald-600" />
                <span className="text-xs sm:text-sm font-bold text-slate-800">
                  {language === 'bn' ? 'দৈনিক খরচ লেখার রিমাইন্ডার' : 'Daily Expense Log Reminder'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => updateNotificationSettings({ dailyReminderEnabled: !notificationSettings.dailyReminderEnabled })}
                className={`relative inline-flex h-6 w-11 shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none ${
                  notificationSettings.dailyReminderEnabled ? 'bg-emerald-600' : 'bg-slate-300'
                }`}
              >
                <span
                  className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${
                    notificationSettings.dailyReminderEnabled ? 'translate-x-5' : 'translate-x-0'
                  }`}
                />
              </button>
            </div>
            {notificationSettings.dailyReminderEnabled && (
              <div className="flex items-center justify-between pt-2 border-t border-slate-200">
                <span className="text-xs text-slate-600 font-medium">
                  {language === 'bn' ? 'প্রতিদিন সতর্ক করার সময়:' : 'Notification Time Daily:'}
                </span>
                <input
                  type="time"
                  value={notificationSettings.dailyReminderTime}
                  onChange={e => updateNotificationSettings({ dailyReminderTime: e.target.value })}
                  className="px-2.5 py-1 text-xs font-semibold bg-white border border-slate-300 rounded-lg focus:outline-none focus:ring-1 focus:ring-emerald-500"
                />
              </div>
            )}
          </div>

          {/* Threshold Configurations */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Budget Alert Threshold */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center gap-1.5 mb-1.5 text-amber-600">
                <AlertTriangle className="w-3.5 h-3.5" />
                <label className="text-xs font-bold text-slate-800">
                  {language === 'bn' ? 'বাজেট সতর্কতা সীমা' : 'Budget Warning Alert'}
                </label>
              </div>
              <p className="text-[11px] text-slate-500 mb-2">
                {language === 'bn' ? 'বাজেটের কত শতাংশ খরচ হলে সতর্ক করবে' : 'Warn when category spend reaches:'}
              </p>
              <select
                value={notificationSettings.budgetAlertThreshold}
                onChange={e => updateNotificationSettings({ budgetAlertThreshold: parseFloat(e.target.value) })}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="0.7">৭০% বাজেট খরচ হলে (70%)</option>
                <option value="0.8">৮০% বাজেট খরচ হলে (80% - Default)</option>
                <option value="0.9">৯০% বাজেট খরচ হলে (90%)</option>
              </select>
            </div>

            {/* Bill Due Days Notice */}
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="flex items-center gap-1.5 mb-1.5 text-indigo-600">
                <Calendar className="w-3.5 h-3.5" />
                <label className="text-xs font-bold text-slate-800">
                  {language === 'bn' ? 'বিল অগ্রিম নোটিশ' : 'Bill Advance Alert'}
                </label>
              </div>
              <p className="text-[11px] text-slate-500 mb-2">
                {language === 'bn' ? 'বিলের শেষ তারিখের কত দিন আগে জানাবে' : 'Notify before due date:'}
              </p>
              <select
                value={notificationSettings.billDueDaysBefore}
                onChange={e => updateNotificationSettings({ billDueDaysBefore: parseInt(e.target.value, 10) })}
                className="w-full px-2.5 py-1.5 bg-white border border-slate-300 rounded-lg text-xs font-semibold text-slate-700 focus:outline-none focus:ring-1 focus:ring-emerald-500"
              >
                <option value="1">১ দিন আগে (1 Day)</option>
                <option value="2">২ দিন আগে (2 Days)</option>
                <option value="3">৩ দিন আগে (3 Days - Default)</option>
                <option value="5">৫ দিন আগে (5 Days)</option>
                <option value="7">৭ দিন আগে (7 Days)</option>
              </select>
            </div>
          </div>

          {/* Low Balance Alert */}
          <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Wallet className="w-4 h-4 text-emerald-600" />
              <div>
                <span className="text-xs font-bold text-slate-800">
                  {language === 'bn' ? 'লো-ব্যালেন্স সতর্কতা লিমিট' : 'Low Balance Alert Minimum'}
                </span>
                <p className="text-[11px] text-slate-500">
                  {language === 'bn' ? 'ব্যাংক বা ওয়ালেটে এর নিচে নামলে অ্যালার্ট' : 'Trigger alert when cash/bank drops below:'}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1 w-28">
              <span className="text-xs font-bold text-slate-500">{currency.symbol}</span>
              <input
                type="number"
                min="0"
                step="100"
                value={notificationSettings.lowBalanceThreshold}
                onChange={e => updateNotificationSettings({ lowBalanceThreshold: parseFloat(e.target.value) || 0 })}
                className="w-full px-2 py-1 bg-white border border-slate-300 rounded-lg text-xs font-bold text-slate-800 text-right focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>
          </div>

          {/* Test System Trigger */}
          <div className="pt-2 border-t border-slate-100 flex items-center justify-between">
            <button
              type="button"
              onClick={handleRunTest}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-bold text-emerald-700 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-xl transition-all"
            >
              <Send className="w-3.5 h-3.5" />
              <span>{language === 'bn' ? 'টেস্ট নোটিফিকেশন পাঠান' : 'Send Test Notification'}</span>
            </button>
            {testSuccess && (
              <span className="flex items-center gap-1 text-xs font-bold text-emerald-600 animate-in fade-in">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>{language === 'bn' ? 'সাউন্ড ও অ্যালার্ট সম্পন্ন!' : 'Test alert triggered!'}</span>
              </span>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            onClick={onClose}
            className="px-5 py-2 text-xs font-bold text-white bg-slate-800 hover:bg-slate-900 rounded-xl transition-colors"
          >
            {language === 'bn' ? 'ঠিক আছে' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
