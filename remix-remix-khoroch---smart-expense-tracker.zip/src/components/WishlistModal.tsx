import React, { useState, useEffect } from 'react';
import { useExpense } from '../context/ExpenseContext';
import { useModalBehavior } from '../utils/useModalBehavior';
import { WishlistItem } from '../types';
import { X, Hourglass, Tag, Wallet, HelpCircle, ExternalLink, Sparkles } from 'lucide-react';

interface WishlistModalProps {
  isOpen: boolean;
  onClose: () => void;
  editItem?: WishlistItem | null;
}

export const WishlistModal: React.FC<WishlistModalProps> = ({
  isOpen,
  onClose,
  editItem,
}) => {
  useModalBehavior({ isOpen, onClose });

  const { categories, accounts, addWishlistItem, editWishlistItem, currency, language } = useExpense();

  const [title, setTitle] = useState('');
  const [estimatedPrice, setEstimatedPrice] = useState('');
  const [categoryId, setCategoryId] = useState('');
  const [accountId, setAccountId] = useState('');
  const [coolingPeriodDays, setCoolingPeriodDays] = useState<number>(30);
  const [customDays, setCustomDays] = useState<string>('');
  const [necessityScore, setNecessityScore] = useState<number>(2);
  const [priority, setPriority] = useState<'low' | 'medium' | 'high'>('medium');
  const [notes, setNotes] = useState('');
  const [productUrl, setProductUrl] = useState('');

  useEffect(() => {
    if (editItem) {
      setTitle(editItem.title);
      setEstimatedPrice(editItem.estimatedPrice.toString());
      setCategoryId(editItem.categoryId || '');
      setAccountId(editItem.accountId || '');
      setCoolingPeriodDays(editItem.coolingPeriodDays || 30);
      setNecessityScore(editItem.necessityScore || 3);
      setPriority(editItem.priority || 'medium');
      setNotes(editItem.notes || '');
      setProductUrl(editItem.productUrl || '');
    } else {
      setTitle('');
      setEstimatedPrice('');
      setCategoryId(categories[0]?.id || 'cat-shopping');
      setAccountId(accounts[0]?.id || '');
      setCoolingPeriodDays(30);
      setCustomDays('');
      setNecessityScore(2);
      setPriority('medium');
      setNotes('');
      setProductUrl('');
    }
  }, [editItem, isOpen, categories, accounts]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const price = parseFloat(estimatedPrice);
    if (!title.trim() || isNaN(price) || price <= 0) return;

    const days = customDays ? parseInt(customDays, 10) || 30 : coolingPeriodDays;

    if (editItem) {
      editWishlistItem({
        ...editItem,
        title: title.trim(),
        estimatedPrice: price,
        categoryId: categoryId || undefined,
        accountId: accountId || undefined,
        coolingPeriodDays: days,
        necessityScore,
        priority,
        notes: notes.trim() || undefined,
        productUrl: productUrl.trim() || undefined,
      });
    } else {
      addWishlistItem({
        title: title.trim(),
        estimatedPrice: price,
        categoryId: categoryId || undefined,
        accountId: accountId || undefined,
        coolingPeriodDays: days,
        necessityScore,
        priority,
        notes: notes.trim() || undefined,
        productUrl: productUrl.trim() || undefined,
        addedDate: new Date().toISOString().split('T')[0],
      });
    }

    onClose();
  };

  const coolingPresets = [
    { days: 7, labelBn: '৭ দিন', labelEn: '7 Days', descBn: 'ছোট খরচ', descEn: 'Small desire' },
    { days: 14, labelBn: '১৪ দিন', labelEn: '14 Days', descBn: 'মাঝারি', descEn: 'Moderate' },
    { days: 30, labelBn: '৩০ দিন', labelEn: '30 Days', descBn: 'গোল্ডেন রুল', descEn: 'Golden Rule' },
    { days: 60, labelBn: '৬০ দিন', labelEn: '60 Days', descBn: 'বড় বিনিয়োগ', descEn: 'Major purchase' },
  ];

  const getScoreDescription = (score: number) => {
    switch (score) {
      case 1:
        return language === 'bn' ? '১/৫ - পিউর ইমপালস বা ক্ষণিক শখ' : '1/5 - Pure Impulse / Fleeting Want';
      case 2:
        return language === 'bn' ? '২/৫ - দেখতে ভালো লেগেছে, না হলেও চলে' : '2/5 - Casual Want / Nice to have';
      case 3:
        return language === 'bn' ? '৩/৫ - কাজে আসবে কিন্তু জরুরি নয়' : '3/5 - Useful but non-urgent';
      case 4:
        return language === 'bn' ? '৪/৫ - যথেষ্ট দরকারি প্রয়োজনীয়তা' : '4/5 - Important Need';
      case 5:
        return language === 'bn' ? '৫/৫ - অপরিহার্য নিত্যপ্রয়োজন' : '5/5 - Vital Necessity';
      default:
        return '';
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto overscroll-contain animate-in fade-in duration-200"
      onClick={(e) => {
        if (e.target === e.currentTarget) {
          e.stopPropagation();
          onClose();
        }
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) e.stopPropagation();
      }}
    >
      <div
        className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[92dvh] sm:max-h-[85vh] animate-in slide-in-from-bottom-4 duration-200 border border-slate-200/80"
        onClick={e => e.stopPropagation()}
        onMouseDown={e => e.stopPropagation()}
      >
        {/* Mobile handle */}
        <div className="w-12 h-1.5 bg-slate-200 rounded-full mx-auto sm:hidden mt-2.5 -mb-1" />

        {/* Header */}
        <div className="flex items-center justify-between px-5 sm:px-6 py-4 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-indigo-50 border border-indigo-100 flex items-center justify-center text-indigo-700">
              <Hourglass className="w-5 h-5 stroke-[2]" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-bold text-slate-900 leading-tight">
                {editItem
                  ? (language === 'bn' ? 'উইশলিস্ট এডিট করুন' : 'Edit Wishlist Item')
                  : (language === 'bn' ? 'উইশলিস্টে ইচ্ছা যোগ করুন' : 'Add Desire to Wishlist')}
              </h2>
              <p className="text-xs text-slate-500">
                {language === 'bn' ? '৩০ দিনের বিরতি দিয়ে আবেগী অপচয় রোধ করুন' : 'Delay impulse buy to save money'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-5 sm:p-6 space-y-4 overflow-y-auto flex-1 pb-[calc(env(safe-area-inset-bottom,0px)+1.5rem)] sm:pb-6">
          
          {/* Item Name */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {language === 'bn' ? 'পণ্যের নাম বা ইচ্ছা *' : 'Item Name or Desire *'}
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder={language === 'bn' ? 'যেমন: মেকানিক্যাল কিবোর্ড, নাইকি শুজ...' : 'e.g. Mechanical Keyboard, Sony ANC Headphones...'}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
          </div>

          {/* Price & Priority Grid */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'আনুমানিক দাম *' : 'Estimated Price *'} ({currency.symbol})
              </label>
              <div className="relative">
                <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                  {currency.symbol}
                </span>
                <input
                  type="number"
                  step="any"
                  required
                  value={estimatedPrice}
                  onChange={e => setEstimatedPrice(e.target.value)}
                  placeholder="0.00"
                  className="w-full pl-8 pr-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold font-mono text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all tabular-nums"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {language === 'bn' ? 'অগ্রাধিকার' : 'Priority'}
              </label>
              <select
                value={priority}
                onChange={e => setPriority(e.target.value as any)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
              >
                <option value="low">{language === 'bn' ? '🟢 কম (Low)' : 'Low Priority'}</option>
                <option value="medium">{language === 'bn' ? '🟡 মাঝারি (Medium)' : 'Medium Priority'}</option>
                <option value="high">{language === 'bn' ? '🔴 উচ্চ (High)' : 'High Priority'}</option>
              </select>
            </div>
          </div>

          {/* Cooling Period Selector */}
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1">
                <Hourglass className="w-3.5 h-3.5 text-indigo-600" />
                {language === 'bn' ? 'কুলিং পিরিয়ড (কতদিন ভাববেন?)' : 'Cooling Delay Period'}
              </label>
              <span className="text-[11px] font-semibold text-indigo-700 font-mono">
                {customDays ? `${customDays} ${language === 'bn' ? 'দিন' : 'Days'}` : `${coolingPeriodDays} ${language === 'bn' ? 'দিন' : 'Days'}`}
              </span>
            </div>

            <div className="grid grid-cols-4 gap-1.5">
              {coolingPresets.map(preset => {
                const isSelected = !customDays && coolingPeriodDays === preset.days;
                return (
                  <button
                    type="button"
                    key={preset.days}
                    onClick={() => {
                      setCoolingPeriodDays(preset.days);
                      setCustomDays('');
                    }}
                    className={`py-2 px-1.5 rounded-xl border text-center transition-all ${
                      isSelected
                        ? 'border-indigo-600 bg-indigo-50/80 text-indigo-900 font-bold shadow-xs'
                        : 'border-slate-200 bg-slate-50 text-slate-600 hover:bg-slate-100 font-medium'
                    }`}
                  >
                    <div className="text-xs font-mono tabular-nums leading-tight">
                      {language === 'bn' ? preset.labelBn : preset.labelEn}
                    </div>
                    <div className="text-[9px] text-slate-400 mt-0.5 truncate">
                      {language === 'bn' ? preset.descBn : preset.descEn}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Necessity vs Impulse Score Slider */}
          <div className="p-3 bg-slate-50/80 border border-slate-200/80 rounded-xl space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
                <HelpCircle className="w-3.5 h-3.5 text-amber-500" />
                {language === 'bn' ? 'প্রয়োজনীয়তা স্কোর (Necessity vs Want)' : 'Necessity vs Want Score'}
              </label>
              <span className="text-xs font-bold font-mono px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-800">
                {necessityScore} / 5
              </span>
            </div>

            <input
              type="range"
              min={1}
              max={5}
              step={1}
              value={necessityScore}
              onChange={e => setNecessityScore(parseInt(e.target.value, 10))}
              className="w-full accent-emerald-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
            />

            <p className="text-[11px] font-medium text-slate-600">
              {getScoreDescription(necessityScore)}
            </p>
          </div>

          {/* Category & Wallet dropdowns */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                {language === 'bn' ? 'ক্যাটাগরি' : 'Category'}
              </label>
              <select
                value={categoryId}
                onChange={e => setCategoryId(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all truncate"
              >
                {categories.map(c => (
                  <option key={c.id} value={c.id}>
                    {language === 'bn' ? c.nameBn : c.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
                <Wallet className="w-3.5 h-3.5 text-slate-400" />
                {language === 'bn' ? 'পরিকল্পিত ওয়ালেট' : 'Planned Wallet'}
              </label>
              <select
                value={accountId}
                onChange={e => setAccountId(e.target.value)}
                className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-semibold text-slate-800 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all truncate"
              >
                <option value="">{language === 'bn' ? 'যেকোনো ওয়ালেট' : 'Any Account'}</option>
                {accounts.map(acc => (
                  <option key={acc.id} value={acc.id}>
                    {language === 'bn' ? acc.nameBn : acc.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Notes / Reason */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {language === 'bn' ? 'কেন কিনতে ইচ্ছা হলো? (নোট)' : 'Why do you want this? (Self-reflection note)'}
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder={language === 'bn' ? 'যেমন: ফেসবুক বিজ্ঞাপন দেখে ভালো লাগলো, তবে ৩০ দিন পর দেখবো সত্যিই কি প্রয়োজন?' : 'e.g. Saw on sale, waiting 30 days to see if still essential...'}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-normal text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all resize-none"
            />
          </div>

          {/* Product URL (optional) */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1 flex items-center gap-1">
              <ExternalLink className="w-3 h-3 text-slate-400" />
              {language === 'bn' ? 'প্রোডাক্ট লিংক (ঐচ্ছিক)' : 'Product URL (Optional)'}
            </label>
            <input
              type="url"
              value={productUrl}
              onChange={e => setProductUrl(e.target.value)}
              placeholder="https://..."
              className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-mono text-slate-800 placeholder-slate-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all"
            />
          </div>

          {/* Buttons */}
          <div className="pt-2 flex items-center justify-end gap-2.5">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2.5 rounded-xl border border-slate-200 text-xs sm:text-sm font-semibold text-slate-600 hover:bg-slate-100 transition-colors"
            >
              {language === 'bn' ? 'বাতিল' : 'Cancel'}
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white text-xs sm:text-sm font-bold shadow-xs hover:shadow-md transition-all active:scale-95 flex items-center gap-1.5"
            >
              <Sparkles className="w-4 h-4" />
              <span>{editItem ? (language === 'bn' ? 'আপডেট করুন' : 'Update Item') : (language === 'bn' ? 'ইচ্ছা সংরক্ষণ করুন' : 'Add to Wishlist')}</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
