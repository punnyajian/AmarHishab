// Authentication & Cloud Sync Types for Khoroch Expense Tracker

export interface AuthUser {
  id: string; // immutable unique ID
  username: string; // display username
  createdAt: string;
  lastLoginAt?: string;
  hasSecurityQuestions?: boolean;
}

export interface AppUser {
  uid: string;
  id: string;
  username: string;
  displayName: string;
  email?: string;
  photoURL?: string;
  createdAt?: string;
  lastLoginAt?: string;
  hasSecurityQuestions?: boolean;
}

export interface SecurityQuestionItem {
  id: string;
  question: string;
  answer: string;
}

export interface SecurityQuestionPrompt {
  id: string;
  question: string;
}

export interface AuthSession {
  token: string;
  user: AuthUser;
  expiresAt: string;
}

export type SyncStatus = 'synced' | 'syncing' | 'offline' | 'error' | 'idle';

export interface AuthState {
  user: AuthUser | null;
  token: string | null;
  isAuthenticated: boolean;
  syncStatus: SyncStatus;
  lastSyncedAt: string | null;
  syncError: string | null;
}

export const PRESET_SECURITY_QUESTIONS: string[] = [
  'What is the name of your first school?',
  'What city or town were you born in?',
  'What was your childhood nickname?',
  'What is your favorite local dish or food?',
  'What was the model or brand of your first phone or bike?',
  'What is the maiden name of your mother or grandmother?',
  'What was the name of your first childhood best friend?',
  'What is your favorite book, movie, or travel destination?'
];
