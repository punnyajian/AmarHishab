export type TransactionType = 'expense' | 'income' | 'transfer';

export type AccountType = 'cash' | 'bank' | 'mobile_wallet' | 'credit_card' | 'savings';

export interface Category {
  id: string;
  name: string;
  nameBn: string;
  type: 'expense' | 'income';
  icon: string;
  color: string;
  budgetLimit?: number;
}

export interface Account {
  id: string;
  name: string;
  nameBn: string;
  type: AccountType;
  balance: number;
  initialBalance: number;
  color: string;
  icon: string;
  accountNumberLast4?: string;
}

export interface Transaction {
  id: string;
  type: TransactionType;
  amount: number;
  categoryId: string;
  accountId: string;
  targetAccountId?: string; // For transfers
  date: string; // YYYY-MM-DD
  time?: string; // HH:mm
  note: string;
  tags?: string[];
  receiptUrl?: string;
  isRecurring?: boolean;
  recurringInterval?: 'daily' | 'weekly' | 'monthly' | 'yearly';
  cardId?: string; // Linked digital card
}

export type DigitalCardNetwork = 'visa' | 'mastercard' | 'amex' | 'nexus' | 'unionpay' | 'other';
export type DigitalCardType = 'debit' | 'credit' | 'prepaid' | 'loyalty';
export type DigitalCardTheme = 'obsidian' | 'emerald' | 'sapphire' | 'amethyst' | 'sunset' | 'platinum' | 'nexus';

export interface DigitalCard {
  id: string;
  cardholderName: string;
  cardNumberMasked: string; // e.g. "4123 •••• •••• 8892"
  last4: string; // "8892"
  network: DigitalCardNetwork;
  type: DigitalCardType;
  issuerName: string; // e.g. "City Bank Platinum", "BRAC Bank", "bKash Mastercard", "Dutch-Bangla Bank"
  expiryDate: string; // "08/29"
  cvv?: string; // "382"
  theme: DigitalCardTheme;
  isDefault?: boolean;
  isFrozen?: boolean;
  contactlessEnabled?: boolean;
  dailySpendLimit?: number; // e.g. 50000
  creditLimit?: number; // for credit card e.g. 150000
  currentSpentThisMonth?: number;
  linkedAccountId?: string; // if linked to an Account
  billingCycleDay?: number; // e.g. 15th of month
  loyaltyBarcode?: string; // for membership barcode
  addedAt: string;
}

export interface Budget {
  id: string;
  categoryId: string;
  monthlyLimit: number;
  month: string; // YYYY-MM
  alertThreshold?: number; // e.g. 0.8 for 80%
}

export interface SavingsGoal {
  id: string;
  name: string;
  nameBn: string;
  targetAmount: number;
  currentAmount: number;
  deadline: string; // YYYY-MM-DD
  icon: string;
  color: string;
  notes?: string;
}

export interface Debt {
  id: string;
  type: 'lent' | 'borrowed'; // lent = I gave to someone (I will get), borrowed = I took (I have to pay)
  personName: string;
  amount: number;
  paidAmount: number;
  dueDate: string; // YYYY-MM-DD
  phone?: string;
  note?: string;
  settled: boolean;
  createdAt: string;
}

export interface BillSplitMember {
  id: string;
  name: string;
  amount: number;
  paid: boolean;
}

export interface BillSplit {
  id: string;
  title: string;
  totalAmount: number;
  taxOrTipPercentage: number;
  paidBy: string; // name
  date: string;
  members: BillSplitMember[];
}

export type WishlistStatus = 'cooling' | 'ready' | 'purchased' | 'dropped';

export interface WishlistItem {
  id: string;
  title: string;
  estimatedPrice: number;
  categoryId?: string;
  accountId?: string;
  priority: 'low' | 'medium' | 'high';
  necessityScore: number; // 1 to 5 (1 = impulsive want, 5 = vital necessity)
  addedDate: string; // YYYY-MM-DD
  coolingPeriodDays: number; // default 30
  status: WishlistStatus;
  notes?: string;
  productUrl?: string;
  decisionDate?: string;
}

export type SafeToSpendMode = 'budget' | 'income' | 'custom';

export interface SafeToSpendConfig {
  mode: SafeToSpendMode;
  customMonthlyCap?: number;
}

export type BillingCycle = 'monthly' | 'yearly' | 'weekly' | 'quarterly';
export type BillCategory = 
  | 'utility' 
  | 'internet' 
  | 'mobile' 
  | 'streaming' 
  | 'rent' 
  | 'fitness' 
  | 'education' 
  | 'insurance' 
  | 'software' 
  | 'other';

export type BillStatus = 'active' | 'paused' | 'cancelled';

export interface BillPaymentRecord {
  id: string;
  paidDate: string; // YYYY-MM-DD
  amount: number;
  transactionId?: string;
  accountId?: string;
  note?: string;
}

export interface SubscriptionBill {
  id: string;
  name: string;
  nameBn?: string;
  category: BillCategory;
  amount: number;
  billingCycle: BillingCycle;
  dueDate: string; // Next due date (YYYY-MM-DD)
  lastPaidDate?: string; // YYYY-MM-DD
  status: BillStatus;
  autoPay?: boolean;
  accountId?: string; // linked bank/wallet account
  cardId?: string; // linked digital card
  reminderDaysBefore: number; // e.g. 3
  subscriberIdOrMeterNo?: string; // Consumer ID / Account ID / Meter No
  providerName?: string; // e.g. DESCO, Netflix, WASA, Titas
  notes?: string;
  color?: string;
  iconName?: string;
  createdAt: string;
  paymentHistory?: BillPaymentRecord[];
}

export interface Currency {
  code: string;
  symbol: string;
  name: string;
}

export type Language = 'bn' | 'en';

export type ActiveTab = 
  | 'dashboard'
  | 'calendar'
  | 'profile'
  | 'ai_control'
  | 'transactions'
  | 'bazar'
  | 'subscriptions'
  | 'investments'
  | 'trips'
  | 'tax_zakat'
  | 'challenges'
  | 'mess'
  | 'budgets'
  | 'analytics'
  | 'wallets'
  | 'goals'
  | 'debts'
  | 'payment_priority'
  | 'split'
  | 'wishlist'
  | 'settings';

export interface MessMember {
  id: string;
  name: string;
  phone?: string;
  roomNo?: string;
  initialDeposit?: number;
  individualExtraCost?: number; // e.g. private penalty, individual milk, etc.
  active: boolean;
  avatarColor?: string;
  joinedDate?: string;
}

export interface DailyMealEntry {
  id: string; // unique: `${date}_${memberId}`
  date: string; // YYYY-MM-DD
  memberId: string;
  breakfast: number; // e.g. 0 or 0.5 or 1
  lunch: number; // e.g. 0 or 1
  dinner: number; // e.g. 0 or 1
  guestMeals?: number; // extra guest meals booked by this member on this date
  totalMeals: number; // calculated: breakfast + lunch + dinner + guestMeals
  isOff?: boolean; // if meal was officially turned off
  note?: string;
}

export interface MessBazarEntry {
  id: string;
  date: string; // YYYY-MM-DD
  shopperMemberId: string;
  shopperName: string;
  amount: number;
  itemsDescription: string;
  paidFromFund: boolean; // true = mess cash was used; false = shopper paid from personal pocket (needs reimbursement or counts as deposit)
  note?: string;
}

export interface MessDepositEntry {
  id: string;
  date: string; // YYYY-MM-DD
  memberId: string;
  memberName: string;
  amount: number;
  paymentMethod: 'cash' | 'bkash' | 'nagad' | 'bank';
  note?: string;
}

export type MessFixedCostCategory = 
  | 'rent'
  | 'cook'
  | 'electricity'
  | 'gas'
  | 'wifi'
  | 'water'
  | 'waste'
  | 'other';

export interface MessFixedCostItem {
  id: string;
  title: string;
  amount: number;
  category: MessFixedCostCategory;
  note?: string;
}

export interface MessBazarScheduleItem {
  id: string;
  dayName: string; // e.g. "শনিবার / Saturday"
  memberId: string;
  memberName: string;
  notes?: string;
}

export interface MessConfig {
  name: string;
  managerName: string;
  managerPhone?: string;
  activeMonth: string; // YYYY-MM (e.g. "2026-10")
  breakfastWeight: number; // default 0.5
  lunchWeight: number; // default 1.0
  dinnerWeight: number; // default 1.0
}

export interface MessData {
  config: MessConfig;
  members: MessMember[];
  dailyMeals: DailyMealEntry[];
  bazarEntries: MessBazarEntry[];
  deposits: MessDepositEntry[];
  fixedCosts: MessFixedCostItem[];
  bazarSchedule: MessBazarScheduleItem[];
}

export type InvestmentType = 
  | 'dps' 
  | 'fdr' 
  | 'sanchayapatra' 
  | 'gold' 
  | 'stocks' 
  | 'mutual_fund' 
  | 'provident_fund' 
  | 'other';

export type SanchayapatraCategory = 
  | 'poribar' 
  | 'three_month' 
  | 'pensioner' 
  | 'bangladesh_5yr' 
  | 'post_office';

export type GoldPurity = '24k' | '22k' | '21k' | '18k' | 'traditional';

export interface GoldMarketRate {
  price24k: number; // per bhori
  price22k: number; // per bhori (BAJUS standard)
  price21k: number;
  price18k: number;
  priceTraditional: number;
  lastUpdated: string;
}

export interface InvestmentPaymentRecord {
  id: string;
  date: string;
  amount: number;
  type: 'installment' | 'profit_payout' | 'dividend' | 'topup';
  transactionId?: string;
  note?: string;
}

export interface InvestmentItem {
  id: string;
  type: InvestmentType;
  title: string;
  titleBn?: string;
  institutionName: string; // e.g. "City Bank", "BRAC Bank", "জাতীয় সঞ্চয় অধিদপ্তর", "BAJUS Gold"
  accountOrCertificateNo?: string;
  investedAmount: number;
  currentValue: number;
  startDate: string; // YYYY-MM-DD
  maturityDate?: string; // YYYY-MM-DD
  interestRate?: number; // annual percentage e.g. 9.5
  status: 'active' | 'matured' | 'closed';
  notes?: string;
  color?: string;

  // DPS specific fields
  monthlyInstallment?: number;
  totalInstallments?: number;
  paidInstallmentsCount?: number;
  nextInstallmentDueDate?: string;
  linkedAccountId?: string;

  // Sanchayapatra specific fields
  sanchayapatraType?: SanchayapatraCategory;
  profitPayoutFrequency?: 'monthly' | 'quarterly' | 'maturity';
  estimatedMonthlyProfit?: number;
  taxAtSourcePercent?: number; // usually 5% or 10%

  // Gold specific fields
  goldPurity?: GoldPurity;
  goldWeightBhori?: number;
  goldWeightGrams?: number;
  buyingPricePerBhori?: number;
  currentPricePerBhori?: number;
  jewelryType?: string; // e.g. "সোনার বার / কয়েন", "বিয়ের গহনা", "চেইন"
  hasZakatPayable?: boolean;

  // FDR / Compound specifics
  maturityAmount?: number;
  compoundingFrequency?: 'monthly' | 'quarterly' | 'yearly' | 'maturity';

  // Stocks / Mutual Fund
  unitsCount?: number;
  avgBuyPrice?: number;
  currentMarketPrice?: number;

  history?: InvestmentPaymentRecord[];
}

export type TripType = 'tour' | 'picnic' | 'wedding' | 'party' | 'official' | 'camping' | 'other';

export type TripExpenseCategory = 
  | 'transport' 
  | 'hotel' 
  | 'food' 
  | 'activity' 
  | 'shopping' 
  | 'logistics' 
  | 'emergency' 
  | 'other';

export interface TripMember {
  id: string;
  name: string;
  phone?: string;
  avatarColor?: string;
  depositAmount: number; // money given to trip pool
  isLead?: boolean;
}

export interface TripExpense {
  id: string;
  tripId: string;
  title: string;
  amount: number;
  category: TripExpenseCategory;
  paidByMemberId: string; // 'fund' or memberId
  date: string; // YYYY-MM-DD
  time?: string;
  note?: string;
  accountId?: string; // If synced to main wallet
  splitAmongMemberIds?: string[]; // If only a subset of members share this
}

export interface TripPackingItem {
  id: string;
  title: string;
  category?: 'documents' | 'clothes' | 'electronics' | 'medicine' | 'toiletries' | 'gear' | 'other';
  isPacked: boolean;
  assignedMemberName?: string;
}

export interface TripItineraryDay {
  id: string;
  dayNumber: number;
  date?: string;
  title: string;
  description: string;
  estimatedCost?: number;
}

export interface TripItem {
  id: string;
  title: string;
  titleBn?: string;
  destination: string;
  type: TripType;
  startDate: string; // YYYY-MM-DD
  endDate: string; // YYYY-MM-DD
  totalBudget: number;
  status: 'upcoming' | 'active' | 'completed';
  coverGradient?: string;
  icon?: string;
  members: TripMember[];
  expenses: TripExpense[];
  packingList: TripPackingItem[];
  itinerary: TripItineraryDay[];
  notes?: string;
  createdAt: string;
}

export type ChallengeCategory = 'daily' | 'weekly' | 'category_ban' | 'custom';

export interface SavingsChallenge {
  id: string;
  title: string;
  titleBn: string;
  description: string;
  descriptionBn: string;
  category: ChallengeCategory;
  targetAmount: number;
  currentAmount: number;
  durationDays: number;
  completedDays: number;
  checkInDates: string[]; // YYYY-MM-DD
  startDate: string;
  status: 'active' | 'completed' | 'abandoned';
  rewardXP: number;
  iconName?: string;
  color?: string;
  dailyTarget?: number;
  linkedAccountId?: string;
  linkedGoalId?: string;
}

export interface NoSpendRecord {
  date: string; // YYYY-MM-DD
  status: 'no_spend' | 'essential_only' | 'spend';
  note?: string;
}

export interface GamificationBadge {
  id: string;
  title: string;
  titleBn: string;
  desc: string;
  descBn: string;
  icon: string;
  unlocked: boolean;
  unlockedAt?: string;
  xpReward: number;
}

export type MoneyLeakSeverity = 'high' | 'medium' | 'low';

export interface MoneyLeakItem {
  id: string;
  title: string;
  titleBn: string;
  categoryName: string;
  categoryNameBn: string;
  icon: string;
  color: string;
  monthlyAmount: number;
  yearlyProjected: number;
  count: number;
  averageAmount: number;
  severity: MoneyLeakSeverity;
  recommendation: string;
  recommendationBn: string;
  savingPotential: number; // e.g. monthly potential savings if plugged
  matchedTransactionIds: string[];
}

export interface MoneyLeakAnalysis {
  totalMonthlyLeak: number;
  totalYearlyLeak: number;
  leakPercentageOfExpense: number;
  detectedLeaksCount: number;
  leaks: MoneyLeakItem[];
  topLeak: MoneyLeakItem | null;
  insightSummaryBn: string;
  insightSummaryEn: string;
}

// ========================
// SMART BAZAR CHECKLIST & PRICE TRENDS
// ========================
export type BazarCategory = 
  | 'vegetables' 
  | 'fish_meat' 
  | 'grocery' 
  | 'spices' 
  | 'dairy_eggs' 
  | 'fruits' 
  | 'other';

export interface BazarItem {
  id: string;
  name: string;
  nameBn: string;
  category: BazarCategory;
  quantity: string;
  estimatedPrice: number;
  actualPrice?: number;
  isPurchased: boolean;
  priority: 'essential' | 'optional';
  notes?: string;
  addedDate: string;
}

export interface PriceHistoryRecord {
  date: string;
  price: number;
  marketName?: string;
}

export interface BazarMarketCommodity {
  id: string;
  name: string;
  nameBn: string;
  category: BazarCategory;
  unit: string;
  unitBn: string;
  currentPrice: number;
  previousPrice: number;
  benchmarkTcbMin?: number;
  benchmarkTcbMax?: number;
  history: PriceHistoryRecord[];
  adviceBn?: string;
  adviceEn?: string;
  icon: string;
}

// ========================
// CENTRAL ADVANCED AI FINANCIAL CONTROL SYSTEM
// ========================
export interface AIHealthScore {
  overallScore: number; // 0 - 100
  status: 'excellent' | 'good' | 'moderate' | 'critical';
  savingsScore: number; // 0 - 100
  budgetDisciplineScore: number; // 0 - 100
  debtToIncomeScore: number; // 0 - 100
  liquidityScore: number; // 0 - 100
  billPunctualityScore: number; // 0 - 100
  summaryBn: string;
  summaryEn: string;
}

export type AIActionType = 
  | 'create_transaction' 
  | 'update_budget' 
  | 'create_savings_goal' 
  | 'remind_bill' 
  | 'adjust_category' 
  | 'optimize_debt' 
  | 'generate_report' 
  | 'plug_leak';

export interface AIActionProposal {
  id: string;
  type: AIActionType;
  title: string;
  titleBn: string;
  description: string;
  descriptionBn: string;
  currentValue?: string;
  newValue: string;
  reason: string;
  reasonBn: string;
  severity: 'info' | 'warning' | 'critical';
  requiresConfirmation: boolean;
  payload: any;
  createdAt: string;
  status: 'pending' | 'confirmed' | 'dismissed';
}

export interface AIActivityEvent {
  id: string;
  timestamp: string;
  type: 
    | 'categorization' 
    | 'anomaly_detected' 
    | 'budget_recommendation' 
    | 'report_generated' 
    | 'bill_reminder' 
    | 'action_executed' 
    | 'user_correction' 
    | 'plan_updated' 
    | 'analysis_run';
  title: string;
  titleBn: string;
  details: string;
  detailsBn: string;
  status: 'completed' | 'pending' | 'alert';
  module: string;
}

export interface AIMemoryPreferences {
  learnedMerchantCategories: Record<string, string>; // normalized merchant -> categoryId
  userCorrectionsCount: number;
  autoBudgetAssistance: boolean;
  anomalySensitivity: 'high' | 'medium' | 'low';
  preferredRiskTolerance: 'conservative' | 'balanced' | 'aggressive';
  lastAnalysisTimestamp: string;
}

export interface AIAnomalyRisk {
  id: string;
  type: 
    | 'duplicate_tx' 
    | 'spending_spike' 
    | 'approaching_limit' 
    | 'cash_shortage' 
    | 'card_utilization' 
    | 'overdue_bill' 
    | 'rapid_inflation';
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  severity: 'low' | 'medium' | 'high' | 'critical';
  suggestedAction: string;
  suggestedActionBn: string;
  detectedAt: string;
  relatedId?: string;
  actionProposal?: AIActionProposal;
}

export interface AINetWorthBreakdown {
  totalAssets: number;
  liquidCashAndBank: number;
  investmentsAndGold: number;
  receivablesLent: number;
  totalLiabilities: number;
  debtsBorrowed: number;
  creditCardDues: number;
  pendingBills: number;
  netWorth: number;
  changeFromLastMonth: number;
  insightBn: string;
  insightEn: string;
}

export interface AICashFlowForecast {
  currentLiquidBalance: number;
  projectedIncomeRemainder: number;
  projectedExpensesRemainder: number;
  upcomingObligations: number;
  estimatedEndOfMonthBalance: number;
  runwayDays: number;
  riskLevel: 'safe' | 'caution' | 'danger';
  adviceBn: string;
  adviceEn: string;
}

export interface AIChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: string;
  actionProposal?: AIActionProposal;
  dataInsight?: any;
}

export interface AIReportSummary {
  period: 'daily' | 'weekly' | 'monthly';
  generatedAt: string;
  headlineBn: string;
  headlineEn: string;
  keyMetrics: {
    income: number;
    expense: number;
    netSavings: number;
    savingsRate: number;
    topCategory: string;
    budgetStatus: string;
    netWorth: number;
  };
  highlightsBn: string[];
  highlightsEn: string[];
  actionableStepsBn: string[];
  actionableStepsEn: string[];
}

// ==================== ADVANCED REMINDER & NOTIFICATION SYSTEM ====================

export type NotificationType = 
  | 'bill_due'          // Subscriptions & utility bills
  | 'budget_warning'    // 80% or 100%+ budget overspend
  | 'debt_due'          // Debt owed to pay or collect
  | 'daily_log'         // Daily expense logging prompt
  | 'low_balance'       // Low liquid balance alert
  | 'custom_reminder'   // User-defined custom reminders
  | 'goal_milestone'    // Savings goal nearing completion or deadline
  | 'wishlist_cooling'; // Impulse item cooled down

export type NotificationSeverity = 'info' | 'warning' | 'danger' | 'success';

export interface AppNotification {
  id: string;
  type: NotificationType;
  title: string;
  titleBn: string;
  message: string;
  messageBn: string;
  severity: NotificationSeverity;
  date: string;
  dueDate?: string;
  isRead: boolean;
  isDismissed?: boolean;
  snoozedUntil?: string;
  amount?: number;
  entityId?: string;
  targetTab?: ActiveTab;
  actionType?: 'pay_bill' | 'view_budget' | 'collect_debt' | 'log_expense' | 'view_goal' | 'view_account';
  createdAt: string;
}

export interface CustomReminder {
  id: string;
  title: string;
  notes?: string;
  dueDate: string;
  dueTime?: string;
  amount?: number;
  category?: string;
  repeat?: 'none' | 'daily' | 'weekly' | 'monthly';
  completed: boolean;
  createdAt: string;
}

export interface NotificationSettings {
  enableSound: boolean;
  enableBrowserPush: boolean;
  dailyReminderEnabled: boolean;
  dailyReminderTime: string;
  budgetAlertThreshold: number;
  billDueDaysBefore: number;
  lowBalanceThreshold: number;
}

export * from './paymentPriority';
export * from './auth';
