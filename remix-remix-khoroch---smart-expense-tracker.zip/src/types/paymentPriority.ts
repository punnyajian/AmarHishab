// Types for Smart Payment Priority Engine — Advanced Edition

export type ObligationSourceType =
  | 'bill'
  | 'credit_card_min'
  | 'credit_card_full'
  | 'debt_borrowed'
  | 'emi_loan'
  | 'dps_installment'
  | 'insurance'
  | 'education'
  | 'medical'
  | 'custom';

export type ConsequenceSeverity =
  | 'disconnection'      // Utilities: power, water, gas cut off
  | 'legal_contractual'  // Lawsuit, default notice, breach of contract
  | 'credit_damage'      // Credit score hit, credit card late mark
  | 'service_interruption' // Internet suspended, subscription paused
  | 'financial_penalty'  // Pure late fee / penalty fine
  | 'mild'               // Friendly personal debt or soft subscription
  | 'uncertain';         // Missing information

export type PriorityLevel = 'critical' | 'high' | 'medium' | 'low';

export type PaymentStrategyType =
  | 'balanced_smart'      // Recommended: Protect essentials, pay imminent minimums, then high APR/penalties
  | 'deadline_first'      // Chronological: Imminent due dates first
  | 'highest_interest'    // Debt Avalanche: Maximize interest saved
  | 'highest_penalty'     // Maximize late fees saved
  | 'essential_first';    // Strict survival buffer first (food, housing, power)

export interface PaymentObligation {
  id: string; // Unique stable ID
  sourceType: ObligationSourceType;
  sourceId: string;
  name: string;
  nameBn?: string;
  category: string; // 'utility' | 'rent' | 'telecom' | 'credit_card' | 'loan' | 'education' | 'medical' | 'entertainment' | 'custom'
  categoryBn?: string;
  amount: number; // In obligation currency
  currencyCode: string; // 'BDT', 'USD', etc.
  amountConverted: number; // Converted into active user currency
  dueDate: string; // YYYY-MM-DD
  daysRemaining: number; // Negative if overdue, 0 if due today
  isOverdue: boolean;
  overdueDays: number;
  isPartiallyPaid: boolean;
  paidAmount: number;
  remainingAmount: number; // In active user currency
  minimumAmountDue: number; // Mandatory minimum if applicable
  lateFeeAmount: number | null; // Known late penalty fee
  lateFeePercentage: number | null; // Known late penalty %
  hasLateFee: boolean;
  interestRateAPR: number | null; // Annual interest percentage
  consequenceSeverity: ConsequenceSeverity;
  consequenceDesc: string;
  consequenceDescBn: string;
  isEssential: boolean; // Food, utilities, rent, healthcare, medicine
  isMandatoryMinimum: boolean;
  notes?: string;
  linkedAccountId?: string;
  linkedCardId?: string;
  recipientPhone?: string;
  subscriberId?: string;
  providerName?: string;
  missingInfoFlags: string[]; // ['unknown_late_fee', 'unknown_interest_rate']
  status: 'unpaid' | 'paid' | 'snoozed' | 'rescheduled';
  createdAt: string;
}

export interface PriorityScoreBreakdown {
  score: number; // 0 to 100
  level: PriorityLevel;
  urgencyScore: number;
  overdueScore: number;
  penaltyScore: number;
  interestScore: number;
  consequenceScore: number;
  essentialScore: number;
  cashBufferScore: number;
  hardOverrideApplied: boolean;
  overrideReason: string | null;
  overrideReasonBn: string | null;
  explanationSummary: string;
  explanationSummaryBn: string;
  recommendedAction: string;
  recommendedActionBn: string;
  assumptions: string[];
}

export interface RankedObligation {
  obligation: PaymentObligation;
  scoreBreakdown: PriorityScoreBreakdown;
  rank: number;
  coverageStatus: 'fully_covered' | 'minimum_covered_only' | 'shortfall_uncovered';
  allocatedAmount: number;
  remainingBalanceAfter: number;
  shortfallForThisItem: number;
}

export interface ScoringWeights {
  urgency: number;     // Default 25
  overdue: number;     // Default 15
  penalty: number;     // Default 20
  interest: number;    // Default 15
  consequence: number; // Default 15
  essential: number;   // Default 10
}

export interface PriorityThresholds {
  critical: number; // Default 85
  high: number;     // Default 65
  medium: number;   // Default 40
  // low: 0 - 39
}

export interface PaymentEngineConfig {
  weights: ScoringWeights;
  thresholds: PriorityThresholds;
  essentialLivingReserve: number; // Cash reserve to safeguard food/medicine before non-essential debt
  advanceReminderDays: number; // Alert days before deadline (default: 3)
  creditCardMinRatePercent: number; // Default 5% if unspecified
  creditCardMinMinimumBDT: number;  // Default 500 BDT
}

export interface CashFlowAnalysis {
  availableBalance: number;
  dueIn24Hours: number;
  dueIn3Days: number;
  dueIn7Days: number;
  totalEssentialDue: number;
  totalAllUpcomingDue: number;
  projectedRemaining: number;
  shortfallAmount: number;
  hasShortfall: boolean;
  shortfallRiskLevel: 'safe' | 'tight' | 'critical_shortfall';
  activeCurrencyCode: string;
  activeCurrencySymbol: string;
}

export interface WhatIfSimulationInput {
  availableFundsOverride: number | null; // Custom cash amount to test
  salaryDelayDays: number;               // E.g. +3 days
  payCreditCardFirst: boolean;           // Prioritize credit card full balance
  payOnlyMinimums: boolean;              // Pay only mandatory minimums across all debts
  delayNonEssentialsDays: number;        // Push back entertainment/streaming
  extraDebtPaymentAmount: number;        // E.g. +৳2,000 toward top debt
  targetDebtId?: string;                 // Target debt for extra payment
  excludeObligationIds?: string[];       // Obligations to toggle off in simulator
}

export interface WhatIfSimulationResult {
  simulatedAvailableBalance: number;
  simulatedDueIn7Days: number;
  simulatedRemainingBalance: number;
  simulatedShortfall: number;
  simulatedPenaltiesAvoided: number;
  simulatedInterestSaved: number;
  simulatedEssentialCoveragePercent: number;
  fullyPaidCount: number;
  partiallyPaidCount: number;
  unpaidCount: number;
  impactSummary: string;
  impactSummaryBn: string;
  rankedItems: RankedObligation[];
}

export interface CustomObligationInput {
  name: string;
  nameBn?: string;
  category: string;
  amount: number;
  currencyCode?: string;
  dueDate: string;
  minimumAmountDue?: number;
  lateFeeAmount?: number;
  interestRateAPR?: number;
  consequenceSeverity: ConsequenceSeverity;
  isEssential: boolean;
  notes?: string;
  recipientPhone?: string;
}
